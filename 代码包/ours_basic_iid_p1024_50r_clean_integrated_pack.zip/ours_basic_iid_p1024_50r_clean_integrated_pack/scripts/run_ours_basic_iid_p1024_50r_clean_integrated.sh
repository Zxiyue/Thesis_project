#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}

CFG="configs/ours_basic_mnist_iid_50r_lr020_p1024_clean_timing.yaml"
NAME="ours_basic_mnist_iid_50r_lr020_p1024_clean_timing"
OUT="outputs/${NAME}"
ROUNDS=50
LOG="/root/ours_basic_mnist_iid_p1024_50r_clean_timing.log"

# Mirror stdout/stderr to log even when user forgets tee.
exec > >(tee -a "$LOG") 2>&1

echo "================================================================"
echo "[RUN] Ours-basic MNIST-IID 50r Paillier-1024 clean integrated timing"
echo "[NOTE] Un-packed Ours-basic baseline; used to compare against Ours-packed."
echo "[CFG] ${CFG}"
echo "[OUTDIR] ${OUT}"
echo "================================================================"

echo "[STEP] reset to Ours-basic core + integrated CS timing"
python3 /root/ours_basic_iid_p1024_50r_clean_integrated_pack/patch/reset_to_ours_basic_with_integrated_cs_timing.py || exit 1

echo "[STEP] generate config"
python3 /root/ours_basic_iid_p1024_50r_clean_integrated_pack/config_tools/make_ours_basic_iid_p1024_50r_config.py || exit 1

echo "[STEP] verify config"
python3 - <<'PY'
import yaml
from pathlib import Path
p = Path('/root/fpa5/configs/ours_basic_mnist_iid_50r_lr020_p1024_clean_timing.yaml')
cfg = yaml.safe_load(p.read_text())
assert cfg['output_dir'] == 'outputs/ours_basic_mnist_iid_50r_lr020_p1024_clean_timing'
assert cfg['federated']['rounds'] == 50
assert abs(float(cfg['federated']['local_lr']) - 0.2) < 1e-12
assert cfg['crypto']['paillier_bits'] == 1024
assert cfg['crypto'].get('packing',{}).get('enabled') is False
print('[OK] config checked')
PY

echo "[STEP] clean old entities"
python3 scripts/stop_all_entities.py --config "${CFG}" || true
pkill -f run_kgc_server.py || true
pkill -f run_cs_server.py || true
pkill -f run_client_server.py || true
pkill -f start_experiment.py || true
sleep 3

echo "[STEP] remove old output"
rm -rf "${OUT}"

echo "[STEP] check Hardhat"
curl -s -X POST http://127.0.0.1:8545 \
  -H "Content-Type: application/json" \
  --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' | grep -q '"result"' \
  || { echo "[ERROR] Hardhat not reachable at 127.0.0.1:8545"; exit 1; }

echo "[STEP] deploy audit board"
npx hardhat run scripts/deploy.js --network localhost || exit 1

echo "[STEP] start KGC/CS/clients"
python3 scripts/start_all_entities.py --config "${CFG}" --clients 5 || exit 1

echo "[STEP] start experiment"
python3 scripts/start_experiment.py --config "${CFG}" || echo "[WARN] start_experiment returned non-zero; continue polling"

done_flag=0
for i in $(seq 1 3600); do
  echo
  echo "---- $(date) ${NAME} status ${i}/3600 ----"
  tail -n 8 "${OUT}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
  cat "${OUT}/verify_result.csv" 2>/dev/null || echo "verify not ready"

  if [ -f "${OUT}/verify_result.csv" ] && grep -q "True,${ROUNDS}" "${OUT}/verify_result.csv"; then
    done_flag=1
    echo "[OK] ${NAME} accepted=True rounds=${ROUNDS}"
    break
  fi

  sleep 60
done

echo "[STEP] collect results"
python3 scripts/collect_results.py --config "${CFG}" || true

echo "[STEP] stop entities"
python3 scripts/stop_all_entities.py --config "${CFG}" || true

if [ "${done_flag}" -ne 1 ]; then
  echo "[ERROR] ${NAME} did not finish correctly"
  exit 1
fi

echo "[STEP] summarize CS timing"
python3 /root/ours_basic_iid_p1024_50r_clean_integrated_pack/scripts/summarize_cs_timing.py "${OUT}" \
  | tee /root/cs_timing_summary_ours_basic_mnist_iid_p1024_clean.csv

echo "[STEP] zip results"
cd /root/fpa5
zip -qr /root/ours_basic_mnist_iid_50r_p1024_clean_integrated_timing_results.zip \
  "${OUT}" \
  /root/cs_timing_summary_ours_basic_mnist_iid_p1024_clean.csv \
  "$LOG"

ls -lh /root/ours_basic_mnist_iid_50r_p1024_clean_integrated_timing_results.zip
echo "[DONE]"
