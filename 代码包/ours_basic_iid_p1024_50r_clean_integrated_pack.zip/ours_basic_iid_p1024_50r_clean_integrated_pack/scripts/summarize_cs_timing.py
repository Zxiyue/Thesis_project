from __future__ import annotations
import csv
import sys
from collections import defaultdict
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit('Usage: summarize_cs_timing.py <output_dir>')
out = Path(sys.argv[1])
runtime = out / 'runtime_cost.csv'
if not runtime.exists():
    raise SystemExit(f'{runtime} not found')
fields = ['cs_decrypt_combine','cs_unpack_vector','cs_decode_aggregate','cs_model_update']
by_stage = defaultdict(list)
by_round = defaultdict(dict)
with runtime.open(newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        stage = row.get('stage') or row.get('name') or row.get('metric')
        if stage not in fields:
            continue
        sec = float(row.get('seconds') or row.get('time') or row.get('value') or 0.0)
        r = int(row.get('round') or row.get('r') or 0)
        by_stage[stage].append(sec)
        by_round[r][stage] = sec

def stats(vals):
    if not vals:
        return (0.0,0.0,0.0,0.0,0.0)
    vals = sorted(vals)
    total = sum(vals)
    avg = total / len(vals)
    mid = len(vals)//2
    med = vals[mid] if len(vals)%2 else (vals[mid-1]+vals[mid])/2
    return total, avg, med, vals[0], vals[-1]

summary_path = out / 'cs_timing_summary.csv'
with summary_path.open('w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['stage','count','total_seconds','avg_seconds','median_seconds','min_seconds','max_seconds'])
    for stage in fields:
        vals = by_stage.get(stage, [])
        total, avg, med, mn, mx = stats(vals)
        w.writerow([stage, len(vals), f'{total:.6f}', f'{avg:.6f}', f'{med:.6f}', f'{mn:.6f}', f'{mx:.6f}'])

round_path = out / 'cs_timing_by_round.csv'
with round_path.open('w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['round'] + fields)
    for r in sorted(by_round):
        w.writerow([r] + [f'{by_round[r].get(stage, 0.0):.6f}' for stage in fields])

print('stage,count,total_seconds,avg_seconds,median_seconds,min_seconds,max_seconds')
for stage in fields:
    vals = by_stage.get(stage, [])
    total, avg, med, mn, mx = stats(vals)
    print(f'{stage},{len(vals)},{total:.6f},{avg:.6f},{med:.6f},{mn:.6f},{mx:.6f}')
print(f'[OK] wrote {summary_path}')
print(f'[OK] wrote {round_path}')
