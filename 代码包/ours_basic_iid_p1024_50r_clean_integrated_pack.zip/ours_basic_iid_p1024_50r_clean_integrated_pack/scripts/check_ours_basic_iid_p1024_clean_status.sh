#!/usr/bin/env bash
set -uo pipefail
cd /root/fpa5
OUT="outputs/ours_basic_mnist_iid_50r_lr020_p1024_clean_timing"
echo "[STATUS] $OUT"
if [ -d "$OUT" ]; then
  echo "--- metrics tail ---"
  tail -n 12 "$OUT/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
  echo "--- verify ---"
  cat "$OUT/verify_result.csv" 2>/dev/null || echo "verify not ready"
  echo "--- runtime cs timing tail ---"
  grep -E 'cs_decrypt_combine|cs_unpack_vector|cs_decode_aggregate|cs_model_update' "$OUT/runtime_cost.csv" 2>/dev/null | tail -n 16 || true
else
  echo "output not created"
fi
