from __future__ import annotations

from pathlib import Path
import yaml

ROOT = Path('/root/fpa5')
OUT = ROOT / 'configs/ours_basic_mnist_iid_50r_lr020_p1024_clean_timing.yaml'
BASE_CANDIDATES = [
    ROOT / 'configs/mnist_iid_50r_main.yaml',
    ROOT / 'configs/mnist_iid_50r_lr020_main.yaml',
    ROOT / 'configs/ours_basic_mnist_iid_50r_lr020_p1024_final.yaml',
]

base = next((p for p in BASE_CANDIDATES if p.exists()), None)
if base is None:
    raise SystemExit('No base MNIST-IID config found')

cfg = yaml.safe_load(base.read_text(encoding='utf-8'))
cfg['output_dir'] = 'outputs/ours_basic_mnist_iid_50r_lr020_p1024_clean_timing'
cfg.setdefault('data', {})
cfg['data']['name'] = cfg.get('data', {}).get('name', 'mnist')
cfg.setdefault('data_split', {})
# Keep existing split if present; mnist_iid_50r_main.yaml already defines it.

cfg.setdefault('federated', {})
cfg['federated']['rounds'] = 50
cfg['federated']['local_lr'] = 0.2
cfg['federated']['parallel_clients'] = True
cfg['federated']['num_clients'] = int(cfg['federated'].get('num_clients', 5))
cfg['federated']['threshold'] = int(cfg['federated'].get('threshold', 3))
# Preserve dropout schedule from base if present. If absent, use the main schedule.
cfg['federated'].setdefault('dropout', {10: [2], 25: [4]})

cfg.setdefault('crypto', {})
cfg['crypto']['paillier_bits'] = 1024
cfg['crypto']['pedersen_prime_bits'] = int(cfg['crypto'].get('pedersen_prime_bits', 521))
cfg['crypto'].setdefault('pedersen_window', 0)
cfg['crypto']['packing'] = {'enabled': False, 'slot_bits': None, 'pack_size': None}

cfg.setdefault('blockchain', {})
cfg['blockchain']['enabled'] = True
cfg.setdefault('runtime', {})
cfg['runtime']['max_client_workers'] = int(cfg['runtime'].get('max_client_workers', 5))
cfg['runtime']['timeout_seconds'] = int(cfg['runtime'].get('timeout_seconds', 3600))

OUT.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding='utf-8')
print('[OK] wrote', OUT)
print('  base:', base)
print('  output_dir:', cfg['output_dir'])
print('  rounds:', cfg['federated']['rounds'])
print('  local_lr:', cfg['federated']['local_lr'])
print('  paillier_bits:', cfg['crypto']['paillier_bits'])
print('  pedersen_prime_bits:', cfg['crypto']['pedersen_prime_bits'])
print('  packing.enabled:', cfg['crypto']['packing']['enabled'])
