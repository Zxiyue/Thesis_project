from __future__ import annotations

import re
import shutil
from pathlib import Path

ROOT = Path('/root/fpa5')
PACK_ROOT = Path(__file__).resolve().parents[1]

CORE_FILES = [
    ('fl_audit/protocol/entities.py', 'pristine_base/fl_audit/protocol/entities.py'),
    ('scripts/run_kgc_server.py', 'pristine_base/scripts/run_kgc_server.py'),
    ('scripts/run_cs_server.py', 'pristine_base/scripts/run_cs_server.py'),
]


def backup(path: Path, suffix: str) -> None:
    bak = path.with_suffix(path.suffix + suffix)
    if path.exists() and not bak.exists():
        shutil.copy2(path, bak)


def restore_ours_basic_core() -> None:
    if not ROOT.exists():
        raise SystemExit('/root/fpa5 does not exist')
    for rel, pristine_rel in CORE_FILES:
        dst = ROOT / rel
        backup(dst, '.before_clean_integrated')
        before_packed = dst.with_suffix(dst.suffix + '.before_ours_packed')
        if before_packed.exists():
            src = before_packed
            reason = 'from .before_ours_packed backup'
        else:
            src = PACK_ROOT / pristine_rel
            reason = 'from packaged pristine Ours-basic file'
        if not src.exists():
            raise RuntimeError(f'missing restore source for {rel}: {src}')
        shutil.copy2(src, dst)
        print(f'[OK] restored {rel} {reason}')


def patch_entities_timing() -> None:
    path = ROOT / 'fl_audit/protocol/entities.py'
    s = path.read_text(encoding='utf-8')
    backup(path, '.before_integrated_cs_timing')

    new_func = '''    def recover_lambda_and_decrypt(self, share_msgs: List[Dict[str, Any]], client_pubkeys: Dict[int, str], field_prime: int, threshold: int, paillier_keypair, cagg: List[int], r: int, alpha: str, timer=None):
        t0 = time.perf_counter()
        shares = []
        for sm in share_msgs:
            msg = sm["ShareMsg"]
            cid = int(msg["j"])
            if verify_obj(client_pubkeys[cid], sm["sigShare"], msg):
                shares.append((cid, int(msg["share"])))
            if len(shares) >= threshold:
                break
        if len(shares) < threshold:
            raise RuntimeError("not enough valid shares")
        lam = reconstruct(shares, field_prime)
        # The CS only needs the public key and threshold-recovered lambda.
        # If a full keypair is passed by the legacy single-process runner, keep
        # compatibility. In distributed mode, mu is recomputed from public data
        # and recovered lambda, so KGC does not disclose the Paillier private key.
        pub = getattr(paillier_keypair, "public", paillier_keypair)
        if hasattr(paillier_keypair, "private"):
            mu = paillier_keypair.private.mu
        else:
            mu = pow(paillier.L(pow(pub.g, lam, pub.n2), pub.n), -1, pub.n)
        priv = paillier.PaillierPrivateKey(lam=lam, mu=mu)
        plain = [paillier.decrypt(pub, priv, int(c)) for c in cagg]
        if timer is not None:
            timer.add(
                r,
                "cs_decrypt_combine",
                time.perf_counter() - t0,
                detail="verify decryption shares, reconstruct threshold secret, and decrypt aggregate Paillier ciphertexts",
                cid="CS",
            )

        t1 = time.perf_counter()
        xagg = np.array(plain, dtype=np.int64)
        if timer is not None:
            timer.add(
                r,
                "cs_unpack_vector",
                time.perf_counter() - t1,
                detail=f"coordinate-wise Ours-basic mode: convert {len(plain)} plaintext coordinates into aggregate vector",
                cid="CS",
            )
        return xagg, shares
'''
    pattern = (r'    def recover_lambda_and_decrypt\(self, share_msgs: List\[Dict\[str, Any\]\], client_pubkeys: Dict\[int, str\], field_prime: int, threshold: int, paillier_keypair, cagg: List\[int\], r: int, alpha: str(?:, timer=None)?\):\n'
               r'.*?        return xagg, shares\n')
    s2, n = re.subn(pattern, new_func, s, flags=re.S)
    if n != 1:
        raise RuntimeError(f'failed to patch recover_lambda_and_decrypt in {path}; replacements={n}')
    path.write_text(s2, encoding='utf-8')
    print('[OK] integrated CS timing in entities.py')


def patch_run_cs_server_timing() -> None:
    path = ROOT / 'scripts/run_cs_server.py'
    s = path.read_text(encoding='utf-8')
    backup(path, '.before_integrated_cs_timing')

    # Add timer=self.timer to recover call if absent.
    if 'timer=self.timer' not in s[s.find('recover_lambda_and_decrypt'):s.find('recover_lambda_and_decrypt')+1200]:
        old = '''                cagg,
                r,
                alpha,
            )
'''
        new = '''                cagg,
                r,
                alpha,
                timer=self.timer,
            )
'''
        if old not in s:
            raise RuntimeError('failed to locate recover_lambda_and_decrypt call in run_cs_server.py')
        s = s.replace(old, new, 1)

    if 'cs_decode_aggregate' not in s or 'cs_model_update' not in s:
        old_update = '''            update = torch.tensor(dequantize(xagg, int(self.cfg["encoding"]["scale"])), dtype=torch.float64)
            W_next_vec = W_r_vec + float(self.cfg["federated"].get("server_lr", 1.0)) * update
            set_vector(self.model, W_next_vec)
            model_hash_next = model_hash(self.model)
'''
        new_update = '''            t_decode = time.perf_counter()
            update = torch.tensor(dequantize(xagg, int(self.cfg["encoding"]["scale"])), dtype=torch.float64)
            self.timer.add(
                r,
                "cs_decode_aggregate",
                time.perf_counter() - t_decode,
                detail="fixed-point dequantization of aggregate update and tensor conversion",
                cid="CS",
            )

            t_update = time.perf_counter()
            W_next_vec = W_r_vec + float(self.cfg["federated"].get("server_lr", 1.0)) * update
            set_vector(self.model, W_next_vec)
            model_hash_next = model_hash(self.model)
            self.timer.add(
                r,
                "cs_model_update",
                time.perf_counter() - t_update,
                detail="apply aggregate update, set model vector, and compute next model hash",
                cid="CS",
            )
'''
        if old_update not in s:
            raise RuntimeError('failed to locate decode/model update block in run_cs_server.py')
        s = s.replace(old_update, new_update, 1)

    path.write_text(s, encoding='utf-8')
    print('[OK] integrated CS timing in run_cs_server.py')


def check_clean_state() -> None:
    entities = (ROOT / 'fl_audit/protocol/entities.py').read_text(encoding='utf-8')
    kgc = (ROOT / 'scripts/run_kgc_server.py').read_text(encoding='utf-8')
    cs = (ROOT / 'scripts/run_cs_server.py').read_text(encoding='utf-8')
    checks = [
        ('no packed slot_bits compensation', 'slot_bits = int(packing_cfg' not in entities),
        ('Ours-basic make_compensation signature', 'def make_compensation(self, r: int, D: List[int], paillier_pub, ped_params):' in entities),
        ('KGC calls basic make_compensation', 'make_compensation(r, D_r, self.pkey.public, self.ped_params)' in kgc and 'cfg=self.cfg' not in kgc[kgc.find('make_compensation'):kgc.find('make_compensation')+200]),
        ('cs_decrypt_combine', 'cs_decrypt_combine' in entities),
        ('cs_unpack_vector', 'cs_unpack_vector' in entities),
        ('run_cs_server passes timer', 'timer=self.timer' in cs[cs.find('recover_lambda_and_decrypt'):cs.find('recover_lambda_and_decrypt')+1200]),
        ('cs_decode_aggregate', 'cs_decode_aggregate' in cs),
        ('cs_model_update', 'cs_model_update' in cs),
    ]
    ok = True
    for name, passed in checks:
        print(f'{name:40s}: {"OK" if passed else "FAIL"}')
        ok = ok and passed
    print('OURS_BASIC_CLEAN_TIMING_READY =', ok)
    if not ok:
        raise SystemExit(1)


def main() -> None:
    restore_ours_basic_core()
    patch_entities_timing()
    patch_run_cs_server_timing()
    check_clean_state()


if __name__ == '__main__':
    main()
