#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

./run_full_priverifl_a_baselines.sh
./run_full_rtpfl_baselines.sh

cd /root
zip -qr /root/full_paper_baseline_all_results.zip \
  full_priverifl_a_baseline_results.zip \
  full_rtpfl_baseline_results.zip

echo "Saved /root/full_paper_baseline_all_results.zip"
