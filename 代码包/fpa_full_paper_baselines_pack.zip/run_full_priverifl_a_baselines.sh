#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

python3 scripts/run_paper_baseline.py --config configs/baseline_full_priverifl_a_mnist_iid_50r.yaml
python3 scripts/run_paper_baseline.py --config configs/baseline_full_priverifl_a_mnist_noniid_50r.yaml

cd /root/fpa5
zip -qr /root/full_priverifl_a_baseline_results.zip \
  outputs/baseline_full_priverifl_a_mnist_iid_50r \
  outputs/baseline_full_priverifl_a_mnist_noniid_50r

echo "Saved /root/full_priverifl_a_baseline_results.zip"
