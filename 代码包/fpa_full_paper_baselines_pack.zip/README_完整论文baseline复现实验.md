# 完整论文 baseline 复现实验补丁：PriVeriFL-A-full 与 RTP-FL-full

本补丁用于覆盖早期的 `PriVeriFL-A-style` / `RTP-FL-style` 工程 baseline，新增两个更接近论文机制的完整复现 baseline：

1. `PriVeriFL-A-full`
   - 真实 MNIST/Fashion-MNIST 数据训练；
   - 模型更新按 bit 进行分段：`x = high * 2^low_bits + low`；
   - low-bit segment 使用 BatchCrypt-style packed Paillier 聚合；
   - high segment 使用 AES-GCM 对称加密保护传输，然后由服务器解密后聚合；
   - 使用乘法同态哈希 `H(x)` 验证 `H(sum_i x_i)=prod_i H(x_i)`；
   - 使用 ECDSA 签名上传收据。

2. `RTP-FL-full`
   - 真实 MNIST 数据训练；
   - Paillier 加密聚合；
   - `(N,k,d)` repairable Shamir-style 私钥段分发；
   - 任意 `k` 个私钥段可恢复 Paillier 私钥参数 `lambda`；
   - 掉线客户端私钥段可由 `d` 个正常客户端发送修复符号完成修复；
   - 上传、修复符号、份额贡献均记录签名/验证与通信开销。

> 注意：这两个 full baseline 仍然是论文机制的工程复现，不包含论文作者未公开的代码级优化。结果表中建议命名为 `PriVeriFL-A-full reproduction` 和 `RTP-FL-full reproduction`，不要再使用 `style`。

---

## 1. 安装

上传压缩包到服务器：

```bash
/root/fpa_full_paper_baselines_pack.zip
```

解压到项目根目录：

```bash
cd /root/fpa5
unzip -o /root/fpa_full_paper_baselines_pack.zip -d /root/fpa5
chmod +x run_full_priverifl_a_baselines.sh
chmod +x run_full_rtpfl_baselines.sh
chmod +x run_all_full_paper_baselines.sh
```

确认环境：

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
python3 - <<'PY'
from fl_audit.baselines.priverifl_a_full import run_priverifl_a_full
from fl_audit.baselines.rtpfl_full import run_rtpfl_full
print('full paper baselines import OK')
PY
```

---

## 2. 检查配置

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

python3 scripts/check_dataset_loader.py --configs \
  configs/baseline_full_priverifl_a_mnist_iid_50r.yaml \
  configs/baseline_full_priverifl_a_mnist_noniid_50r.yaml \
  configs/baseline_full_rtpfl_mnist_iid_50r.yaml \
  configs/baseline_full_rtpfl_mnist_iid_dropout_50r.yaml
```

应看到 MNIST 数据集正确加载。

---

## 3. 建议先做 smoke test

如果担心一次跑 50 轮耗时过长，可临时复制配置改为：

```yaml
federated:
  rounds: 2

dataset:
  max_train_samples: 1000
  max_test_samples: 1000
```

确认 `accepted=True` 后再跑 50 轮正式实验。

---

## 4. 正式运行

### 4.1 只跑 PriVeriFL-A-full

```bash
tmux new -s fullpriveri
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_full_priverifl_a_baselines.sh
```

完成后下载：

```text
/root/full_priverifl_a_baseline_results.zip
```

### 4.2 只跑 RTP-FL-full

```bash
tmux new -s fullrtpfl
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_full_rtpfl_baselines.sh
```

完成后下载：

```text
/root/full_rtpfl_baseline_results.zip
```

### 4.3 全部运行

```bash
tmux new -s fullbaselines
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_all_full_paper_baselines.sh
```

完成后下载：

```text
/root/full_paper_baseline_all_results.zip
```

---

## 5. 输出文件

每组输出目录包含：

```text
metrics_round.csv
runtime_cost.csv
crypto_cost.csv
communication_cost.csv
communication_summary_by_type.csv
baseline_cost.csv
blockchain_cost.csv
verify_result.csv
run_trace.json
summary_tables.xlsx
```

重点看：

- `verify_result.csv`：是否 `accepted=True`；
- `crypto_cost.csv`：Paillier 加密次数、packed 加密次数、AES 次数、repair symbols；
- `communication_summary_by_type.csv`：UpMsg、AggMsg、RepairShareMsg、ShareMsg；
- `baseline_cost.csv`：每轮的签名验证、同态哈希验证、repair/reconstruction 状态。

---

## 6. 和旧 style baseline 的区别

旧 `PriVeriFL-A-style`：整向量逐坐标 Paillier + 简化线性 tag。  
新 `PriVeriFL-A-full`：bit segmentation + packed Paillier + AES-GCM + homomorphic hash + signature。

旧 `RTP-FL-style`：Shamir 门限恢复 lambda，无真实修复流程。  
新 `RTP-FL-full`：显式 `(N,k,d)` repairable share 分发；掉线时由 `d` 个正常客户端生成 repair symbols；修复后恢复私钥段再解密。
