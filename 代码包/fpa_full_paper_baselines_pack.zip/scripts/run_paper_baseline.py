#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import yaml

from fl_audit.baselines.priverifl_a_full import run_priverifl_a_full
from fl_audit.baselines.rtpfl_full import run_rtpfl_full


def load_cfg(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if not isinstance(cfg, dict):
        raise ValueError(f"Invalid YAML config: {path}")
    return cfg


def main() -> None:
    ap = argparse.ArgumentParser(description="Run full paper reproduction baselines for PriVeriFL-A and RTP-FL.")
    ap.add_argument("--config", required=True, help="YAML config path")
    ap.add_argument("--scheme", default=None, choices=[None, "priverifl_a_full", "rtpfl_full"], help="Override baseline.scheme")
    args = ap.parse_args()

    cfg = load_cfg(args.config)
    scheme = (args.scheme or str(cfg.get("baseline", {}).get("scheme", ""))).lower()
    if scheme in {"priverifl-a-full", "priverifl_a_full", "full_priverifl_a", "priverifl_a"}:
        res = run_priverifl_a_full(cfg)
    elif scheme in {"rtpfl-full", "rtpfl_full", "full_rtpfl", "rtpfl"}:
        res = run_rtpfl_full(cfg)
    else:
        raise ValueError(f"Unsupported full baseline scheme: {scheme!r}. Use priverifl_a_full or rtpfl_full.")
    print(json.dumps(res, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
