from __future__ import annotations

import json
import math
import random
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd
import torch
import yaml

from fl_audit.crypto import paillier
from fl_audit.crypto.number import gen_prime
from fl_audit.crypto.signature import generate_keypair, sign_obj, verify_obj
from fl_audit.crypto.shamir_recovery import split_secret, reconstruct
from fl_audit.data import make_loaders
from fl_audit.encoding import quantize, dequantize
from fl_audit.model import evaluate, get_vector, make_model, model_hash, set_vector
from fl_audit.trainer import train_local, weighted_update
from fl_audit.utils.codec import bytes32_hex, canonical_bytes


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def load_yaml(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def save_csv(rows: List[Dict[str, Any]], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")


def save_json(obj: Any, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, default=str)


def estimate_json_bytes(obj: Any) -> int:
    return len(canonical_bytes(obj))


@dataclass
class Runtime:
    rows: List[Dict[str, Any]] = field(default_factory=list)

    @contextmanager
    def record(self, round_id: int, stage: str, detail: str = "", cid: int | str = ""):
        t0 = time.perf_counter()
        try:
            yield
        finally:
            self.rows.append({
                "round": int(round_id),
                "stage": str(stage),
                "detail": str(detail),
                "cid": cid,
                "seconds": float(time.perf_counter() - t0),
            })

    def add(self, round_id: int, stage: str, seconds: float, detail: str = "", cid: int | str = ""):
        self.rows.append({
            "round": int(round_id),
            "stage": str(stage),
            "detail": str(detail),
            "cid": cid,
            "seconds": float(seconds),
        })


@dataclass
class CommRecorder:
    rows: List[Dict[str, Any]] = field(default_factory=list)

    def add(self, round_id: int, sender: str, receiver: str, payload_type: str, payload: Any, *, note: str = "") -> int:
        b = estimate_json_bytes(payload)
        self.rows.append({
            "round": int(round_id),
            "sender": str(sender),
            "receiver": str(receiver),
            "payload_type": str(payload_type),
            "bytes": int(b),
            "actual_seconds": 0.0,
            "process_seconds": 0.0,
            "includes_processing": False,
            "note": note,
        })
        return b

    def summary_by_type(self) -> List[Dict[str, Any]]:
        if not self.rows:
            return []
        df = pd.DataFrame(self.rows)
        g = df.groupby("payload_type", as_index=False).agg(count=("bytes", "count"), total_bytes=("bytes", "sum"))
        g["total_actual_seconds"] = 0.0
        g["total_process_seconds"] = 0.0
        g["network_transfer_count"] = g["count"]
        g["processing_request_count"] = 0
        g["total_MB"] = g["total_bytes"] / (1024 * 1024)
        return g.to_dict(orient="records")


class HomomorphicLinearTag:
    """A simple aggregation-verifiable homomorphic hash/tag.

    For vector x, tag(x)=sum_j a_j*x_j mod p. Since tag is linear,
    tag(sum_i x_i)=sum_i tag(x_i) mod p.  This is not a full PriVeriFL
    implementation, but it captures the aggregation-verification core used by
    the PriVeriFL-A-style baseline.
    """

    def __init__(self, dim: int, seed: int, prime_bits: int = 127):
        self.prime = (1 << 127) - 1 if prime_bits <= 127 else gen_prime(prime_bits)
        rng = random.Random(seed + 13007)
        self.coeffs = np.array([rng.randrange(1, self.prime) for _ in range(dim)], dtype=object)

    def tag(self, x: np.ndarray) -> int:
        total = 0
        p = self.prime
        # Python ints avoid overflow and keep exact modular arithmetic.
        for a, v in zip(self.coeffs, x.reshape(-1).tolist()):
            total = (total + int(a) * int(v)) % p
        return int(total)

    def add_tags(self, tags: Iterable[int]) -> int:
        return int(sum(int(t) for t in tags) % self.prime)


def active_clients_for_round(cfg: dict, r: int) -> Tuple[List[int], List[int]]:
    clients = int(cfg["federated"]["clients"])
    all_ids = list(range(1, clients + 1))
    dropout_cfg = cfg["federated"].get("dropout", {}) or {}
    dropped = dropout_cfg.get(r, dropout_cfg.get(str(r), [])) or []
    dropped = sorted({int(x) for x in dropped})
    active = [cid for cid in all_ids if cid not in set(dropped)]
    return active, dropped


def make_client_keypairs(clients: int) -> Dict[int, Any]:
    return {cid: generate_keypair() for cid in range(1, clients + 1)}


def train_and_quantize_update(global_model, loader, total_samples: int, cfg: dict, timer: Runtime, r: int, cid: int, device: str) -> Tuple[np.ndarray, float, float]:
    epochs = int(cfg["federated"].get("local_epochs", 1))
    lr = float(cfg["federated"].get("local_lr", 0.05))
    scale = int(cfg["encoding"].get("scale", 10000))

    with timer.record(r, "client_local_train", "real local SGD on real dataset", cid=cid):
        local_model, local_loss = train_local(global_model, loader, epochs, lr, device=device)

    with timer.record(r, "client_model_delta", "weighted local model delta", cid=cid):
        weight = len(loader.dataset) / float(max(total_samples, 1))
        u = weighted_update(global_model, local_model, weight).numpy().astype(np.float64)

    with timer.record(r, "client_quant_encode", "fixed-point quantization", cid=cid):
        x = quantize(u, scale)

    return x.astype(np.int64), float(local_loss), float(weight)


def decrypt_vector(pub: paillier.PaillierPublicKey, priv: paillier.PaillierPrivateKey, c_vec: List[int]) -> np.ndarray:
    return np.array([paillier.decrypt(pub, priv, int(c)) for c in c_vec], dtype=np.int64)


def aggregate_cipher_vectors(pub: paillier.PaillierPublicKey, encrypted_vectors: List[List[int]]) -> List[int]:
    if not encrypted_vectors:
        return []
    dim = len(encrypted_vectors[0])
    out = []
    for j in range(dim):
        acc = 1
        for vec in encrypted_vectors:
            acc = paillier.add(pub, acc, int(vec[j]))
        out.append(acc)
    return out


def update_global_model(model, x_agg: np.ndarray, cfg: dict) -> None:
    scale = int(cfg["encoding"].get("scale", 10000))
    server_lr = float(cfg["federated"].get("server_lr", 1.0))
    delta = torch.from_numpy(dequantize(x_agg, scale)).double()
    new_vec = get_vector(model) + server_lr * delta
    set_vector(model, new_vec)


def write_common_outputs(out_dir: str | Path, *, cfg: dict, scheme_name: str, accepted: bool, rounds_done: int, latest_root: str, metrics_rows: list, runtime: Runtime, comm: CommRecorder, crypto_rows: list, trace: dict, blockchain_rows: list | None = None, baseline_rows: list | None = None) -> None:
    out = ensure_dir(out_dir)
    save_csv(metrics_rows, out / "metrics_round.csv")
    save_csv(runtime.rows, out / "runtime_cost.csv")
    save_csv(crypto_rows, out / "crypto_cost.csv")
    save_csv(blockchain_rows or [], out / "blockchain_cost.csv")
    save_csv(baseline_rows or [], out / "baseline_cost.csv")
    save_csv(comm.rows, out / "communication_cost.csv")
    save_csv(comm.rows, out / "communication_network_only.csv")
    save_csv([], out / "communication_processing_requests.csv")
    save_csv(comm.summary_by_type(), out / "communication_summary_by_type.csv")
    save_csv([{"accepted": bool(accepted), "rounds": int(rounds_done), "latestAuditRoot": latest_root}], out / "verify_result.csv")
    trace = dict(trace)
    trace.setdefault("scheme", scheme_name)
    trace.setdefault("config", cfg)
    save_json(trace, out / "run_trace.json")

    try:
        with pd.ExcelWriter(out / "summary_tables.xlsx", engine="openpyxl") as writer:
            pd.DataFrame(metrics_rows).to_excel(writer, sheet_name="metrics_round", index=False)
            pd.DataFrame(runtime.rows).to_excel(writer, sheet_name="runtime_cost", index=False)
            pd.DataFrame(crypto_rows).to_excel(writer, sheet_name="crypto_cost", index=False)
            pd.DataFrame(comm.summary_by_type()).to_excel(writer, sheet_name="comm_by_type", index=False)
            pd.DataFrame(baseline_rows or []).to_excel(writer, sheet_name="baseline_cost", index=False)
    except Exception:
        pass
