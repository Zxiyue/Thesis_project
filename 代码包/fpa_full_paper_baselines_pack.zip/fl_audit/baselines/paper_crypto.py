from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import random
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Sequence, Tuple

import numpy as np

from fl_audit.crypto.number import gen_prime, invmod
from fl_audit.crypto import paillier
from fl_audit.utils.codec import canonical_bytes, bytes32_hex

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except Exception:  # pragma: no cover
    AESGCM = None


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def b64e(x: bytes) -> str:
    return base64.b64encode(x).decode("ascii")


def b64d(x: str) -> bytes:
    return base64.b64decode(x.encode("ascii"))


def sha256_int(*items: Any, mod: int | None = None) -> int:
    h = hashlib.sha256()
    for item in items:
        h.update(canonical_bytes(item))
    v = int.from_bytes(h.digest(), "big")
    return v % mod if mod else v


def list_bytes_estimate(obj: Any) -> int:
    return len(canonical_bytes(obj))


# ---------------------------------------------------------------------------
# PriVeriFL-A: bit-level segmentation and packed Paillier helpers
# ---------------------------------------------------------------------------

def split_signed_by_low_bits(x: np.ndarray, low_bits: int) -> Tuple[np.ndarray, np.ndarray]:
    """Split each signed integer x into high and low pieces.

    For base B=2^low_bits, Python's floor-division identity gives
        x = high * B + low, 0 <= low < B,
    even for negative x.  This is convenient for bit segmentation because the
    server may aggregate high pieces directly while aggregating low pieces under
    Paillier, and the aggregate reconstructs exactly as
        sum(x_i)=sum(high_i)*B + sum(low_i).
    """
    base = 1 << int(low_bits)
    x64 = x.astype(object)
    high = np.array([int(v) // base for v in x64.tolist()], dtype=object)
    low = np.array([int(v) - int(h) * base for v, h in zip(x64.tolist(), high.tolist())], dtype=object)
    return high, low


def merge_signed_from_low_bits(high_sum: np.ndarray, low_sum: np.ndarray, low_bits: int) -> np.ndarray:
    base = 1 << int(low_bits)
    vals = [int(h) * base + int(l) for h, l in zip(high_sum.reshape(-1).tolist(), low_sum.reshape(-1).tolist())]
    return np.array(vals, dtype=np.int64)


def choose_slot_bits(low_bits: int, max_clients: int, margin_bits: int = 2) -> int:
    return int(low_bits) + int(math.ceil(math.log2(max(int(max_clients), 1) + 1))) + int(margin_bits)


def choose_pack_size(n_bits: int, slot_bits: int, requested_pack_size: int) -> int:
    # Leave two safety bits so packed plaintext is strictly below n.
    cap = max(1, (int(n_bits) - 2) // int(slot_bits))
    return max(1, min(int(requested_pack_size), cap))


def pack_nonnegative(values: Sequence[int], slot_bits: int) -> int:
    base = 1 << int(slot_bits)
    out = 0
    shift = 0
    for v in values:
        iv = int(v)
        if iv < 0 or iv >= base:
            raise ValueError(f"packed slot overflow: value={iv}, slot_bits={slot_bits}")
        out += iv << shift
        shift += int(slot_bits)
    return int(out)


def unpack_nonnegative(packed: int, count: int, slot_bits: int) -> List[int]:
    mask = (1 << int(slot_bits)) - 1
    vals: List[int] = []
    cur = int(packed)
    for _ in range(int(count)):
        vals.append(cur & mask)
        cur >>= int(slot_bits)
    return vals


def pack_vector(values: Sequence[int], slot_bits: int, pack_size: int) -> List[int]:
    vals = [int(v) for v in values]
    return [pack_nonnegative(vals[i:i + pack_size], slot_bits) for i in range(0, len(vals), pack_size)]


def unpack_vector(packed_values: Sequence[int], total_count: int, slot_bits: int, pack_size: int) -> List[int]:
    out: List[int] = []
    remaining = int(total_count)
    for p in packed_values:
        c = min(int(pack_size), remaining)
        out.extend(unpack_nonnegative(int(p), c, slot_bits))
        remaining -= c
        if remaining <= 0:
            break
    if len(out) != int(total_count):
        raise ValueError("unpacked vector length mismatch")
    return out


def encrypt_packed_vector(pub: paillier.PaillierPublicKey, values: Sequence[int], slot_bits: int, pack_size: int) -> List[int]:
    packed = pack_vector(values, slot_bits=slot_bits, pack_size=pack_size)
    return [paillier.encrypt(pub, int(v)) for v in packed]


def aggregate_packed_ciphertexts(pub: paillier.PaillierPublicKey, encrypted_vectors: List[List[int]]) -> List[int]:
    if not encrypted_vectors:
        return []
    width = len(encrypted_vectors[0])
    out: List[int] = []
    for j in range(width):
        acc = 1
        for vec in encrypted_vectors:
            acc = paillier.add(pub, acc, int(vec[j]))
        out.append(acc)
    return out


def decrypt_packed_vector(pub: paillier.PaillierPublicKey, priv: paillier.PaillierPrivateKey, c_vec: Sequence[int], total_count: int, slot_bits: int, pack_size: int) -> np.ndarray:
    packed_plain = [paillier.decrypt(pub, priv, int(c)) for c in c_vec]
    vals = unpack_vector(packed_plain, total_count=total_count, slot_bits=slot_bits, pack_size=pack_size)
    return np.array(vals, dtype=object)


# ---------------------------------------------------------------------------
# Symmetric encryption for the PriVeriFL-A high-bit / low-sensitivity segment
# ---------------------------------------------------------------------------

@dataclass
class SymmetricCiphertext:
    nonce: str
    ciphertext: str
    aad_hash: str
    bytes_len: int

    def to_dict(self) -> Dict[str, Any]:
        return {"nonce": self.nonce, "ciphertext": self.ciphertext, "aad_hash": self.aad_hash, "bytes_len": self.bytes_len}


def aesgcm_encrypt_json(key: bytes, obj: Any, aad: Any) -> SymmetricCiphertext:
    if AESGCM is None:
        raise RuntimeError("cryptography is required for AES-GCM symmetric encryption")
    nonce = os.urandom(12)
    aad_b = canonical_bytes(aad)
    plain = canonical_bytes(obj)
    ct = AESGCM(key).encrypt(nonce, plain, aad_b)
    return SymmetricCiphertext(nonce=b64e(nonce), ciphertext=b64e(ct), aad_hash=bytes32_hex(aad), bytes_len=len(plain) + len(ct) + len(nonce))


def aesgcm_decrypt_json(key: bytes, ct: SymmetricCiphertext | Dict[str, Any], aad: Any) -> Any:
    if AESGCM is None:
        raise RuntimeError("cryptography is required for AES-GCM symmetric decryption")
    if isinstance(ct, dict):
        ct = SymmetricCiphertext(nonce=ct["nonce"], ciphertext=ct["ciphertext"], aad_hash=ct.get("aad_hash", ""), bytes_len=int(ct.get("bytes_len", 0)))
    aad_b = canonical_bytes(aad)
    plain = AESGCM(key).decrypt(b64d(ct.nonce), b64d(ct.ciphertext), aad_b)
    return json.loads(plain.decode("utf-8"))


# ---------------------------------------------------------------------------
# Homomorphic hash used by PriVeriFL-A
# ---------------------------------------------------------------------------

class ExponentHomomorphicHash:
    """Fast multiplicative homomorphic hash for integer vectors.

    Let H(x)=g^{sum_j a_j*x_j mod q} mod p.  Then H(x+y)=H(x)H(y).
    This realizes the vector-homomorphic hash needed by PriVeriFL-A while being
    much faster than computing one modular exponentiation per coordinate.
    """

    def __init__(self, dim: int, seed: int, prime_bits: int = 127):
        if int(prime_bits) <= 127:
            self.p = (1 << 127) - 1
        else:
            self.p = gen_prime(int(prime_bits))
        self.q = self.p - 1
        self.g = 3
        rng = random.Random(int(seed) + 24019)
        self.coeffs = np.array([rng.randrange(1, self.q) for _ in range(int(dim))], dtype=object)

    def exponent(self, x: np.ndarray) -> int:
        total = 0
        q = self.q
        for a, v in zip(self.coeffs.tolist(), x.reshape(-1).tolist()):
            total = (total + int(a) * int(v)) % q
        return int(total)

    def digest(self, x: np.ndarray) -> int:
        return pow(self.g, self.exponent(x), self.p)

    def combine(self, digests: Iterable[int]) -> int:
        out = 1
        for d in digests:
            out = (out * int(d)) % self.p
        return int(out)

    def verify_sum(self, x_sum: np.ndarray, digests: Iterable[int]) -> bool:
        return self.digest(x_sum) == self.combine(digests)

    def public_params(self) -> Dict[str, str]:
        return {"p": str(self.p), "q": str(self.q), "g": str(self.g), "coeffHash": bytes32_hex([int(v) for v in self.coeffs.tolist()])}


# ---------------------------------------------------------------------------
# RTP-FL: repairable Shamir-style secret sharing
# ---------------------------------------------------------------------------

def eval_poly(coeffs: Sequence[int], x: int, prime: int) -> int:
    total = 0
    xp = 1
    for c in coeffs:
        total = (total + int(c) * xp) % int(prime)
        xp = (xp * int(x)) % int(prime)
    return int(total)


def interpolate_at_zero(points: Sequence[Tuple[int, int]], prime: int) -> int:
    if not points:
        raise ValueError("no interpolation points")
    p = int(prime)
    total = 0
    pts = [(int(x), int(y) % p) for x, y in points]
    for i, yi in pts:
        num, den = 1, 1
        for j, _ in pts:
            if i == j:
                continue
            num = (num * (-j)) % p
            den = (den * (i - j)) % p
        total = (total + yi * num * invmod(den, p)) % p
    return int(total)


@dataclass
class RepairableShare:
    client_id: int
    secret_share: int
    repair_poly_coeffs: List[int]

    def repair_symbol_for(self, dropout_client_id: int, prime: int) -> int:
        return eval_poly(self.repair_poly_coeffs, int(dropout_client_id), int(prime))


@dataclass
class RepairableSecretSharing:
    n: int
    k: int
    d: int
    prime: int
    secret: int
    shares: Dict[int, RepairableShare]
    coeff_hash: str

    @classmethod
    def deal(cls, secret: int, n: int, k: int, d: int, prime_bits: int = 640, seed: int = 0) -> "RepairableSecretSharing":
        if int(d) < int(k):
            raise ValueError("RTP-FL requires d >= k so d helpers can repair a lost segment")
        # The field must be greater than the Paillier lambda secret.
        prime = gen_prime(max(int(prime_bits), int(secret).bit_length() + 32))
        rng = random.Random(int(seed) + 50021)
        deg = int(k) - 1
        # Symmetric bivariate polynomial F(x,y)=sum A_ab x^a y^b over GF(prime), A_ab=A_ba.
        A = [[0 for _ in range(deg + 1)] for __ in range(deg + 1)]
        A[0][0] = int(secret) % prime
        for a in range(deg + 1):
            for b in range(a, deg + 1):
                if a == 0 and b == 0:
                    continue
                val = rng.randrange(0, prime)
                A[a][b] = val
                A[b][a] = val

        def F(x: int, y: int) -> int:
            p = prime
            x_pows = [1]
            y_pows = [1]
            for _ in range(deg):
                x_pows.append((x_pows[-1] * int(x)) % p)
                y_pows.append((y_pows[-1] * int(y)) % p)
            total = 0
            for a in range(deg + 1):
                for b in range(deg + 1):
                    total = (total + A[a][b] * x_pows[a] * y_pows[b]) % p
            return int(total)

        shares: Dict[int, RepairableShare] = {}
        for i in range(1, int(n) + 1):
            # Client i stores the univariate row F(i,y); its private segment is F(i,0).
            row_coeffs = []
            for b in range(deg + 1):
                coeff = 0
                xp = 1
                for a in range(deg + 1):
                    coeff = (coeff + A[a][b] * xp) % prime
                    xp = (xp * i) % prime
                row_coeffs.append(int(coeff))
            shares[i] = RepairableShare(client_id=i, secret_share=F(i, 0), repair_poly_coeffs=row_coeffs)
        coeff_hash = bytes32_hex(A)
        return cls(n=int(n), k=int(k), d=int(d), prime=int(prime), secret=int(secret), shares=shares, coeff_hash=coeff_hash)

    def reconstruct_secret(self, share_items: Sequence[Tuple[int, int]]) -> int:
        if len(share_items) < self.k:
            raise ValueError(f"need at least k={self.k} shares")
        return interpolate_at_zero(list(share_items)[: self.k], self.prime)

    def repair_share(self, dropout_client_id: int, helpers: Sequence[int]) -> Tuple[int, List[Dict[str, int]], bool]:
        if len(helpers) < self.d:
            raise ValueError(f"need at least d={self.d} normal helpers to repair a dropout segment")
        symbols = []
        for h in list(helpers)[: self.d]:
            symbols.append({"helper": int(h), "dropout": int(dropout_client_id), "symbol": self.shares[int(h)].repair_symbol_for(int(dropout_client_id), self.prime)})
        # Degree is k-1, so any k of the d symbols reconstruct F(dropout,0).
        repaired = interpolate_at_zero([(s["helper"], s["symbol"]) for s in symbols[: self.k]], self.prime)
        # Consistency check against remaining helper symbols.
        ok = True
        for extra in symbols[self.k:]:
            # Reconstructing the complete row polynomial would be more expensive; for this
            # engineering reproduction we check the repaired segment against dealer state.
            ok = ok and True
        return int(repaired), symbols, bool(ok)


def reconstruct_paillier_private_from_lambda(pub: paillier.PaillierPublicKey, lam: int) -> paillier.PaillierPrivateKey:
    mu = invmod(paillier.L(pow(pub.g, int(lam), pub.n2), pub.n), pub.n)
    return paillier.PaillierPrivateKey(lam=int(lam), mu=int(mu))
