from __future__ import annotations

import time
from typing import Any, Dict, List, Tuple

import numpy as np
import torch

from fl_audit.baselines.common import (
    CommRecorder,
    Runtime,
    active_clients_for_round,
    aggregate_cipher_vectors,
    make_client_keypairs,
    set_seed,
    train_and_quantize_update,
    update_global_model,
    write_common_outputs,
)
from fl_audit.baselines.paper_crypto import RepairableSecretSharing, reconstruct_paillier_private_from_lambda
from fl_audit.crypto import paillier
from fl_audit.crypto.signature import sign_obj, verify_obj
from fl_audit.data import make_loaders
from fl_audit.model import evaluate, get_vector, make_model, model_hash
from fl_audit.utils.codec import bytes32_hex


def _cfg_get(cfg: Dict[str, Any], *path: str, default: Any = None) -> Any:
    cur: Any = cfg
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return default
        cur = cur[key]
    return cur


def _decrypt_vector_with_repaired_lambda(pub: paillier.PaillierPublicKey, lambda_secret: int, c_vec: List[int]) -> np.ndarray:
    priv = reconstruct_paillier_private_from_lambda(pub, lambda_secret)
    return np.array([paillier.decrypt(pub, priv, int(c)) for c in c_vec], dtype=np.int64)


def _reconstruct_lambda_from_share_map(rss: RepairableSecretSharing, share_map: Dict[int, int]) -> int:
    items = sorted((int(i), int(s)) for i, s in share_map.items())
    if len(items) < rss.k:
        raise ValueError(f"not enough available/repaired shares: got {len(items)}, need k={rss.k}")
    return int(rss.reconstruct_secret(items[: rss.k]))


def run_rtpfl_full(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Run a paper-mechanism RTP-FL reproduction baseline.

    Implemented mechanisms:
      1. real FL training and Paillier encrypted aggregation;
      2. (N,k,d)-repairable Shamir-style private-key segment distribution;
      3. any k private-key segments recover Paillier lambda;
      4. any d normal clients generate signed repair symbols for a dropout client;
      5. repaired segments can be used together with active segments to recover lambda;
      6. signed uploads, signed key-segment contribution records, and signed repair records.

    The original RTP-FL paper is centered on reparable threshold Paillier key
    segments.  This runner therefore records both repair and reconstruction
    events explicitly in baseline_cost.csv and run_trace.json.
    """
    seed = int(cfg.get("seed", 42))
    set_seed(seed)
    out_dir = cfg.get("output_dir", "outputs/baseline_full_rtpfl")
    device = str(_cfg_get(cfg, "runtime", "device", default="cpu"))
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    if device.startswith("cuda") and not torch.cuda.is_available():
        device = "cpu"

    timer = Runtime()
    comm = CommRecorder()
    metrics_rows: List[Dict[str, Any]] = []
    crypto_rows: List[Dict[str, Any]] = []
    baseline_rows: List[Dict[str, Any]] = []
    trace: Dict[str, Any] = {"scheme": "baseline_rtpfl_full", "rounds": []}

    model = make_model(cfg["model"]["name"])
    train_loaders, test_loader, _parts = make_loaders(cfg)
    clients = int(cfg["federated"]["clients"])
    total_samples = sum(len(loader.dataset) for loader in train_loaders.values())
    dim = int(get_vector(model).numel())

    paillier_bits = int(_cfg_get(cfg, "crypto", "paillier_bits", default=512))
    k = int(_cfg_get(cfg, "baseline", "rtpfl", "k", default=cfg["federated"].get("threshold", 3)))
    d = int(_cfg_get(cfg, "baseline", "rtpfl", "d", default=max(k, clients - 1)))
    repair_prime_bits = int(_cfg_get(cfg, "baseline", "rtpfl", "repair_prime_bits", default=max(640, paillier_bits + 128)))

    with timer.record(0, "rtpfl_paillier_keygen", "Paillier key generation"):
        pkey = paillier.keygen(paillier_bits)
    with timer.record(0, "rtpfl_repairable_share_deal", "deal (N,k,d)-repairable Paillier private-key segments"):
        rss = RepairableSecretSharing.deal(secret=pkey.private.lam, n=clients, k=k, d=d, prime_bits=repair_prime_bits, seed=seed)

    client_keys = make_client_keypairs(clients)
    init_model_hash = model_hash(model)
    init_public = {
        "scheme": "RTP-FL-full",
        "modelHash": init_model_hash,
        "dim": dim,
        "paillier_n": str(pkey.public.n),
        "N": clients,
        "k": k,
        "d": d,
        "repairPrime": str(rss.prime),
        "shareCoeffHash": rss.coeff_hash,
    }
    for cid in range(1, clients + 1):
        comm.add(0, "Dealer", f"C{cid}", "KeyShareMsg", {**init_public, "shareId": cid, "shareHash": bytes32_hex(str(rss.shares[cid].secret_share))})
        comm.add(0, "Server", f"C{cid}", "InitModel", init_public)

    loss0, acc0 = evaluate(model, test_loader, device=device)
    metrics_rows.append({"round": 0, "test_loss": loss0, "test_accuracy": acc0, "effective_clients": 0, "dropout_clients": 0})

    accepted = True
    latest_root = bytes32_hex({"scheme": "baseline_rtpfl_full", "modelHash": init_model_hash, "N": clients, "k": k, "d": d})
    rounds_done = 0
    rounds = int(cfg["federated"]["rounds"])
    exp_t0 = time.perf_counter()

    for r in range(1, rounds + 1):
        r_t0 = time.perf_counter()
        active, dropped = active_clients_for_round(cfg, r)
        active_total_samples = sum(len(train_loaders[cid].dataset) for cid in active)
        model_hash_r = model_hash(model)
        encrypted_vectors: List[List[int]] = []
        local_losses: List[float] = []
        signature_ok = True
        repair_ok = True
        reconstruct_ok = True
        repair_symbol_count = 0
        repaired_share_count = 0
        share_map: Dict[int, int] = {cid: int(rss.shares[cid].secret_share) for cid in active}

        # Client train, encrypt, sign upload.
        for cid in active:
            x, local_loss, weight = train_and_quantize_update(model, train_loaders[cid], active_total_samples, cfg, timer, r, cid, device)
            local_losses.append(local_loss)
            with timer.record(r, "client_paillier_encrypt", "coordinate-wise Paillier encryption", cid=cid):
                c_vec = [paillier.encrypt(pkey.public, int(v)) for v in x.tolist()]
            receipt = {
                "scheme": "RTP-FL-full",
                "r": r,
                "i": cid,
                "modelHash": model_hash_r,
                "cHash": bytes32_hex(c_vec),
                "weight": weight,
            }
            with timer.record(r, "client_receipt_sign", "sign RTP-FL upload receipt", cid=cid):
                sig = sign_obj(client_keys[cid].private_key, receipt)
            comm.add(r, f"C{cid}", "Server", "UpMsg", {"Receipt": receipt, "sigUp": sig, "C": [str(v) for v in c_vec]})
            if not verify_obj(client_keys[cid].public_pem, sig, receipt):
                signature_ok = False
            encrypted_vectors.append(c_vec)

        with timer.record(r, "server_paillier_aggregate", "homomorphic ciphertext aggregation"):
            c_agg = aggregate_cipher_vectors(pkey.public, encrypted_vectors)
        cagg_hash = bytes32_hex(c_agg)
        comm.add(r, "Server", "KeyCombiner", "AggMsg", {"scheme": "RTP-FL-full", "r": r, "CaggHash": cagg_hash, "Cagg": [str(v) for v in c_agg]})

        # Repair missing private-key segments if needed and possible.
        # RTP-FL's goal is exactly to allow dropout private-key segments to be repaired by d normal clients.
        if len(share_map) < k and dropped:
            for missing in dropped:
                if len(active) < d:
                    repair_ok = False
                    break
                helpers = active[:d]
                with timer.record(r, "rtpfl_repair_dropout_share", f"repair private-key segment for dropped client C{missing}"):
                    repaired, symbols, ok = rss.repair_share(missing, helpers)
                repaired_share_count += 1
                repair_symbol_count += len(symbols)
                repair_ok = repair_ok and bool(ok)
                share_map[missing] = int(repaired)
                signed_symbols = []
                for sym in symbols:
                    helper = int(sym["helper"])
                    repair_msg = {"scheme": "RTP-FL-full", "r": r, "dropout": int(missing), "helper": helper, "symbolHash": bytes32_hex(str(sym["symbol"])), "caggHash": cagg_hash}
                    sig = sign_obj(client_keys[helper].private_key, repair_msg)
                    signed_symbols.append({"repairMsg": repair_msg, "sigRepair": sig})
                    if not verify_obj(client_keys[helper].public_pem, sig, repair_msg):
                        signature_ok = False
                comm.add(r, "RepairHelpers", "KeyCombiner", "RepairShareMsg", {"dropout": missing, "symbols": signed_symbols})
                if len(share_map) >= k:
                    break

        # In normal rounds active shares already reach k; in dropout-heavy rounds repaired shares are included.
        share_records = []
        for cid in sorted(share_map.keys())[:k]:
            share_msg = {"scheme": "RTP-FL-full", "r": r, "i": cid, "shareHash": bytes32_hex(str(share_map[cid])), "caggHash": cagg_hash, "isRepaired": cid in dropped}
            sig = sign_obj(client_keys[cid].private_key if cid in active else client_keys[active[0]].private_key, share_msg)
            share_records.append({"ShareMsg": share_msg, "sigShare": sig})
        comm.add(r, "Clients/Repair", "KeyCombiner", "ShareMsg", {"shares": share_records})

        try:
            with timer.record(r, "rtpfl_reconstruct_private_key", "recover Paillier lambda from k available/repaired private-key segments"):
                lam_rec = _reconstruct_lambda_from_share_map(rss, share_map)
            reconstruct_ok = (int(lam_rec) == int(pkey.private.lam))
        except Exception:
            lam_rec = None
            reconstruct_ok = False

        if reconstruct_ok and repair_ok and signature_ok:
            with timer.record(r, "rtpfl_paillier_decrypt_with_recovered_key", "decrypt aggregate with recovered Paillier private key"):
                x_agg = _decrypt_vector_with_repaired_lambda(pkey.public, int(lam_rec), c_agg)
        else:
            x_agg = np.zeros(dim, dtype=np.int64)
            accepted = False

        accepted = bool(accepted and signature_ok and repair_ok and reconstruct_ok)
        if accepted:
            with timer.record(r, "server_model_update", "apply aggregated update"):
                update_global_model(model, x_agg, cfg)
            with timer.record(r, "server_evaluate", "test evaluation"):
                test_loss, test_acc = evaluate(model, test_loader, device=device)
        else:
            test_loss, test_acc = evaluate(model, test_loader, device=device)

        model_hash_next = model_hash(model)
        latest_root = bytes32_hex({
            "prev": latest_root,
            "r": r,
            "modelHashR": model_hash_r,
            "modelHashNext": model_hash_next,
            "caggHash": cagg_hash,
            "repairOk": repair_ok,
            "reconstructOk": reconstruct_ok,
            "signatureOk": signature_ok,
        })
        rounds_done = r

        metrics_rows.append({"round": r, "test_loss": test_loss, "test_accuracy": test_acc, "effective_clients": len(active), "dropout_clients": len(dropped)})
        crypto_rows.extend([
            {"round": r, "metric": "model_dimension", "value": dim},
            {"round": r, "metric": "effective_clients", "value": len(active)},
            {"round": r, "metric": "dropout_clients", "value": len(dropped)},
            {"round": r, "metric": "N", "value": clients},
            {"round": r, "metric": "k_threshold", "value": k},
            {"round": r, "metric": "d_repair_helpers", "value": d},
            {"round": r, "metric": "paillier_encryptions", "value": len(active) * dim},
            {"round": r, "metric": "paillier_decryptions", "value": dim if reconstruct_ok else 0},
            {"round": r, "metric": "private_key_segments_used", "value": min(len(share_map), k)},
            {"round": r, "metric": "repair_symbols", "value": repair_symbol_count},
            {"round": r, "metric": "repaired_private_key_segments", "value": repaired_share_count},
            {"round": r, "metric": "ecdsa_signatures", "value": len(active) + repair_symbol_count + min(len(share_map), k)},
            {"round": r, "metric": "ecdsa_verifications", "value": len(active) + repair_symbol_count},
        ])
        baseline_rows.append({
            "round": r,
            "scheme": "RTP-FL-full",
            "signature_ok": bool(signature_ok),
            "repair_ok": bool(repair_ok),
            "private_key_reconstruct_ok": bool(reconstruct_ok),
            "accepted_so_far": bool(accepted),
            "effective_clients": len(active),
            "dropout_clients": len(dropped),
            "repair_symbols": repair_symbol_count,
            "repaired_shares": repaired_share_count,
            "round_wall_seconds": time.perf_counter() - r_t0,
        })
        trace["rounds"].append({
            "round": r,
            "signature_ok": signature_ok,
            "repair_ok": repair_ok,
            "private_key_reconstruct_ok": reconstruct_ok,
            "active": active,
            "dropped": dropped,
            "repair_symbols": repair_symbol_count,
            "repaired_shares": repaired_share_count,
            "test_accuracy": test_acc,
            "test_loss": test_loss,
        })
        if not accepted:
            break

    timer.add(0, "experiment_wall", time.perf_counter() - exp_t0, detail="total RTP-FL-full baseline wall-clock time")
    write_common_outputs(
        out_dir,
        cfg=cfg,
        scheme_name="baseline_rtpfl_full",
        accepted=accepted,
        rounds_done=rounds_done,
        latest_root=latest_root,
        metrics_rows=metrics_rows,
        runtime=timer,
        comm=comm,
        crypto_rows=crypto_rows,
        trace=trace,
        blockchain_rows=[{"round": "N/A", "tx_type": "N/A", "gas_used": 0, "latency_sec": 0.0, "note": "RTP-FL does not use our blockchain audit board"}],
        baseline_rows=baseline_rows,
    )
    return {"accepted": accepted, "rounds": rounds_done, "output_dir": str(out_dir), "latestRoot": latest_root, "N": clients, "k": k, "d": d}
