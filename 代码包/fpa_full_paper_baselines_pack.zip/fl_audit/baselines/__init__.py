"""Real-data baseline runners for public-auditable FL experiments."""
