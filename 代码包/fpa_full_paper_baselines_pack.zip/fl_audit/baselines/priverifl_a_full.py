from __future__ import annotations

import os
import time
from typing import Any, Dict, List

import numpy as np
import torch

from fl_audit.baselines.common import (
    CommRecorder,
    Runtime,
    active_clients_for_round,
    make_client_keypairs,
    set_seed,
    train_and_quantize_update,
    update_global_model,
    write_common_outputs,
)
from fl_audit.baselines.paper_crypto import (
    ExponentHomomorphicHash,
    aesgcm_decrypt_json,
    aesgcm_encrypt_json,
    aggregate_packed_ciphertexts,
    choose_pack_size,
    choose_slot_bits,
    decrypt_packed_vector,
    encrypt_packed_vector,
    merge_signed_from_low_bits,
    split_signed_by_low_bits,
)
from fl_audit.crypto import paillier
from fl_audit.crypto.signature import sign_obj, verify_obj
from fl_audit.data import make_loaders
from fl_audit.model import evaluate, get_vector, make_model, model_hash
from fl_audit.utils.codec import bytes32_hex


def _cfg_get(cfg: Dict[str, Any], *path: str, default: Any = None) -> Any:
    cur: Any = cfg
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return default
        cur = cur[key]
    return cur


def _safe_int_list(x: np.ndarray) -> List[int]:
    return [int(v) for v in x.reshape(-1).tolist()]


def run_priverifl_a_full(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Run a paper-faithful PriVeriFL-A reproduction baseline.

    Implemented mechanisms:
      1. real local SGD on torchvision data;
      2. bit-level model-update segmentation x = high*2^b + low;
      3. BatchCrypt-style packed Paillier aggregation for the low-bit segment;
      4. AES-GCM protection for the remaining high segment;
      5. multiplicative homomorphic hash H(x) with H(sum x_i)=prod H(x_i);
      6. ECDSA signatures on upload receipts and verification records.

    This runner is intentionally separate from the old "PriVeriFL-A-style"
    baseline so that the result name can be reported as a full-mechanism
    PriVeriFL-A reproduction in the experiment table.
    """
    seed = int(cfg.get("seed", 42))
    set_seed(seed)
    out_dir = cfg.get("output_dir", "outputs/baseline_full_priverifl_a")
    device = str(_cfg_get(cfg, "runtime", "device", default="cpu"))
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    if device.startswith("cuda") and not torch.cuda.is_available():
        device = "cpu"

    timer = Runtime()
    comm = CommRecorder()
    metrics_rows: List[Dict[str, Any]] = []
    crypto_rows: List[Dict[str, Any]] = []
    baseline_rows: List[Dict[str, Any]] = []
    trace: Dict[str, Any] = {"scheme": "baseline_priverifl_a_full", "rounds": []}

    model = make_model(cfg["model"]["name"])
    train_loaders, test_loader, _parts = make_loaders(cfg)
    clients = int(cfg["federated"]["clients"])
    total_samples = sum(len(loader.dataset) for loader in train_loaders.values())
    dim = int(get_vector(model).numel())

    paillier_bits = int(_cfg_get(cfg, "crypto", "paillier_bits", default=512))
    with timer.record(0, "priverifl_a_paillier_keygen", "Paillier key generation"):
        pkey = paillier.keygen(paillier_bits)

    low_bits = int(_cfg_get(cfg, "baseline", "priverifl_a", "low_bits", default=12))
    requested_pack_size = int(_cfg_get(cfg, "baseline", "priverifl_a", "pack_size", default=32))
    slot_bits = choose_slot_bits(low_bits=low_bits, max_clients=clients, margin_bits=int(_cfg_get(cfg, "baseline", "priverifl_a", "slot_margin_bits", default=2)))
    pack_size = choose_pack_size(n_bits=pkey.public.n.bit_length(), slot_bits=slot_bits, requested_pack_size=requested_pack_size)
    high_key = os.urandom(32)

    client_keys = make_client_keypairs(clients)
    hh = ExponentHomomorphicHash(dim=dim, seed=seed, prime_bits=int(_cfg_get(cfg, "baseline", "priverifl_a", "hh_prime_bits", default=127)))

    init_model_hash = model_hash(model)
    init_public = {
        "scheme": "PriVeriFL-A-full",
        "modelHash": init_model_hash,
        "dim": dim,
        "paillier_n": str(pkey.public.n),
        "low_bits": low_bits,
        "slot_bits": slot_bits,
        "pack_size": pack_size,
        "homomorphic_hash": hh.public_params(),
    }
    for cid in range(1, clients + 1):
        comm.add(0, "Server", f"C{cid}", "InitModel", init_public)

    loss0, acc0 = evaluate(model, test_loader, device=device)
    metrics_rows.append({"round": 0, "test_loss": loss0, "test_accuracy": acc0, "effective_clients": 0, "dropout_clients": 0})

    accepted = True
    latest_root = bytes32_hex({"scheme": "baseline_priverifl_a_full", "modelHash": init_model_hash})
    rounds_done = 0
    rounds = int(cfg["federated"]["rounds"])
    exp_t0 = time.perf_counter()

    for r in range(1, rounds + 1):
        r_t0 = time.perf_counter()
        active, dropped = active_clients_for_round(cfg, r)
        active_total_samples = sum(len(train_loaders[cid].dataset) for cid in active)
        model_hash_r = model_hash(model)

        c_low_vectors: List[List[int]] = []
        high_plain_sums = np.zeros(dim, dtype=object)
        hh_digests: List[int] = []
        local_losses: List[float] = []
        signature_ok = True
        decrypt_ok = True
        upload_receipts: List[Dict[str, Any]] = []

        for cid in active:
            x, local_loss, weight = train_and_quantize_update(model, train_loaders[cid], active_total_samples, cfg, timer, r, cid, device)
            local_losses.append(local_loss)

            with timer.record(r, "client_priverifl_bit_segment", "split signed update into high and low bit segments", cid=cid):
                high, low = split_signed_by_low_bits(x, low_bits=low_bits)

            with timer.record(r, "client_priverifl_packed_paillier_encrypt", "BatchCrypt-style packed Paillier for low-bit segment", cid=cid):
                c_low = encrypt_packed_vector(pkey.public, _safe_int_list(low), slot_bits=slot_bits, pack_size=pack_size)

            aad = {"scheme": "PriVeriFL-A-full", "r": r, "cid": cid, "modelHash": model_hash_r, "segment": "high"}
            with timer.record(r, "client_priverifl_symmetric_encrypt", "AES-GCM encrypt high segment", cid=cid):
                high_ct = aesgcm_encrypt_json(high_key, _safe_int_list(high), aad=aad)

            with timer.record(r, "client_priverifl_homomorphic_hash", "homomorphic hash over complete signed update", cid=cid):
                hh_i = hh.digest(x.astype(object))

            receipt = {
                "scheme": "PriVeriFL-A-full",
                "r": r,
                "i": cid,
                "modelHash": model_hash_r,
                "lowBits": low_bits,
                "slotBits": slot_bits,
                "packSize": pack_size,
                "cLowHash": bytes32_hex(c_low),
                "highCipherHash": bytes32_hex(high_ct.to_dict()),
                "hh": str(hh_i),
                "weight": weight,
            }
            with timer.record(r, "client_receipt_sign", "sign PriVeriFL-A upload receipt", cid=cid):
                sig = sign_obj(client_keys[cid].private_key, receipt)

            upload_public = {
                "Receipt": receipt,
                "sigUp": sig,
                "CLow": [str(v) for v in c_low],
                "HighCT": high_ct.to_dict(),
                "HH": str(hh_i),
            }
            comm.add(r, f"C{cid}", "Server", "UpMsg", upload_public)
            if not verify_obj(client_keys[cid].public_pem, sig, receipt):
                signature_ok = False

            with timer.record(r, "server_priverifl_symmetric_decrypt", "decrypt high segment for low-sensitivity aggregation", cid=cid):
                try:
                    high_dec = aesgcm_decrypt_json(high_key, high_ct, aad=aad)
                    high_plain_sums += np.array([int(v) for v in high_dec], dtype=object)
                except Exception:
                    decrypt_ok = False

            c_low_vectors.append(c_low)
            hh_digests.append(hh_i)
            upload_receipts.append(receipt)

        with timer.record(r, "server_priverifl_packed_paillier_aggregate", "aggregate packed low-bit ciphertexts"):
            c_low_agg = aggregate_packed_ciphertexts(pkey.public, c_low_vectors)
        cagg_hash = bytes32_hex(c_low_agg)
        comm.add(r, "Server", "Verifier", "AggMsg", {
            "scheme": "PriVeriFL-A-full",
            "r": r,
            "CLowAggHash": cagg_hash,
            "CLowAgg": [str(v) for v in c_low_agg],
            "highSumHash": bytes32_hex(_safe_int_list(high_plain_sums)),
            "HHList": [str(v) for v in hh_digests],
        })

        with timer.record(r, "server_priverifl_packed_paillier_decrypt", "decrypt aggregate packed low-bit segment"):
            low_sum = decrypt_packed_vector(pkey.public, pkey.private, c_low_agg, total_count=dim, slot_bits=slot_bits, pack_size=pack_size)

        with timer.record(r, "server_priverifl_reconstruct_update", "merge aggregated high and low segments"):
            x_agg = merge_signed_from_low_bits(high_plain_sums, low_sum, low_bits=low_bits)

        with timer.record(r, "server_priverifl_verify", "verify upload signatures and homomorphic hash"):
            hh_ok = hh.verify_sum(x_agg.astype(object), hh_digests)
            accepted = bool(accepted and signature_ok and decrypt_ok and hh_ok)

        with timer.record(r, "server_model_update", "apply aggregated update"):
            update_global_model(model, x_agg, cfg)
        with timer.record(r, "server_evaluate", "test evaluation"):
            test_loss, test_acc = evaluate(model, test_loader, device=device)

        model_hash_next = model_hash(model)
        latest_root = bytes32_hex({
            "prev": latest_root,
            "r": r,
            "modelHashR": model_hash_r,
            "modelHashNext": model_hash_next,
            "cLowAggHash": cagg_hash,
            "hhOk": hh_ok,
            "signatureOk": signature_ok,
        })
        rounds_done = r

        metrics_rows.append({"round": r, "test_loss": test_loss, "test_accuracy": test_acc, "effective_clients": len(active), "dropout_clients": len(dropped)})
        crypto_rows.extend([
            {"round": r, "metric": "model_dimension", "value": dim},
            {"round": r, "metric": "effective_clients", "value": len(active)},
            {"round": r, "metric": "dropout_clients", "value": len(dropped)},
            {"round": r, "metric": "low_bits_paillier_encrypted", "value": low_bits},
            {"round": r, "metric": "packed_slot_bits", "value": slot_bits},
            {"round": r, "metric": "actual_pack_size", "value": pack_size},
            {"round": r, "metric": "paillier_encryptions", "value": len(active) * len(c_low_vectors[0]) if c_low_vectors else 0},
            {"round": r, "metric": "paillier_plain_slots_covered", "value": len(active) * dim},
            {"round": r, "metric": "paillier_decryptions", "value": len(c_low_agg)},
            {"round": r, "metric": "aes_gcm_encryptions", "value": len(active)},
            {"round": r, "metric": "aes_gcm_decryptions", "value": len(active)},
            {"round": r, "metric": "homomorphic_hash_client_ops", "value": len(active)},
            {"round": r, "metric": "homomorphic_hash_verify_ops", "value": 1},
            {"round": r, "metric": "ecdsa_signatures", "value": len(active)},
            {"round": r, "metric": "ecdsa_verifications", "value": len(active)},
        ])
        baseline_rows.append({
            "round": r,
            "scheme": "PriVeriFL-A-full",
            "signature_ok": bool(signature_ok),
            "aes_decrypt_ok": bool(decrypt_ok),
            "homomorphic_hash_ok": bool(hh_ok),
            "accepted_so_far": bool(accepted),
            "effective_clients": len(active),
            "dropout_clients": len(dropped),
            "round_wall_seconds": time.perf_counter() - r_t0,
        })
        trace["rounds"].append({"round": r, "signature_ok": signature_ok, "aes_decrypt_ok": decrypt_ok, "hh_ok": hh_ok, "active": active, "dropped": dropped, "test_accuracy": test_acc, "test_loss": test_loss})
        if not accepted:
            break

    timer.add(0, "experiment_wall", time.perf_counter() - exp_t0, detail="total PriVeriFL-A-full baseline wall-clock time")
    write_common_outputs(
        out_dir,
        cfg=cfg,
        scheme_name="baseline_priverifl_a_full",
        accepted=accepted,
        rounds_done=rounds_done,
        latest_root=latest_root,
        metrics_rows=metrics_rows,
        runtime=timer,
        comm=comm,
        crypto_rows=crypto_rows,
        trace=trace,
        blockchain_rows=[{"round": "N/A", "tx_type": "N/A", "gas_used": 0, "latency_sec": 0.0, "note": "PriVeriFL-A does not use our blockchain audit board"}],
        baseline_rows=baseline_rows,
    )
    return {"accepted": accepted, "rounds": rounds_done, "output_dir": str(out_dir), "latestRoot": latest_root, "low_bits": low_bits, "slot_bits": slot_bits, "pack_size": pack_size}
