# Ours-packed / BatchCrypt-style slot_bits 测试包

## 目的

本包在 Ours-basic 基础上增加 **Paillier ciphertext packing / BatchCrypt-style packing**，用于测试不同 `slot_bits` 的正确性和耗时。

当前版本采用 **lossless modular-residue packing**：

- 不改变训练算法；
- 不改变零和掩码；
- 不改变 Pedersen 向量承诺；
- 不改变 auditRoot / FinalTx / 第三方公开验证语义；
- 只减少 Paillier 密文数量、加密次数、聚合次数和解密次数。

## 建议测试轮次

1. **2轮 smoke test**：先测 `slot_bits = 34, 40, 48`，确认 accepted=True、无溢出、结果文件正常。
2. **10轮选择实验**：对 2轮通过的 slot_bits 再跑 10轮，用于选择正式配置。
3. **50轮正式实验**：只对最终选定的 slot_bits 跑 50轮。

不建议一开始用 50轮测所有 slot_bits。

## 安装补丁

```bash
cd /root
unzip -o ours_packed_slotbits_test_pack.zip

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

python3 /root/ours_packed_slotbits_test_pack/patch/apply_ours_packed_patch.py
python3 /root/ours_packed_slotbits_test_pack/config_tools/make_ours_packed_slotbits_configs.py
chmod +x /root/ours_packed_slotbits_test_pack/scripts/*.sh
```

补丁会备份原文件，备份后缀为：

```text
.before_ours_packed
```

## 跑 2轮 slot_bits 测试

```bash
tmux new -d -s packed_slot2 "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && stdbuf -oL -eL /root/ours_packed_slotbits_test_pack/scripts/run_ours_packed_slotbits_2r.sh | tee /root/packed_slot2.log"
```

查看状态：

```bash
tmux capture-pane -t packed_slot2:0 -p | tail -n 120
tail -n 120 /root/packed_slot2.log
/root/ours_packed_slotbits_test_pack/scripts/check_ours_packed_slotbits_status.sh
```

完成后结果包：

```text
/root/ours_packed_slotbits_2r_results.zip
```

## 跑 10轮选择实验

默认跑 34、40、48：

```bash
tmux new -d -s packed_slot10 "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && stdbuf -oL -eL /root/ours_packed_slotbits_test_pack/scripts/run_ours_packed_slotbits_10r.sh | tee /root/packed_slot10.log"
```

只跑指定 slot_bits，例如只跑 34 和 40：

```bash
tmux new -d -s packed_slot10 "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && SLOT_BITS_LIST='34 40' stdbuf -oL -eL /root/ours_packed_slotbits_test_pack/scripts/run_ours_packed_slotbits_10r.sh | tee /root/packed_slot10.log"
```

完成后结果包：

```text
/root/ours_packed_slotbits_10r_results.zip
```

## 汇总分析

```bash
cd /root/fpa5
python3 /root/ours_packed_slotbits_test_pack/scripts/analyze_ours_packed_slotbits.py | tee /root/ours_packed_slotbits_analysis.csv
```

## 选择标准

优先选择：

1. `accepted=True`
2. 10轮内无 `CS open check failed`
3. `client_paillier_encrypt` 最低
4. `combine_decrypt` 最低
5. `communication_summary_by_type.csv` 中 UpMsg / AggMsg 总量最低
6. `client_upload_parallel_wall` 稳定

一般预期：

- `slot_bits=34`：最快，密文数最少，但余量较小；
- `slot_bits=40`：推荐默认，速度与安全余量平衡；
- `slot_bits=48`：更稳但略慢。

若 34、40、48 都通过，正式优先用 34 或 40；若 34 不稳定，用 40；若 40 不稳定，用 48。
