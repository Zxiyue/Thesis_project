from __future__ import annotations

from pathlib import Path
import csv

ROOT = Path("/root/fpa5")


def read_csv(path: Path):
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def fnum(x):
    try:
        return float(x)
    except Exception:
        return 0.0


def analyze_dir(name: str):
    d = ROOT / "outputs" / name
    metrics = read_csv(d / "metrics_round.csv")
    runtime = read_csv(d / "runtime_cost.csv")
    comm = read_csv(d / "communication_summary_by_type.csv")
    verify = read_csv(d / "verify_result.csv")
    if not d.exists():
        return None
    def sum_stage(stage):
        return sum(fnum(r.get("seconds", 0)) for r in runtime if r.get("stage") == stage)
    def avg_stage(stage):
        vals = [fnum(r.get("seconds", 0)) for r in runtime if r.get("stage") == stage]
        return sum(vals)/len(vals) if vals else 0.0
    total_comm = sum(fnum(r.get("bytes", r.get("total_bytes", 0))) for r in comm)
    final_acc = metrics[-1].get("test_accuracy", "") if metrics else ""
    accepted = verify[-1].get("accepted", "") if verify else ""
    rounds = verify[-1].get("rounds", "") if verify else ""
    return {
        "name": name,
        "accepted": accepted,
        "rounds": rounds,
        "final_acc": final_acc,
        "client_paillier_pack_sum": sum_stage("client_paillier_pack"),
        "client_paillier_encrypt_sum": sum_stage("client_paillier_encrypt"),
        "client_upload_parallel_wall_avg": avg_stage("client_upload_parallel_wall"),
        "combine_decrypt_sum": sum_stage("combine_decrypt"),
        "cs_aggregate_sum": sum_stage("cs_aggregate"),
        "kgc_compensation_sum": sum_stage("kgc_compensation"),
        "total_comm_summary_bytes": total_comm,
    }


def main():
    names = []
    for rounds in [2, 10]:
        for s in [34, 40, 48]:
            names.append(f"ours_packed_mnist_iid_{rounds}r_p2048_s{s}")
    rows = [analyze_dir(n) for n in names]
    rows = [r for r in rows if r]
    if not rows:
        print("No result dirs found.")
        return
    headers = list(rows[0].keys())
    print(",".join(headers))
    for r in rows:
        print(",".join(str(r.get(h, "")) for h in headers))


if __name__ == "__main__":
    main()
