#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}

check_hardhat() {
  curl -s -X POST http://127.0.0.1:8545 \
    -H "Content-Type: application/json" \
    --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' | grep -q '"result"'
}

ensure_hardhat() {
  if ! check_hardhat; then
    echo "[INFO] Hardhat not reachable. Starting hardhat..."
    tmux kill-session -t hardhat 2>/dev/null || true
    tmux new -d -s hardhat "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && npx hardhat node > /root/hardhat.log 2>&1"
    sleep 5
  fi
  if ! check_hardhat; then
    echo "[ERROR] Hardhat still not reachable."
    exit 1
  fi
}

run_one() {
  local cfg="$1"
  local name="$2"
  local rounds="$3"
  echo
  echo "================================================================"
  echo "[RUN] ${name}"
  echo "[CFG] ${cfg}"
  echo "================================================================"

  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  pkill -f "run_kgc_server.py" || true
  pkill -f "run_cs_server.py" || true
  pkill -f "run_client_server.py" || true
  pkill -f "start_experiment.py" || true
  sleep 3
  rm -rf "outputs/${name}"

  npx hardhat run scripts/deploy.js --network localhost || { echo "[ERROR] deploy failed"; exit 1; }
  python3 scripts/start_all_entities.py --config "${cfg}" --clients 5 || { echo "[ERROR] start_all_entities failed"; exit 1; }
  python3 scripts/start_experiment.py --config "${cfg}" || echo "[WARN] start_experiment returned non-zero; continue polling."

  local done_flag=0
  local max_poll="${MAX_POLL:-720}"
  for i in $(seq 1 ${max_poll}); do
    echo
    echo "---- $(date) ${name} status ${i}/${max_poll} ----"
    tail -n 5 "outputs/${name}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
    cat "outputs/${name}/verify_result.csv" 2>/dev/null || echo "verify not ready"
    if [ -f "outputs/${name}/verify_result.csv" ] && grep -q "True,${rounds}" "outputs/${name}/verify_result.csv"; then
      done_flag=1
      break
    fi
    sleep 30
  done

  python3 scripts/collect_results.py --config "${cfg}" || true
  python3 scripts/stop_all_entities.py --config "${cfg}" || true

  if [ "${done_flag}" -ne 1 ]; then
    echo "[ERROR] ${name} did not finish correctly."
    exit 1
  fi

  cd /root/fpa5
  zip -qr "/root/${name}_results.zip" "outputs/${name}"
}

ensure_hardhat
SLOT_BITS_LIST="${SLOT_BITS_LIST:-34 40 48}"
for s in ${SLOT_BITS_LIST}; do
  run_one "configs/ours_packed_mnist_iid_10r_p2048_s${s}.yaml" "ours_packed_mnist_iid_10r_p2048_s${s}" 10
done

cd /root
zip -qr /root/ours_packed_slotbits_10r_results.zip $(for s in ${SLOT_BITS_LIST}; do echo "ours_packed_mnist_iid_10r_p2048_s${s}_results.zip"; done)

echo "[DONE] /root/ours_packed_slotbits_10r_results.zip"
