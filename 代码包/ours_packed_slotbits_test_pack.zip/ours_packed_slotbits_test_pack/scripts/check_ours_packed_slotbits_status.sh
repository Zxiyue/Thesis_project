#!/usr/bin/env bash
set -uo pipefail
cd /root/fpa5
for d in outputs/ours_packed_mnist_iid_2r_p2048_s34 \
         outputs/ours_packed_mnist_iid_2r_p2048_s40 \
         outputs/ours_packed_mnist_iid_2r_p2048_s48 \
         outputs/ours_packed_mnist_iid_10r_p2048_s34 \
         outputs/ours_packed_mnist_iid_10r_p2048_s40 \
         outputs/ours_packed_mnist_iid_10r_p2048_s48; do
  echo
  echo "================ $d ================"
  ls -lah "$d" 2>/dev/null || { echo "not created"; continue; }
  echo "--- metrics tail ---"
  tail -n 8 "$d/metrics_round.csv" 2>/dev/null || true
  echo "--- verify ---"
  cat "$d/verify_result.csv" 2>/dev/null || true
  echo "--- communication summary ---"
  cat "$d/communication_summary_by_type.csv" 2>/dev/null || true
  echo "--- runtime key rows ---"
  grep -E "client_paillier_pack|client_paillier_encrypt|client_upload_parallel_wall|combine_decrypt|cs_aggregate|kgc_compensation" "$d/runtime_cost.csv" 2>/dev/null | tail -n 30 || true
done
echo
ls -lh /root/ours_packed_slotbits_2r_results.zip /root/ours_packed_slotbits_10r_results.zip 2>/dev/null || true
