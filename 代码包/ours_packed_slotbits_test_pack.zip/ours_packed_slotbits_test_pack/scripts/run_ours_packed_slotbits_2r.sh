#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}

check_hardhat() {
  curl -s -X POST http://127.0.0.1:8545 \
    -H "Content-Type: application/json" \
    --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' | grep -q '"result"'
}

ensure_hardhat() {
  if ! check_hardhat; then
    echo "[INFO] Hardhat not reachable. Starting hardhat..."
    tmux kill-session -t hardhat 2>/dev/null || true
    tmux new -d -s hardhat "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && npx hardhat node > /root/hardhat.log 2>&1"
    sleep 5
    tail -n 20 /root/hardhat.log || true
  fi
  if ! check_hardhat; then
    echo "[ERROR] Hardhat still not reachable."
    exit 1
  fi
}

run_one() {
  local cfg="$1"
  local name="$2"
  local rounds="$3"
  echo
  echo "================================================================"
  echo "[RUN] ${name}"
  echo "[CFG] ${cfg}"
  echo "================================================================"

  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  pkill -f "run_kgc_server.py" || true
  pkill -f "run_cs_server.py" || true
  pkill -f "run_client_server.py" || true
  pkill -f "start_experiment.py" || true
  sleep 3
  rm -rf "outputs/${name}"

  echo "[INFO] Deploying audit board contract..."
  npx hardhat run scripts/deploy.js --network localhost || { echo "[ERROR] deploy failed"; exit 1; }

  echo "[INFO] Starting KGC/CS/clients..."
  python3 scripts/start_all_entities.py --config "${cfg}" --clients 5 || { echo "[ERROR] start_all_entities failed"; exit 1; }

  echo "[INFO] Starting experiment..."
  python3 scripts/start_experiment.py --config "${cfg}" || echo "[WARN] start_experiment returned non-zero; continue polling."

  local done_flag=0
  local max_poll="${MAX_POLL:-240}"
  for i in $(seq 1 ${max_poll}); do
    echo
    echo "---- $(date) ${name} status ${i}/${max_poll} ----"
    tail -n 5 "outputs/${name}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
    cat "outputs/${name}/verify_result.csv" 2>/dev/null || echo "verify not ready"
    if [ -f "outputs/${name}/verify_result.csv" ] && grep -q "True,${rounds}" "outputs/${name}/verify_result.csv"; then
      done_flag=1
      echo "[INFO] ${name} accepted=True rounds=${rounds}"
      break
    fi
    sleep 30
  done

  python3 scripts/collect_results.py --config "${cfg}" || true
  python3 scripts/stop_all_entities.py --config "${cfg}" || true

  if [ "${done_flag}" -ne 1 ]; then
    echo "[ERROR] ${name} did not finish correctly."
    exit 1
  fi

  cd /root/fpa5
  zip -qr "/root/${name}_results.zip" "outputs/${name}"
  echo "[INFO] Result zip: /root/${name}_results.zip"
}

ensure_hardhat
run_one "configs/ours_packed_mnist_iid_2r_p2048_s34.yaml" "ours_packed_mnist_iid_2r_p2048_s34" 2
run_one "configs/ours_packed_mnist_iid_2r_p2048_s40.yaml" "ours_packed_mnist_iid_2r_p2048_s40" 2
run_one "configs/ours_packed_mnist_iid_2r_p2048_s48.yaml" "ours_packed_mnist_iid_2r_p2048_s48" 2

cd /root
zip -qr /root/ours_packed_slotbits_2r_results.zip \
  ours_packed_mnist_iid_2r_p2048_s34_results.zip \
  ours_packed_mnist_iid_2r_p2048_s40_results.zip \
  ours_packed_mnist_iid_2r_p2048_s48_results.zip

echo "[DONE] /root/ours_packed_slotbits_2r_results.zip"
