from __future__ import annotations

from pathlib import Path
import yaml

ROOT = Path("/root/fpa5")


def load_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def write_yaml(path: Path, cfg: dict) -> None:
    path.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding="utf-8")
    print("wrote", path)


def base_config_name() -> str:
    if (ROOT / "configs/mnist_iid_50r_lr020_main.yaml").exists():
        return "mnist_iid_50r_lr020_main.yaml"
    return "mnist_iid_50r_main.yaml"


def make_config(out_name: str, rounds: int, slot_bits: int, output_name: str) -> None:
    cfg = load_yaml(ROOT / "configs" / base_config_name())
    cfg["output_dir"] = f"outputs/{output_name}"
    cfg["federated"]["rounds"] = int(rounds)
    cfg["federated"]["local_lr"] = 0.20
    cfg["federated"]["server_lr"] = 1.0
    # Disable scheduled dropout for slot-bit sensitivity to isolate packing overhead.
    cfg["federated"]["dropout"] = {}
    cfg.setdefault("crypto", {})
    cfg["crypto"]["paillier_bits"] = 2048
    cfg["crypto"]["packing"] = {
        "enabled": True,
        "scheme": "mod_q_residue",
        "slot_bits": int(slot_bits),
        "guard_bits": 1,
        "allow_unsafe": False,
    }
    cfg.setdefault("runtime", {})
    cfg["runtime"]["parallel_clients"] = True
    cfg["runtime"]["max_client_workers"] = 5
    cfg.setdefault("distributed", {})
    cfg["distributed"]["enabled"] = True
    cfg["distributed"]["client_mode"] = "individual"
    cfg.setdefault("communication", {})
    cfg["communication"]["enabled"] = True
    cfg["communication"]["mode"] = "http"
    cfg["communication"]["timeout_seconds"] = 3600
    write_yaml(ROOT / "configs" / out_name, cfg)


def main() -> None:
    for slot_bits in [34, 40, 48]:
        make_config(
            f"ours_packed_mnist_iid_2r_p2048_s{slot_bits}.yaml",
            2,
            slot_bits,
            f"ours_packed_mnist_iid_2r_p2048_s{slot_bits}",
        )
        make_config(
            f"ours_packed_mnist_iid_10r_p2048_s{slot_bits}.yaml",
            10,
            slot_bits,
            f"ours_packed_mnist_iid_10r_p2048_s{slot_bits}",
        )


if __name__ == "__main__":
    main()
