from __future__ import annotations

import re
from pathlib import Path
import shutil

ROOT = Path("/root/fpa5")


def backup(path: Path) -> None:
    bak = path.with_suffix(path.suffix + ".before_ours_packed")
    if path.exists() and not bak.exists():
        shutil.copy2(path, bak)


def replace_once(text: str, old: str, new: str, path: str) -> str:
    if old not in text:
        raise RuntimeError(f"pattern not found in {path}:\n{old[:300]}")
    return text.replace(old, new, 1)


def patch_entities() -> None:
    path = ROOT / "fl_audit/protocol/entities.py"
    backup(path)
    s = path.read_text(encoding="utf-8")

    if "from fl_audit.crypto import packing as cipher_packing" not in s:
        s = replace_once(
            s,
            "from fl_audit.crypto import paillier\n",
            "from fl_audit.crypto import paillier\nfrom fl_audit.crypto import packing as cipher_packing\n",
            str(path),
        )

    if 'q = int(cfg["encoding"]["q"])' not in s:
        s = replace_once(
            s,
            '        scale = int(cfg["encoding"]["scale"])\n\n        t0 = tic()\n',
            '        scale = int(cfg["encoding"]["scale"])\n        q = int(cfg["encoding"]["q"])\n\n        t0 = tic()\n',
            str(path),
        )

    old_encrypt = '''        t0 = tic()
        c_vec = [paillier.encrypt(paillier_pub, int(v)) for v in x_mask.tolist()]
        toc(t0, "client_paillier_encrypt", "coordinate-wise Paillier encryption")
'''
    new_encrypt = '''        packing_cfg = cfg.get("crypto", {}).get("packing", {}) or {}
        packing_enabled = bool(packing_cfg.get("enabled", False))
        pack_meta = {"enabled": False}
        if packing_enabled:
            slot_bits = int(packing_cfg.get("slot_bits", 40))
            slots = cipher_packing.slots_per_cipher(paillier_pub, slot_bits)
            min_safe = cipher_packing.minimum_safe_slot_bits(
                q,
                int(cfg["federated"].get("clients", 1)) + 1,
                int(packing_cfg.get("guard_bits", 1)),
            )
            if slot_bits < min_safe and not bool(packing_cfg.get("allow_unsafe", False)):
                raise ValueError(f"slot_bits={slot_bits} is below conservative safe bound {min_safe}")
            t0 = tic()
            packed_plain = cipher_packing.pack_vector_mod_q(x_mask.tolist(), q, slot_bits, slots)
            toc(t0, "client_paillier_pack", f"pack {len(x_mask)} coordinates into {len(packed_plain)} plaintexts")
            t0 = tic()
            c_vec = [paillier.encrypt(paillier_pub, int(v)) for v in packed_plain]
            toc(t0, "client_paillier_encrypt", f"packed Paillier encryption slot_bits={slot_bits}, slots={slots}, ciphers={len(c_vec)}")
            pack_meta = {
                "enabled": True,
                "scheme": "mod_q_residue",
                "slotBits": slot_bits,
                "slotsPerCipher": slots,
                "dim": int(len(x_mask)),
                "q": int(q),
                "cipherCount": int(len(c_vec)),
            }
        else:
            t0 = tic()
            c_vec = [paillier.encrypt(paillier_pub, int(v)) for v in x_mask.tolist()]
            toc(t0, "client_paillier_encrypt", "coordinate-wise Paillier encryption")
'''
    if 'client_paillier_pack' not in s:
        s = replace_once(s, old_encrypt, new_encrypt, str(path))

    if '"packing": pack_meta' not in s:
        s = replace_once(
            s,
            '''            "cHash": c_hash,
            "Com": str(com),
        }
''',
            '''            "cHash": c_hash,
            "Com": str(com),
            "packing": pack_meta,
        }
''',
            str(path),
        )
        s = replace_once(
            s,
            '''            "cHash": c_hash,
            "Com": str(com),
            "Receipt": receipt,
''',
            '''            "cHash": c_hash,
            "Com": str(com),
            "packing": pack_meta,
            "Receipt": receipt,
''',
            str(path),
        )

    if '"packing_cipher_count":' not in s:
        s = replace_once(
            s,
            '''            "x_l1": int(np.abs(x).sum()),
            "xmask_l1": int(np.abs(x_mask).sum()),
            "timings": local_timings,
''',
            '''            "x_l1": int(np.abs(x).sum()),
            "xmask_l1": int(np.abs(x_mask).sum()),
            "packing_enabled": bool(pack_meta.get("enabled", False)),
            "packing_slot_bits": int(pack_meta.get("slotBits", 0) or 0),
            "packing_slots_per_cipher": int(pack_meta.get("slotsPerCipher", 0) or 0),
            "packing_cipher_count": int(pack_meta.get("cipherCount", len(c_vec))),
            "timings": local_timings,
''',
            str(path),
        )

    if '"packing": cfg.get("crypto", {}).get("packing", {"enabled": False}),' not in s:
        s = replace_once(
            s,
            '''            "pp_com": {"p": str(ped_params.p), "q": str(ped_params.q), "h": str(ped_params.h), "g_vec_hash": bytes32_hex(ped_params.g_vec)},
        }
''',
            '''            "pp_com": {"p": str(ped_params.p), "q": str(ped_params.q), "h": str(ped_params.h), "g_vec_hash": bytes32_hex(ped_params.g_vec)},
            "packing": cfg.get("crypto", {}).get("packing", {"enabled": False}),
        }
''',
            str(path),
        )

    new_make_comp = '''    def make_compensation(self, r: int, D: List[int], paillier_pub, ped_params, cfg: Dict[str, Any] | None = None):
        dim = len(ped_params.g_vec)
        cfg = cfg or {}
        packing_cfg = cfg.get("crypto", {}).get("packing", {}) or {}
        packing_enabled = bool(packing_cfg.get("enabled", False))
        slot_bits = int(packing_cfg.get("slot_bits", 40))
        q = int(cfg.get("encoding", {}).get("q", 1000000007))
        if packing_enabled:
            slots = cipher_packing.slots_per_cipher(paillier_pub, slot_bits)
            packed_count = cipher_packing.packed_cipher_count(dim, paillier_pub, slot_bits)
        else:
            slots = 0
            packed_count = dim
        if D:
            m_drop = sum((self.masks[(r, cid)] for cid in D), np.zeros(dim, dtype=np.int64))
            rho_drop = sum((self.rhos[(r, cid)] for cid in D), 0) % ped_params.q
            if packing_enabled:
                packed_drop = cipher_packing.pack_vector_mod_q(m_drop.tolist(), q, slot_bits, slots)
                cdrop = [paillier.encrypt(paillier_pub, int(v)) for v in packed_drop]
            else:
                cdrop = [paillier.encrypt(paillier_pub, int(v)) for v in m_drop.tolist()]
            com_drop = pedersen.commit(ped_params, m_drop.tolist(), rho_drop)
        else:
            # No-dropout optimization: do not encrypt the zero vector.
            # Paillier aggregation uses multiplication in ciphertext space, so 1 is the identity.
            # Pedersen commitments are multiplied in the group, so 1 is also the identity.
            m_drop = np.zeros(dim, dtype=np.int64)
            rho_drop = 0
            cdrop = [1] * packed_count
            com_drop = 1
        return m_drop, rho_drop, cdrop, com_drop
'''
    s, n = re.subn(
        r'    def make_compensation\(self, r: int, D: List\[int\], paillier_pub, ped_params\):\n.*?        return m_drop, rho_drop, cdrop, com_drop\n',
        new_make_comp,
        s,
        flags=re.S,
    )
    if n != 1:
        raise RuntimeError(f"failed to patch make_compensation in {path}; replacements={n}")

    new_recover = '''    def recover_lambda_and_decrypt(self, share_msgs: List[Dict[str, Any]], client_pubkeys: Dict[int, str], field_prime: int, threshold: int, paillier_keypair, cagg: List[int], r: int, alpha: str, cfg: Dict[str, Any] | None = None, dim: int | None = None):
        shares = []
        for sm in share_msgs:
            msg = sm["ShareMsg"]
            cid = int(msg["j"])
            if verify_obj(client_pubkeys[cid], sm["sigShare"], msg):
                shares.append((cid, int(msg["share"])))
            if len(shares) >= threshold:
                break
        if len(shares) < threshold:
            raise RuntimeError("not enough valid shares")
        lam = reconstruct(shares, field_prime)
        # The CS only needs the public key and threshold-recovered lambda.
        # If a full keypair is passed by the legacy single-process runner, keep
        # compatibility. In distributed mode, mu is recomputed from public data
        # and recovered lambda, so KGC does not disclose the Paillier private key.
        pub = getattr(paillier_keypair, "public", paillier_keypair)
        if hasattr(paillier_keypair, "private"):
            mu = paillier_keypair.private.mu
        else:
            mu = pow(paillier.L(pow(pub.g, lam, pub.n2), pub.n), -1, pub.n)
        priv = paillier.PaillierPrivateKey(lam=lam, mu=mu)
        plain = [paillier.decrypt(pub, priv, int(c)) for c in cagg]
        cfg = cfg or {}
        packing_cfg = cfg.get("crypto", {}).get("packing", {}) or {}
        if bool(packing_cfg.get("enabled", False)):
            if dim is None:
                raise ValueError("dim is required when Paillier packing is enabled")
            slot_bits = int(packing_cfg.get("slot_bits", 40))
            q = int(cfg.get("encoding", {}).get("q", 1000000007))
            slots = cipher_packing.slots_per_cipher(pub, slot_bits)
            xagg = cipher_packing.unpack_vector_mod_q(plain, int(dim), q, slot_bits, slots)
        else:
            xagg = np.array(plain, dtype=np.int64)
        return xagg, shares
'''
    s, n = re.subn(
        r'    def recover_lambda_and_decrypt\(self, share_msgs: List\[Dict\[str, Any\]\], client_pubkeys: Dict\[int, str\], field_prime: int, threshold: int, paillier_keypair, cagg: List\[int\], r: int, alpha: str\):\n.*?        return xagg, shares\n',
        new_recover,
        s,
        flags=re.S,
    )
    if n != 1:
        raise RuntimeError(f"failed to patch recover_lambda_and_decrypt in {path}; replacements={n}")

    path.write_text(s, encoding="utf-8")


def patch_run_py() -> None:
    path = ROOT / "run.py"
    if not path.exists():
        return
    backup(path)
    s = path.read_text(encoding="utf-8")
    s = s.replace(
        "kgc.make_compensation(r, D_r, pkey.public, ped_params)",
        "kgc.make_compensation(r, D_r, pkey.public, ped_params, cfg=cfg)",
    )
    s = s.replace(
        "share_msgs, client_pubkeys, setup[\"shareField\"], int(cfg[\"federated\"][\"threshold\"]), pkey, cagg, r, alpha\n            )",
        "share_msgs, client_pubkeys, setup[\"shareField\"], int(cfg[\"federated\"][\"threshold\"]), pkey, cagg, r, alpha, cfg=cfg, dim=dim\n            )",
    )
    path.write_text(s, encoding="utf-8")


def patch_cs_server() -> None:
    path = ROOT / "scripts/run_cs_server.py"
    backup(path)
    s = path.read_text(encoding="utf-8")
    if "cfg=self.cfg" not in s[s.find("recover_lambda_and_decrypt"):s.find("recover_lambda_and_decrypt")+600]:
        s = s.replace(
            '''                cagg,
                r,
                alpha,
            )
''',
            '''                cagg,
                r,
                alpha,
                cfg=self.cfg,
                dim=int(get_vector(self.model).numel()),
            )
''',
            1,
        )
    path.write_text(s, encoding="utf-8")


def patch_kgc_server() -> None:
    path = ROOT / "scripts/run_kgc_server.py"
    backup(path)
    s = path.read_text(encoding="utf-8")
    s = s.replace(
        "self.kgc.make_compensation(r, D_r, self.pkey.public, self.ped_params)",
        "self.kgc.make_compensation(r, D_r, self.pkey.public, self.ped_params, cfg=self.cfg)",
    )
    path.write_text(s, encoding="utf-8")


def main() -> None:
    if not ROOT.exists():
        raise SystemExit("/root/fpa5 does not exist")
    packing_src = Path(__file__).resolve().parents[1] / "patch" / "packing.py"
    packing_dst = ROOT / "fl_audit/crypto/packing.py"
    backup(packing_dst) if packing_dst.exists() else None
    packing_dst.write_text(packing_src.read_text(encoding="utf-8"), encoding="utf-8")
    patch_entities()
    patch_run_py()
    patch_cs_server()
    patch_kgc_server()
    print("[OK] Ours-packed patch applied. Backups use suffix .before_ours_packed")


if __name__ == "__main__":
    main()
