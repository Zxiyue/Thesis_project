#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch

from common import Timer, seed_everything, write_csv, write_json
from model_data import (
    TinyCNN6794, assign_flat_model, build_data, evaluate, flatten_model,
    model_hash, parameter_count, train_local,
)


def main() -> None:
    ap = argparse.ArgumentParser(description="FedAvg 50-round baseline")
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--dataset", default="mnist")
    ap.add_argument("--split", choices=["iid", "noniid"], default="iid")
    ap.add_argument("--data-root", default="/root/fpa5/data")
    ap.add_argument("--rounds", type=int, default=50)
    ap.add_argument("--clients", type=int, default=5)
    ap.add_argument("--local-epochs", type=int, default=1)
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--test-batch-size", type=int, default=512)
    ap.add_argument("--lr", type=float, default=0.20)
    ap.add_argument("--momentum", type=float, default=0.0)
    ap.add_argument("--seed", type=int, default=20260714)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--max-samples-per-client", type=int, default=0)
    ap.add_argument("--download", action="store_true")
    args = ap.parse_args()

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    seed_everything(args.seed)
    device = torch.device(args.device)

    _, _, parts, loaders, test_loader = build_data(
        args.dataset, Path(args.data_root), args.split, args.clients,
        args.batch_size, args.test_batch_size, args.seed,
        args.max_samples_per_client, args.download,
    )
    weights = np.asarray([len(p) for p in parts], dtype=np.float64)
    weights /= weights.sum()

    model = TinyCNN6794().to(device)
    if parameter_count(model) != 6794:
        raise RuntimeError(f"unexpected model dimension: {parameter_count(model)}")

    metrics = []
    runtime = []
    total_started = time.perf_counter()
    acc0, loss0 = evaluate(model, test_loader, device)
    metrics.append({"round": 0, "test_accuracy": acc0, "test_loss": loss0, "model_hash": model_hash(model)})

    for rnd in range(1, args.rounds + 1):
        round_started = time.perf_counter()
        global_flat = flatten_model(model)
        deltas = []
        local_losses = []
        client_times = []
        for cid, loader in enumerate(loaders, start=1):
            with Timer() as t:
                delta, local_loss = train_local(
                    model, loader, device, args.lr, args.local_epochs, args.momentum
                )
            deltas.append(delta)
            local_losses.append(local_loss)
            client_times.append(t.elapsed)
        aggregate = torch.zeros_like(global_flat)
        for w, d in zip(weights, deltas):
            aggregate += float(w) * d
        assign_flat_model(model, global_flat + aggregate)
        with Timer() as eval_timer:
            acc, test_loss = evaluate(model, test_loader, device)
        round_wall = time.perf_counter() - round_started
        metrics.append({
            "round": rnd,
            "test_accuracy": acc,
            "test_loss": test_loss,
            "mean_local_loss": float(np.mean(local_losses)),
            "model_hash": model_hash(model),
        })
        runtime.append({
            "round": rnd,
            "local_train_sum_s": float(sum(client_times)),
            "local_train_parallel_wall_proxy_s": float(max(client_times)),
            "aggregation_s": max(0.0, round_wall - sum(client_times) - eval_timer.elapsed),
            "evaluation_s": eval_timer.elapsed,
            "round_wall_s": round_wall,
        })
        print(json.dumps({"round": rnd, "accuracy": acc, "round_wall_s": round_wall}), flush=True)

    total_wall = time.perf_counter() - total_started
    write_csv(out / "metrics_round.csv", metrics)
    write_csv(out / "runtime_cost.csv", runtime)
    write_csv(out / "communication_cost.csv", [{
        "scope": "fedavg_model_updates",
        "messages": args.rounds * args.clients,
        "bytes": args.rounds * args.clients * parameter_count(model) * 4,
        "note": "float32 model delta payload only",
    }])
    summary = {
        "experiment": "FedAvg",
        "dataset": args.dataset,
        "split": args.split,
        "rounds": args.rounds,
        "clients": args.clients,
        "model": "TinyCNN6794",
        "dimension": parameter_count(model),
        "final_accuracy": metrics[-1]["test_accuracy"],
        "total_wall_s": total_wall,
        "accepted": True,
        "security_components": [],
    }
    write_json(out / "summary.json", summary)
    write_json(out / "run_trace.json", {"summary": summary, "metrics": metrics, "runtime": runtime})
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
