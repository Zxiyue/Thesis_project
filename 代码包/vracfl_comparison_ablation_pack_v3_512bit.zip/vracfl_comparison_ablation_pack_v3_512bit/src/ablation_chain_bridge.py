#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, Mapping


def _last_json(stdout: str) -> Dict[str, Any]:
    for line in reversed(stdout.splitlines()):
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            return json.loads(line)
    raise RuntimeError(f"no JSON line in Hardhat output:\n{stdout[-4000:]}")


def _run(hh: Path, script: str, env: Mapping[str, Any]) -> Dict[str, Any]:
    merged = os.environ.copy()
    merged.update({k: str(v) for k, v in env.items()})
    cmd = ["npx", "hardhat", "run", f"scripts/{script}", "--network", "localhost"]
    t0 = time.perf_counter()
    proc = subprocess.run(cmd, cwd=str(hh), env=merged, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    wall = time.perf_counter() - t0
    if proc.returncode != 0:
        raise RuntimeError(f"Hardhat failed ({proc.returncode}): {' '.join(cmd)}\n{proc.stdout}")
    out = _last_json(proc.stdout)
    out["wallLatencySeconds"] = wall
    return out


def do_action(hh: Path, state: Path, action: str, values: Mapping[str, Any]) -> Dict[str, Any]:
    env = {"ABLATION_BOARD_STATE": str(state), "ABLATION_ACTION": action}
    env.update(values)
    return _run(hh, "ablation_action.js", env)


def replay(plan_path: Path, output_dir: Path, hardhat_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    state = output_dir / "ablation_board_state.json"
    deploy = _run(hardhat_dir, "ablation_deploy.js", {"ABLATION_BOARD_STATE": str(state)})
    init = plan["init"]
    init_r = do_action(hardhat_dir, state, "init", {
        "SYS_PARA_HASH": init["sysParaHash"], "U_ROOT": init["uRoot"],
        "MODEL_HASH0": init["modelHash0"], "AUDIT_ROOT0": init["auditRoot0"],
    })
    rows = []
    fault_isolation_ok = True
    for idx, item in enumerate(plan.get("actions", []), start=1):
        before = do_action(hardhat_dir, state, "status", {})
        typ = item["type"]
        if typ == "final":
            r = do_action(hardhat_dir, state, "final", {
                "ROUND": item["round"], "ALPHA": item["alpha"], "ROOT_UP": item["rootUp"],
                "COM_HASH": item["comAggHash"], "MODEL_PREV": item["modelHashPrev"],
                "MODEL_NEXT": item["modelHashNext"], "PREV_ROOT": item["prevAuditRoot"],
                "AUDIT_ROOT": item["auditRoot"],
            })
        elif typ == "hash":
            r = do_action(hardhat_dir, state, "hash", {
                "ROUND": item["round"], "MODEL_PREV": item["modelHashPrev"], "MODEL_NEXT": item["modelHashNext"],
            })
        elif typ == "fault":
            r = do_action(hardhat_dir, state, "fault", {
                "ROUND": item["round"], "ATTEMPT": item.get("attempt", 1), "ALPHA": item["alpha"],
                "FAULT_TYPE": item["faultTypeCode"], "FAULT_STAGE": item["failureStageCode"],
                "RESOLUTION": item["resolutionCode"], "EVIDENCE_HASH": item["evidenceHash"],
                "ANCHOR_ROOT": before["latestAuditRoot"],
            })
        else:
            raise ValueError(f"unknown action: {typ}")
        after = do_action(hardhat_dir, state, "status", {})
        isolated = True
        if typ == "fault":
            isolated = (
                before["latestAuditRoot"] == after["latestAuditRoot"]
                and before["currentModelHash"] == after["currentModelHash"]
                and before["latestFinalRound"] == after["latestFinalRound"]
                and before["latestHashRound"] == after["latestHashRound"]
            )
            fault_isolation_ok = fault_isolation_ok and isolated
        rows.append({
            "index": idx, "type": typ, "round": item.get("round", ""),
            "gasUsed": int(r.get("gasUsed", 0)), "wallLatencySeconds": float(r.get("wallLatencySeconds", 0)),
            "txHash": r.get("txHash", ""), "faultIsolationPassed": isolated if typ == "fault" else "",
        })
    final_status = do_action(hardhat_dir, state, "status", {})
    unauthorized = do_action(hardhat_dir, state, "unauthorized-fault", {
        "ALPHA": init["auditRoot0"], "EVIDENCE_HASH": init["sysParaHash"], "ANCHOR_ROOT": final_status["latestAuditRoot"],
    })
    expected = plan.get("expected", {})
    count_ok = (
        int(final_status["faultCount"]) == int(expected.get("faultTxCount", final_status["faultCount"]))
        and int(final_status["latestFinalRound"]) == int(expected.get("finalTxCount", final_status["latestFinalRound"]))
        and int(final_status["latestHashRound"]) == int(expected.get("hashTxCount", final_status["latestHashRound"]))
    )
    result = {
        "scenario": plan.get("scenario"), "boardMode": plan.get("boardMode"),
        "deployment": deploy, "initReceipt": init_r, "finalStatus": final_status,
        "faultIsolationPassed": fault_isolation_ok, "countExpectationPassed": count_ok,
        "unauthorizedKGCOnlyPassed": bool(unauthorized.get("rejected")),
        "passed": fault_isolation_ok and count_ok and bool(unauthorized.get("rejected")),
        "transactions": rows,
    }
    (output_dir / "chain_result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    with (output_dir / "chain_transactions.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["index", "type", "round", "gasUsed", "wallLatencySeconds", "txHash", "faultIsolationPassed"])
        w.writeheader(); w.writerows(rows)
    print(json.dumps({"scenario": result["scenario"], "passed": result["passed"], "finalStatus": final_status}, ensure_ascii=False))
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--hardhat-dir", required=True)
    args = ap.parse_args()
    replay(Path(args.plan), Path(args.output_dir), Path(args.hardhat_dir))


if __name__ == "__main__":
    main()
