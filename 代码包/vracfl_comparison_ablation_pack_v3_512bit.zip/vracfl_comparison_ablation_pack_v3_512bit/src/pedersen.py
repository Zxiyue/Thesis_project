#!/usr/bin/env python3
from __future__ import annotations

import hashlib
from typing import Iterable, Sequence

from threshold_paillier import TEST_SAFE_P_512


class PedersenVector:
    """Vector Pedersen commitment in a safe-prime subgroup for experiments."""

    def __init__(self, dimension: int, prime: int = TEST_SAFE_P_512) -> None:
        self.P = int(prime)
        self.q = (self.P - 1) // 2
        self.dimension = int(dimension)
        self.generators = [self._generator(f"g:{j}") for j in range(self.dimension)]
        self.h = self._generator("h")

    def _generator(self, label: str) -> int:
        x = int.from_bytes(hashlib.sha256(label.encode()).digest(), "big") % self.P
        g = pow(max(2, x), 2, self.P)
        return 4 if g in (0, 1) else g

    def commit(self, vec: Sequence[int], rho: int) -> int:
        if len(vec) != self.dimension:
            raise ValueError("dimension mismatch")
        out = pow(self.h, int(rho) % self.q, self.P)
        for g, x in zip(self.generators, vec):
            out = (out * pow(g, int(x) % self.q, self.P)) % self.P
        return out

    def aggregate(self, commitments: Iterable[int]) -> int:
        out = 1
        for c in commitments:
            out = (out * int(c)) % self.P
        return out
