#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import statistics
from pathlib import Path
from typing import Any, Dict, List


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--output-dir", default="")
    args = ap.parse_args()
    root = Path(args.root)
    out = Path(args.output_dir) if args.output_dir else root
    out.mkdir(parents=True, exist_ok=True)

    rows: List[Dict[str, Any]] = []
    for p in sorted(root.rglob("summary.json")):
        if p.parent == out and p.name == "summary.json":
            continue
        d = load_json(p)
        chain_path = p.parent / "chain" / "chain_result.json"
        chain = load_json(chain_path) if chain_path.exists() else {}
        txs = chain.get("transactions", [])
        gas_final = sum(int(x.get("gasUsed", 0)) for x in txs if x.get("type") == "final")
        gas_hash = sum(int(x.get("gasUsed", 0)) for x in txs if x.get("type") == "hash")
        gas_fault = sum(int(x.get("gasUsed", 0)) for x in txs if x.get("type") == "fault")
        row = {
            "result_dir": str(p.parent.relative_to(root)),
            "experiment": d.get("experiment", d.get("variant", "")),
            "label": d.get("label", d.get("definition", "")),
            "rounds": d.get("rounds", ""),
            "bits": d.get("paillier_bits_actual", d.get("requested_paillier_bits", "")),
            "dimension": d.get("dimension", d.get("model_dimension", "")),
            "final_accuracy": d.get("final_accuracy", ""),
            "total_wall_s": d.get("total_wall_s", d.get("protocol_total_wall_s", "")),
            "mean_round_s": d.get("mean_round_protocol_wall_s", ""),
            "accepted": d.get("accepted", d.get("accepted_normal_path", "")),
            "finaltx_gas": gas_final,
            "hashtx_gas": gas_hash,
            "faulttx_gas": gas_fault,
            "chain_passed": chain.get("passed", ""),
        }
        probe = d.get("security_probe", {})
        for key in [
            "aggregate_tamper_detected", "dropout_attack_detected", "dropout_attack_accepted",
            "fault_publicly_recorded", "fault_classifiable", "fault_localizable",
            "modelsync_impersonation_detected", "modelsync_impersonation_accepted",
        ]:
            row[key] = probe.get(key, "")
        rows.append(row)

    fields: List[str] = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with (out / "comparison_ablation_summary.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)
    (out / "comparison_ablation_summary.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")

    md = ["# Comparison and Ablation Summary", "", "| Experiment | Rounds | Bits | Dimension | Accuracy | Total wall (s) | FinalTx Gas | FaultTx Gas | Chain |", "|---|---:|---:|---:|---:|---:|---:|---:|---|"]
    for r in rows:
        md.append(
            f"| {r['experiment']} | {r['rounds']} | {r['bits']} | {r['dimension']} | {r['final_accuracy']} | "
            f"{r['total_wall_s']} | {r['finaltx_gas']} | {r['faulttx_gas']} | {r['chain_passed']} |"
        )
    (out / "comparison_ablation_summary.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(json.dumps({"rows": len(rows), "output": str(out / 'comparison_ablation_summary.csv')}, ensure_ascii=False))


if __name__ == "__main__":
    main()
