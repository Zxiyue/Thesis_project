#!/usr/bin/env python3
from __future__ import annotations

import json
import math
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Mapping, Sequence

import sympy

TEST_SAFE_P_512 = 106156326297970418690025119199905755623605263228620289413657912000294162649763
TEST_SAFE_Q_512 = 109447338125132373447679735675435613082393248557899094350131151539043851016647


def _safe_prime(bits: int) -> int:
    if bits < 64:
        raise ValueError("safe-prime bits too small")
    low = 1 << (bits - 2)
    high = 1 << (bits - 1)
    while True:
        q = int(sympy.randprime(low, high))
        p = 2 * q + 1
        if p.bit_length() == bits and sympy.isprime(p):
            return p


def load_or_generate_factors(modulus_bits: int, cache_path: Path) -> tuple[int, int, float]:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    if cache_path.exists():
        d = json.loads(cache_path.read_text(encoding="utf-8"))
        p, q = int(d["p"]), int(d["q"])
        if (p * q).bit_length() < modulus_bits - 4:
            raise ValueError(f"cached key is too small for requested {modulus_bits} bits")
        return p, q, 0.0
    if modulus_bits == 512:
        p, q = TEST_SAFE_P_512, TEST_SAFE_Q_512
        cache_path.write_text(json.dumps({"bits": 512, "p": str(p), "q": str(q)}, indent=2), encoding="utf-8")
        return p, q, 0.0
    started = time.perf_counter()
    half = modulus_bits // 2
    p = _safe_prime(half)
    q = _safe_prime(half)
    while q == p:
        q = _safe_prime(half)
    elapsed = time.perf_counter() - started
    cache_path.write_text(json.dumps({"bits": modulus_bits, "p": str(p), "q": str(q)}, indent=2), encoding="utf-8")
    return p, q, elapsed


@dataclass(frozen=True)
class PublicKey:
    n: int
    n2: int


class ThresholdPaillier:
    """Dealer-based threshold Paillier reference used by the experiment pack.

    The construction follows the same functional-test combine equations used by
    the prior attack pack. Key generation is excluded from per-round timings and
    cached on disk. It is research prototype code, not production cryptography.
    """

    def __init__(self, p: int, q: int, n_clients: int, threshold: int, seed: int) -> None:
        if p == q or p * q <= 0:
            raise ValueError("invalid factors")
        if not (1 <= threshold <= n_clients):
            raise ValueError("invalid threshold")
        self.p = int(p)
        self.q = int(q)
        self.p1 = (self.p - 1) // 2
        self.q1 = (self.q - 1) // 2
        self.n = self.p * self.q
        self.n2 = self.n * self.n
        self.m = self.p1 * self.q1
        self.nm = self.n * self.m
        self.n_clients = n_clients
        self.threshold = threshold
        self.delta = math.factorial(n_clients)
        d = (self.m * pow(self.m, -1, self.n)) % self.nm
        import random
        rng = random.Random(seed ^ 0xA5A55A5A)
        coeff = [d] + [rng.randrange(0, self.nm) for _ in range(threshold - 1)]
        self.shares: Dict[int, int] = {}
        for i in range(1, n_clients + 1):
            self.shares[i] = sum(coeff[k] * pow(i, k, self.nm) for k in range(threshold)) % self.nm

    @property
    def public_key(self) -> PublicKey:
        return PublicKey(self.n, self.n2)

    def encode(self, m: int) -> int:
        return int(m) % self.n

    def decode(self, m: int) -> int:
        m = int(m)
        return m - self.n if m > self.n // 2 else m

    def encrypt(self, m: int) -> int:
        return encrypt_int(self.public_key, int(m))

    def encrypt_vector(self, values: Sequence[int]) -> list[int]:
        return [self.encrypt(int(v)) for v in values]

    def add(self, ciphertexts: Sequence[int]) -> int:
        out = 1
        for c in ciphertexts:
            out = (out * int(c)) % self.n2
        return out

    def add_vectors(self, vectors: Sequence[Sequence[int]]) -> list[int]:
        if not vectors:
            return []
        d = len(vectors[0])
        if any(len(v) != d for v in vectors):
            raise ValueError("cipher vector dimension mismatch")
        out = [1] * d
        for vec in vectors:
            for j, c in enumerate(vec):
                out[j] = (out[j] * int(c)) % self.n2
        return out

    def partial_decrypt(self, client_id: int, c: int) -> int:
        return pow(int(c), 2 * self.delta * self.shares[int(client_id)], self.n2)

    def partial_decrypt_vector(self, client_id: int, ciphertexts: Sequence[int]) -> list[int]:
        return [self.partial_decrypt(client_id, c) for c in ciphertexts]

    @staticmethod
    def _lagrange(indices: Sequence[int], i: int, delta: int) -> int:
        num = delta
        den = 1
        for j in indices:
            if j == i:
                continue
            num *= -j
            den *= i - j
        if num % den != 0:
            raise ArithmeticError("non-integral Lagrange coefficient")
        return num // den

    def combine(self, partials: Mapping[int, int]) -> int:
        ids = list(partials.keys())
        if len(ids) < self.threshold:
            raise ValueError("threshold unreached")
        ids = ids[: self.threshold]
        c_prime = 1
        for i in ids:
            base = int(partials[i])
            exp = 2 * self._lagrange(ids, i, self.delta)
            if exp < 0:
                base = pow(base, -1, self.n2)
                exp = -exp
            c_prime = (c_prime * pow(base, exp, self.n2)) % self.n2
        L = (c_prime - 1) // self.n
        value = (L * pow(4 * self.delta * self.delta, -1, self.n)) % self.n
        return self.decode(value)

    def combine_vector(self, share_vectors: Mapping[int, Sequence[int]]) -> list[int]:
        ids = list(share_vectors.keys())
        if len(ids) < self.threshold:
            raise ValueError("threshold unreached")
        d = len(share_vectors[ids[0]])
        if any(len(share_vectors[i]) != d for i in ids):
            raise ValueError("share vector dimension mismatch")
        return [self.combine({i: int(share_vectors[i][j]) for i in ids}) for j in range(d)]


def encrypt_int(pk: PublicKey, m: int) -> int:
    n, n2 = int(pk.n), int(pk.n2)
    m %= n
    while True:
        r = secrets.randbelow(n - 1) + 1
        if math.gcd(r, n) == 1:
            break
    return (pow(1 + n, m, n2) * pow(r, n, n2)) % n2


def ciphertext_bytes(pk: PublicKey) -> int:
    return (pk.n2.bit_length() + 7) // 8
