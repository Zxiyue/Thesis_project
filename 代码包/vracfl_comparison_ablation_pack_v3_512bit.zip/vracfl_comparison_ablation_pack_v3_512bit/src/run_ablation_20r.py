#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Any, Dict, List

import numpy as np

from common import Timer, canonical_bytes, int_hex, merkle_root, seed_everything, sha256_hex, write_csv, write_json
from pedersen import PedersenVector
from signing import generate_key, sign_obj, verify_obj
from threshold_paillier import PublicKey, ThresholdPaillier, ciphertext_bytes, encrypt_int, load_or_generate_factors

VARIANTS = {
    "full_control": {
        "label": "Full VRAC-FL 512-bit paired control",
        "pedersen": True, "board": "full", "kgc_independent_set": True,
        "faulttx": True, "unit_comp_opt": True, "modelsync_signature": True,
    },
    "hash_only": {
        "label": "Only on-chain model hash",
        "pedersen": True, "board": "hash", "kgc_independent_set": True,
        "faulttx": False, "unit_comp_opt": True, "modelsync_signature": True,
    },
    "no_pedersen": {
        "label": "No Pedersen commitment",
        "pedersen": False, "board": "full", "kgc_independent_set": True,
        "faulttx": True, "unit_comp_opt": True, "modelsync_signature": True,
    },
    "no_kgc_independent_set": {
        "label": "KGC directly trusts CS dropout set",
        "pedersen": True, "board": "full", "kgc_independent_set": False,
        "faulttx": True, "unit_comp_opt": True, "modelsync_signature": True,
    },
    "no_faulttx": {
        "label": "No FaultTx",
        "pedersen": True, "board": "full", "kgc_independent_set": True,
        "faulttx": False, "unit_comp_opt": True, "modelsync_signature": True,
    },
    "no_unit_comp_opt": {
        "label": "No identity-element compensation optimization",
        "pedersen": True, "board": "full", "kgc_independent_set": True,
        "faulttx": True, "unit_comp_opt": False, "modelsync_signature": True,
    },
    "no_modelsync_signature": {
        "label": "No ModelSync source authentication",
        "pedersen": True, "board": "full", "kgc_independent_set": True,
        "faulttx": True, "unit_comp_opt": True, "modelsync_signature": False,
    },
}

FAULT_TYPES = {"SET_VIEW_MISMATCH": 1, "AGGREGATE_INCONSISTENCY": 5, "MODEL_SYNC_INTEGRITY_FAILURE": 7}
FAULT_STAGES = {"DROPOUT_COMPENSATION": 1, "AGGREGATE_OPEN_CHECK": 3, "MODEL_SYNC_VERIFY": 5}
RESOLUTIONS = {"RECOVERED": 1, "REJECTED": 4}


def _encrypt_vector_worker(args: tuple[int, int, list[int]]) -> list[int]:
    n, n2, values = args
    pk = PublicKey(n, n2)
    return [encrypt_int(pk, int(v)) for v in values]


def zero_sum_matrix(n_clients: int, dimension: int, bound: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    first = rng.integers(-bound, bound + 1, size=(n_clients - 1, dimension), dtype=np.int64)
    return np.vstack([first, -first.sum(axis=0, dtype=np.int64)])


def zero_sum_scalars(n_clients: int, bound: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    first = rng.integers(-bound, bound + 1, size=(n_clients - 1,), dtype=np.int64)
    return np.concatenate([first, np.asarray([-first.sum(dtype=np.int64)], dtype=np.int64)])


def full_final_action(round_no: int, alpha: str, root_up: str, com_hash: str, model_prev: str, model_next: str, prev_root: str) -> dict:
    audit_root = sha256_hex({
        "prev": prev_root, "round": round_no, "alpha": alpha,
        "rootUp": root_up, "comAggHash": com_hash,
        "modelPrev": model_prev, "modelNext": model_next,
    })
    return {
        "type": "final", "round": round_no, "alpha": alpha,
        "rootUp": root_up, "comAggHash": com_hash,
        "modelHashPrev": model_prev, "modelHashNext": model_next,
        "prevAuditRoot": prev_root, "auditRoot": audit_root,
    }


def fault_action(round_no: int, alpha: str, prev_root: str) -> dict:
    evidence = {
        "rootDCS": sha256_hex({"dropout": [2]}),
        "rootDKGC": sha256_hex({"dropout": []}),
        "resolution": "retransmit original UpMsg and reaggregate",
    }
    return {
        "type": "fault", "round": round_no, "attempt": 1, "alpha": alpha,
        "faultType": "SET_VIEW_MISMATCH", "faultTypeCode": FAULT_TYPES["SET_VIEW_MISMATCH"],
        "failureStage": "DROPOUT_COMPENSATION", "failureStageCode": FAULT_STAGES["DROPOUT_COMPENSATION"],
        "resolution": "RECOVERED", "resolutionCode": RESOLUTIONS["RECOVERED"],
        "evidenceHash": sha256_hex(evidence), "anchorAuditRoot": prev_root,
    }


def security_probe(variant: str, flags: dict, model_hash: str, client_keys: list[Any], pedersen: PedersenVector | None, recovered_probe: np.ndarray | None, com_agg_probe: int | None) -> dict:
    probe: Dict[str, Any] = {"variant": variant}
    # Aggregate tampering probe uses a real recovered vector and commitment from round 10 (or the last round in smoke mode).
    aggregate_detected = False
    if pedersen is not None and recovered_probe is not None and com_agg_probe is not None:
        tampered = recovered_probe.copy()
        tampered[0] += 1
        aggregate_detected = pedersen.commit(tampered.tolist(), 0) != int(com_agg_probe)
    probe["aggregate_tamper_detected"] = bool(aggregate_detected)
    probe["aggregate_tamper_localizable"] = bool(aggregate_detected and flags["board"] == "full")

    # Dropout-set manipulation probe: C2 reached KGC but CS omits it.
    cs_set, kgc_set = [1, 3, 4, 5], [1, 2, 3, 4, 5]
    root_cs = sha256_hex(cs_set)
    root_kgc = sha256_hex(kgc_set)
    mismatch = root_cs != root_kgc
    probe["dropout_root_mismatch_exists"] = mismatch
    probe["dropout_attack_detected"] = bool(mismatch and flags["kgc_independent_set"])
    probe["dropout_attack_accepted"] = bool(not flags["kgc_independent_set"])

    # Fault visibility probe.
    probe["fault_detected_offchain"] = True
    probe["fault_publicly_recorded"] = bool(flags["faulttx"] and flags["board"] == "full")
    probe["fault_type_visible"] = bool(flags["faulttx"] and flags["board"] == "full")
    probe["fault_stage_visible"] = bool(flags["faulttx"] and flags["board"] == "full")
    probe["fault_resolution_visible"] = bool(flags["faulttx"] and flags["board"] == "full")
    probe["evidence_hash_bound"] = bool(flags["faulttx"] and flags["board"] == "full")

    # ModelSync source-authentication probe: payload and model hash are correct,
    # but an attacker, rather than CS, supplies the response.
    cs_sk = client_keys[0]
    attacker_sk = client_keys[1]
    body = {"round": 10, "modelHash": model_hash, "payloadHash": sha256_hex("correct-current-model")}
    forged_sig = sign_obj(attacker_sk, body)
    signature_valid_as_cs = verify_obj(cs_sk.public_key(), body, forged_sig)
    probe["modelsync_model_hash_valid"] = True
    probe["modelsync_signature_valid_as_cs"] = signature_valid_as_cs
    probe["modelsync_impersonation_detected"] = bool(flags["modelsync_signature"] and not signature_valid_as_cs)
    probe["modelsync_impersonation_accepted"] = bool(not flags["modelsync_signature"])
    probe["fault_attributable_to_cs"] = bool(flags["modelsync_signature"])

    # Public audit capability.
    probe["board_mode"] = flags["board"]
    probe["fault_classifiable"] = bool(flags["board"] == "full" and flags["faulttx"])
    probe["fault_localizable"] = bool(flags["board"] == "full" and flags["faulttx"])
    return probe


def main() -> None:
    ap = argparse.ArgumentParser(description="Run one 512-bit, 20-round paired ablation on a shared MNIST update trace")
    ap.add_argument("--variant", choices=sorted(VARIANTS), required=True)
    ap.add_argument("--trace", required=True, help="update_trace.npz from build_update_trace.py")
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--rounds", type=int, default=20)
    ap.add_argument("--clients", type=int, default=5)
    ap.add_argument("--threshold", type=int, default=3)
    ap.add_argument("--paillier-bits", type=int, default=512)
    ap.add_argument("--key-cache", default="/root/fpa5/cache/threshold_paillier_p512.json")
    ap.add_argument("--mask-bound", type=int, default=64)
    ap.add_argument("--rho-bound", type=int, default=1024)
    ap.add_argument("--seed", type=int, default=20260714)
    ap.add_argument("--encrypt-workers", type=int, default=5)
    ap.add_argument("--dimension-limit", type=int, default=0, help="smoke only; 0 uses full trace dimension")
    args = ap.parse_args()

    flags = VARIANTS[args.variant]
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    seed_everything(args.seed)

    trace = np.load(args.trace, allow_pickle=False)
    all_updates = trace["updates"]
    model_prev_hashes = trace["model_prev_hashes"].astype(str)
    model_next_hashes = trace["model_next_hashes"].astype(str)
    scale = int(trace["scale"][0])
    rounds = min(args.rounds, all_updates.shape[0])
    clients = all_updates.shape[1]
    full_dim = all_updates.shape[2]
    dimension = full_dim if args.dimension_limit <= 0 else min(full_dim, args.dimension_limit)
    if clients != args.clients:
        raise ValueError(f"trace clients={clients}, requested={args.clients}")
    if rounds < args.rounds:
        raise ValueError(f"trace only has {rounds} rounds")

    p, q, keygen_s = load_or_generate_factors(args.paillier_bits, Path(args.key_cache))
    tp = ThresholdPaillier(p, q, clients, args.threshold, args.seed)
    pedersen = PedersenVector(dimension) if flags["pedersen"] else None
    client_keys = [generate_key() for _ in range(clients)]
    kgc_key = generate_key()

    sys_hash = sha256_hex({"variant": args.variant, "n": int_hex(tp.n), "dimension": dimension, "scale": scale})
    u_root = merkle_root([str(i).encode() for i in range(1, clients + 1)], b"EMPTY_USERS")
    audit_root = sha256_hex({"sysParaHash": sys_hash, "uRoot": u_root, "modelHash0": model_prev_hashes[0]})
    chain_plan: dict[str, Any] = {
        "scenario": args.variant,
        "boardMode": flags["board"],
        "init": {"sysParaHash": sys_hash, "uRoot": u_root, "modelHash0": model_prev_hashes[0], "auditRoot0": audit_root},
        "actions": [],
    }

    metrics_rows: List[dict] = []
    runtime_rows: List[dict] = []
    crypto_rows: List[dict] = []
    comm_rows: List[dict] = []
    verify_rows: List[dict] = []
    fault_count = 0
    final_count = 0
    hash_count = 0

    pool = ProcessPoolExecutor(max_workers=max(1, args.encrypt_workers)) if args.encrypt_workers > 1 else None
    recovered_probe: np.ndarray | None = None
    com_agg_probe: int | None = None
    total_started = time.perf_counter()
    try:
        for rnd in range(1, rounds + 1):
            round_started = time.perf_counter()
            qmat = all_updates[rnd - 1, :, :dimension].astype(np.int64, copy=True)
            masks = zero_sum_matrix(clients, dimension, args.mask_bound, args.seed + rnd * 1009)
            rhos = zero_sum_scalars(clients, args.rho_bound, args.seed + rnd * 2003)
            masked = qmat + masks
            alpha = sha256_hex({"round": rnd, "modelHash": model_prev_hashes[rnd - 1], "uRoot": u_root})

            with Timer() as enc_timer:
                jobs = [(tp.n, tp.n2, masked[i].astype(object).tolist()) for i in range(clients)]
                encrypted = list(pool.map(_encrypt_vector_worker, jobs)) if pool else [_encrypt_vector_worker(x) for x in jobs]

            compensation_encrypt_s = 0.0
            compensation_cipher = [1] * dimension
            if not flags["unit_comp_opt"]:
                with Timer() as comp_timer:
                    compensation_cipher = _encrypt_vector_worker((tp.n, tp.n2, [0] * dimension))
                compensation_encrypt_s = comp_timer.elapsed

            with Timer() as commit_timer:
                if pedersen is not None:
                    commitments = [pedersen.commit(masked[i].tolist(), int(rhos[i])) for i in range(clients)]
                    com_agg = pedersen.aggregate(commitments)
                else:
                    commitments = []
                    com_agg = 0

            receipts = []
            with Timer() as receipt_timer:
                for i in range(clients):
                    body = {
                        "r": rnd, "i": i + 1, "alpha": alpha,
                        "encHash": sha256_hex([int_hex(c) for c in encrypted[i]]),
                        "Com": int_hex(commitments[i]) if commitments else "0x0",
                    }
                    receipts.append({**body, "sigUp": sign_obj(client_keys[i], body)})
            root_up = merkle_root([canonical_bytes(x) for x in receipts], b"EMPTY_UPLOADS")

            with Timer() as agg_timer:
                cagg = tp.add_vectors(encrypted + [compensation_cipher])
            with Timer() as share_timer:
                shares = {cid: tp.partial_decrypt_vector(cid, cagg) for cid in range(1, args.threshold + 1)}
            with Timer() as combine_timer:
                recovered = np.asarray(tp.combine_vector(shares), dtype=np.int64)
            expected = qmat.sum(axis=0, dtype=np.int64)
            aggregate_ok = bool(np.array_equal(recovered, expected))

            with Timer() as verify_timer:
                if pedersen is not None:
                    commit_ok = pedersen.commit(recovered.tolist(), 0) == com_agg
                else:
                    commit_ok = None
            accepted = aggregate_ok and (commit_ok is not False)
            if rnd == min(10, rounds):
                recovered_probe = recovered.copy()
                com_agg_probe = int(com_agg) if pedersen is not None else None
            if not accepted:
                raise RuntimeError(f"{args.variant} round {rnd} failed normal-path verification")

            com_hash = sha256_hex(int_hex(com_agg)) if pedersen is not None else "0x" + "00" * 32
            if rnd == 10 and args.variant == "full_control":
                chain_plan["actions"].append(fault_action(rnd, alpha, audit_root))
                fault_count += 1

            if flags["board"] == "hash":
                chain_plan["actions"].append({
                    "type": "hash", "round": rnd, "modelHashPrev": model_prev_hashes[rnd - 1],
                    "modelHashNext": model_next_hashes[rnd - 1],
                })
                hash_count += 1
            else:
                final = full_final_action(
                    rnd, alpha, root_up, com_hash,
                    model_prev_hashes[rnd - 1], model_next_hashes[rnd - 1], audit_root,
                )
                chain_plan["actions"].append(final)
                audit_root = final["auditRoot"]
                final_count += 1

            cbytes = ciphertext_bytes(tp.public_key)
            round_wall = time.perf_counter() - round_started
            runtime_rows.append({
                "round": rnd,
                "paillier_encrypt_s": enc_timer.elapsed,
                "compensation_encrypt_s": compensation_encrypt_s,
                "pedersen_commit_s": commit_timer.elapsed,
                "receipt_sign_s": receipt_timer.elapsed,
                "cipher_aggregate_s": agg_timer.elapsed,
                "partial_decrypt_s": share_timer.elapsed,
                "threshold_combine_s": combine_timer.elapsed,
                "aggregate_verify_s": verify_timer.elapsed,
                "round_protocol_wall_s": round_wall,
            })
            crypto_rows.extend([
                {"round": rnd, "operation": "paillier_encrypt", "seconds": enc_timer.elapsed, "count": clients * dimension},
                {"round": rnd, "operation": "zero_compensation_encrypt", "seconds": compensation_encrypt_s, "count": 0 if flags["unit_comp_opt"] else dimension},
                {"round": rnd, "operation": "pedersen_commit", "seconds": commit_timer.elapsed, "count": 0 if pedersen is None else clients},
                {"round": rnd, "operation": "partial_decrypt", "seconds": share_timer.elapsed, "count": args.threshold * dimension},
                {"round": rnd, "operation": "threshold_combine", "seconds": combine_timer.elapsed, "count": dimension},
            ])
            comm_rows.extend([
                {"round": rnd, "payload_type": "UpMsgCipher", "messages": clients, "bytes": clients * dimension * cbytes},
                {"round": rnd, "payload_type": "PedersenCommitment", "messages": 0 if pedersen is None else clients, "bytes": 0 if pedersen is None else clients * ((pedersen.P.bit_length() + 7) // 8)},
                {"round": rnd, "payload_type": "DropMsgCipher", "messages": 0 if flags["unit_comp_opt"] else 1, "bytes": 0 if flags["unit_comp_opt"] else dimension * cbytes},
                {"round": rnd, "payload_type": "DecryptShare", "messages": args.threshold, "bytes": args.threshold * dimension * cbytes},
            ])
            metrics_rows.append({
                "round": rnd,
                "trace_model_hash_prev": model_prev_hashes[rnd - 1],
                "trace_model_hash_next": model_next_hashes[rnd - 1],
                "aggregate_l1": int(np.abs(expected).sum()),
                "board_mode": flags["board"],
            })
            verify_rows.append({
                "round": rnd, "aggregate_recovered": aggregate_ok,
                "pedersen_checked": pedersen is not None,
                "pedersen_passed": "" if commit_ok is None else commit_ok,
                "faulttx_generated": rnd == 10 and args.variant == "full_control",
                "finaltx_generated": flags["board"] == "full",
                "hash_tx_generated": flags["board"] == "hash",
                "accepted": accepted,
            })
            print(json.dumps({"variant": args.variant, "round": rnd, "round_protocol_wall_s": round_wall}), flush=True)
    finally:
        if pool:
            pool.shutdown(wait=True, cancel_futures=False)

    total_wall = time.perf_counter() - total_started
    probe = security_probe(args.variant, flags, model_next_hashes[min(rounds, len(model_next_hashes)) - 1], client_keys, pedersen, recovered_probe, com_agg_probe)
    chain_plan["expected"] = {"faultTxCount": fault_count, "finalTxCount": final_count, "hashTxCount": hash_count}
    write_json(out / "chain_plan.json", chain_plan)
    write_json(out / "security_probe.json", probe)
    write_csv(out / "metrics_round.csv", metrics_rows)
    write_csv(out / "runtime_cost.csv", runtime_rows)
    write_csv(out / "crypto_cost.csv", crypto_rows)
    write_csv(out / "communication_cost.csv", comm_rows)
    write_csv(out / "verify_result.csv", verify_rows)

    summary = {
        "variant": args.variant,
        "label": flags["label"],
        "rounds": rounds,
        "clients": clients,
        "threshold": args.threshold,
        "requested_paillier_bits": args.paillier_bits,
        "paillier_bits_actual": tp.n.bit_length(),
        "dimension": dimension,
        "full_trace_dimension": full_dim,
        "scale": scale,
        "flags": flags,
        "keygen_s_excluded": keygen_s,
        "protocol_total_wall_s": total_wall,
        "mean_round_protocol_wall_s": float(np.mean([r["round_protocol_wall_s"] for r in runtime_rows])),
        "total_compensation_encrypt_s": float(sum(r["compensation_encrypt_s"] for r in runtime_rows)),
        "total_pedersen_commit_s": float(sum(r["pedersen_commit_s"] for r in runtime_rows)),
        "faulttx_planned": fault_count,
        "finaltx_planned": final_count,
        "hash_tx_planned": hash_count,
        "accepted_normal_path": all(bool(r["accepted"]) for r in verify_rows),
        "security_probe": probe,
    }
    write_json(out / "summary.json", summary)
    write_json(out / "run_trace.json", {"summary": summary, "runtime": runtime_rows, "verify": verify_rows, "securityProbe": probe})
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
