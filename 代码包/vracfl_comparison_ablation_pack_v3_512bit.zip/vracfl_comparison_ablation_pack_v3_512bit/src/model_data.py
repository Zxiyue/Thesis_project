#!/usr/bin/env python3
from __future__ import annotations

import copy
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset, Subset
from torchvision import datasets, transforms


class TinyCNN6794(nn.Module):
    """Tiny CNN whose trainable parameter count is exactly 6,794.

    28x28 -> conv(1,2,3) -> pool -> conv(2,14,3) -> pool -> 14x5x5
    -> fc(350,18) -> fc(18,10)
    """

    def __init__(self) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(1, 2, kernel_size=3)
        self.conv2 = nn.Conv2d(2, 14, kernel_size=3)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(14 * 5 * 5, 18)
        self.fc2 = nn.Linear(18, 10)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.relu(self.conv1(x))
        x = self.pool(x)
        x = torch.relu(self.conv2(x))
        x = self.pool(x)
        x = x.reshape(x.shape[0], -1)
        x = torch.relu(self.fc1(x))
        return self.fc2(x)


def parameter_count(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


def flatten_model(model: nn.Module) -> torch.Tensor:
    return torch.cat([p.detach().reshape(-1).cpu() for p in model.parameters()])


def assign_flat_model(model: nn.Module, flat: torch.Tensor) -> None:
    flat = flat.detach().cpu()
    offset = 0
    with torch.no_grad():
        for p in model.parameters():
            n = p.numel()
            p.copy_(flat[offset: offset + n].reshape_as(p).to(p.device, dtype=p.dtype))
            offset += n
    if offset != flat.numel():
        raise ValueError(f"flat vector length mismatch: consumed={offset}, total={flat.numel()}")


def model_hash(model: nn.Module) -> str:
    h = hashlib.sha256()
    state = model.state_dict()
    for key in sorted(state):
        t = state[key].detach().cpu().contiguous()
        h.update(key.encode())
        h.update(str(t.dtype).encode())
        h.update(str(tuple(t.shape)).encode())
        h.update(t.numpy().tobytes())
    return "0x" + h.hexdigest()


def load_dataset(name: str, root: Path, train: bool, download: bool) -> Dataset:
    tfm = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
    normalized = name.lower().replace("_", "-")
    if normalized == "mnist":
        return datasets.MNIST(root=str(root), train=train, transform=tfm, download=download)
    if normalized in {"fashion-mnist", "fashionmnist"}:
        return datasets.FashionMNIST(root=str(root), train=train, transform=tfm, download=download)
    raise ValueError(f"unsupported dataset: {name}")


def labels_of(dataset: Dataset) -> np.ndarray:
    targets = getattr(dataset, "targets", None)
    if targets is None:
        return np.array([int(dataset[i][1]) for i in range(len(dataset))], dtype=np.int64)
    if isinstance(targets, torch.Tensor):
        return targets.cpu().numpy().astype(np.int64)
    return np.asarray(targets, dtype=np.int64)


def partition_iid(dataset: Dataset, n_clients: int, seed: int) -> List[List[int]]:
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(dataset))
    return [x.astype(int).tolist() for x in np.array_split(idx, n_clients)]


def partition_noniid_shards(dataset: Dataset, n_clients: int, seed: int, shards_per_client: int = 2) -> List[List[int]]:
    labels = labels_of(dataset)
    order = np.lexsort((np.arange(len(labels)), labels))
    n_shards = n_clients * shards_per_client
    shards = [x.astype(int).tolist() for x in np.array_split(order, n_shards)]
    rng = np.random.default_rng(seed)
    rng.shuffle(shards)
    out = [[] for _ in range(n_clients)]
    for cid in range(n_clients):
        for s in shards[cid * shards_per_client: (cid + 1) * shards_per_client]:
            out[cid].extend(s)
    return out


def limit_partition(parts: List[List[int]], max_samples_per_client: int, seed: int) -> List[List[int]]:
    if max_samples_per_client <= 0:
        return parts
    rng = np.random.default_rng(seed)
    out: List[List[int]] = []
    for p in parts:
        if len(p) <= max_samples_per_client:
            out.append(list(p))
        else:
            chosen = rng.choice(np.asarray(p), size=max_samples_per_client, replace=False)
            out.append(chosen.astype(int).tolist())
    return out


def build_loaders(
    dataset: Dataset,
    partitions: Sequence[Sequence[int]],
    batch_size: int,
    seed: int,
    num_workers: int = 0,
) -> List[DataLoader]:
    loaders = []
    for cid, ids in enumerate(partitions, start=1):
        g = torch.Generator().manual_seed(seed + cid)
        loaders.append(DataLoader(
            Subset(dataset, list(ids)), batch_size=batch_size, shuffle=True,
            num_workers=num_workers, generator=g, drop_last=False,
        ))
    return loaders


def train_local(
    global_model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    lr: float,
    local_epochs: int,
    momentum: float = 0.0,
) -> Tuple[torch.Tensor, float]:
    model = copy.deepcopy(global_model).to(device)
    model.train()
    opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=momentum)
    loss_fn = nn.CrossEntropyLoss()
    total_loss = 0.0
    total_batches = 0
    for _ in range(local_epochs):
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            loss = loss_fn(model(x), y)
            loss.backward()
            opt.step()
            total_loss += float(loss.detach().cpu())
            total_batches += 1
    delta = flatten_model(model) - flatten_model(global_model)
    return delta, total_loss / max(1, total_batches)


@torch.no_grad()
def evaluate(model: nn.Module, loader: DataLoader, device: torch.device) -> Tuple[float, float]:
    model = model.to(device)
    model.eval()
    loss_fn = nn.CrossEntropyLoss(reduction="sum")
    correct = 0
    total = 0
    loss_sum = 0.0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        logits = model(x)
        loss_sum += float(loss_fn(logits, y).cpu())
        correct += int((logits.argmax(dim=1) == y).sum().cpu())
        total += y.numel()
    return correct / max(1, total), loss_sum / max(1, total)


def build_data(
    dataset_name: str,
    data_root: Path,
    split: str,
    n_clients: int,
    batch_size: int,
    test_batch_size: int,
    seed: int,
    max_samples_per_client: int,
    download: bool,
) -> tuple[Dataset, Dataset, List[List[int]], List[DataLoader], DataLoader]:
    train_ds = load_dataset(dataset_name, data_root, train=True, download=download)
    test_ds = load_dataset(dataset_name, data_root, train=False, download=download)
    if split.lower() == "iid":
        parts = partition_iid(train_ds, n_clients, seed)
    elif split.lower() in {"noniid", "non-iid"}:
        parts = partition_noniid_shards(train_ds, n_clients, seed)
    else:
        raise ValueError(f"unsupported split: {split}")
    parts = limit_partition(parts, max_samples_per_client, seed)
    loaders = build_loaders(train_ds, parts, batch_size, seed)
    test_loader = DataLoader(test_ds, batch_size=test_batch_size, shuffle=False, num_workers=0)
    return train_ds, test_ds, parts, loaders, test_loader
