#!/usr/bin/env python3
from __future__ import annotations

from typing import Any

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec

from common import canonical_bytes


def generate_key() -> ec.EllipticCurvePrivateKey:
    return ec.generate_private_key(ec.SECP256R1())


def sign_obj(sk: ec.EllipticCurvePrivateKey, obj: Any) -> str:
    return sk.sign(canonical_bytes(obj), ec.ECDSA(hashes.SHA256())).hex()


def verify_obj(pk: ec.EllipticCurvePublicKey, obj: Any, signature_hex: str) -> bool:
    try:
        pk.verify(bytes.fromhex(signature_hex), canonical_bytes(obj), ec.ECDSA(hashes.SHA256()))
        return True
    except Exception:
        return False
