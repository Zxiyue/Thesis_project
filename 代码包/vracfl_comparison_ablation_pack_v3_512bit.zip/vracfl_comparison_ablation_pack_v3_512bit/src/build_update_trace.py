#!/usr/bin/env python3
from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np
import torch

from common import Timer, hash_ndarray, seed_everything, write_csv, write_json
from model_data import (
    TinyCNN6794, assign_flat_model, build_data, evaluate, flatten_model,
    model_hash, parameter_count, train_local,
)


def main() -> None:
    ap = argparse.ArgumentParser(description="Build one paired 20-round MNIST update trace for all ablations")
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--dataset", default="mnist")
    ap.add_argument("--split", choices=["iid", "noniid"], default="iid")
    ap.add_argument("--data-root", default="/root/fpa5/data")
    ap.add_argument("--rounds", type=int, default=20)
    ap.add_argument("--clients", type=int, default=5)
    ap.add_argument("--local-epochs", type=int, default=1)
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--test-batch-size", type=int, default=512)
    ap.add_argument("--lr", type=float, default=0.20)
    ap.add_argument("--momentum", type=float, default=0.0)
    ap.add_argument("--scale", type=int, default=10000)
    ap.add_argument("--seed", type=int, default=20260714)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--max-samples-per-client", type=int, default=0)
    ap.add_argument("--download", action="store_true")
    args = ap.parse_args()

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    seed_everything(args.seed)
    device = torch.device(args.device)
    _, _, parts, loaders, test_loader = build_data(
        args.dataset, Path(args.data_root), args.split, args.clients,
        args.batch_size, args.test_batch_size, args.seed,
        args.max_samples_per_client, args.download,
    )
    sample_counts = np.asarray([len(p) for p in parts], dtype=np.int64)
    weights = sample_counts.astype(np.float64) / sample_counts.sum()

    model = TinyCNN6794().to(device)
    d = parameter_count(model)
    updates = np.zeros((args.rounds, args.clients, d), dtype=np.int64)
    rows = []
    training_rows = []
    model_prev_hashes = []
    model_next_hashes = []

    for rnd in range(1, args.rounds + 1):
        prev_flat = flatten_model(model)
        prev_hash = model_hash(model)
        weighted_quantized = []
        local_losses = []
        train_times = []
        for cid, loader in enumerate(loaders, start=1):
            with Timer() as t:
                delta, local_loss = train_local(model, loader, device, args.lr, args.local_epochs, args.momentum)
            q = torch.round(delta * float(weights[cid - 1]) * args.scale).to(torch.int64).cpu().numpy()
            weighted_quantized.append(q)
            local_losses.append(local_loss)
            train_times.append(t.elapsed)
        qmat = np.stack(weighted_quantized, axis=0)
        updates[rnd - 1] = qmat
        recovered = qmat.sum(axis=0).astype(np.float64) / float(args.scale)
        assign_flat_model(model, prev_flat + torch.from_numpy(recovered).to(dtype=prev_flat.dtype))
        acc, test_loss = evaluate(model, test_loader, device)
        next_hash = model_hash(model)
        model_prev_hashes.append(prev_hash)
        model_next_hashes.append(next_hash)
        rows.append({
            "round": rnd,
            "test_accuracy": acc,
            "test_loss": test_loss,
            "mean_local_loss": float(np.mean(local_losses)),
            "model_hash_prev": prev_hash,
            "model_hash_next": next_hash,
            "aggregate_l1": int(np.abs(qmat.sum(axis=0)).sum()),
        })
        training_rows.append({
            "round": rnd,
            "local_train_sum_s": float(sum(train_times)),
            "local_train_parallel_wall_proxy_s": float(max(train_times)),
        })
        print(f"[trace] round={rnd} accuracy={acc:.6f}", flush=True)

    np.savez_compressed(
        out / "update_trace.npz",
        updates=updates,
        sample_counts=sample_counts,
        weights=weights,
        model_prev_hashes=np.asarray(model_prev_hashes, dtype="U66"),
        model_next_hashes=np.asarray(model_next_hashes, dtype="U66"),
        scale=np.asarray([args.scale], dtype=np.int64),
    )
    write_csv(out / "metrics_round.csv", rows)
    write_csv(out / "training_runtime.csv", training_rows)
    manifest = {
        "dataset": args.dataset,
        "split": args.split,
        "rounds": args.rounds,
        "clients": args.clients,
        "dimension": d,
        "scale": args.scale,
        "seed": args.seed,
        "sample_counts": sample_counts.tolist(),
        "updates_hash": hash_ndarray(updates),
        "model": "TinyCNN6794",
    }
    write_json(out / "trace_manifest.json", manifest)
    print(manifest, flush=True)


if __name__ == "__main__":
    main()
