#!/usr/bin/env bash
# One-command entry point: install/refresh the pack, start Hardhat when needed,
# run the 50-round main baselines and all 20-round ablations, then package results.
set -Eeuo pipefail
PACK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
TARGET="${TARGET_DIR:-$FPA5_ROOT/ablation_pack_v3_512bit}"

if [[ "${SKIP_INSTALL:-0}" != "1" ]]; then
  bash "$PACK_ROOT/scripts/install.sh"
fi

if [[ ! -x "$TARGET/scripts/run_one_click.sh" ]]; then
  echo "[ERROR] installed runner not found: $TARGET/scripts/run_one_click.sh" >&2
  exit 1
fi

exec bash "$TARGET/scripts/run_one_click.sh"
