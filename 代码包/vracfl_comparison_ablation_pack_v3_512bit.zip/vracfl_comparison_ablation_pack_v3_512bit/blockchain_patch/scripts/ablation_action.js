const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

function req(name, fallback = undefined) {
  const v = process.env[name];
  if ((v === undefined || v === "") && fallback === undefined) throw new Error(`missing env ${name}`);
  return (v === undefined || v === "") ? fallback : v;
}
function statePath() { return req("ABLATION_BOARD_STATE", path.join(process.cwd(), "outputs", "ablation_board_state.json")); }
function b32(name, fallback = "0x" + "00".repeat(32)) {
  const value = req(name, fallback);
  if (!/^0x[0-9a-fA-F]{64}$/.test(value)) throw new Error(`${name} must be bytes32: ${value}`);
  return value;
}
async function address() { return JSON.parse(fs.readFileSync(statePath(), "utf8")).address; }
async function receiptInfo(tx, extra = {}) {
  const r = await tx.wait();
  return { ok: true, txHash: r.hash || r.transactionHash, gasUsed: r.gasUsed.toString(), blockNumber: Number(r.blockNumber), ...extra };
}

async function main() {
  const action = req("ABLATION_ACTION");
  const signers = await hre.ethers.getSigners();
  const contract = await hre.ethers.getContractAt("AblationAuditBoard", await address(), signers[0]);
  if (action === "init") {
    console.log(JSON.stringify(await receiptInfo(await contract.recordInit(b32("SYS_PARA_HASH"), b32("U_ROOT"), b32("MODEL_HASH0"), b32("AUDIT_ROOT0")), {action})));
    return;
  }
  if (action === "final") {
    const tx = await contract.recordFinal(req("ROUND"), b32("ALPHA"), b32("ROOT_UP"), b32("COM_HASH"), b32("MODEL_PREV"), b32("MODEL_NEXT"), b32("PREV_ROOT"), b32("AUDIT_ROOT"));
    console.log(JSON.stringify(await receiptInfo(tx, {action}))); return;
  }
  if (action === "hash") {
    const tx = await contract.recordHash(req("ROUND"), b32("MODEL_PREV"), b32("MODEL_NEXT"));
    console.log(JSON.stringify(await receiptInfo(tx, {action}))); return;
  }
  if (action === "fault") {
    const tx = await contract.recordFault(req("ROUND"), Number(req("ATTEMPT", "1")), b32("ALPHA"), Number(req("FAULT_TYPE")), Number(req("FAULT_STAGE")), Number(req("RESOLUTION")), b32("EVIDENCE_HASH"), b32("ANCHOR_ROOT"));
    console.log(JSON.stringify(await receiptInfo(tx, {action}))); return;
  }
  if (action === "status") {
    console.log(JSON.stringify({
      ok: true, action, address: await address(), kgc: await contract.kgc(), initialized: await contract.initialized(),
      latestFinalRound: (await contract.latestFinalRound()).toString(), latestHashRound: (await contract.latestHashRound()).toString(),
      currentModelHash: await contract.currentModelHash(), latestAuditRoot: await contract.latestAuditRoot(), faultCount: (await contract.faultCount()).toString()
    })); return;
  }
  if (action === "unauthorized-fault") {
    try {
      const bad = contract.connect(signers[1]);
      const tx = await bad.recordFault(1, 999, b32("ALPHA"), 1, 1, 4, b32("EVIDENCE_HASH"), b32("ANCHOR_ROOT"));
      await tx.wait();
      console.log(JSON.stringify({ok: false, rejected: false, action})); process.exitCode = 2;
    } catch (err) {
      console.log(JSON.stringify({ok: true, rejected: true, action, reason: String(err.message || err)}));
    }
    return;
  }
  throw new Error(`unknown ABLATION_ACTION=${action}`);
}
main().catch((err) => { console.error(err); process.exitCode = 1; });
