const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

async function main() {
  const signers = await hre.ethers.getSigners();
  const kgc = signers[0];
  const Factory = await hre.ethers.getContractFactory("AblationAuditBoard", kgc);
  const contract = await Factory.deploy(await kgc.getAddress());
  await contract.waitForDeployment();
  const address = await contract.getAddress();
  const statePath = process.env.ABLATION_BOARD_STATE || path.join(process.cwd(), "outputs", "ablation_board_state.json");
  fs.mkdirSync(path.dirname(statePath), { recursive: true });
  fs.writeFileSync(statePath, JSON.stringify({ address, kgc: await kgc.getAddress() }, null, 2));
  const tx = contract.deploymentTransaction();
  const receipt = tx ? await tx.wait() : null;
  console.log(JSON.stringify({ ok: true, address, kgc: await kgc.getAddress(), gasUsed: receipt ? receipt.gasUsed.toString() : "0" }));
}

main().catch((err) => { console.error(err); process.exitCode = 1; });
