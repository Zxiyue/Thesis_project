#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3

echo "root=$ROOT"
echo "python=$PY"
"$PY" --version
"$PY" - <<'PY'
import numpy, yaml, cryptography, torch, torchvision, sympy
from pathlib import Path
print('numpy', numpy.__version__)
print('torch', torch.__version__)
print('torchvision', torchvision.__version__)
print('cryptography', cryptography.__version__)
print('sympy', sympy.__version__)
PY

DATA_ROOT="${DATA_ROOT:-/root/fpa5/data}"
if [[ -d "$DATA_ROOT/MNIST" || -d "$DATA_ROOT/MNIST/raw" ]]; then
  echo "mnist_data=OK:$DATA_ROOT"
else
  echo "mnist_data=MISSING:$DATA_ROOT (use DOWNLOAD=1 on first run)"
fi

if [[ -f "$ROOT/.hardhat_dir" ]]; then
  HH_DIR="$(cat "$ROOT/.hardhat_dir")"
  echo "hardhat_dir=$HH_DIR"
  if curl -fsS http://127.0.0.1:8545 >/dev/null 2>&1; then
    echo "hardhat_rpc=UP"
  else
    echo "hardhat_rpc=DOWN (start npx hardhat node in another tmux)"
  fi
else
  echo "hardhat_dir=NOT_CONFIGURED"
fi

"$PY" -m py_compile "$ROOT"/src/*.py
echo "python_compile=OK"
