#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
export OUT_ROOT="${OUT_ROOT:-$FPA5_ROOT/outputs/comparison_ablation_v1_smoke}"
export ROUNDS=2
export MAX_SAMPLES_PER_CLIENT="${MAX_SAMPLES_PER_CLIENT:-128}"
export DIMENSION_LIMIT="${DIMENSION_LIMIT:-32}"
export RUN_NONIID=0
export RUN_PRIVACY=0
export SKIP_CHAIN="${SKIP_CHAIN:-0}"
export ONLY_VARIANTS="${ONLY_VARIANTS:-full_control,hash_only,no_unit_comp_opt}"
bash "$ROOT/scripts/run_main_performance_50r.sh"
bash "$ROOT/scripts/run_ablation_20r.sh"
