#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
if [[ -n "${OUT_ROOT:-}" ]]; then
  CURRENT="$OUT_ROOT"
elif [[ -f "$ROOT/.last_output_root" ]]; then
  CURRENT="$(cat "$ROOT/.last_output_root")"
else
  CURRENT="$FPA5_ROOT/outputs/comparison_ablation_v3_512bit"
fi

echo "output_root=$CURRENT"
if [[ -f "$ROOT/.last_result_zip" ]]; then echo "result_zip=$(cat "$ROOT/.last_result_zip")"; fi
find "$CURRENT" -maxdepth 4 -type f \( -name summary.json -o -name chain_result.json -o -name '*.log' -o -name run_manifest.json \) \
  -printf '%TY-%Tm-%Td %TH:%TM %p\n' 2>/dev/null | sort || true
echo "--- running processes ---"
ps -eo pid,etime,%cpu,%mem,cmd | grep -E 'run_(fedavg|privacy_only|ablation_20r|build_update_trace)|hardhat node' | grep -v grep || true
echo "--- latest log tails ---"
for f in "$CURRENT/logs/main_performance_50r.log" "$CURRENT/logs/ablation_20r.log" "$CURRENT/logs/hardhat_node.log"; do
  [[ -f "$f" ]] || continue
  echo "### $f"
  tail -20 "$f"
done
