#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3
OUT_ROOT="${OUT_ROOT:-$FPA5_ROOT/outputs/comparison_ablation_v3_512bit}"
DATA_ROOT="${DATA_ROOT:-$FPA5_ROOT/data}"
ROUNDS="${ROUNDS:-${MAIN_ROUNDS:-50}}"
SEED="${SEED:-20260714}"
MAX_SAMPLES="${MAX_SAMPLES_PER_CLIENT:-0}"
PRIVACY_BITS="${PRIVACY_BITS:-512}"
DOWNLOAD_FLAG=()
[[ "${DOWNLOAD:-0}" == "1" ]] && DOWNLOAD_FLAG=(--download)
RUN_NONIID="${RUN_NONIID:-1}"
RUN_FEDAVG="${RUN_FEDAVG:-1}"
RUN_PRIVACY="${RUN_PRIVACY:-1}"
RESUME="${RESUME:-1}"
FORCE_RERUN="${FORCE_RERUN:-0}"
REUSE_PREVIOUS_RESULTS="${REUSE_PREVIOUS_RESULTS:-1}"

mkdir -p "$OUT_ROOT"
should_skip() {
  local out="$1"
  [[ "$FORCE_RERUN" != "1" && "$RESUME" == "1" && -s "$out/summary.json" ]]
}

validate_summary() {
  local summary="$1" exp="$2" split="$3" bits="$4"
  "$PY" - "$summary" "$exp" "$split" "$ROUNDS" "$bits" <<'PY'
import json, sys
p, exp, split, rounds, bits = sys.argv[1:]
try:
    d=json.load(open(p, encoding='utf-8'))
except Exception:
    raise SystemExit(1)
ok = (
    str(d.get('experiment','')).lower() == exp.lower()
    and str(d.get('dataset','')).lower() == 'mnist'
    and str(d.get('split','')).lower() == split.lower()
    and int(d.get('rounds',-1)) == int(rounds)
    and int(d.get('clients',-1)) == 5
    and bool(d.get('accepted', False))
)
if bits not in ('', 'none'):
    requested=d.get('requested_paillier_bits', d.get('paillier_bits'))
    actual=d.get('paillier_bits_actual')
    if requested is not None:
        ok = ok and int(requested) == int(bits)
    elif actual is not None:
        ok = ok and int(bits)-1 <= int(actual) <= int(bits)
    else:
        ok = False
raise SystemExit(0 if ok else 1)
PY
}

try_reuse() {
  local out="$1" exp="$2" split="$3" pattern="$4" bits="$5"
  [[ "$REUSE_PREVIOUS_RESULTS" == "1" && "$FORCE_RERUN" != "1" ]] || return 1
  local current_real candidate summary
  current_real="$(realpath -m "$out")"
  while IFS= read -r summary; do
    [[ -n "$summary" ]] || continue
    candidate="$(dirname "$summary")"
    [[ "$(realpath -m "$candidate")" != "$current_real" ]] || continue
    if validate_summary "$summary" "$exp" "$split" "$bits"; then
      echo "[REUSE] compatible completed result: $candidate"
      rm -rf "$out"
      mkdir -p "$(dirname "$out")"
      cp -a "$candidate" "$out"
      printf '%s\n' "$candidate" > "$out/reused_from.txt"
      return 0
    fi
  done < <(find "$FPA5_ROOT/outputs" -type f -path "$pattern/summary.json" -printf '%T@ %p\n' 2>/dev/null | sort -nr | cut -d' ' -f2-)
  return 1
}

run_fedavg() {
  local split="$1" out="$OUT_ROOT/E1_fedavg_${split}_${ROUNDS}r"
  if should_skip "$out"; then
    echo "[SKIP] completed FedAvg result found: $out"
    return
  fi
  if try_reuse "$out" "FedAvg" "$split" "*/E1_fedavg_${split}_${ROUNDS}r" none; then
    return
  fi
  "$PY" "$ROOT/src/run_fedavg_baseline.py" \
    --output-dir "$out" --dataset mnist --split "$split" --data-root "$DATA_ROOT" \
    --rounds "$ROUNDS" --clients 5 --lr 0.20 --seed "$SEED" \
    --max-samples-per-client "$MAX_SAMPLES" "${DOWNLOAD_FLAG[@]}"
}
run_privacy() {
  local split="$1" out="$OUT_ROOT/E2_privacy_only_${split}_${ROUNDS}r_p${PRIVACY_BITS}"
  if should_skip "$out"; then
    echo "[SKIP] completed Privacy-only result found: $out"
    return
  fi
  if try_reuse "$out" "Privacy-only" "$split" "*/E2_privacy_only_${split}_${ROUNDS}r_p${PRIVACY_BITS}" "$PRIVACY_BITS"; then
    return
  fi
  "$PY" "$ROOT/src/run_privacy_only_baseline.py" \
    --output-dir "$out" --dataset mnist --split "$split" --data-root "$DATA_ROOT" \
    --rounds "$ROUNDS" --clients 5 --threshold 3 --paillier-bits "$PRIVACY_BITS" \
    --key-cache "$FPA5_ROOT/cache/threshold_paillier_p${PRIVACY_BITS}.json" \
    --lr 0.20 --seed "$SEED" --max-samples-per-client "$MAX_SAMPLES" \
    --encrypt-workers "${ENCRYPT_WORKERS:-5}" "${DOWNLOAD_FLAG[@]}"
}
run_split() {
  local split="$1"
  if [[ "$RUN_FEDAVG" == "1" ]]; then run_fedavg "$split"; fi
  if [[ "$RUN_PRIVACY" == "1" ]]; then run_privacy "$split"; fi
}

run_split iid
if [[ "$RUN_NONIID" == "1" ]]; then run_split noniid; fi

echo "[DONE] main performance outputs: $OUT_ROOT"
