#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3
OUT_ROOT="${OUT_ROOT:-$FPA5_ROOT/outputs/comparison_ablation_v3_512bit}"
ZIP_OUT="${ZIP_OUT:-/root/vracfl_comparison_ablation_v3_512bit_results_$(date +%Y%m%d_%H%M).zip}"

mkdir -p "$OUT_ROOT"
"$PY" "$ROOT/src/summarize_ablation_results.py" --root "$OUT_ROOT"
rm -f "$ZIP_OUT"
cd "$(dirname "$OUT_ROOT")"
zip -qr "$ZIP_OUT" "$(basename "$OUT_ROOT")"
echo "$ZIP_OUT"
