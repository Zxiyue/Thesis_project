# VRAC-FL Comparison and Ablation Pack v3 — 512-bit One Click

本包将主性能基线中的 Privacy-only 从 2048-bit 改为 **512-bit**，其余20轮消融继续使用512-bit。一次启动即可自动完成运行、上链、汇总和打包。

## 实验矩阵

1. E1 FedAvg：MNIST-IID/Non-IID，50轮；
2. E2 Privacy-only：MNIST-IID/Non-IID，512-bit、50轮；
3. CONTROL Full VRAC-FL：512-bit、20轮；
4. E3 Hash-only：512-bit、20轮；
5. E4 No Pedersen：512-bit、20轮；
6. E5 No KGC independent set：512-bit、20轮；
7. E6 No FaultTx：512-bit、20轮；
8. E7 No identity compensation optimization：512-bit、20轮；
9. E8 No ModelSync signature：512-bit、20轮。

512-bit用于原型配置下的收敛、配对性能和功能消融，不能表述为实际部署安全级别。已有2048-bit主方案结果继续用于标准安全参数性能说明。

## 是否清理旧结果

不需要删除已经完成的FedAvg结果。本包默认 `REUSE_PREVIOUS_RESULTS=1`，会在 `/root/fpa5/outputs` 中寻找并复用字段匹配的已完成FedAvg结果；只存在部分文件、没有有效 `summary.json` 的2048-bit Privacy-only结果不会复用。

启动新版前必须停止仍在运行的旧2048-bit进程，避免两个实验争抢CPU。旧输出建议先保留，确认新版结果包生成后再归档或删除。

## 一条命令运行

```bash
cd /root
unzip -o vracfl_comparison_ablation_pack_v3_512bit.zip
cd vracfl_comparison_ablation_pack_v3_512bit

tmux new -s vrac_ablation_512 \
"cd /root/vracfl_comparison_ablation_pack_v3_512bit && DOWNLOAD=1 bash run_once.sh 2>&1 | tee /root/vracfl_comparison_ablation_v3_512bit.log"
```

运行结束后自动生成：

```text
/root/vracfl_comparison_ablation_v3_512bit_results_<时间戳>.zip
```

## 常用参数

```bash
# 不搜索旧结果，全部重新运行
REUSE_PREVIOUS_RESULTS=0 bash run_once.sh

# 强制覆盖当前输出目录中的完整结果
FORCE_RERUN=1 bash run_once.sh

# 不运行Non-IID
RUN_NONIID=0 bash run_once.sh

# 无链调试
SKIP_CHAIN=1 bash run_once.sh
```

查看状态：

```bash
cd /root/fpa5/ablation_pack_v3_512bit
bash scripts/check_status.sh
```
