# Changelog

## v3-512bit-oneclick

- Privacy-only IID/Non-IID 50轮由2048-bit改为512-bit。
- 所有20轮消融继续使用512-bit。
- 新输出目录与结果ZIP使用 `v3_512bit` 标识，避免覆盖旧结果。
- 默认自动搜索并复用兼容的已完成FedAvg结果。
- 只复用存在有效 `summary.json`、参数完全匹配且 `accepted=true` 的结果。
- 不复用未完成的2048-bit Privacy-only目录。
- 文档增加停止旧进程、保留旧结果和完成后归档部分结果的步骤。
