#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}

echo "[1/3] Check dataset loaders for remaining Ours-basic configs"
python3 scripts/check_dataset_loader.py --configs \
  configs/mnist_iid_50r_lr020_main.yaml \
  configs/mnist_noniid_50r_lr020_main.yaml \
  configs/fashion_mnist_iid_50r_lr020_main.yaml \
  configs/cifar10_iid_50r_lr020_main.yaml \
  configs/cifar10_noniid_50r_lr020_main.yaml

echo "[2/3] Check dataset loaders for paper baseline configs"
python3 scripts/check_dataset_loader.py --configs \
  configs/baseline_repro_priverifl_a_mnist_iid_50r_lr020.yaml \
  configs/baseline_repro_priverifl_a_mnist_noniid_50r_lr020.yaml \
  configs/baseline_repro_rtpfl_mnist_iid_50r_lr020.yaml \
  configs/baseline_repro_rtpfl_mnist_iid_dropout_50r_lr020.yaml

echo "[3/3] Check paper baseline imports"
python3 - <<'PY'
from fl_audit.baselines.priverifl_a_repro import run_priverifl_a_repro
from fl_audit.baselines.rtpfl_repro import run_rtpfl_repro
print("paper baseline imports OK")
PY

echo "All lr020 remaining configs are ready."
