#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}

./run_ours_basic_lr020_remaining5.sh
./run_repro_paper_baselines_lr020.sh

cd /root
if [ -f /root/ours_basic_lr020_6x50_with_reused_fmnist_noniid_results.zip ]; then
  zip -qr /root/lr020_remaining9_plus_reused_all_results.zip \
    ours_basic_lr020_6x50_with_reused_fmnist_noniid_results.zip \
    repro_paper_baseline_lr020_all_results.zip
  echo "All experiments finished: /root/lr020_remaining9_plus_reused_all_results.zip"
else
  zip -qr /root/lr020_remaining9_all_results.zip \
    ours_basic_lr020_remaining5_results.zip \
    repro_paper_baseline_lr020_all_results.zip
  echo "All experiments finished: /root/lr020_remaining9_all_results.zip"
fi
