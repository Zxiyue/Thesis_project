#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
REUSED="outputs/fashion_mnist_noniid_50r_lr020_dropout"
echo "Checking reused Fashion-MNIST-Non-IID lr020 dropout probe result: ${REUSED}"
if [ ! -f "${REUSED}/verify_result.csv" ]; then
  echo "[WARN] ${REUSED}/verify_result.csv not found."
  echo "You can still run remaining 5 Ours-basic experiments, but the combined 6x50 package will not include the reused Fashion-MNIST-Non-IID result."
  exit 0
fi
cat "${REUSED}/verify_result.csv"
if grep -q "True,50" "${REUSED}/verify_result.csv"; then
  echo "[OK] Reused result is accepted=True, rounds=50."
else
  echo "[WARN] Reused result exists, but it is not accepted=True, rounds=50."
fi
tail -n 5 "${REUSED}/metrics_round.csv" 2>/dev/null || true
