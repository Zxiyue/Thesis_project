#!/usr/bin/env bash
set -uo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}

CONFIGS=(
  "configs/mnist_iid_50r_lr020_main.yaml"
  "configs/mnist_noniid_50r_lr020_main.yaml"
  "configs/fashion_mnist_iid_50r_lr020_main.yaml"
  "configs/cifar10_iid_50r_lr020_main.yaml"
  "configs/cifar10_noniid_50r_lr020_main.yaml"
)
NAMES=(
  "mnist_iid_50r_lr020_main"
  "mnist_noniid_50r_lr020_main"
  "fashion_mnist_iid_50r_lr020_main"
  "cifar10_iid_50r_lr020_main"
  "cifar10_noniid_50r_lr020_main"
)

check_hardhat() {
  curl -s -X POST http://127.0.0.1:8545 \
    -H "Content-Type: application/json" \
    --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' | grep -q '"result"'
}

if ! check_hardhat; then
  echo "[ERROR] Hardhat node is not reachable at 127.0.0.1:8545."
  echo "Start it first:"
  echo 'tmux new -d -s hardhat "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && npx hardhat node > /root/hardhat.log 2>&1"'
  exit 1
fi

run_one() {
  local cfg="$1"
  local name="$2"
  echo "================================================================"
  echo "Running ${name}"
  echo "Config: ${cfg}"
  echo "Ours-basic, local_lr=0.20, server_lr=1.0, 50 rounds"
  echo "================================================================"

  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  pkill -f "run_kgc_server.py" || true
  pkill -f "run_cs_server.py" || true
  pkill -f "run_client_server.py" || true
  pkill -f "start_experiment.py" || true
  sleep 3

  rm -rf "outputs/${name}"

  echo "[INFO] Deploying audit board contract..."
  npx hardhat run scripts/deploy.js --network localhost || { echo "[ERROR] deploy failed. Is Hardhat node running?"; exit 1; }

  echo "[INFO] Starting KGC/CS/clients..."
  python3 scripts/start_all_entities.py --config "${cfg}" --clients 5 || { echo "[ERROR] start_all_entities failed"; exit 1; }

  echo "[INFO] Starting experiment..."
  python3 scripts/start_experiment.py --config "${cfg}" || echo "[WARN] start_experiment returned non-zero; continue polling."

  local done_flag=0
  for i in $(seq 1 540); do
    if [ -f "outputs/${name}/verify_result.csv" ] && grep -q "True,50" "outputs/${name}/verify_result.csv"; then
      done_flag=1
      echo "[INFO] ${name} accepted=True rounds=50"
      break
    fi
    echo "---- $(date) ${name} status ----"
    tail -n 5 "outputs/${name}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
    cat "outputs/${name}/verify_result.csv" 2>/dev/null || echo "verify not ready"
    sleep 30
  done

  if [ "${done_flag}" -ne 1 ]; then
    echo "[ERROR] ${name} did not finish within polling window."
    python3 scripts/stop_all_entities.py --config "${cfg}" || true
    exit 1
  fi

  python3 scripts/collect_results.py --config "${cfg}" || true
  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  (cd /root/fpa5 && zip -qr "/root/${name}_results.zip" "outputs/${name}")
  echo "[INFO] Result zip: /root/${name}_results.zip"
}

for idx in "${!CONFIGS[@]}"; do
  run_one "${CONFIGS[$idx]}" "${NAMES[$idx]}"
done

cd /root
zip -qr /root/ours_basic_lr020_remaining5_results.zip \
  mnist_iid_50r_lr020_main_results.zip \
  mnist_noniid_50r_lr020_main_results.zip \
  fashion_mnist_iid_50r_lr020_main_results.zip \
  cifar10_iid_50r_lr020_main_results.zip \
  cifar10_noniid_50r_lr020_main_results.zip

echo "[INFO] Remaining 5 Ours-basic results: /root/ours_basic_lr020_remaining5_results.zip"

REUSED_DIR="/root/fpa5/outputs/fashion_mnist_noniid_50r_lr020_dropout"
if [ -f "${REUSED_DIR}/verify_result.csv" ] && grep -q "True,50" "${REUSED_DIR}/verify_result.csv"; then
  (cd /root/fpa5 && zip -qr /root/fashion_mnist_noniid_50r_lr020_reused_dropout_results.zip outputs/fashion_mnist_noniid_50r_lr020_dropout)
  cd /root
  zip -qr /root/ours_basic_lr020_6x50_with_reused_fmnist_noniid_results.zip \
    mnist_iid_50r_lr020_main_results.zip \
    mnist_noniid_50r_lr020_main_results.zip \
    fashion_mnist_iid_50r_lr020_main_results.zip \
    fashion_mnist_noniid_50r_lr020_reused_dropout_results.zip \
    cifar10_iid_50r_lr020_main_results.zip \
    cifar10_noniid_50r_lr020_main_results.zip
  echo "[INFO] Combined 6x50 Ours-basic package with reused Fashion-MNIST-Non-IID result:"
  echo "       /root/ours_basic_lr020_6x50_with_reused_fmnist_noniid_results.zip"
else
  echo "[WARN] Reused Fashion-MNIST-Non-IID lr020 dropout result not found or not accepted=True rounds=50."
  echo "       Only /root/ours_basic_lr020_remaining5_results.zip was created."
fi
