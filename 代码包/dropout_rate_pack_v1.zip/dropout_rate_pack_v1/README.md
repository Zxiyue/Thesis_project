# Dropout Rate Experiment Pack v1

This pack runs the Ours-packed dropout-rate functional experiment for the public-auditable FL project.

Default setting:

- Scheme: Ours-packed
- Dataset: MNIST-IID
- Clients: 10
- Threshold: 6
- Rounds: 20
- Paillier: 512-bit functional setting
- Packing: enabled, slot_bits=40, pack_size=auto
- Dropout rates: 0%, 10%, 20%, 30%, 40%, 50%-fail
- Blockchain: disabled; audit-chain verification is executed locally

The purpose is to verify dropout compensation, threshold recovery, model synchronization, and safe abort when the number of online clients is below the threshold. It is not used to evaluate the cryptographic security strength of 512-bit Paillier. Main performance experiments should still use 2048-bit Paillier.

## Run

```bash
cd /root
unzip -o dropout_rate_pack_v1.zip
cd /root/dropout_rate_pack_v1

stdbuf -oL -eL bash scripts/run_dropout_rate_suite.sh \
  | tee /root/dropout_rate_suite_v1.log
```

## Check status

```bash
bash /root/dropout_rate_pack_v1/scripts/check_dropout_rate_status.sh
```

## Output

The combined result package will be:

```text
/root/dropout_rate_mnist_iid_c10_t6_20r_p512_results.zip
```

Main files inside each rate directory:

- `dropout_result.csv`: one-row summary
- `dropout_round_status.csv`: per-round dropout/threshold status
- `model_sync_events.csv`: model synchronization events
- `compensation_status.csv`: dropout compensation status
- `runtime_cost.csv`: runtime details
- `communication_cost.csv`: communication details
- `verify_result.csv`: final verification result
