from __future__ import annotations
import argparse
import csv
import json
import zipfile
from pathlib import Path
from typing import Dict, List, Any


def read_csv_rows(path: Path) -> List[Dict[str, str]]:
    if not path.exists() or path.stat().st_size == 0:
        return []
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: List[Dict[str, Any]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def to_float(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-dir", required=True)
    ap.add_argument("--zip-out", default="/root/dropout_rate_mnist_iid_c10_t6_20r_p512_results.zip")
    args = ap.parse_args()
    base = Path(args.base_dir).resolve()
    rows: List[Dict[str, Any]] = []
    detail_rows: List[Dict[str, Any]] = []

    for result_file in sorted(base.glob("*/dropout_result.csv")):
        rs = read_csv_rows(result_file)
        if not rs:
            continue
        row = dict(rs[0])
        row["result_dir"] = str(result_file.parent)
        rows.append(row)

        round_file = result_file.parent / "dropout_round_status.csv"
        for rr in read_csv_rows(round_file):
            rr = dict(rr)
            rr["rate_dir"] = result_file.parent.name
            detail_rows.append(rr)

    # numeric sort by dropout_rate
    rows.sort(key=lambda r: to_float(r.get("dropout_rate", 0)))
    detail_rows.sort(key=lambda r: (to_float(r.get("dropout_rate", 0)), int(float(r.get("round", 0) or 0))))

    summary_csv = base / "dropout_rate_summary.csv"
    write_csv(summary_csv, rows)
    detail_csv = base / "dropout_rate_round_detail.csv"
    write_csv(detail_csv, detail_rows)
    summary_json = base / "dropout_rate_summary.json"
    summary_json.write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")

    md = base / "dropout_rate_summary.md"
    lines = ["# Dropout Rate Suite Summary", "", f"Base directory: `{base}`", ""]
    if rows:
        headers = [
            "dropout_rate", "dropout_count_per_round", "online_count_per_round", "threshold",
            "accepted", "status", "rounds_completed", "abort_round", "final_acc", "best_acc",
            "total_comm_mb", "model_sync_req_count", "model_sync_verified_count", "reason",
        ]
        lines.append("| " + " | ".join(headers) + " |")
        lines.append("|" + "|".join(["---"] * len(headers)) + "|")
        for r in rows:
            vals = [str(r.get(h, "")).replace("|", "/") for h in headers]
            lines.append("| " + " | ".join(vals) + " |")
    else:
        lines.append("No dropout_result.csv files found.")
    md.write_text("\n".join(lines) + "\n", encoding="utf-8")

    zip_out = Path(args.zip_out)
    if zip_out.exists():
        zip_out.unlink()
    with zipfile.ZipFile(zip_out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(base.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(base.parent))
    print(f"[OK] summary_csv={summary_csv}")
    print(f"[OK] detail_csv={detail_csv}")
    print(f"[OK] summary_md={md}")
    print(f"[OK] zip={zip_out}")


if __name__ == "__main__":
    main()
