#!/usr/bin/env bash
set -euo pipefail

FPA_DIR="${FPA_DIR:-/root/fpa5}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${CONFIG:-configs/dropout_rate_mnist_iid_c10_t6_20r_p512_packed.yaml}"
DEVICE="${DEVICE:-cpu}"
ROUNDS="${ROUNDS:-20}"
CLIENTS="${CLIENTS:-10}"
THRESHOLD="${THRESHOLD:-6}"
PAILLIER_BITS="${PAILLIER_BITS:-512}"
SLOT_BITS="${SLOT_BITS:-40}"
RATES="${RATES:-0 10 20 30 40 50}"
BASE_OUT="${BASE_OUT:-outputs/dropout_rate_mnist_iid_c10_t6_20r_p512}"
ZIP_OUT="${ZIP_OUT:-/root/dropout_rate_mnist_iid_c10_t6_20r_p512_results.zip}"

bash "$PACK_DIR/scripts/install_dropout_rate_pack.sh"
cd "$FPA_DIR"
export PYTHONPATH="$FPA_DIR:${PYTHONPATH:-}"

if [[ -d .venv ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

# Matgo public dataset helper: avoid slow公网 downloads.
if [[ ! -d /mnt/fpa5/data/MNIST && -d /root/fpa5/data/MNIST ]]; then
  echo "[INFO] Copy MNIST from /root/fpa5/data to /mnt/fpa5/data"
  mkdir -p /mnt/fpa5/data
  cp -a /root/fpa5/data/MNIST /mnt/fpa5/data/
fi
if [[ ! -d /mnt/fpa5/data/MNIST && -d /public/torchvision_datasets/MNIST ]]; then
  echo "[INFO] Copy MNIST from /public/torchvision_datasets to /mnt/fpa5/data"
  mkdir -p /mnt/fpa5/data
  cp -a /public/torchvision_datasets/MNIST /mnt/fpa5/data/
fi
if [[ ! -d /mnt/fpa5/data/MNIST ]]; then
  echo "[ERROR] MNIST not found at /mnt/fpa5/data/MNIST"
  echo "Please copy Matgo public dataset first: cp -a /public/torchvision_datasets/MNIST /mnt/fpa5/data/"
  exit 1
fi

mkdir -p "$BASE_OUT"

rate_key() {
  local r="$1"
  printf "d%02d" "$r"
}

for rate in ${RATES}; do
  key="$(rate_key "$rate")"
  out_dir="$BASE_OUT/$key"
  echo
  echo "================ RUN dropout_rate=${rate}% (${key}) ================"
  rm -rf "$out_dir"
  cmd=(python scripts/run_dropout_rate_experiment.py
    --config "$CONFIG"
    --dropout-rate "$rate"
    --rounds "$ROUNDS"
    --clients "$CLIENTS"
    --threshold "$THRESHOLD"
    --paillier-bits "$PAILLIER_BITS"
    --slot-bits "$SLOT_BITS"
    --device "$DEVICE"
    --output-dir "$out_dir")
  echo "${cmd[*]}"
  "${cmd[@]}" 2>&1 | tee "$out_dir.log"
done

python "$PACK_DIR/scripts/summarize_dropout_rate_results.py" --base-dir "$FPA_DIR/$BASE_OUT" --zip-out "$ZIP_OUT"

echo
echo "[DONE] Results package: $ZIP_OUT"
