#!/usr/bin/env bash
set -euo pipefail
FPA_DIR="${FPA_DIR:-/root/fpa5}"
BASE_OUT="${BASE_OUT:-outputs/dropout_rate_mnist_iid_c10_t6_20r_p512}"
cd "$FPA_DIR"
echo "[status] base: $FPA_DIR/$BASE_OUT"
if [[ -f "$BASE_OUT/dropout_rate_summary.csv" ]]; then
  echo "--- summary ---"
  cat "$BASE_OUT/dropout_rate_summary.csv"
  exit 0
fi
for d in "$BASE_OUT"/*; do
  [[ -d "$d" ]] || continue
  echo "--- $d ---"
  if [[ -f "$d/dropout_result.csv" ]]; then
    cat "$d/dropout_result.csv"
  else
    echo "dropout_result.csv not found"
    if [[ -f "$d.log" ]]; then tail -n 20 "$d.log"; fi
  fi
done
