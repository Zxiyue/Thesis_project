#!/usr/bin/env bash
set -euo pipefail

FPA_DIR="${FPA_DIR:-/root/fpa5}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ ! -d "$FPA_DIR" ]]; then
  echo "[ERROR] FPA_DIR not found: $FPA_DIR"
  echo "Please set FPA_DIR=/path/to/fpa5 and rerun."
  exit 1
fi

mkdir -p "$FPA_DIR/scripts" "$FPA_DIR/configs"

echo "[STEP] Reset core protocol files to pristine Ours-basic base"
python3 "$PACK_DIR/patch/reset_to_pristine_base.py"
echo "[STEP] Apply Ours-packed patch"
python3 "$PACK_DIR/patch/apply_ours_packed_patch.py"

cp -f "$PACK_DIR/fpa5_patch/scripts/run_dropout_rate_experiment.py" "$FPA_DIR/scripts/run_dropout_rate_experiment.py"
cp -f "$PACK_DIR/fpa5_patch/configs/dropout_rate_mnist_iid_c10_t6_20r_p512_packed.yaml" "$FPA_DIR/configs/dropout_rate_mnist_iid_c10_t6_20r_p512_packed.yaml"
chmod +x "$FPA_DIR/scripts/run_dropout_rate_experiment.py" || true

echo "[OK] Dropout-rate runner installed into $FPA_DIR"
echo "     - scripts/run_dropout_rate_experiment.py"
echo "     - configs/dropout_rate_mnist_iid_c10_t6_20r_p512_packed.yaml"
