# 门限参数 t 对比实验代码包 v1

本包用于在已有 `/root/fpa5` 项目环境上运行门限参数 `t` 对比实验。

## 1. 实验定位

本实验不用于重新证明模型收敛，而用于观察门限值 `t` 对协议恢复阶段、通信开销、运行时间和链上开销的影响。

历史实验设置中，客户端数量扩展性实验已经完成：

- 多进程 HTTP；
- individual 客户端进程；
- blockchain=on；
- 客户端数 5、10、20、40、60、80、100；
- 10 轮；
- Paillier 512-bit；
- slot_bits=40。

因此本实验保持相同实现口径，只固定客户端数量 `n=20`，改变门限参数 `t`。

## 2. 默认实验配置

```text
clients = 20
threshold_list = 4 8 12 16 20
rounds = 10
model = tiny_cnn
dataset = MNIST-IID
paillier_bits = 512
slot_bits = 40
blockchain = on
client_mode = individual
dropout = 0
```

对应实验点：

| case | n | t | 门限比例 |
|---|---:|---:|---:|
| t04 | 20 | 4 | 20% |
| t08 | 20 | 8 | 40% |
| t12 | 20 | 12 | 60% |
| t16 | 20 | 16 | 80% |
| t20 | 20 | 20 | 100% |

## 3. 为什么用 10 轮

门限参数 `t` 不改变聚合明文，只改变需要多少个合法份额才能恢复聚合结果。因此该实验核心是协议开销，而不是模型收敛。10 轮已足够计算平均通信、平均 gas 和恢复阶段运行开销，并且与已经完成的客户端数量实验保持一致。

## 4. 输出目录

默认输出目录：

```text
/root/fpa5/outputs/threshold_t_multiprocess_mnist_iid_c20_p512_s40_10r_chain
```

默认结果包：

```text
/root/threshold_t_multiprocess_mnist_iid_c20_p512_s40_10r_chain_results.zip
```

默认日志：

```text
/root/threshold_t_multiprocess_mnist_iid_c20_p512_s40_10r_chain.log
```

## 5. 已处理的历史问题

本包已内置以下修复，避免重复手工修改：

1. 自动使用 `/root/fpa5/.venv/bin/python`，避免 `python: command not found`。
2. 自动将 `start_all_entities.py` 的 health timeout 补到 600 秒。
3. 自动清理 9200、9300、9401-9500 端口残留进程。
4. 自动限制 OMP/OpenBLAS/MKL/NumExpr/PyTorch 线程数为 1。
5. 汇总脚本不使用 `pandas.to_markdown()`，不依赖 `tabulate`。
6. 汇总脚本对 runtime/crypto 数值字段使用 `pd.to_numeric(errors="coerce")`，避免历史 `6794` 字符串转数值错误。

## 6. 运行脚本

先运行边界 smoke：

```bash
bash scripts/run_threshold_t_smoke_1r.sh
```

smoke 成功后运行完整实验：

```bash
bash scripts/run_threshold_t_multiprocess_full.sh
```

建议在 `tmux` 中运行完整实验。

## 7. 可覆盖参数

可以通过环境变量覆盖默认参数：

```bash
THRESHOLD_LIST="4 8 12 16 20" ROUNDS=10 bash scripts/run_threshold_t_multiprocess_full.sh
```

常用覆盖项：

```text
CLIENTS
THRESHOLD_LIST
ROUNDS
MODEL
PAILLIER_BITS
SLOT_BITS
BLOCKCHAIN
CLIENT_MODE
BASE_OUT
ZIP_OUT
SUITE_LOG
DATASET_DIR
```
