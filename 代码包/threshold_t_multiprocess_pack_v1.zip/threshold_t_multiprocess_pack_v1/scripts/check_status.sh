#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE:-/root/fpa5/outputs/threshold_t_multiprocess_mnist_iid_c20_p512_s40_10r_chain}"
echo "[INFO] base: $BASE"
if [[ ! -d "$BASE" ]]; then
  echo "[WARN] base directory not found"
  exit 0
fi
for d in "$BASE"/t*; do
  [[ -d "$d" ]] || continue
  echo "===== $(basename "$d") ====="
  if [[ -f "$d/verify_result.csv" ]]; then
    tail -n +1 "$d/verify_result.csv"
  else
    echo "verify_result.csv missing"
  fi
  if [[ -f "$d/blockchain_cost.csv" ]]; then
    echo "tx_count=$(($(wc -l < "$d/blockchain_cost.csv")-1))"
    tail -n 3 "$d/blockchain_cost.csv"
  fi
  if [[ -f "$d/metrics.csv" ]]; then
    echo "metrics tail:"
    tail -n 2 "$d/metrics.csv"
  fi
done
