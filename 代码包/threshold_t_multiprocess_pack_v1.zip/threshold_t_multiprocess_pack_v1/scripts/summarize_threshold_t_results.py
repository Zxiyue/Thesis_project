#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path
import pandas as pd


def read_csv(p: Path) -> pd.DataFrame:
    try:
        return pd.read_csv(p)
    except Exception:
        return pd.DataFrame()


def read_json(p: Path):
    try:
        return json.loads(p.read_text(encoding='utf-8'))
    except Exception:
        return None


def find_col(df: pd.DataFrame, names: list[str]) -> str | None:
    lower = {c.lower(): c for c in df.columns}
    for n in names:
        if n.lower() in lower:
            return lower[n.lower()]
    for c in df.columns:
        cl = c.lower()
        for n in names:
            if n.lower() in cl:
                return c
    return None


def boolish(x):
    if isinstance(x, bool):
        return x
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return None
    return str(x).strip().lower() in {'true', '1', 'yes', 'y', 'accepted'}


def as_float(x, default=0.0):
    try:
        if pd.isna(x):
            return default
        return float(x)
    except Exception:
        return default


def safe_name(x: object, limit: int = 64) -> str:
    return re.sub(r'[^A-Za-z0-9]+', '_', str(x)).strip('_')[:limit] or 'unknown'


def summarize_one(run_dir: Path) -> dict:
    m = re.search(r't(\d+)', run_dir.name)
    threshold = int(m.group(1)) if m else None
    row = {'case': run_dir.name, 'threshold': threshold, 'run_dir': str(run_dir)}

    # Config fields
    cfg_candidates = list(run_dir.parent.glob(f'{run_dir.name}_runtime.yaml')) + list(run_dir.glob('*runtime*.yaml'))
    if cfg_candidates:
        txt = cfg_candidates[0].read_text(encoding='utf-8', errors='ignore')
        for key, pat, typ in [
            ('clients', r'clients:\s*(\d+)', int),
            ('rounds_configured', r'rounds:\s*(\d+)', int),
            ('threshold_configured', r'threshold:\s*(\d+)', int),
            ('paillier_bits', r'paillier_bits:\s*(\d+)', int),
            ('slot_bits', r'slot_bits:\s*(\d+)', int),
        ]:
            mm = re.search(pat, txt)
            if mm:
                row[key] = typ(mm.group(1))
        mm = re.search(r'model:\s*\n\s*name:\s*([A-Za-z0-9_\-]+)', txt)
        if mm:
            row['model'] = mm.group(1)

    vr = read_csv(run_dir / 'verify_result.csv')
    if not vr.empty:
        for col in vr.columns:
            val = vr.iloc[-1][col]
            if col.lower() in {'accepted', 'verify_accepted', 'third_party_accepted'}:
                row['accepted'] = boolish(val)
            elif col.lower() in {'completed', 'success'}:
                row['completed'] = boolish(val)
            else:
                row[f'verify_{col}'] = val

    metrics = read_csv(run_dir / 'metrics.csv')
    if not metrics.empty:
        rcol = find_col(metrics, ['round', 'r'])
        if rcol:
            rr = pd.to_numeric(metrics[rcol], errors='coerce').dropna()
            row['rounds_completed'] = int(rr.max()) if len(rr) else len(metrics)
        else:
            row['rounds_completed'] = len(metrics)
        acc_col = find_col(metrics, ['test_acc', 'accuracy', 'acc'])
        loss_col = find_col(metrics, ['test_loss', 'loss'])
        if acc_col:
            accs = pd.to_numeric(metrics[acc_col], errors='coerce').dropna()
            row['final_accuracy'] = float(accs.iloc[-1]) if len(accs) else 0.0
        if loss_col:
            losses = pd.to_numeric(metrics[loss_col], errors='coerce').dropna()
            row['final_loss'] = float(losses.iloc[-1]) if len(losses) else 0.0
    else:
        row.setdefault('rounds_completed', 0)

    comm = read_csv(run_dir / 'communication_cost.csv')
    if not comm.empty:
        bytes_col = find_col(comm, ['bytes', 'size_bytes', 'actual_bytes', 'total_bytes'])
        ptype_col = find_col(comm, ['payload_type', 'type', 'message_type'])
        sec_col = find_col(comm, ['actual_seconds', 'seconds', 'elapsed_seconds'])
        if bytes_col:
            b = pd.to_numeric(comm[bytes_col], errors='coerce').fillna(0)
            row['comm_rows'] = len(comm)
            row['total_comm_bytes'] = int(b.sum())
            row['total_comm_MB'] = float(b.sum() / 1024 / 1024)
            rounds = int(row.get('rounds_completed', row.get('rounds_configured', 1)) or 1)
            row['comm_MB_per_round'] = row['total_comm_MB'] / max(1, rounds)
        if sec_col:
            secs = pd.to_numeric(comm[sec_col], errors='coerce').dropna()
            row['comm_actual_seconds_sum'] = float(secs.sum()) if len(secs) else 0.0
        if ptype_col and bytes_col:
            temp = comm.assign(_bytes=pd.to_numeric(comm[bytes_col], errors='coerce').fillna(0))
            grp = temp.groupby(ptype_col)['_bytes'].sum().sort_values(ascending=False)
            for ptype, val in grp.items():
                row['comm_MB_' + safe_name(ptype, 60)] = float(val / 1024 / 1024)

    bc = read_csv(run_dir / 'blockchain_cost.csv')
    if not bc.empty:
        gas_col = find_col(bc, ['gas_used', 'gas', 'gasUsed'])
        tx_col = find_col(bc, ['tx_type', 'type', 'name'])
        lat_col = find_col(bc, ['latency_seconds', 'seconds', 'actual_seconds'])
        if gas_col:
            gas = pd.to_numeric(bc[gas_col], errors='coerce').fillna(0)
            row['chain_tx_count'] = len(bc)
            row['total_gas'] = int(gas.sum())
            if tx_col:
                txs = bc[tx_col].astype(str)
                init_mask = txs.str.contains('Init', case=False, na=False)
                final_mask = txs.str.contains('Final', case=False, na=False)
                row['init_tx_count'] = int(init_mask.sum())
                row['finaltx_count'] = int(final_mask.sum())
                if init_mask.any():
                    row['init_tx_gas'] = int(pd.to_numeric(bc.loc[init_mask, gas_col], errors='coerce').fillna(0).iloc[0])
                if final_mask.any():
                    final_gas = pd.to_numeric(bc.loc[final_mask, gas_col], errors='coerce').dropna()
                    row['avg_finaltx_gas'] = float(final_gas.mean()) if len(final_gas) else 0.0
                    row['min_finaltx_gas'] = int(final_gas.min()) if len(final_gas) else 0
                    row['max_finaltx_gas'] = int(final_gas.max()) if len(final_gas) else 0
        if lat_col:
            lat = pd.to_numeric(bc[lat_col], errors='coerce').dropna()
            row['chain_latency_seconds_sum'] = float(lat.sum()) if len(lat) else 0.0

    # Runtime / crypto cost. Explicit numeric conversion avoids historical `6794` string bug.
    for fname, prefix in [('runtime_cost.csv', 'runtime'), ('crypto_cost.csv', 'crypto')]:
        df = read_csv(run_dir / fname)
        if df.empty:
            continue
        metric_col = find_col(df, ['metric', 'name', 'stage'])
        val_col = find_col(df, ['value', 'seconds', 'time_seconds'])
        if metric_col and val_col:
            d2 = df.copy()
            d2['_value'] = pd.to_numeric(d2[val_col], errors='coerce')
            row[f'{prefix}_numeric_sum'] = float(d2['_value'].dropna().sum())
            for metric, sub in d2.groupby(metric_col):
                vals = sub['_value'].dropna()
                if not len(vals):
                    continue
                safe = safe_name(metric, 60)
                row[f'{prefix}_mean_{safe}'] = float(vals.mean())
                row[f'{prefix}_sum_{safe}'] = float(vals.sum())

    # Wall-clock from trace when available.
    trace = read_json(run_dir / 'run_trace.json')
    if trace:
        row['trace_completed'] = bool(trace.get('completed', False))
        if 'accepted' in trace:
            row['trace_accepted'] = bool(trace.get('accepted', False))
        if isinstance(trace.get('rounds'), list):
            row['trace_round_count'] = len(trace['rounds'])
        for key in ['wall_seconds', 'total_seconds', 'elapsed_seconds']:
            if key in trace:
                row['trace_' + key] = as_float(trace[key])

    return row


def df_to_markdown(df: pd.DataFrame) -> str:
    if df is None or len(df) == 0:
        return '(No summary rows found.)'
    cols = list(df.columns)
    rows = []
    for _, r in df.iterrows():
        row = []
        for c in cols:
            v = r.get(c, '')
            if pd.isna(v):
                v = ''
            elif isinstance(v, float):
                v = f'{v:.4f}'
            row.append(str(v))
        rows.append(row)
    widths = [max(len(str(c)), *(len(row[i]) for row in rows)) if rows else len(str(c)) for i, c in enumerate(cols)]
    def fmt(vals):
        return '| ' + ' | '.join(str(v).ljust(widths[i]) for i, v in enumerate(vals)) + ' |'
    return '\n'.join([fmt(cols), '| ' + ' | '.join('-' * w for w in widths) + ' |'] + [fmt(row) for row in rows])


def write_markdown(base_dir: Path, summary: pd.DataFrame) -> None:
    md = []
    md.append('# Threshold t Multiprocess Summary\n')
    md.append(f'- Base dir: `{base_dir}`')
    md.append(f'- Runs: {len(summary)}')
    if len(summary) and 'accepted' in summary.columns:
        ok = summary['accepted'].astype(str).str.lower().isin(['true', '1']).sum()
        md.append(f'- Accepted runs: {ok}/{len(summary)}')
    md.append('\n## Key table\n')
    keys = [c for c in [
        'case','clients','threshold','rounds_completed','accepted','final_accuracy',
        'total_comm_MB','comm_MB_per_round','comm_MB_DecShare','comm_MB_AggMsg',
        'init_tx_gas','finaltx_count','avg_finaltx_gas','total_gas',
        'runtime_numeric_sum','crypto_numeric_sum'
    ] if c in summary.columns]
    md.append(df_to_markdown(summary[keys]) if keys and len(summary) else '(No summary rows found.)')
    md.append('\n\n## Notes\n')
    md.append('- Final protocol verdict uses `verify_result.csv` / `accepted`. Some `run_trace.json` files do not contain top-level `accepted`.')
    md.append('- If every online client sends a decryption share in the implementation, total share communication may not vary strongly with t. In that case, use Combine/recovery runtime and the security-availability tradeoff as the main t-related evidence.')
    md.append('- Chain cost is expected to remain nearly stable because the chain writes fixed InitTx/FinalTx declarations, not per-client decryption shares.')
    (base_dir / 'threshold_t_multiprocess_summary.md').write_text('\n'.join(md), encoding='utf-8')


def zip_dir(base_dir: Path, zip_out: Path, extra_files: list[Path] | None = None) -> None:
    zip_out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_out, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(base_dir.rglob('*')):
            if p.is_file():
                zf.write(p, arcname=str(base_dir.name + '/' + p.relative_to(base_dir).as_posix()))
        for p in extra_files or []:
            if p.exists() and p.is_file():
                zf.write(p, arcname=str(base_dir.name + '/logs/' + p.name))
    print(f'[OK] zip written: {zip_out}')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base-dir', required=True)
    ap.add_argument('--zip-out', required=True)
    ap.add_argument('--extra-log', action='append', default=[])
    args = ap.parse_args()

    base_dir = Path(args.base_dir).resolve()
    if base_dir.exists():
        runs = sorted([p for p in base_dir.iterdir() if p.is_dir() and re.match(r't\d+$', p.name)], key=lambda p: int(re.search(r't(\d+)', p.name).group(1)))
    else:
        runs = []
    rows = [summarize_one(p) for p in runs]
    summary = pd.DataFrame(rows)
    if len(summary) and 'threshold' in summary.columns:
        summary = summary.sort_values('threshold')
    base_dir.mkdir(parents=True, exist_ok=True)
    summary.to_csv(base_dir / 'threshold_t_summary.csv', index=False)

    if len(summary):
        gas_cols = [c for c in ['case','clients','threshold','init_tx_gas','finaltx_count','avg_finaltx_gas','min_finaltx_gas','max_finaltx_gas','total_gas','chain_tx_count','chain_latency_seconds_sum'] if c in summary.columns]
        if gas_cols:
            summary[gas_cols].to_csv(base_dir / 'gas_by_threshold_t.csv', index=False)
        comm_cols = [c for c in summary.columns if c in ['case','clients','threshold','rounds_completed','total_comm_bytes','total_comm_MB','comm_MB_per_round','comm_actual_seconds_sum'] or c.startswith('comm_MB_')]
        if comm_cols:
            summary[comm_cols].to_csv(base_dir / 'communication_by_threshold_t.csv', index=False)
        runtime_cols = [c for c in summary.columns if c in ['case','clients','threshold','runtime_numeric_sum','crypto_numeric_sum'] or c.startswith('runtime_') or c.startswith('crypto_')]
        if runtime_cols:
            summary[runtime_cols].to_csv(base_dir / 'runtime_by_threshold_t.csv', index=False)

    write_markdown(base_dir, summary)
    print(summary.to_string(index=False) if len(summary) else '[WARN] no tNN run directories found')
    zip_dir(base_dir, Path(args.zip_out), extra_files=[Path(x) for x in args.extra_log])


if __name__ == '__main__':
    main()
