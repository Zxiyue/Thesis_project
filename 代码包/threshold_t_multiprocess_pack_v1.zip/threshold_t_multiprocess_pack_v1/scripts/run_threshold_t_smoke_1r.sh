#!/usr/bin/env bash
set -euo pipefail

# Boundary smoke test: n=20, t=20, 1 round, multiprocess HTTP, chain on.
# This checks the strictest threshold case before the full threshold sweep.
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PACK_DIR"

export CLIENTS="${CLIENTS:-20}"
export THRESHOLD_LIST="${THRESHOLD_LIST:-20}"
export ROUNDS="${ROUNDS:-1}"
export CLIENT_MODE="${CLIENT_MODE:-individual}"
export BLOCKCHAIN="${BLOCKCHAIN:-on}"
export PAILLIER_BITS="${PAILLIER_BITS:-512}"
export SLOT_BITS="${SLOT_BITS:-40}"
export MODEL="${MODEL:-tiny_cnn}"
export BASE_OUT="${BASE_OUT:-outputs/threshold_t_multiprocess_smoke_mnist_iid_c20_p512_s40_1r_chain}"
export ZIP_OUT="${ZIP_OUT:-/root/threshold_t_multiprocess_smoke_mnist_iid_c20_p512_s40_1r_chain_results.zip}"
export SUITE_LOG="${SUITE_LOG:-/root/threshold_t_multiprocess_smoke_mnist_iid_c20_p512_s40_1r_chain.log}"
export CLEAN_BASE_OUT="${CLEAN_BASE_OUT:-1}"

bash scripts/run_threshold_t_multiprocess_full.sh
