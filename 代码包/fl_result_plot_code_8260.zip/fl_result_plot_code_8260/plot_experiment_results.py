#!/usr/bin/env python3
"""
Analyze and plot 4x50-round federated public-audit experiment results.

Input can be either:
  1) a combined zip containing four nested result zips, e.g. all_4x50_8260_results.zip; or
  2) a directory containing *_results.zip files; or
  3) an already extracted directory containing outputs/<experiment_name> directories.

Output:
  figures/*.png
  tables/*.csv
  data_integrity_warnings.txt
"""

from __future__ import annotations

import argparse
import hashlib
import shutil
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


EXPERIMENT_ORDER = [
    "MNIST-IID",
    "MNIST-Non-IID",
    "Fashion-MNIST-IID",
    "Fashion-MNIST-Non-IID",
]

DIR_TO_LABEL = {
    "mnist_iid_50r_main": "MNIST-IID",
    "mnist_noniid_50r_main": "MNIST-Non-IID",
    "fashion_mnist_iid_50r_main": "Fashion-MNIST-IID",
    "fashion_mnist_noniid_50r_main": "Fashion-MNIST-Non-IID",
}

REQUIRED_FILES = [
    "metrics_round.csv",
    "verify_result.csv",
    "runtime_cost.csv",
    "crypto_cost.csv",
    "blockchain_cost.csv",
    "communication_summary_by_type.csv",
    "communication_network_only.csv",
    "communication_processing_requests.csv",
]


@dataclass
class ExperimentData:
    label: str
    path: Path
    metrics: pd.DataFrame
    verify: pd.DataFrame
    runtime: pd.DataFrame
    crypto: pd.DataFrame
    blockchain: pd.DataFrame
    comm_summary: pd.DataFrame
    comm_network: pd.DataFrame
    comm_processing: pd.DataFrame


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path)


def _extract_zip(zip_path: Path, dest: Path) -> None:
    with zipfile.ZipFile(zip_path, "r") as zf:
        for member in zf.infolist():
            # Protect against zip-slip paths.
            member_path = dest / member.filename
            if not str(member_path.resolve()).startswith(str(dest.resolve())):
                raise RuntimeError(f"Unsafe zip member path: {member.filename}")
        zf.extractall(dest)


def prepare_input(input_path: Path, work_dir: Path) -> Path:
    """Return a directory that can be scanned for outputs/* result dirs."""
    input_path = input_path.resolve()
    if input_path.is_file() and input_path.suffix.lower() == ".zip":
        root = work_dir / "combined_extracted"
        root.mkdir(parents=True, exist_ok=True)
        _extract_zip(input_path, root)
        # Extract any nested result zips.
        for z in list(root.rglob("*.zip")):
            out = root / z.stem
            out.mkdir(parents=True, exist_ok=True)
            _extract_zip(z, out)
        return root

    if input_path.is_dir():
        root = work_dir / "dir_input"
        root.mkdir(parents=True, exist_ok=True)
        # If directory contains zips, extract them; otherwise copy nothing and scan original too.
        zips = list(input_path.rglob("*.zip"))
        if zips:
            for z in zips:
                out = root / z.stem
                out.mkdir(parents=True, exist_ok=True)
                _extract_zip(z, out)
            return root
        return input_path

    raise FileNotFoundError(f"Input path not found: {input_path}")


def find_experiments(scan_root: Path) -> Dict[str, Path]:
    candidates: Dict[str, Path] = {}
    for d in scan_root.rglob("outputs"):
        if not d.is_dir():
            continue
        for child in d.iterdir():
            if child.is_dir() and child.name in DIR_TO_LABEL:
                label = DIR_TO_LABEL[child.name]
                candidates[label] = child

    # Also support scanning direct experiment directories.
    for child in scan_root.rglob("*"):
        if child.is_dir() and child.name in DIR_TO_LABEL:
            if all((child / f).exists() for f in ["metrics_round.csv", "verify_result.csv"]):
                candidates[DIR_TO_LABEL[child.name]] = child

    return {label: candidates[label] for label in EXPERIMENT_ORDER if label in candidates}


def load_experiment(label: str, path: Path) -> ExperimentData:
    missing = [f for f in REQUIRED_FILES if not (path / f).exists()]
    if missing:
        raise FileNotFoundError(f"Missing files for {label}: {missing}")

    return ExperimentData(
        label=label,
        path=path,
        metrics=_safe_read_csv(path / "metrics_round.csv"),
        verify=_safe_read_csv(path / "verify_result.csv"),
        runtime=_safe_read_csv(path / "runtime_cost.csv"),
        crypto=_safe_read_csv(path / "crypto_cost.csv"),
        blockchain=_safe_read_csv(path / "blockchain_cost.csv"),
        comm_summary=_safe_read_csv(path / "communication_summary_by_type.csv"),
        comm_network=_safe_read_csv(path / "communication_network_only.csv"),
        comm_processing=_safe_read_csv(path / "communication_processing_requests.csv"),
    )


def collect_summary(experiments: Dict[str, ExperimentData]) -> Tuple[pd.DataFrame, List[str]]:
    rows: List[dict] = []
    warnings: List[str] = []

    metric_hashes: Dict[str, str] = {}
    for label, exp in experiments.items():
        metric_hashes[label] = _sha256_file(exp.path / "metrics_round.csv")

    labels = list(experiments.keys())
    for i, a in enumerate(labels):
        for b in labels[i + 1:]:
            if metric_hashes[a] == metric_hashes[b]:
                warnings.append(f"WARNING: metrics_round.csv is identical for {a} and {b}.")

    for label, exp in experiments.items():
        m = exp.metrics.copy()
        v = exp.verify.copy()
        rt = exp.runtime.copy()
        bc = exp.blockchain.copy()
        cs = exp.comm_summary.copy()
        net = exp.comm_network.copy()
        proc = exp.comm_processing.copy()

        for col in ["test_accuracy", "test_loss", "round", "effective_clients", "dropout_clients"]:
            if col in m.columns:
                m[col] = pd.to_numeric(m[col], errors="coerce")

        r50 = m[m["round"] == 50]
        if r50.empty:
            warnings.append(f"WARNING: {label} has no round=50 row in metrics_round.csv.")
            last = m.iloc[-1]
        else:
            last = r50.iloc[0]

        launcher = proc[proc.get("payload_type", pd.Series(dtype=str)).eq("StartExperiment")]
        start_exp_sec = float(launcher["actual_seconds"].iloc[0]) if len(launcher) else np.nan

        start_wall = rt[rt["stage"].eq("start_experiment_total_wall")]["seconds"].sum()
        upload_wall = rt[rt["stage"].eq("client_upload_parallel_wall")]["seconds"].sum()

        finaltx = bc[bc["tx_type"].eq("FinalTx")]
        init = bc[bc["tx_type"].eq("InitTx")]

        rows.append({
            "experiment": label,
            "accepted": bool(v["accepted"].iloc[0]),
            "rounds": int(v["rounds"].iloc[0]),
            "initial_accuracy": float(m[m["round"].eq(0)]["test_accuracy"].iloc[0]) if (m["round"].eq(0)).any() else np.nan,
            "final_accuracy": float(last["test_accuracy"]),
            "final_loss": float(last["test_loss"]),
            "best_accuracy": float(m["test_accuracy"].max()),
            "best_accuracy_round": int(m.loc[m["test_accuracy"].idxmax(), "round"]),
            "min_loss": float(m["test_loss"].min()),
            "min_loss_round": int(m.loc[m["test_loss"].idxmin(), "round"]),
            "dropout_rounds": ";".join(map(str, m.loc[m["dropout_clients"].gt(0), "round"].astype(int).tolist())),
            "summary_total_MB": float(cs["total_MB"].sum()),
            "network_total_MB": float(net["bytes"].sum() / 1024 / 1024),
            "message_count_total": int(cs["count"].sum()),
            "start_experiment_http_seconds": start_exp_sec,
            "total_wall_seconds_runtime": float(start_wall),
            "total_wall_minutes_runtime": float(start_wall / 60.0),
            "upload_parallel_wall_seconds": float(upload_wall),
            "upload_parallel_wall_avg_per_round_seconds": float(upload_wall / 50.0),
            "blockchain_total_gas": int(bc["gas_used"].sum()),
            "init_gas": int(init["gas_used"].sum()) if len(init) else 0,
            "finaltx_total_gas": int(finaltx["gas_used"].sum()),
            "finaltx_avg_gas": float(finaltx["gas_used"].mean()),
            "blockchain_total_latency_seconds": float(bc["latency_sec"].sum()),
            "metrics_sha256": metric_hashes[label],
        })

        if not bool(v["accepted"].iloc[0]) or int(v["rounds"].iloc[0]) != 50:
            warnings.append(f"WARNING: {label} verification is not accepted=True, rounds=50.")

    return pd.DataFrame(rows), warnings


def build_tables(experiments: Dict[str, ExperimentData], tables_dir: Path) -> pd.DataFrame:
    tables_dir.mkdir(parents=True, exist_ok=True)
    summary, warnings = collect_summary(experiments)
    summary.to_csv(tables_dir / "experiment_summary.csv", index=False)

    # Combined metrics by round.
    metrics_all = []
    for label, exp in experiments.items():
        df = exp.metrics.copy()
        df.insert(0, "experiment", label)
        metrics_all.append(df)
    pd.concat(metrics_all, ignore_index=True).to_csv(tables_dir / "metrics_round_combined.csv", index=False)

    # Runtime by stage.
    runtime_rows = []
    for label, exp in experiments.items():
        agg = exp.runtime.groupby("stage", as_index=False)["seconds"].sum()
        agg.insert(0, "experiment", label)
        runtime_rows.append(agg)
    runtime_summary = pd.concat(runtime_rows, ignore_index=True)
    runtime_summary.to_csv(tables_dir / "runtime_stage_summary.csv", index=False)

    # Communication by type.
    comm_rows = []
    for label, exp in experiments.items():
        df = exp.comm_summary.copy()
        df.insert(0, "experiment", label)
        total = df["total_MB"].sum()
        df["share_percent"] = np.where(total > 0, df["total_MB"] / total * 100, np.nan)
        comm_rows.append(df)
    comm_summary = pd.concat(comm_rows, ignore_index=True)
    comm_summary.to_csv(tables_dir / "communication_summary_combined.csv", index=False)

    # Blockchain summary.
    bc_rows = []
    for label, exp in experiments.items():
        agg = exp.blockchain.groupby("tx_type").agg(
            count=("tx_type", "count"),
            total_gas=("gas_used", "sum"),
            avg_gas=("gas_used", "mean"),
            min_gas=("gas_used", "min"),
            max_gas=("gas_used", "max"),
            total_latency_sec=("latency_sec", "sum"),
            avg_latency_sec=("latency_sec", "mean"),
        ).reset_index()
        agg.insert(0, "experiment", label)
        bc_rows.append(agg)
    pd.concat(bc_rows, ignore_index=True).to_csv(tables_dir / "blockchain_summary.csv", index=False)

    # Crypto summary.
    crypto_rows = []
    for label, exp in experiments.items():
        df = exp.crypto.copy()
        df["value_num"] = pd.to_numeric(df["value"], errors="coerce")
        agg = df.groupby("metric").agg(
            count=("value_num", "count"),
            total=("value_num", "sum"),
            mean=("value_num", "mean"),
            max=("value_num", "max"),
        ).reset_index()
        agg.insert(0, "experiment", label)
        crypto_rows.append(agg)
    pd.concat(crypto_rows, ignore_index=True).to_csv(tables_dir / "crypto_summary.csv", index=False)

    # Data integrity warnings.
    if not warnings:
        warnings.append("No duplicated metrics_round.csv files detected. All loaded experiments are accepted=True and rounds=50.")
    (tables_dir / "data_integrity_warnings.txt").write_text("\n".join(warnings) + "\n", encoding="utf-8")

    return summary


def save_fig(fig: plt.Figure, path: Path) -> None:
    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_accuracy_loss(experiments: Dict[str, ExperimentData], figures_dir: Path) -> None:
    fig, ax = plt.subplots(figsize=(9, 5))
    for label in EXPERIMENT_ORDER:
        if label in experiments:
            m = experiments[label].metrics
            ax.plot(m["round"], m["test_accuracy"], marker="o", markersize=2, linewidth=1.6, label=label)
    ax.set_xlabel("Round")
    ax.set_ylabel("Test accuracy")
    ax.set_title("Accuracy over 50 rounds")
    ax.grid(True, alpha=0.3)
    ax.legend()
    save_fig(fig, figures_dir / "01_accuracy_curves.png")

    fig, ax = plt.subplots(figsize=(9, 5))
    for label in EXPERIMENT_ORDER:
        if label in experiments:
            m = experiments[label].metrics
            ax.plot(m["round"], m["test_loss"], marker="o", markersize=2, linewidth=1.6, label=label)
    ax.set_xlabel("Round")
    ax.set_ylabel("Test loss")
    ax.set_title("Loss over 50 rounds")
    ax.grid(True, alpha=0.3)
    ax.legend()
    save_fig(fig, figures_dir / "02_loss_curves.png")


def plot_final_bars(summary: pd.DataFrame, figures_dir: Path) -> None:
    df = summary.set_index("experiment").loc[[x for x in EXPERIMENT_ORDER if x in summary["experiment"].values]].reset_index()
    x = np.arange(len(df))

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(x, df["final_accuracy"] * 100)
    ax.set_xticks(x)
    ax.set_xticklabels(df["experiment"], rotation=20, ha="right")
    ax.set_ylabel("Final accuracy (%)")
    ax.set_title("Final accuracy at round 50")
    ax.grid(True, axis="y", alpha=0.3)
    for i, v in enumerate(df["final_accuracy"] * 100):
        ax.text(i, v, f"{v:.2f}%", ha="center", va="bottom", fontsize=9)
    save_fig(fig, figures_dir / "03_final_accuracy_bar.png")

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(x, df["final_loss"])
    ax.set_xticks(x)
    ax.set_xticklabels(df["experiment"], rotation=20, ha="right")
    ax.set_ylabel("Final loss")
    ax.set_title("Final loss at round 50")
    ax.grid(True, axis="y", alpha=0.3)
    for i, v in enumerate(df["final_loss"]):
        ax.text(i, v, f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    save_fig(fig, figures_dir / "04_final_loss_bar.png")


def plot_iid_gap(summary: pd.DataFrame, figures_dir: Path) -> None:
    # Compare IID and Non-IID for MNIST/Fashion final accuracy.
    rows = []
    for dataset in ["MNIST", "Fashion-MNIST"]:
        iid = summary[summary["experiment"].eq(f"{dataset}-IID")]
        non = summary[summary["experiment"].eq(f"{dataset}-Non-IID")]
        if len(iid) and len(non):
            rows.append({
                "dataset": dataset,
                "IID": float(iid["final_accuracy"].iloc[0] * 100),
                "Non-IID": float(non["final_accuracy"].iloc[0] * 100),
                "gap": float((iid["final_accuracy"].iloc[0] - non["final_accuracy"].iloc[0]) * 100),
            })
    if not rows:
        return
    df = pd.DataFrame(rows)
    x = np.arange(len(df))
    width = 0.35
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(x - width/2, df["IID"], width, label="IID")
    ax.bar(x + width/2, df["Non-IID"], width, label="Non-IID")
    ax.set_xticks(x)
    ax.set_xticklabels(df["dataset"])
    ax.set_ylabel("Final accuracy (%)")
    ax.set_title("Effect of non-IID data on final accuracy")
    ax.grid(True, axis="y", alpha=0.3)
    ax.legend()
    for i, row in df.iterrows():
        ax.text(i, max(row["IID"], row["Non-IID"]) + 1.0, f"gap {row['gap']:.2f} pp", ha="center", fontsize=9)
    save_fig(fig, figures_dir / "05_iid_vs_noniid_accuracy_gap.png")


def plot_dropout(experiments: Dict[str, ExperimentData], figures_dir: Path) -> None:
    # Effective clients: all experiments have same dropout schedule, but plot all to verify.
    fig, ax = plt.subplots(figsize=(9, 5))
    for label in EXPERIMENT_ORDER:
        if label in experiments:
            m = experiments[label].metrics
            ax.plot(m["round"], m["effective_clients"], marker="o", markersize=2, linewidth=1.2, label=label)
    ax.set_xlabel("Round")
    ax.set_ylabel("Effective clients")
    ax.set_title("Effective clients per round")
    ax.set_ylim(0, 5.5)
    ax.grid(True, alpha=0.3)
    ax.legend()
    save_fig(fig, figures_dir / "06_effective_clients.png")

    fig, ax = plt.subplots(figsize=(9, 5))
    for label in EXPERIMENT_ORDER:
        if label in experiments:
            m = experiments[label].metrics
            ax.plot(m["round"], m["dropout_clients"], marker="o", markersize=2, linewidth=1.2, label=label)
    ax.set_xlabel("Round")
    ax.set_ylabel("Dropout clients")
    ax.set_title("Dropout clients per round")
    ax.set_ylim(0, 1.5)
    ax.grid(True, alpha=0.3)
    ax.legend()
    save_fig(fig, figures_dir / "07_dropout_clients.png")


def plot_communication(experiments: Dict[str, ExperimentData], figures_dir: Path) -> None:
    # Top payload types by average total MB.
    all_comm = []
    for label, exp in experiments.items():
        df = exp.comm_summary.copy()
        df.insert(0, "experiment", label)
        all_comm.append(df)
    df = pd.concat(all_comm, ignore_index=True)
    top_types = (df.groupby("payload_type")["total_MB"].mean().sort_values(ascending=False).head(8).index.tolist())
    piv = df[df["payload_type"].isin(top_types)].pivot_table(index="payload_type", columns="experiment", values="total_MB", aggfunc="sum").reindex(top_types)
    piv = piv[[c for c in EXPERIMENT_ORDER if c in piv.columns]]

    fig, ax = plt.subplots(figsize=(10, 5.5))
    piv.plot(kind="bar", ax=ax)
    ax.set_xlabel("Payload type")
    ax.set_ylabel("Total communication (MiB)")
    ax.set_title("Communication breakdown by payload type")
    ax.grid(True, axis="y", alpha=0.3)
    ax.legend(title="Experiment", fontsize=8)
    save_fig(fig, figures_dir / "08_communication_breakdown_by_type.png")

    # Share of UpMsg and AggMsg combined.
    rows = []
    for label, exp in experiments.items():
        cs = exp.comm_summary.copy()
        total = cs["total_MB"].sum()
        up = cs.loc[cs["payload_type"].eq("UpMsg"), "total_MB"].sum()
        agg = cs.loc[cs["payload_type"].eq("AggMsg"), "total_MB"].sum()
        other = max(total - up - agg, 0)
        rows.append({"experiment": label, "UpMsg": up, "AggMsg": agg, "Other": other})
    share = pd.DataFrame(rows).set_index("experiment")
    share = share.reindex([x for x in EXPERIMENT_ORDER if x in share.index])
    fig, ax = plt.subplots(figsize=(9, 5))
    bottom = np.zeros(len(share))
    for col in ["UpMsg", "AggMsg", "Other"]:
        ax.bar(np.arange(len(share)), share[col], bottom=bottom, label=col)
        bottom += share[col].values
    ax.set_xticks(np.arange(len(share)))
    ax.set_xticklabels(share.index, rotation=20, ha="right")
    ax.set_ylabel("Total communication (MiB)")
    ax.set_title("Dominant communication components")
    ax.grid(True, axis="y", alpha=0.3)
    ax.legend()
    save_fig(fig, figures_dir / "09_dominant_communication_components.png")


def plot_runtime(experiments: Dict[str, ExperimentData], summary: pd.DataFrame, figures_dir: Path) -> None:
    key_stages = [
        "client_paillier_encrypt",
        "client_local_train",
        "client_pedersen_commit",
        "client_cipher_hash",
        "client_upload_pack",
    ]
    rows = []
    for label, exp in experiments.items():
        agg = exp.runtime.groupby("stage")["seconds"].sum()
        row = {"experiment": label}
        for s in key_stages:
            row[s] = agg.get(s, 0.0)
        rows.append(row)
    df = pd.DataFrame(rows).set_index("experiment").reindex([x for x in EXPERIMENT_ORDER if x in experiments])

    fig, ax = plt.subplots(figsize=(10, 5.5))
    df.plot(kind="bar", ax=ax)
    ax.set_xlabel("Experiment")
    ax.set_ylabel("Accumulated work time (seconds)")
    ax.set_title("Runtime breakdown by main stage")
    ax.grid(True, axis="y", alpha=0.3)
    ax.legend(fontsize=8)
    save_fig(fig, figures_dir / "10_runtime_breakdown_by_stage.png")

    sm = summary.set_index("experiment").reindex([x for x in EXPERIMENT_ORDER if x in experiments])
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(np.arange(len(sm)), sm["total_wall_minutes_runtime"])
    ax.set_xticks(np.arange(len(sm)))
    ax.set_xticklabels(sm.index, rotation=20, ha="right")
    ax.set_ylabel("Wall-clock time (minutes)")
    ax.set_title("Total experiment wall-clock time")
    ax.grid(True, axis="y", alpha=0.3)
    for i, v in enumerate(sm["total_wall_minutes_runtime"]):
        ax.text(i, v, f"{v:.1f}", ha="center", va="bottom", fontsize=9)
    save_fig(fig, figures_dir / "11_total_wall_time.png")

    fig, ax = plt.subplots(figsize=(9, 5))
    for label in EXPERIMENT_ORDER:
        if label in experiments:
            rt = experiments[label].runtime
            stage = rt[rt["stage"].eq("client_upload_parallel_wall")]
            ax.plot(stage["round"], stage["seconds"], marker="o", markersize=2, linewidth=1.2, label=label)
    ax.set_xlabel("Round")
    ax.set_ylabel("Parallel upload wall time (seconds)")
    ax.set_title("Per-round client upload parallel wall time")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    save_fig(fig, figures_dir / "12_upload_parallel_wall_by_round.png")


def plot_blockchain(experiments: Dict[str, ExperimentData], figures_dir: Path) -> None:
    fig, ax = plt.subplots(figsize=(9, 5))
    for label in EXPERIMENT_ORDER:
        if label in experiments:
            bc = experiments[label].blockchain
            ft = bc[bc["tx_type"].eq("FinalTx")]
            ax.plot(ft["round"], ft["gas_used"], marker="o", markersize=2, linewidth=1.2, label=label)
    ax.set_xlabel("Round")
    ax.set_ylabel("Gas used")
    ax.set_title("FinalTx gas per round")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    save_fig(fig, figures_dir / "13_finaltx_gas_by_round.png")

    fig, ax = plt.subplots(figsize=(9, 5))
    for label in EXPERIMENT_ORDER:
        if label in experiments:
            bc = experiments[label].blockchain
            ax.plot(bc["round"], bc["latency_sec"], marker="o", markersize=2, linewidth=1.2, label=label)
    ax.set_xlabel("Round")
    ax.set_ylabel("Latency (seconds)")
    ax.set_title("Blockchain transaction latency")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    save_fig(fig, figures_dir / "14_blockchain_latency_by_round.png")


def plot_crypto(experiments: Dict[str, ExperimentData], figures_dir: Path) -> None:
    fig, ax = plt.subplots(figsize=(9, 5))
    for label in EXPERIMENT_ORDER:
        if label in experiments:
            cr = experiments[label].crypto.copy()
            cr["value_num"] = pd.to_numeric(cr["value"], errors="coerce")
            comp = cr[cr["metric"].eq("compensation_encryptions")]
            ax.plot(comp["round"], comp["value_num"], marker="o", markersize=2, linewidth=1.2, label=label)
    ax.set_xlabel("Round")
    ax.set_ylabel("Compensation encryptions")
    ax.set_title("Compensation encryptions only occur in dropout rounds")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    save_fig(fig, figures_dir / "15_compensation_encryptions.png")


def generate_plots(experiments: Dict[str, ExperimentData], summary: pd.DataFrame, figures_dir: Path) -> None:
    figures_dir.mkdir(parents=True, exist_ok=True)
    plot_accuracy_loss(experiments, figures_dir)
    plot_final_bars(summary, figures_dir)
    plot_iid_gap(summary, figures_dir)
    plot_dropout(experiments, figures_dir)
    plot_communication(experiments, figures_dir)
    plot_runtime(experiments, summary, figures_dir)
    plot_blockchain(experiments, figures_dir)
    plot_crypto(experiments, figures_dir)


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyze public-audit FL result zips and generate figures/tables.")
    parser.add_argument("--input", required=True, help="combined result zip, directory of result zips, or extracted result directory")
    parser.add_argument("--output", default="analysis_outputs", help="output directory")
    parser.add_argument("--clean", action="store_true", help="remove output directory before writing")
    args = parser.parse_args()

    input_path = Path(args.input)
    output = Path(args.output)
    if args.clean and output.exists():
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="fl_result_analysis_") as tmp:
        scan_root = prepare_input(input_path, Path(tmp))
        exp_paths = find_experiments(scan_root)
        if not exp_paths:
            print("No experiment outputs found. Check input path.", file=sys.stderr)
            return 2
        missing = [x for x in EXPERIMENT_ORDER if x not in exp_paths]
        if missing:
            print(f"Warning: missing experiments: {missing}", file=sys.stderr)

        experiments = {label: load_experiment(label, path) for label, path in exp_paths.items()}
        summary = build_tables(experiments, output / "tables")
        generate_plots(experiments, summary, output / "figures")

    print(f"Wrote outputs to: {output.resolve()}")
    print("Summary:")
    cols = ["experiment", "accepted", "rounds", "final_accuracy", "final_loss", "total_wall_minutes_runtime", "summary_total_MB", "blockchain_total_gas"]
    print(summary[cols].to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
