# FL 4×50-round result analysis code

This package analyzes the unified 8260 CPU-server results for the public-audit federated-learning experiment.

## Input

Use either the combined zip:

```bash
python plot_experiment_results.py --input all_4x50_8260_results.zip --output analysis_outputs --clean
```

or a directory containing the four result zips:

```bash
python plot_experiment_results.py --input ./results_zips --output analysis_outputs --clean
```

The script supports nested zips, so it can directly read `all_4x50_8260_results.zip`.

## Install dependencies

```bash
pip install -r requirements.txt
```

## Outputs

The script creates:

```text
analysis_outputs/
  figures/
    01_accuracy_curves.png
    02_loss_curves.png
    03_final_accuracy_bar.png
    04_final_loss_bar.png
    05_iid_vs_noniid_accuracy_gap.png
    06_effective_clients.png
    07_dropout_clients.png
    08_communication_breakdown_by_type.png
    09_dominant_communication_components.png
    10_runtime_breakdown_by_stage.png
    11_total_wall_time.png
    12_upload_parallel_wall_by_round.png
    13_finaltx_gas_by_round.png
    14_blockchain_latency_by_round.png
    15_compensation_encryptions.png
  tables/
    experiment_summary.csv
    metrics_round_combined.csv
    runtime_stage_summary.csv
    communication_summary_combined.csv
    blockchain_summary.csv
    crypto_summary.csv
    data_integrity_warnings.txt
```

## Notes

- Communication size uses MiB-style conversion from bytes (`bytes / 1024 / 1024`) and is labeled as MB/MiB in result summaries.
- `TrainUploadReq.actual_seconds` contains end-to-end processing time, not pure network transmission time.
- Runtime stage sums such as `client_paillier_encrypt` are accumulated client-side work times; `start_experiment_total_wall` is a wall-clock experiment time recorded by the system.
