#!/usr/bin/env bash
set -Eeuo pipefail
PACK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
TARGET="${TARGET_DIR:-$FPA5_ROOT/full512_50r_pack_v1}"
if [[ "${SKIP_INSTALL:-0}" != "1" ]]; then bash "$PACK_ROOT/scripts/install.sh"; fi
exec bash "$TARGET/scripts/run_one_click.sh"
