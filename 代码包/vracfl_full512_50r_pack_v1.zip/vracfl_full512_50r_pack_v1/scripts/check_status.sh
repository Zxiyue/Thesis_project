#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
if [[ -n "${OUT_ROOT:-}" ]]; then CURRENT="$OUT_ROOT"; elif [[ -f "$ROOT/.last_output_root" ]]; then CURRENT="$(cat "$ROOT/.last_output_root")"; else CURRENT="$FPA5_ROOT/outputs/full512_50r_v1"; fi
echo "output_root=$CURRENT"
[[ -f "$ROOT/.last_result_zip" ]] && echo "result_zip=$(cat "$ROOT/.last_result_zip")"
echo "--- completed summaries ---"
find "$CURRENT" -maxdepth 3 -type f \( -name summary.json -o -name summary_prechain.json -o -name chain_result.json -o -name run_manifest.json \) -printf '%TY-%Tm-%Td %TH:%TM %p\n' 2>/dev/null | sort || true
echo "--- running processes ---"
ps -eo pid,etime,%cpu,%mem,cmd | grep -E 'run_full_vracfl_50r|full_replay|hardhat node|run_one_click' | grep -v grep || true
echo "--- latest logs ---"
for f in "$CURRENT"/logs/*.log; do [[ -f "$f" ]] || continue; echo "### $f"; tail -15 "$f"; done
