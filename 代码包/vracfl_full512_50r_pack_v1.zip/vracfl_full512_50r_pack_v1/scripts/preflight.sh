#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3

echo "pack_root=$ROOT"
echo "python=$PY"
"$PY" --version
"$PY" - <<'PY'
import numpy, torch, torchvision, cryptography, sympy
print('numpy', numpy.__version__)
print('torch', torch.__version__)
print('torchvision', torchvision.__version__)
print('cryptography', cryptography.__version__)
print('sympy', sympy.__version__)
PY
"$PY" -m py_compile "$ROOT"/src/*.py
"$PY" "$ROOT/src/selftest_crypto.py"

DATA_ROOT="${DATA_ROOT:-$FPA5_ROOT/data}"
if [[ -d "$DATA_ROOT/MNIST" || -d "$DATA_ROOT/MNIST/raw" ]]; then
  echo "mnist_data=OK:$DATA_ROOT"
else
  echo "mnist_data=MISSING:$DATA_ROOT; run with DOWNLOAD=1"
fi
[[ -f "$ROOT/.hardhat_dir" ]] || { echo "hardhat_dir=NOT_CONFIGURED" >&2; exit 2; }
echo "hardhat_dir=$(cat "$ROOT/.hardhat_dir")"
