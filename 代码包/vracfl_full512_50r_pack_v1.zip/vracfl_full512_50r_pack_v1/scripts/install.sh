#!/usr/bin/env bash
set -Eeuo pipefail
PACK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
TARGET="${TARGET_DIR:-$FPA5_ROOT/full512_50r_pack_v1}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3

[[ -d "$FPA5_ROOT" ]] || { echo "[ERROR] fpa5 not found: $FPA5_ROOT" >&2; exit 1; }
rm -rf "$TARGET"
mkdir -p "$TARGET"
cp -a "$PACK_ROOT"/. "$TARGET"/
chmod +x "$TARGET"/scripts/*.sh "$TARGET"/src/*.py "$TARGET"/run_once.sh

HH_DIR="${HARDHAT_DIR:-}"
if [[ -z "$HH_DIR" ]]; then
  while IFS= read -r cfg; do HH_DIR="$(dirname "$cfg")"; break; done < <(
    find "$FPA5_ROOT" -maxdepth 6 -type f \( -name 'hardhat.config.js' -o -name 'hardhat.config.cjs' -o -name 'hardhat.config.ts' \) | sort
  )
fi
if [[ -z "$HH_DIR" || ! -d "$HH_DIR" ]]; then
  echo "[ERROR] Hardhat project not found under $FPA5_ROOT. Set HARDHAT_DIR explicitly." >&2
  exit 2
fi
mkdir -p "$HH_DIR/contracts" "$HH_DIR/scripts"
cp -f "$PACK_ROOT/blockchain_patch/contracts/FullAuditBoard.sol" "$HH_DIR/contracts/"
cp -f "$PACK_ROOT/blockchain_patch/scripts/full_replay.js" "$HH_DIR/scripts/"
printf '%s\n' "$HH_DIR" > "$TARGET/.hardhat_dir"
(cd "$HH_DIR" && npx hardhat compile)

mkdir -p "$FPA5_ROOT/cache" "$FPA5_ROOT/outputs"
"$PY" -m py_compile "$TARGET"/src/*.py
"$PY" "$TARGET/src/selftest_crypto.py"
echo "[DONE] installed=$TARGET"
echo "hardhat_dir=$HH_DIR"
