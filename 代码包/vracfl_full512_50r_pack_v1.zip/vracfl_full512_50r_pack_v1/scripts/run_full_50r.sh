#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3
OUT_ROOT="${OUT_ROOT:-$FPA5_ROOT/outputs/full512_50r_v1}"
DATA_ROOT="${DATA_ROOT:-$FPA5_ROOT/data}"
ROUNDS="${ROUNDS:-50}"
SEED="${SEED:-20260714}"
DOWNLOAD_FLAG=(); [[ "${DOWNLOAD:-0}" == "1" ]] && DOWNLOAD_FLAG=(--download)
HH_DIR="$(cat "$ROOT/.hardhat_dir")"
RESUME="${RESUME:-1}"
FORCE_RERUN="${FORCE_RERUN:-0}"
RUN_IID="${RUN_IID:-1}"
RUN_NONIID="${RUN_NONIID:-1}"
mkdir -p "$OUT_ROOT/logs"

valid_completed() {
  local out="$1" split="$2"
  [[ -s "$out/summary.json" ]] || return 1
  "$PY" - "$out/summary.json" "$split" "$ROUNDS" <<'PY'
import json, sys
p, split, rounds = sys.argv[1:]
try: d=json.load(open(p, encoding='utf-8'))
except Exception: raise SystemExit(1)
ok=(d.get('experiment')=='Full VRAC-FL' and d.get('split')==split and int(d.get('rounds',-1))==int(rounds)
    and int(d.get('requested_paillier_bits',-1))==512 and bool(d.get('accepted')) and bool(d.get('chain_passed'))
    and int(d.get('finaltx_count',-1))==int(rounds) and int(d.get('faulttx_count',-1))==0)
raise SystemExit(0 if ok else 1)
PY
}

run_split() {
  local split="$1"
  local out="$OUT_ROOT/full_vracfl_${split}_${ROUNDS}r_p512"
  local log="$OUT_ROOT/logs/full_${split}_${ROUNDS}r.log"
  mkdir -p "$out"
  if [[ "$FORCE_RERUN" != "1" && "$RESUME" == "1" ]] && valid_completed "$out" "$split"; then
    echo "[SKIP] completed full result: $out"
    return
  fi
  if [[ "$FORCE_RERUN" == "1" ]]; then rm -rf "$out"; mkdir -p "$out"; fi

  if [[ ! -s "$out/summary_prechain.json" || "$FORCE_RERUN" == "1" ]]; then
    echo "[RUN] Full VRAC-FL split=$split rounds=$ROUNDS bits=512"
    "$PY" "$ROOT/src/run_full_vracfl_50r.py" \
      --output-dir "$out" --dataset mnist --split "$split" --data-root "$DATA_ROOT" \
      --rounds "$ROUNDS" --clients 5 --threshold 3 --paillier-bits 512 \
      --key-cache "$FPA5_ROOT/cache/threshold_paillier_p512.json" \
      --local-epochs 1 --batch-size 64 --test-batch-size 512 --lr 0.20 \
      --scale 10000 --mask-bound 64 --rho-bound 1024 --seed "$SEED" \
      --encrypt-workers "${ENCRYPT_WORKERS:-5}" --max-samples-per-client "${MAX_SAMPLES_PER_CLIENT:-0}" \
      "${DOWNLOAD_FLAG[@]}" 2>&1 | tee "$log"
  else
    echo "[RESUME] pre-chain protocol result exists: $out"
  fi

  if [[ "${SKIP_CHAIN:-0}" != "1" ]]; then
    if [[ ! -s "$out/chain/chain_result.json" || "$FORCE_RERUN" == "1" ]]; then
      "$PY" "$ROOT/src/full_chain_bridge.py" \
        --plan "$out/chain_plan.json" --output-dir "$out/chain" --hardhat-dir "$HH_DIR" \
        2>&1 | tee -a "$log"
    else
      echo "[RESUME] chain result exists: $out/chain/chain_result.json"
    fi
    "$PY" "$ROOT/src/merge_full_result.py" --result-dir "$out" 2>&1 | tee -a "$log"
  else
    echo "[WARN] SKIP_CHAIN=1: summary.json will not be finalized"
  fi
}

[[ "$RUN_IID" == "1" ]] && run_split iid
[[ "$RUN_NONIID" == "1" ]] && run_split noniid
"$PY" "$ROOT/src/summarize_full_results.py" --root "$OUT_ROOT"
echo "[DONE] full 512-bit 50-round outputs=$OUT_ROOT"
