#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3
OUT_ROOT="${OUT_ROOT:?OUT_ROOT is required}"
ZIP_OUT="${ZIP_OUT:?ZIP_OUT is required}"

if ! "$PY" "$ROOT/src/summarize_full_results.py" --root "$OUT_ROOT"; then
  echo "[WARN] complete IID/Non-IID summaries are not both available; packaging partial outputs" >&2
fi
rm -f "$ZIP_OUT"
cd "$(dirname "$OUT_ROOT")"
zip -qr "$ZIP_OUT" "$(basename "$OUT_ROOT")"
echo "result_zip=$ZIP_OUT"
