#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3
RUN_ID="${RUN_ID:-$(date +%Y%m%d_%H%M%S)}"
OUT_ROOT="${OUT_ROOT:-$FPA5_ROOT/outputs/full512_50r_v1_${RUN_ID}}"
ZIP_OUT="${ZIP_OUT:-/root/vracfl_full512_50r_results_${RUN_ID}.zip}"
LOG_DIR="$OUT_ROOT/logs"; mkdir -p "$LOG_DIR"
printf '%s\n' "$OUT_ROOT" > "$ROOT/.last_output_root"
printf '%s\n' "$ZIP_OUT" > "$ROOT/.last_result_zip"
START_EPOCH="$(date +%s)"
CHAIN_PID=""; CHAIN_STARTED=0; FINALIZED=0
export OUT_ROOT ZIP_OUT

rpc_up() {
  curl -sS --max-time 2 -H 'Content-Type: application/json' \
    --data '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}' \
    http://127.0.0.1:8545 2>/dev/null | grep -q '"result"'
}
stop_chain() {
  if [[ "$CHAIN_STARTED" == "1" && -n "$CHAIN_PID" ]]; then
    kill -TERM -- "-$CHAIN_PID" 2>/dev/null || kill -TERM "$CHAIN_PID" 2>/dev/null || true
    sleep 2
    kill -KILL -- "-$CHAIN_PID" 2>/dev/null || kill -KILL "$CHAIN_PID" 2>/dev/null || true
  fi
}
write_manifest() {
  local code="$1" end; end="$(date +%s)"
  "$PY" - "$OUT_ROOT/run_manifest.json" "$RUN_ID" "$START_EPOCH" "$end" "$code" "$ZIP_OUT" <<'PY'
import json, os, platform, socket, sys
p, rid, start, end, code, z = sys.argv[1:]
d={"run_id":rid,"status":"completed" if int(code)==0 else "failed_or_interrupted","exit_code":int(code),
   "start_epoch":int(start),"end_epoch":int(end),"elapsed_s":int(end)-int(start),"hostname":socket.gethostname(),
   "platform":platform.platform(),"result_zip":z,"configuration":{"rounds":int(os.environ.get('ROUNDS','50')),
   "paillier_bits":512,"run_iid":os.environ.get('RUN_IID','1'),"run_noniid":os.environ.get('RUN_NONIID','1'),
   "seed":int(os.environ.get('SEED','20260714'))}}
open(p,'w',encoding='utf-8').write(json.dumps(d,ensure_ascii=False,indent=2))
PY
}
finalize() {
  local code=$?; [[ "$FINALIZED" == "1" ]] && exit "$code"; FINALIZED=1; set +e
  write_manifest "$code"
  bash "$ROOT/scripts/collect_results.sh" > >(tee "$LOG_DIR/collect_results.log") 2>&1
  local pack_code=$?
  stop_chain
  echo "============================================================"
  [[ "$code" == "0" && "$pack_code" == "0" ]] && echo "[DONE] IID and Non-IID Full 512-bit 50r completed" || echo "[WARN] partial results packaged"
  echo "output_root=$OUT_ROOT"
  echo "result_zip=$ZIP_OUT"
  echo "============================================================"
  exit "$code"
}
trap finalize EXIT INT TERM

export ROUNDS="${ROUNDS:-50}" RUN_IID="${RUN_IID:-1}" RUN_NONIID="${RUN_NONIID:-1}"
export RESUME="${RESUME:-1}" FORCE_RERUN="${FORCE_RERUN:-0}" SEED="${SEED:-20260714}"

if [[ "${SKIP_CHAIN:-0}" != "1" ]]; then
  HH_DIR="$(cat "$ROOT/.hardhat_dir")"
  if rpc_up; then
    echo "[INFO] reusing existing Hardhat RPC"
  else
    echo "[INFO] starting Hardhat node from $HH_DIR"
    setsid bash -lc "cd \"$HH_DIR\" && exec npx hardhat node" > "$LOG_DIR/hardhat_node.log" 2>&1 &
    CHAIN_PID=$!; CHAIN_STARTED=1
    for _ in $(seq 1 120); do rpc_up && break; kill -0 "$CHAIN_PID" 2>/dev/null || { tail -100 "$LOG_DIR/hardhat_node.log"; exit 3; }; sleep 1; done
    rpc_up || { echo "[ERROR] Hardhat RPC timeout" >&2; exit 4; }
  fi
fi

bash "$ROOT/scripts/preflight.sh" 2>&1 | tee "$LOG_DIR/preflight.log"
bash "$ROOT/scripts/run_full_50r.sh" 2>&1 | tee "$LOG_DIR/full512_50r_all.log"
