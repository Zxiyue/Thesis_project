# VRAC-FL Full 512-bit 50r Pack v1

该包只完成当前最优先的两组缺失实验：

- Full VRAC-FL，MNIST-IID，512-bit，50轮；
- Full VRAC-FL，MNIST-Non-IID，512-bit，50轮。

## 特点

- 一次启动完成两组实验；
- 真实TinyCNN6794训练；
- 真实门限Paillier、零和掩码、Pedersen承诺、签名收据；
- 无掉线单位元补偿；
- KGC门控的50笔FinalTx真实上链；
- 正常场景不生成FaultTx；
- 自动启动Hardhat、自动汇总、自动压缩；
- 支持密码阶段完成后仅重做链上回放；
- 使用新结果目录，不覆盖旧实验。

执行入口：

```bash
DOWNLOAD=1 bash run_once.sh
```

详细命令见《云服务器执行说明.md》。
