#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import os
import subprocess
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser(description="Replay Full VRAC-FL InitTx and FinalTx actions on Hardhat")
    ap.add_argument("--plan", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--hardhat-dir", required=True)
    args = ap.parse_args()

    plan = Path(args.plan).resolve()
    output = Path(args.output_dir).resolve()
    hh = Path(args.hardhat_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    result_path = output / "chain_result.json"

    env = os.environ.copy()
    env["FULL_CHAIN_PLAN"] = str(plan)
    env["FULL_CHAIN_RESULT"] = str(result_path)
    cmd = ["npx", "hardhat", "run", "scripts/full_replay.js", "--network", "localhost"]
    proc = subprocess.run(cmd, cwd=str(hh), env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (output / "hardhat_replay.log").write_text(proc.stdout, encoding="utf-8")
    if proc.returncode != 0:
        raise RuntimeError(f"Hardhat full replay failed ({proc.returncode})\n{proc.stdout[-8000:]}")
    result = json.loads(result_path.read_text(encoding="utf-8"))
    if not result.get("passed"):
        raise RuntimeError("chain replay completed but final state verification failed")

    rows = result.get("transactions", [])
    with (output / "chain_transactions.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fields = ["type", "round", "gasUsed", "latencySeconds", "txHash", "blockNumber"]
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    print(json.dumps({"passed": True, "transactions": len(rows), "result": str(result_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
