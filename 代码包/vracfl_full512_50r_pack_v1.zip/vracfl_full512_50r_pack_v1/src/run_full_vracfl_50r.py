#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import torch

from common import Timer, canonical_bytes, int_hex, merkle_root, seed_everything, sha256_hex, write_csv, write_json
from model_data import (
    TinyCNN6794, assign_flat_model, build_data, evaluate, flatten_model,
    model_hash, parameter_count, train_local,
)
from pedersen import PedersenVector
from signing import generate_key, sign_obj, verify_obj
from threshold_paillier import PublicKey, ThresholdPaillier, ciphertext_bytes, encrypt_int, load_or_generate_factors


def _encrypt_vector_worker(args: tuple[int, int, list[int]]) -> list[int]:
    n, n2, values = args
    pk = PublicKey(n, n2)
    return [encrypt_int(pk, int(v)) for v in values]


def zero_sum_matrix(n_clients: int, dimension: int, bound: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    first = rng.integers(-bound, bound + 1, size=(n_clients - 1, dimension), dtype=np.int64)
    return np.vstack([first, -first.sum(axis=0, dtype=np.int64)])


def zero_sum_scalars(n_clients: int, bound: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    first = rng.integers(-bound, bound + 1, size=(n_clients - 1,), dtype=np.int64)
    return np.concatenate([first, np.asarray([-first.sum(dtype=np.int64)], dtype=np.int64)])


def final_action(
    round_no: int,
    alpha: str,
    root_up: str,
    com_hash: str,
    model_prev: str,
    model_next: str,
    prev_root: str,
) -> dict:
    audit_root = sha256_hex({
        "prev": prev_root,
        "round": round_no,
        "alpha": alpha,
        "rootUp": root_up,
        "comAggHash": com_hash,
        "modelPrev": model_prev,
        "modelNext": model_next,
    })
    return {
        "type": "final",
        "round": round_no,
        "alpha": alpha,
        "rootUp": root_up,
        "comAggHash": com_hash,
        "modelHashPrev": model_prev,
        "modelHashNext": model_next,
        "prevAuditRoot": prev_root,
        "auditRoot": audit_root,
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="Full VRAC-FL 512-bit, 50-round end-to-end MNIST experiment")
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--dataset", default="mnist")
    ap.add_argument("--split", choices=["iid", "noniid"], required=True)
    ap.add_argument("--data-root", default="/root/fpa5/data")
    ap.add_argument("--rounds", type=int, default=50)
    ap.add_argument("--clients", type=int, default=5)
    ap.add_argument("--threshold", type=int, default=3)
    ap.add_argument("--paillier-bits", type=int, default=512)
    ap.add_argument("--key-cache", default="/root/fpa5/cache/threshold_paillier_p512.json")
    ap.add_argument("--local-epochs", type=int, default=1)
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--test-batch-size", type=int, default=512)
    ap.add_argument("--lr", type=float, default=0.20)
    ap.add_argument("--momentum", type=float, default=0.0)
    ap.add_argument("--scale", type=int, default=10000)
    ap.add_argument("--mask-bound", type=int, default=64)
    ap.add_argument("--rho-bound", type=int, default=1024)
    ap.add_argument("--seed", type=int, default=20260714)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--max-samples-per-client", type=int, default=0)
    ap.add_argument("--encrypt-workers", type=int, default=5)
    ap.add_argument("--dimension-limit", type=int, default=0, help="smoke only; 0 uses all 6794 coordinates")
    ap.add_argument("--download", action="store_true")
    args = ap.parse_args()

    if args.threshold > args.clients:
        raise ValueError("threshold cannot exceed clients")
    if args.paillier_bits != 512:
        raise ValueError("this pack is fixed to the 512-bit prototype configuration")

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    seed_everything(args.seed)
    device = torch.device(args.device)

    _, _, parts, loaders, test_loader = build_data(
        args.dataset, Path(args.data_root), args.split, args.clients,
        args.batch_size, args.test_batch_size, args.seed,
        args.max_samples_per_client, args.download,
    )
    sample_counts = np.asarray([len(p) for p in parts], dtype=np.int64)
    weights = sample_counts.astype(np.float64) / sample_counts.sum()

    p, q, keygen_s = load_or_generate_factors(args.paillier_bits, Path(args.key_cache))
    tp = ThresholdPaillier(p, q, args.clients, args.threshold, args.seed)
    model = TinyCNN6794().to(device)
    full_dim = parameter_count(model)
    dimension = full_dim if args.dimension_limit <= 0 else min(full_dim, args.dimension_limit)
    if dimension != full_dim:
        print(f"[WARN] dimension-limit={dimension}; smoke mode does not update the complete model", flush=True)
    pedersen = PedersenVector(dimension)
    client_keys = [generate_key() for _ in range(args.clients)]

    initial_model_hash = model_hash(model)
    sys_hash = sha256_hex({
        "scheme": "VRAC-FL",
        "dataset": args.dataset,
        "split": args.split,
        "paillierN": int_hex(tp.n),
        "dimension": dimension,
        "scale": args.scale,
        "clients": args.clients,
        "threshold": args.threshold,
    })
    u_root = merkle_root([str(i).encode() for i in range(1, args.clients + 1)], b"EMPTY_USERS")
    audit_root = sha256_hex({"sysParaHash": sys_hash, "uRoot": u_root, "modelHash0": initial_model_hash})
    chain_plan: Dict[str, Any] = {
        "scenario": f"full_vracfl_{args.split}_{args.rounds}r_p512",
        "boardMode": "full",
        "init": {
            "sysParaHash": sys_hash,
            "uRoot": u_root,
            "modelHash0": initial_model_hash,
            "auditRoot0": audit_root,
        },
        "actions": [],
    }

    metrics: List[dict] = []
    runtime_rows: List[dict] = []
    crypto_rows: List[dict] = []
    comm_rows: List[dict] = []
    verify_rows: List[dict] = []

    acc0, loss0 = evaluate(model, test_loader, device)
    metrics.append({
        "round": 0,
        "test_accuracy": acc0,
        "test_loss": loss0,
        "model_hash": initial_model_hash,
    })

    total_started = time.perf_counter()
    pool = ProcessPoolExecutor(max_workers=max(1, args.encrypt_workers)) if args.encrypt_workers > 1 else None
    try:
        for rnd in range(1, args.rounds + 1):
            round_started = time.perf_counter()
            prev_flat = flatten_model(model)
            model_prev_hash = model_hash(model)

            deltas: List[np.ndarray] = []
            train_times: List[float] = []
            local_losses: List[float] = []
            for cid, loader in enumerate(loaders, start=1):
                with Timer() as train_timer:
                    delta, local_loss = train_local(
                        model, loader, device, args.lr,
                        args.local_epochs, args.momentum,
                    )
                qvec = torch.round(
                    delta[:dimension] * float(weights[cid - 1]) * args.scale
                ).to(torch.int64).cpu().numpy()
                deltas.append(qvec)
                train_times.append(train_timer.elapsed)
                local_losses.append(local_loss)
            qmat = np.stack(deltas, axis=0).astype(np.int64)

            with Timer() as mask_timer:
                masks = zero_sum_matrix(args.clients, dimension, args.mask_bound, args.seed + rnd * 1009)
                rhos = zero_sum_scalars(args.clients, args.rho_bound, args.seed + rnd * 2003)
                masked = qmat + masks

            with Timer() as enc_timer:
                jobs = [(tp.n, tp.n2, masked[i].astype(object).tolist()) for i in range(args.clients)]
                encrypted = list(pool.map(_encrypt_vector_worker, jobs)) if pool else [_encrypt_vector_worker(x) for x in jobs]

            with Timer() as commit_timer:
                commitments = [pedersen.commit(masked[i].tolist(), int(rhos[i])) for i in range(args.clients)]
                com_agg = pedersen.aggregate(commitments)

            receipts = []
            with Timer() as receipt_timer:
                for i in range(args.clients):
                    body = {
                        "r": rnd,
                        "i": i + 1,
                        "alpha": sha256_hex({"round": rnd, "modelHash": model_prev_hash, "uRoot": u_root}),
                        "encHash": sha256_hex([int_hex(c) for c in encrypted[i]]),
                        "Com": int_hex(commitments[i]),
                    }
                    sig = sign_obj(client_keys[i], body)
                    if not verify_obj(client_keys[i].public_key(), body, sig):
                        raise RuntimeError(f"client receipt signature verification failed: round={rnd}, client={i+1}")
                    receipts.append({**body, "sigUp": sig})
            alpha = receipts[0]["alpha"]
            root_up = merkle_root([canonical_bytes(x) for x in receipts], b"EMPTY_UPLOADS")

            # No dropout in this main performance run, so identity-element compensation is used.
            with Timer() as agg_timer:
                cagg = tp.add_vectors(encrypted)

            with Timer() as share_timer:
                share_vectors = {
                    cid: tp.partial_decrypt_vector(cid, cagg)
                    for cid in range(1, args.threshold + 1)
                }

            with Timer() as combine_timer:
                recovered = np.asarray(tp.combine_vector(share_vectors), dtype=np.int64)

            expected = qmat.sum(axis=0, dtype=np.int64)
            aggregate_ok = bool(np.array_equal(recovered, expected))

            with Timer() as verify_timer:
                commitment_ok = pedersen.commit(recovered.tolist(), 0) == com_agg
            accepted = aggregate_ok and commitment_ok
            if not accepted:
                mismatch = int(np.flatnonzero(recovered != expected)[0]) if np.any(recovered != expected) else -1
                raise RuntimeError(
                    f"full VRAC-FL verification failed at round={rnd}, aggregate_ok={aggregate_ok}, "
                    f"commitment_ok={commitment_ok}, mismatch_coordinate={mismatch}"
                )

            with Timer() as update_timer:
                if dimension == full_dim:
                    next_flat = prev_flat + torch.from_numpy(
                        recovered.astype(np.float64) / float(args.scale)
                    ).to(prev_flat.dtype)
                    assign_flat_model(model, next_flat)
                    acc, test_loss = evaluate(model, test_loader, device)
                else:
                    acc, test_loss = float("nan"), float("nan")
                model_next_hash = model_hash(model)

            com_hash = sha256_hex(int_hex(com_agg))
            action = final_action(
                rnd, alpha, root_up, com_hash,
                model_prev_hash, model_next_hash, audit_root,
            )
            chain_plan["actions"].append(action)
            audit_root = action["auditRoot"]

            cbytes = ciphertext_bytes(tp.public_key)
            commitment_bytes = (pedersen.P.bit_length() + 7) // 8
            receipt_bytes = sum(len(canonical_bytes(x)) for x in receipts)
            round_wall = time.perf_counter() - round_started

            metrics.append({
                "round": rnd,
                "test_accuracy": acc,
                "test_loss": test_loss,
                "mean_local_loss": float(np.mean(local_losses)),
                "model_hash": model_next_hash,
            })
            runtime_rows.append({
                "round": rnd,
                "local_train_sum_s": float(sum(train_times)),
                "local_train_parallel_wall_proxy_s": float(max(train_times)),
                "mask_generation_s": mask_timer.elapsed,
                "paillier_encrypt_s": enc_timer.elapsed,
                "pedersen_commit_s": commit_timer.elapsed,
                "receipt_sign_verify_s": receipt_timer.elapsed,
                "cipher_aggregate_s": agg_timer.elapsed,
                "partial_decrypt_s": share_timer.elapsed,
                "threshold_combine_s": combine_timer.elapsed,
                "aggregate_commitment_verify_s": verify_timer.elapsed,
                "model_update_eval_s": update_timer.elapsed,
                "round_wall_excluding_chain_s": round_wall,
            })
            crypto_rows.extend([
                {"round": rnd, "operation": "zero_sum_mask_generation", "seconds": mask_timer.elapsed, "count": args.clients * dimension},
                {"round": rnd, "operation": "paillier_encrypt", "seconds": enc_timer.elapsed, "count": args.clients * dimension},
                {"round": rnd, "operation": "pedersen_commit", "seconds": commit_timer.elapsed, "count": args.clients},
                {"round": rnd, "operation": "receipt_sign_verify", "seconds": receipt_timer.elapsed, "count": args.clients},
                {"round": rnd, "operation": "cipher_aggregate", "seconds": agg_timer.elapsed, "count": dimension},
                {"round": rnd, "operation": "partial_decrypt", "seconds": share_timer.elapsed, "count": args.threshold * dimension},
                {"round": rnd, "operation": "threshold_combine", "seconds": combine_timer.elapsed, "count": dimension},
                {"round": rnd, "operation": "pedersen_open_verify", "seconds": verify_timer.elapsed, "count": 1},
            ])
            comm_rows.extend([
                {"round": rnd, "payload_type": "MaskMsg", "messages": args.clients, "bytes": args.clients * (dimension * 8 + 8)},
                {"round": rnd, "payload_type": "UpMsgCipher", "messages": args.clients, "bytes": args.clients * dimension * cbytes},
                {"round": rnd, "payload_type": "PedersenCommitment", "messages": args.clients, "bytes": args.clients * commitment_bytes},
                {"round": rnd, "payload_type": "ReceiptHeaderSignature", "messages": args.clients, "bytes": receipt_bytes},
                {"round": rnd, "payload_type": "DecryptShare", "messages": args.threshold, "bytes": args.threshold * dimension * cbytes},
                {"round": rnd, "payload_type": "DropMsgCipher", "messages": 0, "bytes": 0},
            ])
            verify_rows.append({
                "round": rnd,
                "receipt_signatures_valid": True,
                "aggregate_recovered": aggregate_ok,
                "pedersen_checked": True,
                "pedersen_passed": commitment_ok,
                "faulttx_generated": False,
                "finaltx_planned": True,
                "accepted": accepted,
            })
            print(json.dumps({
                "experiment": "Full VRAC-FL",
                "split": args.split,
                "round": rnd,
                "accuracy": acc,
                "encrypt_s": enc_timer.elapsed,
                "partial_decrypt_s": share_timer.elapsed,
                "pedersen_s": commit_timer.elapsed,
                "round_wall_s": round_wall,
            }), flush=True)
    finally:
        if pool is not None:
            pool.shutdown(wait=True, cancel_futures=False)

    total_wall = time.perf_counter() - total_started
    chain_plan["expected"] = {
        "faultTxCount": 0,
        "finalTxCount": args.rounds,
        "hashTxCount": 0,
        "finalModelHash": metrics[-1]["model_hash"],
        "finalAuditRoot": audit_root,
    }

    write_csv(out / "metrics_round.csv", metrics)
    write_csv(out / "runtime_cost.csv", runtime_rows)
    write_csv(out / "crypto_cost.csv", crypto_rows)
    write_csv(out / "communication_cost.csv", comm_rows)
    write_csv(out / "verify_result.csv", verify_rows)
    write_json(out / "chain_plan.json", chain_plan)

    summary = {
        "experiment": "Full VRAC-FL",
        "definition": "threshold Paillier + zero-sum masks + Pedersen vector commitment + KGC-gated FinalTx audit chain",
        "dataset": args.dataset,
        "split": args.split,
        "rounds": args.rounds,
        "clients": args.clients,
        "threshold": args.threshold,
        "model": "TinyCNN6794",
        "dimension": dimension,
        "model_dimension": full_dim,
        "scale": args.scale,
        "requested_paillier_bits": args.paillier_bits,
        "paillier_bits_actual": tp.n.bit_length(),
        "keygen_s_excluded": keygen_s,
        "sample_counts": sample_counts.tolist(),
        "final_accuracy": metrics[-1]["test_accuracy"],
        "total_wall_excluding_chain_s": total_wall,
        "mean_round_wall_excluding_chain_s": float(np.mean([x["round_wall_excluding_chain_s"] for x in runtime_rows])),
        "finaltx_planned": args.rounds,
        "faulttx_planned": 0,
        "accepted_prechain": all(bool(x["accepted"]) for x in verify_rows),
        "identity_compensation_used": True,
        "chain_replay_pending": True,
    }
    write_json(out / "summary_prechain.json", summary)
    write_json(out / "run_trace.json", {"summary": summary, "runtime": runtime_rows, "verify": verify_rows})
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
