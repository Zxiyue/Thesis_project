#!/usr/bin/env python3
from __future__ import annotations

import numpy as np
from pathlib import Path

from pedersen import PedersenVector
from threshold_paillier import ThresholdPaillier, load_or_generate_factors


def main() -> None:
    p, q, _ = load_or_generate_factors(512, Path("/tmp/vracfl_full512_selftest_key.json"))
    tp = ThresholdPaillier(p, q, 3, 2, 12345)
    vals = np.asarray([[1, -2, 3, 4], [5, 6, -7, 8], [-1, 2, 1, -3]], dtype=np.int64)
    masks = np.asarray([[2, 1, -1, 3], [-2, 2, 3, -1], [0, -3, -2, -2]], dtype=np.int64)
    masked = vals + masks
    enc = [tp.encrypt_vector(v.tolist()) for v in masked]
    agg = tp.add_vectors(enc)
    shares = {i: tp.partial_decrypt_vector(i, agg) for i in (1, 2)}
    recovered = np.asarray(tp.combine_vector(shares), dtype=np.int64)
    expected = vals.sum(axis=0)
    if not np.array_equal(recovered, expected):
        raise RuntimeError(f"Paillier selftest failed: {recovered} != {expected}")
    ped = PedersenVector(4)
    rhos = [3, -5, 2]
    coms = [ped.commit(masked[i].tolist(), rhos[i]) for i in range(3)]
    if ped.aggregate(coms) != ped.commit(recovered.tolist(), 0):
        raise RuntimeError("Pedersen selftest failed")
    print("crypto_selftest=OK")


if __name__ == "__main__":
    main()
