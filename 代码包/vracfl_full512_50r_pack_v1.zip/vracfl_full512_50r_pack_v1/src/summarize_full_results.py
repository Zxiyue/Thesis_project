#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    args = ap.parse_args()
    root = Path(args.root)
    rows = []
    for p in sorted(root.glob("full_vracfl_*_50r_p512/summary.json")):
        d = json.loads(p.read_text(encoding="utf-8"))
        rows.append({
            "split": d.get("split"),
            "rounds": d.get("rounds"),
            "clients": d.get("clients"),
            "threshold": d.get("threshold"),
            "bits": d.get("paillier_bits_actual"),
            "dimension": d.get("dimension"),
            "final_accuracy": d.get("final_accuracy"),
            "wall_excluding_chain_s": d.get("total_wall_excluding_chain_s"),
            "wall_including_finaltx_s": d.get("total_wall_including_finaltx_s"),
            "mean_round_excluding_chain_s": d.get("mean_round_wall_excluding_chain_s"),
            "finaltx_count": d.get("finaltx_count"),
            "finaltx_mean_gas": d.get("finaltx_mean_gas"),
            "finaltx_total_gas": d.get("finaltx_total_gas"),
            "finaltx_mean_latency_s": d.get("finaltx_mean_latency_s"),
            "faulttx_count": d.get("faulttx_count"),
            "chain_passed": d.get("chain_passed"),
            "accepted": d.get("accepted"),
            "result_dir": str(p.parent),
        })
    if not rows:
        raise SystemExit("no completed full 50r summary.json files found")
    fields = list(rows[0].keys())
    with (root / "full512_50r_summary.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)
    (root / "full512_50r_summary.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    md = [
        "# Full VRAC-FL 512-bit 50-round Summary", "",
        "| Split | Accuracy | Wall excl. chain (s) | Wall incl. FinalTx (s) | Mean FinalTx Gas | Mean FinalTx latency (s) | Accepted |",
        "|---|---:|---:|---:|---:|---:|---|",
    ]
    for r in rows:
        md.append(
            f"| {r['split']} | {r['final_accuracy']} | {r['wall_excluding_chain_s']} | "
            f"{r['wall_including_finaltx_s']} | {r['finaltx_mean_gas']} | "
            f"{r['finaltx_mean_latency_s']} | {r['accepted']} |"
        )
    (root / "full512_50r_summary.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(json.dumps({"completed": len(rows), "root": str(root)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
