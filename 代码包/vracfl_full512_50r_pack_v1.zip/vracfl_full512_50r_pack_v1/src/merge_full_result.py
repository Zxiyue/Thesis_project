#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--result-dir", required=True)
    args = ap.parse_args()
    root = Path(args.result_dir)
    pre = read_json(root / "summary_prechain.json")
    chain = read_json(root / "chain" / "chain_result.json")
    txs = chain.get("transactions", [])

    final_gas = sum(int(x.get("gasUsed", 0)) for x in txs if x.get("type") == "final")
    final_latency = sum(float(x.get("latencySeconds", 0.0)) for x in txs if x.get("type") == "final")
    init_gas = int(chain.get("init", {}).get("gasUsed", 0))
    init_latency = float(chain.get("init", {}).get("latencySeconds", 0.0))
    deploy_gas = int(chain.get("deploy", {}).get("gasUsed", 0))
    deploy_latency = float(chain.get("deploy", {}).get("latencySeconds", 0.0))

    summary = dict(pre)
    summary.update({
        "chain_replay_pending": False,
        "chain_passed": bool(chain.get("passed")),
        "chain_id": chain.get("chainId"),
        "contract_address": chain.get("contractAddress"),
        "deployment_gas": deploy_gas,
        "init_tx_gas": init_gas,
        "finaltx_count": len([x for x in txs if x.get("type") == "final"]),
        "faulttx_count": int(chain.get("finalStatus", {}).get("faultCount", 0)),
        "finaltx_total_gas": final_gas,
        "finaltx_mean_gas": final_gas / max(1, len(txs)),
        "deployment_latency_s": deploy_latency,
        "init_tx_latency_s": init_latency,
        "finaltx_total_latency_s": final_latency,
        "finaltx_mean_latency_s": final_latency / max(1, len(txs)),
        "total_wall_including_finaltx_s": float(pre["total_wall_excluding_chain_s"]) + final_latency,
        "total_wall_including_init_and_finaltx_s": float(pre["total_wall_excluding_chain_s"]) + init_latency + final_latency,
        "total_wall_including_chain_setup_s": float(pre["total_wall_excluding_chain_s"]) + deploy_latency + init_latency + final_latency,
        "accepted": bool(pre.get("accepted_prechain")) and bool(chain.get("passed")),
    })
    (root / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    # Append measured chain costs to the communication/crypto result set without changing the pre-chain rows.
    chain_rows = []
    for x in txs:
        chain_rows.append({
            "round": x.get("round"),
            "operation": "finaltx_onchain",
            "seconds": x.get("latencySeconds"),
            "count": 1,
            "gasUsed": x.get("gasUsed"),
            "txHash": x.get("txHash"),
        })
    with (root / "chain_cost.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fields = ["round", "operation", "seconds", "count", "gasUsed", "txHash"]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(chain_rows)
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
