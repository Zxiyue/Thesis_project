# Changelog

## v1

- 新增Full VRAC-FL 512-bit、50轮IID和Non-IID一键实验。
- 删除消融控制组中第10轮人工FaultTx注入，正常主性能实验固定为0笔FaultTx。
- 每轮真实执行训练、TPHE、Pedersen、收据签名、门限恢复和模型更新。
- 新增单进程Hardhat批量回放，记录50笔FinalTx的真实Gas和确认延迟。
- 新增断点续跑、自动汇总和自动压缩。
