const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

function nsToSeconds(ns) { return Number(ns) / 1e9; }

async function timedTx(makeTx) {
  const start = process.hrtime.bigint();
  const tx = await makeTx();
  const receipt = await tx.wait();
  const end = process.hrtime.bigint();
  return {
    txHash: receipt.hash || tx.hash,
    gasUsed: receipt.gasUsed.toString(),
    latencySeconds: nsToSeconds(end - start),
    blockNumber: Number(receipt.blockNumber),
  };
}

async function main() {
  const planPath = process.env.FULL_CHAIN_PLAN;
  const resultPath = process.env.FULL_CHAIN_RESULT;
  if (!planPath || !resultPath) throw new Error("FULL_CHAIN_PLAN and FULL_CHAIN_RESULT are required");
  const plan = JSON.parse(fs.readFileSync(planPath, "utf8"));
  const [kgc] = await hre.ethers.getSigners();

  const deployStart = process.hrtime.bigint();
  const Factory = await hre.ethers.getContractFactory("FullAuditBoard", kgc);
  const contract = await Factory.deploy(await kgc.getAddress());
  await contract.waitForDeployment();
  const deployReceipt = await contract.deploymentTransaction().wait();
  const deployEnd = process.hrtime.bigint();

  const init = plan.init;
  const initResult = await timedTx(() => contract.recordInit(
    init.sysParaHash, init.uRoot, init.modelHash0, init.auditRoot0
  ));

  const txs = [];
  for (const item of plan.actions || []) {
    if (item.type !== "final") throw new Error(`normal full run only accepts final actions, got ${item.type}`);
    const r = await timedTx(() => contract.recordFinal(
      item.round, item.alpha, item.rootUp, item.comAggHash,
      item.modelHashPrev, item.modelHashNext,
      item.prevAuditRoot, item.auditRoot
    ));
    txs.push({ type: "final", round: item.round, ...r });
    console.log(JSON.stringify({type: "final", round: item.round, gasUsed: r.gasUsed, latencySeconds: r.latencySeconds}));
  }

  const status = {
    address: await contract.getAddress(),
    kgc: await contract.kgc(),
    initialized: await contract.initialized(),
    latestFinalRound: Number(await contract.latestFinalRound()),
    latestHashRound: Number(await contract.latestHashRound()),
    currentModelHash: await contract.currentModelHash(),
    latestAuditRoot: await contract.latestAuditRoot(),
    faultCount: Number(await contract.faultCount()),
  };
  const expected = plan.expected || {};
  const passed = (
    status.initialized === true &&
    status.latestFinalRound === Number(expected.finalTxCount || txs.length) &&
    status.latestHashRound === 0 &&
    status.faultCount === Number(expected.faultTxCount || 0) &&
    (!expected.finalModelHash || status.currentModelHash.toLowerCase() === expected.finalModelHash.toLowerCase()) &&
    (!expected.finalAuditRoot || status.latestAuditRoot.toLowerCase() === expected.finalAuditRoot.toLowerCase())
  );

  const result = {
    scenario: plan.scenario,
    chainId: Number((await hre.ethers.provider.getNetwork()).chainId),
    contractAddress: await contract.getAddress(),
    deploy: {
      gasUsed: deployReceipt.gasUsed.toString(),
      latencySeconds: nsToSeconds(deployEnd - deployStart),
      txHash: deployReceipt.hash,
    },
    init: initResult,
    transactions: txs,
    finalStatus: status,
    expected,
    passed,
  };
  fs.mkdirSync(path.dirname(resultPath), { recursive: true });
  fs.writeFileSync(resultPath, JSON.stringify(result, null, 2));
  console.log(JSON.stringify({scenario: plan.scenario, passed, finalStatus: status, resultPath}));
  if (!passed) process.exitCode = 2;
}

main().catch((err) => { console.error(err); process.exitCode = 1; });
