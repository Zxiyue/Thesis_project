// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

/// @title AblationAuditBoard
/// @notice KGC-controlled experimental board supporting full FinalTx/FaultTx and
///         a weak hash-only baseline. FaultTx never advances the success chain.
contract FullAuditBoard {
    address public immutable kgc;
    bool public initialized;

    bytes32 public sysParaHash;
    bytes32 public uRoot;
    bytes32 public currentModelHash;
    bytes32 public latestAuditRoot;
    uint64 public latestFinalRound;
    uint64 public latestHashRound;
    uint256 public faultCount;

    mapping(bytes32 => bool) public faultIdUsed;

    event InitRecorded(bytes32 indexed sysParaHash, bytes32 indexed uRoot, bytes32 modelHash0, bytes32 auditRoot0, address indexed kgc);
    event FinalRecorded(
        uint64 indexed round, bytes32 indexed alpha, bytes32 rootUp, bytes32 comAggHash,
        bytes32 modelHashPrev, bytes32 modelHashNext, bytes32 prevAuditRoot, bytes32 auditRoot
    );
    event HashRecorded(uint64 indexed round, bytes32 modelHashPrev, bytes32 modelHashNext);
    event FaultRecorded(
        bytes32 indexed faultId, uint64 indexed round, uint32 indexed attempt,
        bytes32 alpha, uint8 faultType, uint8 failureStage, uint8 resolution,
        bytes32 evidenceHash, bytes32 anchorAuditRoot
    );

    modifier onlyKGC() {
        require(msg.sender == kgc, "only KGC");
        _;
    }

    constructor(address kgc_) {
        require(kgc_ != address(0), "zero KGC");
        kgc = kgc_;
    }

    function recordInit(bytes32 sysParaHash_, bytes32 uRoot_, bytes32 modelHash0_, bytes32 auditRoot0_) external onlyKGC {
        require(!initialized, "already initialized");
        initialized = true;
        sysParaHash = sysParaHash_;
        uRoot = uRoot_;
        currentModelHash = modelHash0_;
        latestAuditRoot = auditRoot0_;
        emit InitRecorded(sysParaHash_, uRoot_, modelHash0_, auditRoot0_, kgc);
    }

    function recordFinal(
        uint64 round_, bytes32 alpha_, bytes32 rootUp_, bytes32 comAggHash_,
        bytes32 modelHashPrev_, bytes32 modelHashNext_, bytes32 prevAuditRoot_, bytes32 auditRoot_
    ) external onlyKGC {
        require(initialized, "not initialized");
        require(round_ == latestFinalRound + 1, "non-contiguous round");
        require(modelHashPrev_ == currentModelHash, "model hash discontinuity");
        require(prevAuditRoot_ == latestAuditRoot, "audit root discontinuity");
        latestFinalRound = round_;
        currentModelHash = modelHashNext_;
        latestAuditRoot = auditRoot_;
        emit FinalRecorded(round_, alpha_, rootUp_, comAggHash_, modelHashPrev_, modelHashNext_, prevAuditRoot_, auditRoot_);
    }

    function recordHash(uint64 round_, bytes32 modelHashPrev_, bytes32 modelHashNext_) external onlyKGC {
        require(initialized, "not initialized");
        require(round_ == latestHashRound + 1, "non-contiguous hash round");
        require(modelHashPrev_ == currentModelHash, "model hash discontinuity");
        latestHashRound = round_;
        currentModelHash = modelHashNext_;
        emit HashRecorded(round_, modelHashPrev_, modelHashNext_);
    }

    function recordFault(
        uint64 round_, uint32 attempt_, bytes32 alpha_, uint8 faultType_,
        uint8 failureStage_, uint8 resolution_, bytes32 evidenceHash_, bytes32 anchorAuditRoot_
    ) external onlyKGC returns (bytes32 faultId) {
        require(initialized, "not initialized");
        require(anchorAuditRoot_ == latestAuditRoot, "stale audit anchor");
        require(faultType_ != 0 && failureStage_ != 0 && resolution_ != 0, "empty fault field");
        faultId = keccak256(abi.encodePacked(
            address(this), round_, attempt_, alpha_, faultType_, failureStage_, resolution_, evidenceHash_, anchorAuditRoot_
        ));
        require(!faultIdUsed[faultId], "duplicate fault");
        faultIdUsed[faultId] = true;
        faultCount += 1;
        emit FaultRecorded(faultId, round_, attempt_, alpha_, faultType_, failureStage_, resolution_, evidenceHash_, anchorAuditRoot_);
    }
}
