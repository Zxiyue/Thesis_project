#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
for name in \
  ours_packed_mnist_iid_50r_p2048_s34_final \
  ours_packed_mnist_noniid_50r_p2048_s34_final; do
  echo
  echo "================ ${name} ================"
  if [ ! -d "outputs/${name}" ]; then
    echo "not created"
    continue
  fi
  echo "--- metrics tail ---"
  tail -n 12 "outputs/${name}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
  echo "--- verify ---"
  cat "outputs/${name}/verify_result.csv" 2>/dev/null || echo "verify not ready"
  echo "--- communication summary ---"
  cat "outputs/${name}/communication_summary_by_type.csv" 2>/dev/null || echo "communication summary not ready"
  echo "--- runtime tail ---"
  tail -n 25 "outputs/${name}/runtime_cost.csv" 2>/dev/null || echo "runtime not ready"
  echo "--- packing trace sample ---"
  python3 - <<PY 2>/dev/null || true
import json
from pathlib import Path
p=Path('outputs/${name}/run_trace.json')
if not p.exists():
    print('run_trace not ready')
else:
    obj=json.load(open(p))
    for rd in obj.get('rounds', [])[:1]:
        stats=rd.get('clientStats', [])
        if stats:
            s=stats[0]
            print({k:s.get(k) for k in ['packing_enabled','packing_slot_bits','packing_slots_per_cipher','packing_cipher_count']})
PY
done

ls -lh /root/ours_packed_*50r*_results.zip 2>/dev/null || true
