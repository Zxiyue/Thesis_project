#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}

check_hardhat() {
  curl -s -X POST http://127.0.0.1:8545 \
    -H "Content-Type: application/json" \
    --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' | grep -q '"result"'
}

cleanup_processes() {
  local cfg="$1"
  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  pkill -f "run_kgc_server.py" || true
  pkill -f "run_cs_server.py" || true
  pkill -f "run_client_server.py" || true
  pkill -f "start_experiment.py" || true
  sleep 3
}

run_one() {
  local dataset_key="$1"
  local cfg=""
  local name=""
  local rounds=50

  case "${dataset_key}" in
    mnist_iid)
      name="ours_packed_mnist_iid_50r_p2048_s34_final"
      cfg="configs/${name}.yaml"
      ;;
    mnist_noniid)
      name="ours_packed_mnist_noniid_50r_p2048_s34_final"
      cfg="configs/${name}.yaml"
      ;;
    *)
      echo "[ERROR] Unknown dataset key: ${dataset_key}. Use mnist_iid or mnist_noniid."
      exit 1
      ;;
  esac

  echo
  echo "================================================================"
  echo "[RUN] ${name}"
  echo "[CFG] ${cfg}"
  echo "================================================================"

  if [ ! -f "${cfg}" ]; then
    echo "[ERROR] Config not found: ${cfg}"
    echo "Run: python3 /root/ours_packed_s34_50r_final_pack/config_tools/make_ours_packed_s34_50r_configs.py"
    exit 1
  fi

  if ! check_hardhat; then
    echo "[ERROR] Hardhat RPC is not reachable at http://127.0.0.1:8545"
    echo "Start Hardhat in another tmux/window first:"
    echo "  cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && npx hardhat node | tee /root/hardhat.log"
    exit 1
  fi

  cleanup_processes "${cfg}"
  rm -rf "outputs/${name}"

  echo "[INFO] Deploying audit board contract..."
  npx hardhat run scripts/deploy.js --network localhost || { echo "[ERROR] deploy failed"; exit 1; }

  echo "[INFO] Starting KGC/CS/clients..."
  python3 scripts/start_all_entities.py --config "${cfg}" --clients 5 || { echo "[ERROR] start_all_entities failed"; exit 1; }

  echo "[INFO] Starting experiment..."
  python3 scripts/start_experiment.py --config "${cfg}" || echo "[WARN] start_experiment returned non-zero; continue polling."

  local done_flag=0
  local max_poll="${MAX_POLL:-720}"
  for i in $(seq 1 "${max_poll}"); do
    echo
    echo "---- $(date) ${name} status ${i}/${max_poll} ----"
    tail -n 8 "outputs/${name}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
    cat "outputs/${name}/verify_result.csv" 2>/dev/null || echo "verify not ready"

    if [ -f "outputs/${name}/verify_result.csv" ] && grep -q "True,${rounds}" "outputs/${name}/verify_result.csv"; then
      done_flag=1
      echo "[INFO] ${name} accepted=True rounds=${rounds}"
      break
    fi
    sleep 30
  done

  echo "[INFO] Collecting results..."
  python3 scripts/collect_results.py --config "${cfg}" || true

  echo "[INFO] Stopping entities..."
  cleanup_processes "${cfg}"

  if [ "${done_flag}" -ne 1 ]; then
    echo "[ERROR] ${name} did not finish correctly. Keeping partial outputs for debugging."
    zip -qr "/root/${name}_partial_results.zip" "outputs/${name}" 2>/dev/null || true
    exit 1
  fi

  cd /root/fpa5
  zip -qr "/root/${name}_results.zip" "outputs/${name}"
  echo "[INFO] Result zip: /root/${name}_results.zip"
}

DATASETS="${DATASETS:-mnist_iid mnist_noniid}"
for ds in ${DATASETS}; do
  run_one "${ds}"
done

cd /root/fpa5
COMBINED="/root/ours_packed_s34_50r_final_results.zip"
rm -f "${COMBINED}"
zip_args=()
for ds in ${DATASETS}; do
  case "${ds}" in
    mnist_iid) zip_args+=("outputs/ours_packed_mnist_iid_50r_p2048_s34_final") ;;
    mnist_noniid) zip_args+=("outputs/ours_packed_mnist_noniid_50r_p2048_s34_final") ;;
  esac
done
zip -qr "${COMBINED}" "${zip_args[@]}" 2>/dev/null || true
echo "[DONE] Combined result zip: ${COMBINED}"
