from __future__ import annotations

from pathlib import Path
import csv
import json
import statistics as stats

ROOT = Path('/root/fpa5')
NAMES = [
    'ours_packed_mnist_iid_50r_p2048_s34_final',
    'ours_packed_mnist_noniid_50r_p2048_s34_final',
]


def read_csv(path: Path):
    if not path.exists():
        return []
    with path.open(newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))


def fnum(v):
    try:
        return float(v)
    except Exception:
        return 0.0


def best_metric(metrics):
    if not metrics:
        return ('', '')
    best = max(metrics, key=lambda r: fnum(r.get('test_accuracy', 0)))
    return best.get('test_accuracy', ''), best.get('round', '')


def sum_runtime(runtime, stage):
    return sum(fnum(r.get('seconds', 0)) for r in runtime if r.get('stage') == stage)


def avg_runtime(runtime, stage):
    vals = [fnum(r.get('seconds', 0)) for r in runtime if r.get('stage') == stage]
    return sum(vals)/len(vals) if vals else 0.0


def total_comm_bytes(comm):
    total = 0.0
    for r in comm:
        total += fnum(r.get('total_bytes', r.get('bytes', 0)))
    return total


def trace_packing(d: Path):
    p = d / 'run_trace.json'
    out = {
        'packing_slot_bits': '',
        'packing_slots_per_cipher': '',
        'packing_cipher_count': '',
        'logical_coordinates': '',
        'compression_ratio': '',
    }
    if not p.exists():
        return out
    try:
        obj = json.load(open(p, encoding='utf-8'))
        vals = []
        slots = []
        ciphers = []
        for rd in obj.get('rounds', []):
            for cs in rd.get('clientStats', []):
                if cs.get('packing_enabled'):
                    vals.append(cs.get('packing_slot_bits'))
                    slots.append(cs.get('packing_slots_per_cipher'))
                    ciphers.append(cs.get('packing_cipher_count'))
        if vals:
            out['packing_slot_bits'] = vals[0]
        if slots:
            out['packing_slots_per_cipher'] = slots[0]
        if ciphers:
            out['packing_cipher_count'] = ciphers[0]
            # tiny_cnn dimension used in this project. If trace has no direct
            # dimension field, infer from slot count and known packed cipher count
            # would be unsafe; leave logical coord from current model default.
            out['logical_coordinates'] = 6794
            out['compression_ratio'] = 6794 / float(ciphers[0])
    except Exception as e:
        out['trace_error'] = repr(e)
    return out


def analyze(name: str):
    d = ROOT / 'outputs' / name
    metrics = read_csv(d / 'metrics_round.csv')
    runtime = read_csv(d / 'runtime_cost.csv')
    comm = read_csv(d / 'communication_summary_by_type.csv')
    verify = read_csv(d / 'verify_result.csv')
    chain = read_csv(d / 'blockchain_cost.csv')
    if not d.exists():
        return None
    final = metrics[-1] if metrics else {}
    best_acc, best_round = best_metric(metrics)
    ver = verify[-1] if verify else {}
    trace = trace_packing(d)
    total_gas = sum(fnum(r.get('gasUsed', r.get('gas_used', 0))) for r in chain)
    row = {
        'name': name,
        'accepted': ver.get('accepted', ''),
        'rounds': ver.get('rounds', ''),
        'final_acc': final.get('test_accuracy', ''),
        'best_acc': best_acc,
        'best_round': best_round,
        'final_loss': final.get('test_loss', ''),
        **trace,
        'total_comm_MB': total_comm_bytes(comm) / 1024 / 1024,
        'client_upload_parallel_wall_avg_s': avg_runtime(runtime, 'client_upload_parallel_wall'),
        'client_paillier_encrypt_sum_s': sum_runtime(runtime, 'client_paillier_encrypt'),
        'client_paillier_pack_sum_s': sum_runtime(runtime, 'client_paillier_pack'),
        'client_pedersen_commit_sum_s': sum_runtime(runtime, 'client_pedersen_commit'),
        'client_local_train_sum_s': sum_runtime(runtime, 'client_local_train'),
        'combine_decrypt_sum_s': sum_runtime(runtime, 'combine_decrypt'),
        'cs_aggregate_sum_s': sum_runtime(runtime, 'cs_aggregate'),
        'kgc_compensation_sum_s': sum_runtime(runtime, 'kgc_compensation'),
        'blockchain_total_gas': total_gas,
    }
    return row


def main():
    rows = [r for r in (analyze(n) for n in NAMES) if r]
    if not rows:
        print('No outputs found.')
        return
    headers = list(rows[0].keys())
    print(','.join(headers))
    for r in rows:
        print(','.join(str(r.get(h, '')) for h in headers))


if __name__ == '__main__':
    main()
