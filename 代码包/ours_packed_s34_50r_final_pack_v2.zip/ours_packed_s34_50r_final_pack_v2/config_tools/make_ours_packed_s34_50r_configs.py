from __future__ import annotations

from pathlib import Path
import copy
import yaml

ROOT = Path("/root/fpa5")
CONFIG_DIR = ROOT / "configs"

DATASETS = {
    "mnist_iid": {
        "candidates": [
            "mnist_iid_50r_lr020_main.yaml",
            "mnist_iid_50r_main.yaml",
            "ours_packed_mnist_iid_10r_p2048_s34.yaml",
        ],
        "out_name": "ours_packed_mnist_iid_50r_p2048_s34_final.yaml",
        "output_dir": "outputs/ours_packed_mnist_iid_50r_p2048_s34_final",
        "dataset_name": "MNIST",
        "iid": True,
    },
    "mnist_noniid": {
        "candidates": [
            "mnist_noniid_50r_lr020_main.yaml",
            "mnist_noniid_50r_main.yaml",
            "ours_packed_mnist_iid_10r_p2048_s34.yaml",
        ],
        "out_name": "ours_packed_mnist_noniid_50r_p2048_s34_final.yaml",
        "output_dir": "outputs/ours_packed_mnist_noniid_50r_p2048_s34_final",
        "dataset_name": "MNIST",
        "iid": False,
    },
}


def load_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def write_yaml(path: Path, cfg: dict) -> None:
    path.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding="utf-8")
    print(f"wrote {path}")


def find_base(candidates: list[str]) -> Path:
    for name in candidates:
        p = CONFIG_DIR / name
        if p.exists():
            return p
    raise FileNotFoundError("None of the base config candidates exist: " + ", ".join(candidates))


def normalize_dropout(cfg: dict) -> None:
    # Formal 50-round packed experiments should preserve the dropout setting
    # from the 50r main configs when available. If the base is a 10r sensitivity
    # config with dropout disabled, restore the representative schedule used by
    # the lr=0.20 main experiments.
    fed = cfg.setdefault("federated", {})
    dropout = fed.get("dropout", None)
    if not dropout:
        fed["dropout"] = {10: [2], 25: [4]}


def make_one(key: str) -> None:
    meta = DATASETS[key]
    base_path = find_base(meta["candidates"])
    cfg = copy.deepcopy(load_yaml(base_path))

    cfg["output_dir"] = meta["output_dir"]

    cfg.setdefault("dataset", {})
    cfg["dataset"]["name"] = meta["dataset_name"]
    cfg["dataset"]["iid"] = bool(meta["iid"])
    cfg["dataset"].setdefault("data_dir", "/root/fpa5/data")
    cfg["dataset"].setdefault("download", False)
    cfg["dataset"].setdefault("shards_per_client", 2)

    cfg.setdefault("model", {})
    cfg["model"]["name"] = "tiny_cnn"

    cfg.setdefault("federated", {})
    cfg["federated"]["rounds"] = 50
    cfg["federated"]["clients"] = 5
    cfg["federated"]["threshold"] = 3
    cfg["federated"]["local_lr"] = 0.20
    cfg["federated"]["server_lr"] = 1.0
    cfg["federated"].setdefault("local_epochs", 1)
    cfg["federated"].setdefault("batch_size", 64)
    normalize_dropout(cfg)

    cfg.setdefault("encoding", {})
    cfg["encoding"].setdefault("q", 1000000007)
    cfg["encoding"].setdefault("scale", 10000)

    cfg.setdefault("crypto", {})
    cfg["crypto"]["paillier_bits"] = 2048
    cfg["crypto"].setdefault("pedersen_prime_bits", 521)
    cfg["crypto"].setdefault("pedersen_window", 0)
    cfg["crypto"]["packing"] = {
        "enabled": True,
        "scheme": "mod_q_residue",
        "slot_bits": 34,
        "pack_size": None,
        "guard_bits": 1,
        "allow_unsafe": False,
    }

    cfg.setdefault("runtime", {})
    cfg["runtime"]["device"] = cfg["runtime"].get("device", "cpu")
    cfg["runtime"]["parallel_clients"] = True
    cfg["runtime"]["max_client_workers"] = 5
    cfg["runtime"].setdefault("num_workers", 0)
    cfg["runtime"].setdefault("pin_memory", False)
    cfg["runtime"].setdefault("test_batch_size", 256)

    cfg.setdefault("distributed", {})
    cfg["distributed"]["enabled"] = True
    cfg["distributed"]["client_mode"] = "individual"
    cfg["distributed"].setdefault("host", "127.0.0.1")
    cfg["distributed"].setdefault("kgc_port", 9200)
    cfg["distributed"].setdefault("cs_port", 9300)
    cfg["distributed"].setdefault("client_base_port", 9400)

    cfg.setdefault("communication", {})
    cfg["communication"]["enabled"] = True
    cfg["communication"]["mode"] = "http"
    cfg["communication"]["record_actual_time"] = True
    cfg["communication"]["timeout_seconds"] = 7200

    cfg.setdefault("blockchain", {})
    cfg["blockchain"]["enabled"] = True
    cfg["blockchain"].setdefault("rpc_url", "http://127.0.0.1:8545")
    cfg["blockchain"].setdefault("contract_json", "outputs/contract.json")

    cfg.setdefault("logging", {})
    cfg["logging"]["save_trace"] = True
    cfg["logging"]["verbose"] = True

    cfg["seed"] = cfg.get("seed", 20260627)

    write_yaml(CONFIG_DIR / meta["out_name"], cfg)
    print(f"  base: {base_path.name}")
    print(f"  output_dir: {meta['output_dir']}")


def main() -> None:
    for key in ["mnist_iid", "mnist_noniid"]:
        make_one(key)


if __name__ == "__main__":
    main()
