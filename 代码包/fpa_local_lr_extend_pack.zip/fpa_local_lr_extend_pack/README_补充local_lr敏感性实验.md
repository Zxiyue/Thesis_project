# 补充 local_lr 敏感性实验

## 目的

补充当前 local_lr 实验在 0.10 处仍上升的问题，继续测试较大学习率区间。

## 新增实验

- dataset: Fashion-MNIST-Non-IID
- clients: 5
- threshold: 3
- rounds: 30
- server_lr: 1.0
- dropout: {}
- model: tiny_cnn
- local_lr: 0.12, 0.15, 0.18, 0.20

## 使用方法

上传本补丁包到服务器 `/root/fpa_local_lr_extend_pack.zip` 后执行：

```bash
cd /root/fpa5
unzip -o /root/fpa_local_lr_extend_pack.zip -d /root/fpa5
chmod +x run_local_lr_sensitivity_extend.sh
```

确认配置：

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
python3 scripts/check_dataset_loader.py --configs \
configs/sensitivity_local_lr_0_12.yaml \
configs/sensitivity_local_lr_0_15.yaml \
configs/sensitivity_local_lr_0_18.yaml \
configs/sensitivity_local_lr_0_20.yaml
```

启动 Hardhat：

```bash
tmux new -d -s hardhat "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && npx hardhat node > /root/hardhat.log 2>&1"
sleep 5
tail -n 20 /root/hardhat.log
```

运行：

```bash
tmux new -s localextend
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_local_lr_sensitivity_extend.sh
```

完成后下载：

```text
/root/local_lr_sensitivity_extend_results.zip
```

## 判断标准

如果 local_lr=0.20 仍然最好，建议继续补 0.25 和 0.30；如果 0.12/0.15 附近最好且 0.18/0.20 下降，则当前范围足以支持论文中的“合理学习率区间”分析。
