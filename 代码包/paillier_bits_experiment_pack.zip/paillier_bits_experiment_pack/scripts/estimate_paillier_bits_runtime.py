#!/usr/bin/env python3
"""
Estimate 50-round runtime from 2-round smoke outputs.
Run on server after smoke test:
  cd /root/fpa5
  python3 /root/paillier_bits_experiment_pack/scripts/estimate_paillier_bits_runtime.py
"""
from __future__ import annotations
import csv, json, statistics, math
from pathlib import Path
from datetime import timedelta

BASE = Path("/root/fpa5")
OUTS = {
    "p1024_iid_2r": BASE / "outputs/smoke_mnist_iid_2r_lr020_p1024",
    "p2048_iid_2r": BASE / "outputs/smoke_mnist_iid_2r_lr020_p2048",
}

def fmt_sec(x: float | None) -> str:
    if x is None or math.isnan(x):
        return "N/A"
    return str(timedelta(seconds=int(round(x))))

def read_csv(path: Path):
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def sum_stage(outdir: Path, stage: str) -> float:
    rows = read_csv(outdir / "runtime_cost.csv")
    total = 0.0
    for r in rows:
        if r.get("stage") == stage:
            try: total += float(r.get("seconds", 0) or 0)
            except Exception: pass
    return total

def avg_stage_by_round(outdir: Path, stage: str) -> float | None:
    rows = read_csv(outdir / "runtime_cost.csv")
    vals = []
    for r in rows:
        if r.get("stage") == stage:
            try: vals.append(float(r.get("seconds", 0) or 0))
            except Exception: pass
    if not vals:
        return None
    return statistics.mean(vals)

def get_start_seconds(outdir: Path) -> float | None:
    rows = read_csv(outdir / "communication_summary_by_type.csv")
    for r in rows:
        if r.get("payload_type") == "StartExperiment":
            try: return float(r.get("total_actual_seconds", 0) or 0)
            except Exception: return None
    return None

def get_verify(outdir: Path):
    rows = read_csv(outdir / "verify_result.csv")
    if not rows: return None
    return rows[-1]

def final_metric(outdir: Path):
    rows = read_csv(outdir / "metrics_round.csv")
    if not rows: return None
    return rows[-1]

def analyze(label: str, outdir: Path, target_rounds=50):
    ver = get_verify(outdir)
    met = final_metric(outdir)
    if not outdir.exists() or not ver:
        print(f"[{label}] output missing or verify_result.csv missing: {outdir}")
        return None
    rounds = int(float(ver.get("rounds", 0)))
    accepted = str(ver.get("accepted", "")).lower() == "true"
    start_seconds = get_start_seconds(outdir)
    avg_parallel_wall = avg_stage_by_round(outdir, "client_upload_parallel_wall")
    total_encrypt = sum_stage(outdir, "client_paillier_encrypt")
    total_commit = sum_stage(outdir, "client_pedersen_commit")
    total_train = sum_stage(outdir, "client_local_train")
    total_runtime_rows = sum(float(r.get("seconds", 0) or 0) for r in read_csv(outdir / "runtime_cost.csv") if r.get("seconds"))

    if start_seconds is not None and rounds > 0:
        direct_est = start_seconds / rounds * target_rounds
    else:
        direct_est = None
    if avg_parallel_wall is not None:
        wall_stage_est = avg_parallel_wall * target_rounds
    else:
        wall_stage_est = None

    # Conservative estimate: 1.25x linear StartExperiment estimate; if unavailable, 1.35x parallel wall estimate.
    base = direct_est if direct_est is not None else wall_stage_est
    conservative = base * 1.25 if base is not None else None

    print("\n" + "=" * 72)
    print(f"{label}: {outdir}")
    print("=" * 72)
    print(f"accepted={accepted}, rounds={rounds}, final_metric={met}")
    print(f"2r StartExperiment wall: {fmt_sec(start_seconds)} ({start_seconds})")
    print(f"avg client_upload_parallel_wall per round: {fmt_sec(avg_parallel_wall)} ({avg_parallel_wall})")
    print(f"2r total client_paillier_encrypt: {fmt_sec(total_encrypt)} ({total_encrypt:.2f}s)")
    print(f"2r total client_pedersen_commit: {fmt_sec(total_commit)} ({total_commit:.2f}s)")
    print(f"2r total client_local_train: {fmt_sec(total_train)} ({total_train:.2f}s)")
    print(f"Estimated 50r by StartExperiment linear: {fmt_sec(direct_est)}")
    print(f"Estimated 50r by round parallel-wall stage: {fmt_sec(wall_stage_est)}")
    print(f"Conservative 50r estimate (+25%): {fmt_sec(conservative)}")
    return {"label": label, "rounds": rounds, "accepted": accepted, "direct_est": direct_est, "conservative": conservative}

def main():
    print("Ours-basic Paillier-bit runtime estimate from smoke tests")
    print("Note: 2-round smoke tests can under/over-estimate 50-round runtime. Use the conservative estimate for scheduling.")
    res = {}
    for label, outdir in OUTS.items():
        r = analyze(label, outdir)
        if r: res[label] = r
    print("\n" + "#" * 72)
    print("Suggested scheduling for the 3 full experiments")
    print("#" * 72)
    p1024 = res.get("p1024_iid_2r", {})
    p2048 = res.get("p2048_iid_2r", {})
    e1 = p1024.get("conservative")
    e2 = p2048.get("conservative")
    e3 = e2 * 1.10 if e2 is not None else None  # Non-IID: same crypto dimension; add 10% buffer.
    print(f"1) MNIST-IID 50r Paillier-1024: {fmt_sec(e1)}")
    print(f"2) MNIST-IID 50r Paillier-2048: {fmt_sec(e2)}")
    print(f"3) MNIST-Non-IID 50r Paillier-2048: {fmt_sec(e3)}  (uses 2048 IID estimate +10% buffer)")
    total = sum(x for x in [e1, e2, e3] if x is not None)
    print(f"Estimated total sequential runtime: {fmt_sec(total)}")
    print("\nIf the 2048-bit 2-round test is already very slow, run the 50-round jobs one by one, not all in parallel.")

if __name__ == "__main__":
    main()
