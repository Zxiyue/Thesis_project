#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}

check_hardhat() {
  curl -s -X POST http://127.0.0.1:8545 \
    -H "Content-Type: application/json" \
    --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' | grep -q '"result"'
}

verify_done() {
  local outdir="$1"
  local rounds="$2"
  python3 - "$outdir" "$rounds" <<'PY'
import csv, sys
from pathlib import Path
outdir = Path(sys.argv[1])
rounds = int(sys.argv[2])
p = outdir / "verify_result.csv"
if not p.exists():
    sys.exit(1)
with p.open("r", encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))
if not rows:
    sys.exit(1)
r = rows[-1]
accepted = str(r.get("accepted", "")).strip().lower() == "true"
round_ok = int(float(r.get("rounds", -1))) == rounds
sys.exit(0 if accepted and round_ok else 1)
PY
}

if ! check_hardhat; then
  echo "[INFO] Hardhat not reachable. Starting hardhat..."
  tmux kill-session -t hardhat 2>/dev/null || true
  tmux new -d -s hardhat "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && npx hardhat node > /root/hardhat.log 2>&1"
  sleep 5
  tail -n 20 /root/hardhat.log || true
fi

if ! check_hardhat; then
  echo "[ERROR] Hardhat still not reachable."
  exit 1
fi

run_one() {
  local cfg="$1"
  local name="$2"
  local rounds="$3"
  local outdir="outputs/${name}"

  echo
  echo "================================================================"
  echo "[FULL RUN] ${name}"
  echo "[CFG] ${cfg}"
  echo "================================================================"

  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  pkill -f "run_kgc_server.py" || true
  pkill -f "run_cs_server.py" || true
  pkill -f "run_client_server.py" || true
  pkill -f "start_experiment.py" || true
  sleep 3

  rm -rf "${outdir}"

  echo "[INFO] Deploying audit board contract..."
  npx hardhat run scripts/deploy.js --network localhost || { echo "[ERROR] deploy failed."; exit 1; }

  echo "[INFO] Starting KGC/CS/clients..."
  python3 scripts/start_all_entities.py --config "${cfg}" --clients 5 || { echo "[ERROR] start_all_entities failed."; exit 1; }

  echo "[INFO] Starting experiment..."
  python3 scripts/start_experiment.py --config "${cfg}" || echo "[WARN] start_experiment returned non-zero; continue polling."

  local done_flag=0
  local max_poll=2160   # 2160 * 30s = 18h per experiment

  for i in $(seq 1 ${max_poll}); do
    echo
    echo "---- $(date '+%F %T') ${name} status ${i}/${max_poll} ----"
    tail -n 5 "${outdir}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
    cat "${outdir}/verify_result.csv" 2>/dev/null || echo "verify not ready"

    if verify_done "${outdir}" "${rounds}"; then
      done_flag=1
      echo "[INFO] ${name} accepted=True rounds=${rounds}"
      break
    fi
    sleep 30
  done

  echo "[INFO] Collecting results..."
  python3 scripts/collect_results.py --config "${cfg}" || true

  echo "[INFO] Stopping entities..."
  python3 scripts/stop_all_entities.py --config "${cfg}" || true

  if [ "${done_flag}" -ne 1 ]; then
    echo "[ERROR] ${name} did not finish correctly."
    zip -qr "/root/${name}_partial_results.zip" "${outdir}" 2>/dev/null || true
    exit 1
  fi

  cd /root/fpa5
  zip -qr "/root/${name}_results.zip" "${outdir}"
  echo "[INFO] Result zip: /root/${name}_results.zip"
}

run_one "configs/mnist_iid_50r_lr020_p1024.yaml" "mnist_iid_50r_lr020_p1024" 50
run_one "configs/mnist_iid_50r_lr020_p2048.yaml" "mnist_iid_50r_lr020_p2048" 50
run_one "configs/mnist_noniid_50r_lr020_p2048.yaml" "mnist_noniid_50r_lr020_p2048" 50

cd /root
zip -qr /root/ours_basic_paillier_bits_3x50_results.zip \
  mnist_iid_50r_lr020_p1024_results.zip \
  mnist_iid_50r_lr020_p2048_results.zip \
  mnist_noniid_50r_lr020_p2048_results.zip \
  paillier_bits_3x50.log 2>/dev/null || true

echo
echo "[DONE] 3 full Paillier-bit experiments finished."
echo "[ZIP] /root/ours_basic_paillier_bits_3x50_results.zip"
