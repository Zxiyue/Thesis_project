#!/usr/bin/env python3
"""
Create Ours-basic Paillier-bit smoke and full-run configs under /root/fpa5/configs.
Run on server:
  cd /root/fpa5
  source .venv/bin/activate
  export PYTHONPATH=/root/fpa5:$PYTHONPATH
  python3 /root/paillier_bits_experiment_pack/config_tools/make_paillier_bits_configs.py
"""
from pathlib import Path
import yaml

BASE = Path("/root/fpa5")

def deep_set(cfg, path, value):
    cur = cfg
    for key in path[:-1]:
        cur = cur.setdefault(key, {})
    cur[path[-1]] = value


def make(src: str, dst: str, bits: int, rounds: int, outdir: str):
    srcp = BASE / src
    dstp = BASE / dst
    if not srcp.exists():
        raise FileNotFoundError(f"base config not found: {srcp}")
    cfg = yaml.safe_load(srcp.read_text(encoding="utf-8"))

    deep_set(cfg, ["crypto", "paillier_bits"], bits)
    deep_set(cfg, ["federated", "rounds"], rounds)
    deep_set(cfg, ["federated", "local_lr"], 0.20)
    deep_set(cfg, ["federated", "server_lr"], 1.0)
    cfg["output_dir"] = outdir

    # Keep the experiment comparable with the existing Ours-basic distributed setting.
    deep_set(cfg, ["runtime", "parallel_clients"], True)
    deep_set(cfg, ["runtime", "max_client_workers"], 5)
    deep_set(cfg, ["distributed", "enabled"], True)
    deep_set(cfg, ["communication", "enabled"], True)
    deep_set(cfg, ["communication", "mode"], "http")
    deep_set(cfg, ["communication", "timeout_seconds"], 3600)

    dstp.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding="utf-8")
    print(f"[OK] wrote {dstp}")


def main():
    jobs = [
        ("configs/mnist_iid_50r_lr020_main.yaml", "configs/smoke_mnist_iid_2r_lr020_p1024.yaml", 1024, 2, "outputs/smoke_mnist_iid_2r_lr020_p1024"),
        ("configs/mnist_iid_50r_lr020_main.yaml", "configs/smoke_mnist_iid_2r_lr020_p2048.yaml", 2048, 2, "outputs/smoke_mnist_iid_2r_lr020_p2048"),
        ("configs/mnist_iid_50r_lr020_main.yaml", "configs/mnist_iid_50r_lr020_p1024.yaml", 1024, 50, "outputs/mnist_iid_50r_lr020_p1024"),
        ("configs/mnist_iid_50r_lr020_main.yaml", "configs/mnist_iid_50r_lr020_p2048.yaml", 2048, 50, "outputs/mnist_iid_50r_lr020_p2048"),
        ("configs/mnist_noniid_50r_lr020_main.yaml", "configs/mnist_noniid_50r_lr020_p2048.yaml", 2048, 50, "outputs/mnist_noniid_50r_lr020_p2048"),
    ]
    for job in jobs:
        make(*job)

if __name__ == "__main__":
    main()
