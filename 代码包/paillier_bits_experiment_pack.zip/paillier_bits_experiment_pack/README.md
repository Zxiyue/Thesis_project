# Ours-basic Paillier bits 实验包

用途：先跑 2 轮 smoke test，用输出估算 50 轮时间；确认后再跑 3 组 50 轮正式实验，并在程序结束后自动打包结果。

## 1. 放置文件

把整个 `paillier_bits_experiment_pack` 目录上传/复制到服务器：

```bash
/root/paillier_bits_experiment_pack
```

## 2. 生成配置

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
python3 /root/paillier_bits_experiment_pack/config_tools/make_paillier_bits_configs.py
```

生成配置：

```text
configs/smoke_mnist_iid_2r_lr020_p1024.yaml
configs/smoke_mnist_iid_2r_lr020_p2048.yaml
configs/mnist_iid_50r_lr020_p1024.yaml
configs/mnist_iid_50r_lr020_p2048.yaml
configs/mnist_noniid_50r_lr020_p2048.yaml
```

## 3. 只跑 2 轮测试

```bash
chmod +x /root/paillier_bits_experiment_pack/scripts/*.sh

tmux new -d -s paillier_smoke "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && stdbuf -oL -eL /root/paillier_bits_experiment_pack/scripts/run_paillier_bits_smoke_only.sh | tee /root/paillier_smoke.log"
```

查看：

```bash
tmux capture-pane -t paillier_smoke:0 -p | tail -n 120
tail -n 120 /root/paillier_smoke.log
```

完成后得到：

```text
/root/ours_basic_paillier_bits_smoke_results.zip
```

## 4. 根据 2 轮结果估算 50 轮时间

```bash
cd /root/fpa5
python3 /root/paillier_bits_experiment_pack/scripts/estimate_paillier_bits_runtime.py | tee /root/paillier_bits_estimate.txt
```

估算依据：

- `communication_summary_by_type.csv` 中 `StartExperiment` 的 wall time；
- `runtime_cost.csv` 中 `client_upload_parallel_wall` 的每轮并行等待时间；
- 对 50 轮给出线性估算和 +25% 保守估算；
- MNIST-Non-IID 2048-bit 使用 MNIST-IID 2048-bit 估算并加 10% buffer。

## 5. 确认后跑 3 组 50 轮正式实验

```bash
tmux new -d -s paillier_3x50 "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && stdbuf -oL -eL /root/paillier_bits_experiment_pack/scripts/run_paillier_bits_3x50.sh | tee /root/paillier_bits_3x50.log"
```

查看：

```bash
tmux capture-pane -t paillier_3x50:0 -p | tail -n 120
tail -n 120 /root/paillier_bits_3x50.log
```

完成后得到总结果包：

```text
/root/ours_basic_paillier_bits_3x50_results.zip
```

每组单独结果包：

```text
/root/mnist_iid_50r_lr020_p1024_results.zip
/root/mnist_iid_50r_lr020_p2048_results.zip
/root/mnist_noniid_50r_lr020_p2048_results.zip
```
