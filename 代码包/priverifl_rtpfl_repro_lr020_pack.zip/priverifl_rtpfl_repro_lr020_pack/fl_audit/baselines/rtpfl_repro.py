from __future__ import annotations

import time
from typing import Any, Dict, List

import numpy as np
import torch

from fl_audit.baselines.common import (
    CommRecorder,
    Runtime,
    active_clients_for_round,
    apply_integer_update,
    get_device,
    make_client_keypairs,
    set_seed,
    train_raw_delta,
    write_common_outputs,
)
from fl_audit.baselines.paper_repro_crypto import (
    RTPFLCodeState,
    decrypt_with_private_exponent,
    quantize_decimal,
    rtpfl_partial_decrypt_cipher,
)
from fl_audit.crypto import paillier
from fl_audit.crypto.signature import sign_obj, verify_obj
from fl_audit.data import make_loaders
from fl_audit.model import evaluate, get_vector, make_model, model_hash
from fl_audit.utils.codec import bytes32_hex


def _cfg_get(cfg: Dict[str, Any], *path: str, default: Any = None) -> Any:
    cur: Any = cfg
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return default
        cur = cur[key]
    return cur


def _int_list(x: np.ndarray) -> List[int]:
    return [int(v) for v in x.reshape(-1).tolist()]


def _aggregate_cipher_vectors(pub: paillier.PaillierPublicKey, encrypted_vectors: List[List[int]]) -> List[int]:
    if not encrypted_vectors:
        return []
    dim = len(encrypted_vectors[0])
    out = []
    for j in range(dim):
        acc = 1
        for vec in encrypted_vectors:
            acc = (acc * int(vec[j])) % pub.n2
        out.append(acc)
    return out


def run_rtpfl_repro(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Paper-mechanism RTP-FL reproduction baseline.

    This runner rewrites the previous RTP-FL-style baseline.  It now implements
    the RTP-FL paper's three core mechanisms for experiments:
      * Paillier public key and private exponent gammaM/lambda;
      * (N,k,d) product-matrix MBR regenerating code for repairable private-key
        segments, with alpha=d and beta=1;
      * dropout private-key segment repair by any d normal clients;
      * Algorithm-1-like partial decryption vectors c_i=c^{s_i R_i} and
        Hadamard product reconstruction of c^{Delta*gammaM}.

    The code is an experimental reproduction for FL benchmarking.  It is not a
    production-grade cryptographic library.
    """
    seed = int(cfg.get("seed", 42))
    set_seed(seed)
    out_dir = cfg.get("output_dir", "outputs/baseline_repro_rtpfl")
    device = get_device(cfg)

    timer = Runtime()
    comm = CommRecorder()
    metrics_rows: List[Dict[str, Any]] = []
    crypto_rows: List[Dict[str, Any]] = []
    baseline_rows: List[Dict[str, Any]] = []
    trace: Dict[str, Any] = {"scheme": "baseline_repro_rtpfl", "rounds": []}

    model = make_model(cfg["model"]["name"])
    train_loaders, test_loader, _parts = make_loaders(cfg)
    clients = int(cfg["federated"]["clients"])
    dim = int(get_vector(model).numel())
    paillier_bits = int(_cfg_get(cfg, "crypto", "paillier_bits", default=512))
    decimal_scale = int(_cfg_get(cfg, "baseline", "rtpfl", "decimal_scale", default=10000))
    k = int(_cfg_get(cfg, "baseline", "rtpfl", "k", default=cfg["federated"].get("threshold", 3)))
    d = int(_cfg_get(cfg, "baseline", "rtpfl", "d", default=max(k, clients - 1)))
    random_bits = int(_cfg_get(cfg, "baseline", "rtpfl", "message_random_bits", default=96))
    decrypt_mode = str(_cfg_get(cfg, "baseline", "rtpfl", "decrypt_mode", default="paper_hadamard"))

    with timer.record(0, "rtpfl_paillier_keygen", "Paillier key generation"):
        pkey = paillier.keygen(paillier_bits)
    with timer.record(0, "rtpfl_mbr_repairable_share_deal", "deal (N,k,d) MBR-code private-key segments"):
        code_state = RTPFLCodeState.deal(private_exp=pkey.private.lam, N=clients, k=k, d=d, seed=seed, random_bits=random_bits)

    client_keys = make_client_keypairs(clients)
    init_model_hash = model_hash(model)
    init_public = {
        "scheme": "RTP-FL-reproduction",
        "modelHash": init_model_hash,
        "dim": dim,
        "paillier_n_bits": pkey.public.n.bit_length(),
        "N": clients,
        "k": k,
        "d": d,
        "alpha": d,
        "beta": 1,
        "t": code_state.t,
        "Delta": str(code_state.Delta),
        "GHash": bytes32_hex(code_state.G),
        "RHash": bytes32_hex(code_state.R_delta),
        "independentColumns": code_state.independent_columns,
    }
    for cid in range(1, clients + 1):
        share_msg = {
            **init_public,
            "client": cid,
            "s_i_hash": bytes32_hex(code_state.shares[cid]),
            "R_i_hash": bytes32_hex(code_state.R_block(cid)),
        }
        comm.add(0, "TrustAuthority", f"C{cid}", "KeyShareMsg", share_msg)
        comm.add(0, "Server", f"C{cid}", "InitModel", init_public)

    # Self-check: any k participants can reconstruct the message vector and thus gammaM.
    try:
        recon_msg = code_state.reconstruct_message_from_nodes(list(range(1, k + 1)))
        any_k_ok = all(v.denominator == 1 for v in recon_msg) and int(sum(recon_msg)) == int(pkey.private.lam)
    except Exception:
        any_k_ok = False

    loss0, acc0 = evaluate(model, test_loader, device=device)
    metrics_rows.append({"round": 0, "test_loss": loss0, "test_accuracy": acc0, "effective_clients": 0, "dropout_clients": 0})

    accepted = bool(any_k_ok)
    latest_root = bytes32_hex({"scheme": "baseline_repro_rtpfl", "modelHash": init_model_hash, "N": clients, "k": k, "d": d})
    rounds_done = 0
    exp_t0 = time.perf_counter()

    for r in range(1, int(cfg["federated"]["rounds"]) + 1):
        r_t0 = time.perf_counter()
        active, dropped = active_clients_for_round(cfg, r)
        model_hash_r = model_hash(model)
        encrypted_vectors: List[List[int]] = []
        signature_ok = True
        repair_ok = True
        partial_decrypt_ok = True
        repair_symbol_count = 0
        repaired_share_count = 0
        local_losses: List[float] = []

        for cid in active:
            delta, local_loss, _n_i = train_raw_delta(model, train_loaders[cid], cfg, timer, r, cid, device)
            local_losses.append(local_loss)
            with timer.record(r, "client_decimal_quantize", "fixed-point encode local update", cid=cid):
                x = quantize_decimal(delta, decimal_scale)
            with timer.record(r, "client_paillier_encrypt", "coordinate-wise Paillier encryption", cid=cid):
                c_vec = [paillier.encrypt(pkey.public, int(v)) for v in x.tolist()]
            receipt = {"scheme": "RTP-FL", "r": r, "i": cid, "modelHash": model_hash_r, "cHash": bytes32_hex(c_vec)}
            sig = sign_obj(client_keys[cid].private_key, receipt)
            if not verify_obj(client_keys[cid].public_pem, sig, receipt):
                signature_ok = False
            comm.add(r, f"C{cid}", "Server", "UpMsg", {"Receipt": receipt, "sigUp": sig, "C": [str(v) for v in c_vec]})
            encrypted_vectors.append(c_vec)

        with timer.record(r, "server_paillier_aggregate", "homomorphic ciphertext aggregation"):
            c_agg = _aggregate_cipher_vectors(pkey.public, encrypted_vectors)
        cagg_hash = bytes32_hex(c_agg)
        comm.add(r, "Server", "Clients/Decryptor", "AggMsg", {"scheme": "RTP-FL", "r": r, "CaggHash": cagg_hash, "Cagg": [str(v) for v in c_agg]})

        # RTP-FL repairs each failed private-key segment from any d normal clients.
        share_map: Dict[int, List[int]] = {cid: list(code_state.shares[cid]) for cid in active}
        for missing in dropped:
            if len(active) < d:
                repair_ok = False
                break
            helpers = active[:d]
            with timer.record(r, "rtpfl_repair_dropout_share", f"repair failed segment of C{missing} from d helpers"):
                try:
                    repaired, symbols = code_state.repair_share(int(missing), helpers)
                    expected = code_state.shares[int(missing)]
                    ok = all(int(a) == int(b) for a, b in zip(repaired, expected))
                except Exception:
                    repaired, symbols, ok = [], [], False
            repair_ok = bool(repair_ok and ok)
            repaired_share_count += 1 if ok else 0
            repair_symbol_count += len(symbols)
            if ok:
                share_map[int(missing)] = [int(v) for v in repaired]
            signed_symbols = []
            for sym in symbols:
                helper = int(sym["helper"])
                repair_msg = {"scheme": "RTP-FL", "r": r, "failed": int(missing), "helper": helper, "symbolHash": bytes32_hex(str(sym["symbol"])), "caggHash": cagg_hash}
                sig_repair = sign_obj(client_keys[helper].private_key, repair_msg)
                signed_symbols.append({"repairMsg": repair_msg, "sigRepair": sig_repair})
                if not verify_obj(client_keys[helper].public_pem, sig_repair, repair_msg):
                    signature_ok = False
            comm.add(r, "RepairHelpers", "Clients/Decryptor", "RepairShareMsg", {"failed": int(missing), "symbols": signed_symbols})

        if len(share_map) < clients:
            # Algorithm 1 decryption needs the repaired segments of failed clients.
            partial_decrypt_ok = False

        share_records = []
        for cid in sorted(share_map.keys()):
            signer = cid if cid in active else (active[0] if active else 1)
            share_msg = {"scheme": "RTP-FL", "r": r, "i": cid, "shareHash": bytes32_hex(share_map[cid]), "RHash": bytes32_hex(code_state.R_block(cid)), "isRepaired": cid in dropped, "caggHash": cagg_hash}
            sig = sign_obj(client_keys[signer].private_key, share_msg)
            share_records.append({"ShareMsg": share_msg, "sigShare": sig})
        comm.add(r, "Clients/Repair", "Decryptor", "PartialShareMetaMsg", {"shares": share_records})

        if accepted and signature_ok and repair_ok and partial_decrypt_ok:
            with timer.record(r, "rtpfl_partial_decrypt_combine", f"decrypt aggregate by {decrypt_mode}"):
                try:
                    if decrypt_mode == "fast_equivalent":
                        x_agg = np.array([decrypt_with_private_exponent(pkey.public, pkey.private.lam, c) for c in c_agg], dtype=object)
                    else:
                        x_agg = np.array([rtpfl_partial_decrypt_cipher(pkey.public, code_state, share_map, c) for c in c_agg], dtype=object)
                except Exception:
                    x_agg = np.zeros(dim, dtype=object)
                    partial_decrypt_ok = False
        else:
            x_agg = np.zeros(dim, dtype=object)

        accepted = bool(accepted and signature_ok and repair_ok and partial_decrypt_ok)
        if accepted:
            with timer.record(r, "server_model_update", "apply decrypted aggregate update"):
                # Updates are already averaged by equal-size client partitions only if data are equal.
                # For this baseline we follow the usual encrypted-sum FL prototype and divide by active clients.
                avg_update = np.array([int(v) // max(len(active), 1) for v in x_agg.tolist()], dtype=object)
                apply_integer_update(model, avg_update, scale=decimal_scale, server_lr=float(cfg["federated"].get("server_lr", 1.0)))
        with timer.record(r, "server_evaluate", "test evaluation"):
            test_loss, test_acc = evaluate(model, test_loader, device=device)

        model_hash_next = model_hash(model)
        latest_root = bytes32_hex({
            "prev": latest_root,
            "r": r,
            "modelHashR": model_hash_r,
            "modelHashNext": model_hash_next,
            "caggHash": cagg_hash,
            "repairOk": repair_ok,
            "partialDecryptOk": partial_decrypt_ok,
            "signatureOk": signature_ok,
        })
        rounds_done = r
        metrics_rows.append({"round": r, "test_loss": test_loss, "test_accuracy": test_acc, "effective_clients": len(active), "dropout_clients": len(dropped)})
        crypto_rows.extend([
            {"round": r, "metric": "model_dimension", "value": dim},
            {"round": r, "metric": "N", "value": clients},
            {"round": r, "metric": "k_threshold", "value": k},
            {"round": r, "metric": "d_repair_helpers", "value": d},
            {"round": r, "metric": "alpha", "value": d},
            {"round": r, "metric": "beta", "value": 1},
            {"round": r, "metric": "t_secret_symbols", "value": code_state.t},
            {"round": r, "metric": "paillier_encryptions", "value": len(active) * dim},
            {"round": r, "metric": "paper_partial_decryption_ciphertexts", "value": dim if partial_decrypt_ok else 0},
            {"round": r, "metric": "repair_symbols", "value": repair_symbol_count},
            {"round": r, "metric": "repaired_private_key_segments", "value": repaired_share_count},
            {"round": r, "metric": "ecdsa_signatures", "value": len(active) + repair_symbol_count + len(share_records)},
            {"round": r, "metric": "ecdsa_verifications", "value": len(active) + repair_symbol_count},
        ])
        baseline_rows.append({
            "round": r,
            "scheme": "RTP-FL-reproduction",
            "any_k_reconstruct_init_ok": bool(any_k_ok),
            "signature_ok": bool(signature_ok),
            "repair_ok": bool(repair_ok),
            "partial_decrypt_ok": bool(partial_decrypt_ok),
            "accepted_so_far": bool(accepted),
            "effective_clients": len(active),
            "dropout_clients": len(dropped),
            "repair_symbols": repair_symbol_count,
            "repaired_shares": repaired_share_count,
            "round_wall_seconds": float(time.perf_counter() - r_t0),
        })
        trace["rounds"].append({"round": r, "active": active, "dropped": dropped, "repair_ok": repair_ok, "partial_decrypt_ok": partial_decrypt_ok, "accepted": accepted, "test_accuracy": test_acc, "test_loss": test_loss})
        if not accepted:
            break

    timer.add(0, "experiment_wall", time.perf_counter() - exp_t0, detail="total RTP-FL reproduction wall-clock time")
    write_common_outputs(
        out_dir,
        cfg=cfg,
        scheme_name="baseline_repro_rtpfl",
        accepted=accepted,
        rounds_done=rounds_done,
        latest_root=latest_root,
        metrics_rows=metrics_rows,
        runtime=timer,
        comm=comm,
        crypto_rows=crypto_rows,
        trace=trace,
        blockchain_rows=[{"round": "N/A", "tx_type": "N/A", "gas_used": 0, "latency_sec": 0.0, "note": "RTP-FL has no blockchain audit board"}],
        baseline_rows=baseline_rows,
    )
    return {"accepted": bool(accepted), "rounds": rounds_done, "output_dir": str(out_dir), "latestRoot": latest_root, "N": clients, "k": k, "d": d, "t": code_state.t, "Delta": str(code_state.Delta)}
