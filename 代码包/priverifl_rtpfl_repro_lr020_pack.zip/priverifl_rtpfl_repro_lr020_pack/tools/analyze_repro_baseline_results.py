from __future__ import annotations
import csv, json, sys
from pathlib import Path

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/root/fpa5/outputs')
patterns = ['baseline_repro_priverifl_a_*p2048_lr020', 'baseline_repro_rtpfl_*p2048_lr020']

def read_csv(path: Path):
    if not path.exists(): return []
    with path.open(newline='') as f: return list(csv.DictReader(f))

rows=[]
for pat in patterns:
    for d in sorted(ROOT.glob(pat)):
        metrics=read_csv(d/'metrics_round.csv')
        verify=read_csv(d/'verify_result.csv')
        runtime=read_csv(d/'runtime_cost.csv')
        comm=read_csv(d/'communication_summary_by_type.csv')
        final=metrics[-1] if metrics else {}
        best_acc=max([float(r.get('test_accuracy',0) or 0) for r in metrics], default=0)
        total_wall=sum(float(r.get('seconds',0) or 0) for r in runtime if r.get('stage') in {'experiment_total_wall','start_experiment_total_wall'})
        if total_wall == 0:
            total_wall=sum(float(r.get('seconds',0) or 0) for r in runtime if 'total' in (r.get('stage','')))
        comm_bytes=sum(float(r.get('bytes',0) or 0) for r in comm)
        rows.append({
            'output_dir': str(d),
            'accepted': verify[-1].get('accepted','') if verify else '',
            'rounds': verify[-1].get('rounds','') if verify else (final.get('round','') if final else ''),
            'final_acc': final.get('test_accuracy',''),
            'best_acc': best_acc,
            'final_loss': final.get('test_loss',''),
            'total_wall_s': total_wall,
            'total_comm_mb': comm_bytes/1024/1024 if comm_bytes else '',
        })

w=csv.DictWriter(sys.stdout, fieldnames=['output_dir','accepted','rounds','final_acc','best_acc','final_loss','total_wall_s','total_comm_mb'])
w.writeheader(); w.writerows(rows)
