#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}
python3 scripts/run_repro_baseline.py --config configs/baseline_repro_rtpfl_mnist_iid_2r_p2048_lr020.yaml
python3 scripts/run_repro_baseline.py --config configs/baseline_repro_rtpfl_mnist_noniid_2r_p2048_lr020.yaml
python3 scripts/run_repro_baseline.py --config configs/baseline_repro_rtpfl_mnist_iid_dropout_2r_p2048_lr020.yaml
cd /root
zip -qr rtpfl_p2048_smoke_2r_results.zip \
  fpa5/outputs/baseline_repro_rtpfl_mnist_iid_2r_p2048_lr020 \
  fpa5/outputs/baseline_repro_rtpfl_mnist_noniid_2r_p2048_lr020 \
  fpa5/outputs/baseline_repro_rtpfl_mnist_iid_dropout_2r_p2048_lr020
ls -lh /root/rtpfl_p2048_smoke_2r_results.zip
