#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}
./run_repro_priverifl_a_baselines_lr020.sh
./run_repro_rtpfl_baselines_lr020.sh
cd /root
zip -qr repro_paper_baseline_lr020_all_results.zip \
  repro_priverifl_a_baseline_lr020_results.zip \
  repro_rtpfl_baseline_lr020_results.zip
