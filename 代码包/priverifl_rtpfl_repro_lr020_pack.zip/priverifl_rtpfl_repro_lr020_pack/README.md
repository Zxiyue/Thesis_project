# PriVeriFL-A / RTP-FL reproduction baseline code pack

本包包含两个论文机制复现 baseline：

- `PriVeriFL-A reproduction`
- `RTP-FL reproduction`

它们用于和 VRAC-FL / Ours / Ours-packed 做功能与开销对比。当前包是**本地 reproduction baseline**，不是 KGC/CS/Clients 独立 HTTP 服务版。它适合先跑 smoke test 和 50 轮基线结果；如果后续需要严格端到端 HTTP 公平对比，还需要再做 parallel HTTP 改造。

## 1. 解压

```bash
cd /root/fpa5
unzip -o /root/priverifl_rtpfl_repro_lr020_pack.zip -d /root/fpa5
chmod +x run_priverifl_a_p2048_smoke_2r.sh \
         run_priverifl_a_p2048_50r.sh \
         run_rtpfl_p2048_smoke_2r.sh \
         run_rtpfl_p2048_50r_optional.sh \
         run_all_repro_smoke_2r.sh
```

## 2. 共同配置

默认配置：

```text
MNIST-IID / MNIST-Non-IID
clients = 5
rounds = 2 或 50
local_lr = 0.20
server_lr = 1.0
Paillier bits = 2048
model = tiny_cnn
```

## 3. 推荐运行顺序

先跑 smoke：

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
stdbuf -oL -eL ./run_priverifl_a_p2048_smoke_2r.sh | tee /root/priverifl_a_p2048_smoke_2r.log
stdbuf -oL -eL ./run_rtpfl_p2048_smoke_2r.sh | tee /root/rtpfl_p2048_smoke_2r.log
```

如果 PriVeriFL-A smoke 正常，再跑 50 轮：

```bash
stdbuf -oL -eL ./run_priverifl_a_p2048_50r.sh | tee /root/priverifl_a_p2048_50r.log
```

RTP-FL 2048-bit 可能很慢，建议只在 2 轮 smoke 可接受时再跑 50 轮：

```bash
stdbuf -oL -eL ./run_rtpfl_p2048_50r_optional.sh | tee /root/rtpfl_p2048_50r.log
```

## 4. 结果包

运行后会生成：

```text
/root/priverifl_a_p2048_smoke_2r_results.zip
/root/rtpfl_p2048_smoke_2r_results.zip
/root/priverifl_a_p2048_50r_results.zip
/root/rtpfl_p2048_50r_results.zip
```

## 5. 汇总分析

```bash
cd /root/fpa5
python3 tools/analyze_repro_baseline_results.py /root/fpa5/outputs | tee /root/repro_baseline_summary.csv
```

## 6. 说明

- PriVeriFL-A reproduction 按论文机制实现低敏感位/敏感位拆分、BatchCrypt-style packed Paillier、AES-GCM、homomorphic hash 和签名验证。
- RTP-FL reproduction 按论文机制实现 repairable threshold Paillier 的实验复现，包括 MBR-code private-key segments、dropout repair 和 paper_hadamard 解密恢复。
- 本包不需要 Hardhat，因为这两个 baseline 不是 VRAC-FL 的链上公告板方案。
