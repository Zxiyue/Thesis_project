# local_lr=0.20 剩余实验重跑包

本包用于在已完成以下 2 组探测实验的基础上继续运行：

- `outputs/fashion_mnist_noniid_50r_lr020_nodrop`：Fashion-MNIST-Non-IID，50轮，无掉线
- `outputs/fashion_mnist_noniid_50r_lr020_dropout`：Fashion-MNIST-Non-IID，50轮，有掉线，R10 掉 C2，R25 掉 C4

其中 `fashion_mnist_noniid_50r_lr020_dropout` 可复用为 Ours-basic 的 Fashion-MNIST-Non-IID 主实验结果，因此本包只运行剩余 5 组 Ours-basic 和 4 组论文复现 baseline。

## 实验列表

### Ours-basic remaining 5

- MNIST-IID 50r, local_lr=0.20
- MNIST-Non-IID 50r, local_lr=0.20
- Fashion-MNIST-IID 50r, local_lr=0.20
- CIFAR-10-IID 50r, local_lr=0.20
- CIFAR-10-Non-IID 50r, local_lr=0.20

统一设置：`server_lr=1.0`, `rounds=50`, `dropout={10:[2],25:[4]}`。

### Paper baselines 4

- PriVeriFL-A reproduction MNIST-IID 50r, local_lr=0.20
- PriVeriFL-A reproduction MNIST-Non-IID 50r, local_lr=0.20
- RTP-FL reproduction MNIST-IID 50r, local_lr=0.20
- RTP-FL reproduction MNIST-IID-dropout 50r, local_lr=0.20

## 使用

```bash
cd /root/fpa5
unzip -o /root/fpa_lr020_remaining_rerun_pack.zip -d /root/fpa5
chmod +x check_lr020_remaining_configs.sh check_reused_fashion_noniid_lr020.sh run_ours_basic_lr020_remaining5.sh run_repro_priverifl_a_baselines_lr020.sh run_repro_rtpfl_baselines_lr020.sh run_repro_paper_baselines_lr020.sh run_all_lr020_remaining9.sh

source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./check_lr020_remaining_configs.sh
./check_reused_fashion_noniid_lr020.sh
```

Ours-basic 需要 Hardhat：

```bash
curl -s -X POST http://127.0.0.1:8545 \
  -H "Content-Type: application/json" \
  --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}'
```

如未返回 result，启动：

```bash
tmux kill-session -t hardhat 2>/dev/null || true
tmux new -d -s hardhat "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && npx hardhat node > /root/hardhat.log 2>&1"
sleep 5
tail -n 20 /root/hardhat.log
```

推荐分两批运行：

```bash
# 第一批：剩余 5 组 Ours-basic
tmux new -s ours020_remain
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_ours_basic_lr020_remaining5.sh
```

完成后下载：

- `/root/ours_basic_lr020_remaining5_results.zip`
- 如果复用结果存在，还会生成 `/root/ours_basic_lr020_6x50_with_reused_fmnist_noniid_results.zip`

第二批：

```bash
# 论文复现 baseline 4 组
tmux new -s repro020
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_repro_paper_baselines_lr020.sh
```

完成后下载：

- `/root/repro_paper_baseline_lr020_all_results.zip`

不建议一次性跑 `run_all_lr020_remaining9.sh`，除非确认服务器资源充足且希望无人值守。
