from __future__ import annotations

import argparse
from pathlib import Path

from fl_audit.baselines.common import load_yaml
from fl_audit.baselines.priverifl_a_repro import run_priverifl_a_repro
from fl_audit.baselines.rtpfl_repro import run_rtpfl_repro


def main() -> None:
    ap = argparse.ArgumentParser(description="Run paper-faithful reproduced baselines: PriVeriFL-A or RTP-FL")
    ap.add_argument("--config", required=True)
    args = ap.parse_args()
    cfg = load_yaml(args.config)
    scheme = str(((cfg.get("baseline", {}) or {}).get("scheme", ""))).lower()
    if scheme in {"priverifl_a_repro", "priverifl-a-repro", "priverifl_a", "priverifl-a"}:
        res = run_priverifl_a_repro(cfg)
    elif scheme in {"rtpfl_repro", "rtpfl-repro", "rtpfl", "rtp-fl"}:
        res = run_rtpfl_repro(cfg)
    else:
        raise SystemExit(f"Unsupported baseline.scheme={scheme!r}; use priverifl_a_repro or rtpfl_repro")
    print(res)


if __name__ == "__main__":
    main()
