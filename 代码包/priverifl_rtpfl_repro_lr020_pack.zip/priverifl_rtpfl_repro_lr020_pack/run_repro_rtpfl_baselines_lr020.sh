#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}
python3 scripts/run_repro_baseline.py --config configs/baseline_repro_rtpfl_mnist_iid_50r_lr020.yaml
python3 scripts/run_repro_baseline.py --config configs/baseline_repro_rtpfl_mnist_iid_dropout_50r_lr020.yaml
cd /root
zip -qr repro_rtpfl_baseline_lr020_results.zip \
  fpa5/outputs/baseline_repro_rtpfl_mnist_iid_50r_lr020 \
  fpa5/outputs/baseline_repro_rtpfl_mnist_iid_dropout_50r_lr020
