#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}
./run_priverifl_a_p2048_smoke_2r.sh
./run_rtpfl_p2048_smoke_2r.sh
cd /root
zip -qr priverifl_a_rtpfl_p2048_smoke_2r_all_results.zip \
  priverifl_a_p2048_smoke_2r_results.zip \
  rtpfl_p2048_smoke_2r_results.zip
ls -lh /root/priverifl_a_rtpfl_p2048_smoke_2r_all_results.zip
