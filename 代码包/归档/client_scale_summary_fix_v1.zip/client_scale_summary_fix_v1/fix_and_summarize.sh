#!/usr/bin/env bash
set -euo pipefail
PACK_DIR="${PACK_DIR:-/root/client_scale_pack_v2_chain_on}"
FPA_DIR="${FPA_DIR:-/root/fpa5}"
BASE_OUT="${BASE_OUT:-outputs/client_scale_mnist_iid_p512_s40_10r_chain}"
ZIP_OUT="${ZIP_OUT:-/root/client_scale_mnist_iid_p512_s40_10r_chain_results.zip}"
SCRIPT="$PACK_DIR/scripts/summarize_client_scale_results.py"

if [ ! -f "$SCRIPT" ]; then
  echo "[ERR] not found: $SCRIPT" >&2
  exit 1
fi
cp -f "$SCRIPT" "$SCRIPT.bak.$(date +%Y%m%d_%H%M%S)"
python - <<'PY'
from pathlib import Path
p = Path('/root/client_scale_pack_v2_chain_on/scripts/summarize_client_scale_results.py')
s = p.read_text(encoding='utf-8')
old = "ctmp=comm.groupby('type')['bytes'].sum().to_dict()"
new = """type_col = None\n            for cand in ['type', 'payload_type', 'message_type', 'msg_type']:\n                if cand in comm.columns:\n                    type_col = cand\n                    break\n            bytes_col = None\n            for cand in ['bytes', 'size_bytes', 'total_bytes', 'actual_bytes']:\n                if cand in comm.columns:\n                    bytes_col = cand\n                    break\n            if type_col and bytes_col:\n                comm[bytes_col] = pd.to_numeric(comm[bytes_col], errors='coerce').fillna(0)\n                ctmp = comm.groupby(type_col)[bytes_col].sum().to_dict()\n            else:\n                ctmp = {}"""
if old not in s:
    print('[WARN] target line not found; script may already be patched')
else:
    s = s.replace(old, new)
    p.write_text(s, encoding='utf-8')
    print('[OK] patched summarizer:', p)
PY
python "$SCRIPT" --base-dir "$FPA_DIR/$BASE_OUT" --zip-out "$ZIP_OUT"
echo "[OK] result zip: $ZIP_OUT"
