# client_scale_summary_fix_v1

修复 `summarize_client_scale_results.py` 中把 `communication_cost.csv` 的消息类型列写死为 `type` 的问题。
当前实验输出的通信表列名通常是 `payload_type`，所以原脚本会在汇总阶段报 `KeyError: 'type'`。

使用方法：

```bash
cd /root
unzip -o client_scale_summary_fix_v1.zip
bash /root/client_scale_summary_fix_v1/fix_and_summarize.sh
```

默认会读取：

```text
/root/fpa5/outputs/client_scale_mnist_iid_p512_s40_10r_chain
```

并生成：

```text
/root/client_scale_mnist_iid_p512_s40_10r_chain_results.zip
```
