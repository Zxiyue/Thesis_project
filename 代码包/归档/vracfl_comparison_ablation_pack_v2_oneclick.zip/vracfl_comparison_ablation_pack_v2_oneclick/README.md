# VRAC-FL Comparison and Ablation Pack v2 — One Click

本包运行 8 组对比/消融实验，并自动执行共享完整方案对照：

1. E1 FedAvg：IID/Non-IID，50轮；
2. E2 Privacy-only：IID/Non-IID，2048-bit、50轮；
3. E3 只链上模型 Hash：512-bit、20轮；
4. E4 无 Pedersen 向量承诺：512-bit、20轮；
5. E5 无 KGC 独立掉线集合：512-bit、20轮；
6. E6 无 FaultTx：512-bit、20轮；
7. E7 无掉线单位元补偿优化：512-bit、20轮；
8. E8 无 ModelSync 签名：512-bit、20轮；
9. CONTROL：完整 VRAC-FL，512-bit、20轮配对对照。

## v2 的主要变化

- 只需要启动一次；
- 自动安装/刷新代码；
- 自动检测并启动 Hardhat 节点；
- 自动顺序运行 50 轮主性能基线和 20 轮消融；
- 自动生成汇总 CSV、JSON、Markdown；
- 自动压缩全部结果；
- 中断或失败时也会自动压缩当前已有的部分结果；
- 默认支持断点续跑，已有 `summary.json` 和 `chain_result.json` 的实验会跳过；
- `FORCE_RERUN=1` 可强制重跑。

## 一条命令运行全部实验

```bash
cd /root
unzip -o vracfl_comparison_ablation_pack_v2_oneclick.zip
cd vracfl_comparison_ablation_pack_v2_oneclick
bash run_once.sh
```

推荐在一个 tmux 会话中执行，但不再需要分别启动 Hardhat、主性能实验、消融实验和打包脚本：

```bash
tmux new -s vrac_ablation "cd /root/vracfl_comparison_ablation_pack_v2_oneclick && bash run_once.sh 2>&1 | tee /root/vracfl_comparison_ablation_v2.log"
```

完成后会打印：

- `output_root=...`
- `result_zip=/root/vracfl_comparison_ablation_v2_results_<时间戳>.zip`

## 常用控制参数

```bash
# 首次运行时允许下载 MNIST
DOWNLOAD=1 bash run_once.sh

# 不运行 Non-IID 主基线
RUN_NONIID=0 bash run_once.sh

# 强制覆盖重跑所有实验
FORCE_RERUN=1 bash run_once.sh

# 仅做无链调试
SKIP_CHAIN=1 bash run_once.sh
```

状态查看：

```bash
cd /root/fpa5/ablation_pack_v2_oneclick
bash scripts/check_status.sh
```
