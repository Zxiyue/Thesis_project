#!/usr/bin/env bash
# Complete one-start workflow. The caller only needs to execute this script once.
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3

RUN_ID="${RUN_ID:-$(date +%Y%m%d_%H%M%S)}"
OUT_ROOT="${OUT_ROOT:-$FPA5_ROOT/outputs/comparison_ablation_v2_${RUN_ID}}"
ZIP_OUT="${ZIP_OUT:-/root/vracfl_comparison_ablation_v2_results_${RUN_ID}.zip}"
LOG_DIR="$OUT_ROOT/logs"
mkdir -p "$LOG_DIR"
printf '%s\n' "$OUT_ROOT" > "$ROOT/.last_output_root"
printf '%s\n' "$ZIP_OUT" > "$ROOT/.last_result_zip"

START_EPOCH="$(date +%s)"
CHAIN_PID=""
CHAIN_STARTED_BY_RUNNER=0
FINALIZED=0

rpc_up() {
  curl -sS --max-time 2 \
    -H 'Content-Type: application/json' \
    --data '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}' \
    http://127.0.0.1:8545 2>/dev/null | grep -q '"result"'
}

stop_owned_chain() {
  if [[ "$CHAIN_STARTED_BY_RUNNER" == "1" && -n "$CHAIN_PID" ]]; then
    echo "[INFO] stopping Hardhat node started by this run (pid=$CHAIN_PID)"
    kill -TERM -- "-$CHAIN_PID" 2>/dev/null || kill -TERM "$CHAIN_PID" 2>/dev/null || true
    sleep 2
    kill -KILL -- "-$CHAIN_PID" 2>/dev/null || kill -KILL "$CHAIN_PID" 2>/dev/null || true
  fi
}

write_manifest() {
  local exit_code="$1"
  local end_epoch
  end_epoch="$(date +%s)"
  "$PY" - "$OUT_ROOT/run_manifest.json" "$RUN_ID" "$START_EPOCH" "$end_epoch" "$exit_code" "$ZIP_OUT" <<'PY'
import json, os, platform, socket, sys, time
path, run_id, start, end, code, zip_out = sys.argv[1:]
data = {
    "run_id": run_id,
    "status": "completed" if int(code) == 0 else "failed_or_interrupted",
    "exit_code": int(code),
    "start_epoch": int(start),
    "end_epoch": int(end),
    "elapsed_s": int(end) - int(start),
    "hostname": socket.gethostname(),
    "platform": platform.platform(),
    "result_zip": zip_out,
    "configuration": {
        "main_rounds": int(os.environ.get("MAIN_ROUNDS", "50")),
        "ablation_rounds": int(os.environ.get("ABLATION_ROUNDS", "20")),
        "ablation_paillier_bits": 512,
        "privacy_only_paillier_bits": 2048,
        "run_noniid": os.environ.get("RUN_NONIID", "1"),
        "skip_chain": os.environ.get("SKIP_CHAIN", "0"),
        "force_rerun": os.environ.get("FORCE_RERUN", "0"),
    },
}
with open(path, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
PY
}

finalize() {
  local exit_code=$?
  if [[ "$FINALIZED" == "1" ]]; then
    exit "$exit_code"
  fi
  FINALIZED=1
  set +e
  write_manifest "$exit_code"
  echo "[INFO] summarizing and packaging all available results..."
  OUT_ROOT="$OUT_ROOT" ZIP_OUT="$ZIP_OUT" bash "$ROOT/scripts/collect_results.sh" \
    > >(tee "$LOG_DIR/collect_results.log") 2>&1
  local pack_code=$?
  stop_owned_chain
  echo ""
  echo "============================================================"
  if [[ "$exit_code" == "0" && "$pack_code" == "0" ]]; then
    echo "[DONE] all requested experiments completed and packaged"
  else
    echo "[WARN] workflow did not finish cleanly; partial results were still packaged"
    echo "workflow_exit_code=$exit_code packaging_exit_code=$pack_code"
  fi
  echo "output_root=$OUT_ROOT"
  echo "result_zip=$ZIP_OUT"
  echo "main_log=$LOG_DIR/main_performance_50r.log"
  echo "ablation_log=$LOG_DIR/ablation_20r.log"
  echo "hardhat_log=$LOG_DIR/hardhat_node.log"
  echo "============================================================"
  exit "$exit_code"
}
trap finalize EXIT INT TERM

export OUT_ROOT
export MAIN_ROUNDS="${MAIN_ROUNDS:-50}"
export ABLATION_ROUNDS="${ABLATION_ROUNDS:-20}"
export RUN_NONIID="${RUN_NONIID:-1}"
export FORCE_RERUN="${FORCE_RERUN:-0}"
export RESUME="${RESUME:-1}"

cat <<INFO
============================================================
VRAC-FL one-click comparison and ablation workflow
run_id=$RUN_ID
output_root=$OUT_ROOT
result_zip=$ZIP_OUT
main_rounds=$MAIN_ROUNDS
ablation_rounds=$ABLATION_ROUNDS
RUN_NONIID=$RUN_NONIID
RESUME=$RESUME FORCE_RERUN=$FORCE_RERUN
============================================================
INFO

# Hardhat is started automatically only when no existing RPC is available.
if [[ "${SKIP_CHAIN:-0}" != "1" ]]; then
  if [[ ! -f "$ROOT/.hardhat_dir" ]]; then
    echo "[ERROR] .hardhat_dir is not configured. Re-run install.sh or set SKIP_CHAIN=1." >&2
    exit 2
  fi
  HH_DIR="$(cat "$ROOT/.hardhat_dir")"
  if rpc_up; then
    echo "[INFO] reusing existing Hardhat RPC at 127.0.0.1:8545"
  else
    echo "[INFO] starting Hardhat node automatically from $HH_DIR"
    setsid bash -lc "cd \"$HH_DIR\" && exec npx hardhat node" \
      > "$LOG_DIR/hardhat_node.log" 2>&1 &
    CHAIN_PID=$!
    CHAIN_STARTED_BY_RUNNER=1
    for _ in $(seq 1 120); do
      if rpc_up; then break; fi
      if ! kill -0 "$CHAIN_PID" 2>/dev/null; then
        echo "[ERROR] Hardhat node exited before RPC became ready" >&2
        tail -100 "$LOG_DIR/hardhat_node.log" >&2 || true
        exit 3
      fi
      sleep 1
    done
    if ! rpc_up; then
      echo "[ERROR] Hardhat RPC did not become ready within 120 seconds" >&2
      tail -100 "$LOG_DIR/hardhat_node.log" >&2 || true
      exit 4
    fi
    echo "[INFO] Hardhat RPC is ready"
  fi
fi

bash "$ROOT/scripts/preflight.sh" 2>&1 | tee "$LOG_DIR/preflight.log"

# Main baselines (FedAvg and Privacy-only) are run sequentially in this same start.
ROUNDS="$MAIN_ROUNDS" bash "$ROOT/scripts/run_main_performance_50r.sh" \
  2>&1 | tee "$LOG_DIR/main_performance_50r.log"

# All 20-round ablations and the shared full-control run follow automatically.
ROUNDS="$ABLATION_ROUNDS" bash "$ROOT/scripts/run_ablation_20r.sh" \
  2>&1 | tee "$LOG_DIR/ablation_20r.log"

# The EXIT trap performs summary generation and ZIP packaging automatically.
