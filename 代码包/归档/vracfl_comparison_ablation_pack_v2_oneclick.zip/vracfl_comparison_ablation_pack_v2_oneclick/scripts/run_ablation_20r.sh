#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3
OUT_ROOT="${OUT_ROOT:-$FPA5_ROOT/outputs/comparison_ablation_v2}"
ROUNDS="${ROUNDS:-${ABLATION_ROUNDS:-20}}"
TRACE_DIR="${TRACE_DIR:-$OUT_ROOT/shared_mnist_iid_${ROUNDS}r_trace}"
DATA_ROOT="${DATA_ROOT:-$FPA5_ROOT/data}"
SEED="${SEED:-20260714}"
MAX_SAMPLES="${MAX_SAMPLES_PER_CLIENT:-0}"
DIM_LIMIT="${DIMENSION_LIMIT:-0}"
RESUME="${RESUME:-1}"
FORCE_RERUN="${FORCE_RERUN:-0}"
DOWNLOAD_FLAG=()
[[ "${DOWNLOAD:-0}" == "1" ]] && DOWNLOAD_FLAG=(--download)

mkdir -p "$OUT_ROOT"
if [[ ! -f "$TRACE_DIR/update_trace.npz" || "${REBUILD_TRACE:-0}" == "1" || "$FORCE_RERUN" == "1" ]]; then
  "$PY" "$ROOT/src/build_update_trace.py" \
    --output-dir "$TRACE_DIR" --dataset mnist --split iid --data-root "$DATA_ROOT" \
    --rounds "$ROUNDS" --clients 5 --lr 0.20 --seed "$SEED" \
    --max-samples-per-client "$MAX_SAMPLES" "${DOWNLOAD_FLAG[@]}"
else
  echo "[SKIP] reusing shared update trace: $TRACE_DIR/update_trace.npz"
fi

VARIANTS=(
  full_control
  hash_only
  no_pedersen
  no_kgc_independent_set
  no_faulttx
  no_unit_comp_opt
  no_modelsync_signature
)
if [[ -n "${ONLY_VARIANTS:-}" ]]; then
  IFS=',' read -r -a VARIANTS <<< "$ONLY_VARIANTS"
fi

for variant in "${VARIANTS[@]}"; do
  echo "================ $variant ================"
  vout="$OUT_ROOT/${ROUNDS}r_${variant}_p512"
  if [[ "$FORCE_RERUN" != "1" && "$RESUME" == "1" && -s "$vout/summary.json" ]]; then
    echo "[SKIP] completed protocol result found: $vout"
  else
    "$PY" "$ROOT/src/run_ablation_20r.py" \
      --variant "$variant" --trace "$TRACE_DIR/update_trace.npz" \
      --output-dir "$vout" --rounds "$ROUNDS" --clients 5 --threshold 3 \
      --paillier-bits 512 --key-cache "$FPA5_ROOT/cache/threshold_paillier_p512.json" \
      --seed "$SEED" --encrypt-workers "${ENCRYPT_WORKERS:-5}" --dimension-limit "$DIM_LIMIT"
  fi

  if [[ "${SKIP_CHAIN:-0}" != "1" && -f "$ROOT/.hardhat_dir" ]]; then
    if [[ "$FORCE_RERUN" != "1" && "$RESUME" == "1" && -s "$vout/chain/chain_result.json" ]]; then
      echo "[SKIP] completed chain replay found: $vout/chain/chain_result.json"
    else
      HH_DIR="$(cat "$ROOT/.hardhat_dir")"
      "$PY" "$ROOT/src/ablation_chain_bridge.py" \
        --plan "$vout/chain_plan.json" --output-dir "$vout/chain" --hardhat-dir "$HH_DIR"
    fi
  else
    echo "[INFO] skip chain replay for $variant"
  fi
done

"$PY" "$ROOT/src/summarize_ablation_results.py" --root "$OUT_ROOT"
echo "[DONE] ${ROUNDS}-round ablation outputs: $OUT_ROOT"
