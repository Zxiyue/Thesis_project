#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PY="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"
[[ -x "$PY" ]] || PY=python3
OUT_ROOT="${OUT_ROOT:-$FPA5_ROOT/outputs/comparison_ablation_v2}"
DATA_ROOT="${DATA_ROOT:-$FPA5_ROOT/data}"
ROUNDS="${ROUNDS:-${MAIN_ROUNDS:-50}}"
SEED="${SEED:-20260714}"
MAX_SAMPLES="${MAX_SAMPLES_PER_CLIENT:-0}"
DOWNLOAD_FLAG=()
[[ "${DOWNLOAD:-0}" == "1" ]] && DOWNLOAD_FLAG=(--download)
RUN_NONIID="${RUN_NONIID:-1}"
RUN_FEDAVG="${RUN_FEDAVG:-1}"
RUN_PRIVACY="${RUN_PRIVACY:-1}"
RESUME="${RESUME:-1}"
FORCE_RERUN="${FORCE_RERUN:-0}"

mkdir -p "$OUT_ROOT"
should_skip() {
  local out="$1"
  [[ "$FORCE_RERUN" != "1" && "$RESUME" == "1" && -s "$out/summary.json" ]]
}
run_fedavg() {
  local split="$1" out="$OUT_ROOT/E1_fedavg_${split}_${ROUNDS}r"
  if should_skip "$out"; then
    echo "[SKIP] completed FedAvg result found: $out"
    return
  fi
  "$PY" "$ROOT/src/run_fedavg_baseline.py" \
    --output-dir "$out" --dataset mnist --split "$split" --data-root "$DATA_ROOT" \
    --rounds "$ROUNDS" --clients 5 --lr 0.20 --seed "$SEED" \
    --max-samples-per-client "$MAX_SAMPLES" "${DOWNLOAD_FLAG[@]}"
}
run_privacy() {
  local split="$1" out="$OUT_ROOT/E2_privacy_only_${split}_${ROUNDS}r_p2048"
  if should_skip "$out"; then
    echo "[SKIP] completed Privacy-only result found: $out"
    return
  fi
  "$PY" "$ROOT/src/run_privacy_only_baseline.py" \
    --output-dir "$out" --dataset mnist --split "$split" --data-root "$DATA_ROOT" \
    --rounds "$ROUNDS" --clients 5 --threshold 3 --paillier-bits 2048 \
    --key-cache "$FPA5_ROOT/cache/threshold_paillier_p2048.json" \
    --lr 0.20 --seed "$SEED" --max-samples-per-client "$MAX_SAMPLES" \
    --encrypt-workers "${ENCRYPT_WORKERS:-5}" "${DOWNLOAD_FLAG[@]}"
}
run_split() {
  local split="$1"
  [[ "$RUN_FEDAVG" == "1" ]] && run_fedavg "$split"
  [[ "$RUN_PRIVACY" == "1" ]] && run_privacy "$split"
}

run_split iid
[[ "$RUN_NONIID" == "1" ]] && run_split noniid

echo "[DONE] main performance outputs: $OUT_ROOT"
