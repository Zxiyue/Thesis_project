from pathlib import Path
ROOT = Path('/root/fpa5')
entities = (ROOT / 'fl_audit/protocol/entities.py').read_text(encoding='utf-8')
cs = (ROOT / 'scripts/run_cs_server.py').read_text(encoding='utf-8')
checks = [
    ('entities has timer parameter', 'timer=None' in entities[entities.find('def recover_lambda_and_decrypt'):entities.find('def recover_lambda_and_decrypt')+400]),
    ('cs_decrypt_combine', 'cs_decrypt_combine' in entities),
    ('cs_unpack_vector', 'cs_unpack_vector' in entities),
    ('run_cs_server passes timer', 'timer=self.timer' in cs[cs.find('recover_lambda_and_decrypt'):cs.find('recover_lambda_and_decrypt')+1000]),
    ('cs_decode_aggregate', 'cs_decode_aggregate' in cs),
    ('cs_model_update', 'cs_model_update' in cs),
]
ok = True
for name, passed in checks:
    print(f'{name:32s}: {"OK" if passed else "FAIL"}')
    ok = ok and passed
print('CS_TIMING_PATCH_READY =', ok)
