from __future__ import annotations
import argparse
import csv
from pathlib import Path
from statistics import mean, median

STAGES = ['cs_decrypt_combine', 'cs_unpack_vector', 'cs_decode_aggregate', 'cs_model_update']

def read_rows(path: Path):
    with path.open(newline='', encoding='utf-8') as f:
        yield from csv.DictReader(f)

def fmt(x: float) -> str:
    return f'{x:.6f}'

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('output_dir', help='e.g., outputs/ours_packed_mnist_noniid_50r_p2048_s34_final')
    args = ap.parse_args()
    out = Path(args.output_dir)
    runtime = out / 'runtime_cost.csv'
    if not runtime.exists():
        raise SystemExit(f'{runtime} not found')
    data = {s: [] for s in STAGES}
    by_round = {}
    for row in read_rows(runtime):
        stage = row.get('stage','')
        if stage in data:
            sec = float(row.get('seconds', 0) or 0)
            r = int(float(row.get('round', 0) or 0))
            data[stage].append(sec)
            by_round.setdefault(r, {})[stage] = sec
    print('stage,total_seconds,mean_seconds,median_seconds,min_seconds,max_seconds,count')
    for s in STAGES:
        vals = data[s]
        if vals:
            print(','.join([s, fmt(sum(vals)), fmt(mean(vals)), fmt(median(vals)), fmt(min(vals)), fmt(max(vals)), str(len(vals))]))
        else:
            print(','.join([s, 'NA','NA','NA','NA','NA','0']))
    if by_round:
        out_csv = out / 'cs_timing_by_round.csv'
        with out_csv.open('w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=['round'] + STAGES)
            w.writeheader()
            for r in sorted(by_round):
                w.writerow({'round': r, **{s: by_round[r].get(s, '') for s in STAGES}})
        print(f'wrote {out_csv}')

if __name__ == '__main__':
    main()
