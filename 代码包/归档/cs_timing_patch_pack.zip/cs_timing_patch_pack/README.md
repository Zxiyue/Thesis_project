# CS timing patch

This patch adds four server-side timing fields to `runtime_cost.csv` for later experiments:

- `cs_decrypt_combine`: verify decryption shares, reconstruct the threshold secret, and decrypt aggregate Paillier ciphertexts.
- `cs_unpack_vector`: unpack packed plaintexts into the aggregate vector, or convert coordinate-wise plaintexts in non-packed mode.
- `cs_decode_aggregate`: fixed-point dequantization and tensor conversion.
- `cs_model_update`: apply aggregate update, set the model vector, and compute the next model hash.

## Apply

```bash
cd /root
unzip -o cs_timing_patch_pack.zip

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

python3 /root/cs_timing_patch_pack/patch/apply_cs_timing_patch.py
python3 /root/cs_timing_patch_pack/scripts/check_cs_timing_patch.py
```

Backups use suffix `.before_cs_timing`.

## After an experiment

```bash
python3 /root/cs_timing_patch_pack/scripts/summarize_cs_timing.py \
  outputs/ours_packed_mnist_noniid_50r_p2048_s34_final \
  | tee /root/cs_timing_summary.csv
```

The script also writes `cs_timing_by_round.csv` into the output directory.
