from __future__ import annotations

import re
import shutil
from pathlib import Path

ROOT = Path('/root/fpa5')


def backup(path: Path) -> None:
    bak = path.with_suffix(path.suffix + '.before_cs_timing')
    if path.exists() and not bak.exists():
        shutil.copy2(path, bak)


def patch_entities() -> None:
    path = ROOT / 'fl_audit/protocol/entities.py'
    if not path.exists():
        raise SystemExit(f'{path} not found')
    backup(path)
    s = path.read_text(encoding='utf-8')

    # If already patched, keep idempotent.
    if 'cs_decrypt_combine' in s and 'cs_unpack_vector' in s and 'timer=None' in s[s.find('def recover_lambda_and_decrypt'):s.find('def recover_lambda_and_decrypt')+500]:
        print('[SKIP] entities.py already has CS decrypt/unpack timing')
        return

    # Replace the whole ServerCS.recover_lambda_and_decrypt method. This version is compatible
    # with both packed and non-packed Paillier aggregation, and adds optional TimerRecorder hooks.
    new_func = '''    def recover_lambda_and_decrypt(self, share_msgs: List[Dict[str, Any]], client_pubkeys: Dict[int, str], field_prime: int, threshold: int, paillier_keypair, cagg: List[int], r: int, alpha: str, cfg: Dict[str, Any] | None = None, dim: int | None = None, timer=None):
        t0 = time.perf_counter()
        shares = []
        for sm in share_msgs:
            msg = sm["ShareMsg"]
            cid = int(msg["j"])
            if verify_obj(client_pubkeys[cid], sm["sigShare"], msg):
                shares.append((cid, int(msg["share"])))
            if len(shares) >= threshold:
                break
        if len(shares) < threshold:
            raise RuntimeError("not enough valid shares")
        lam = reconstruct(shares, field_prime)
        # The CS only needs the public key and threshold-recovered lambda.
        # If a full keypair is passed by the legacy single-process runner, keep
        # compatibility. In distributed mode, mu is recomputed from public data
        # and recovered lambda, so KGC does not disclose the Paillier private key.
        pub = getattr(paillier_keypair, "public", paillier_keypair)
        if hasattr(paillier_keypair, "private"):
            mu = paillier_keypair.private.mu
        else:
            mu = pow(paillier.L(pow(pub.g, lam, pub.n2), pub.n), -1, pub.n)
        priv = paillier.PaillierPrivateKey(lam=lam, mu=mu)
        plain = [paillier.decrypt(pub, priv, int(c)) for c in cagg]
        if timer is not None:
            timer.add(
                r,
                "cs_decrypt_combine",
                time.perf_counter() - t0,
                detail="verify decryption shares, reconstruct threshold secret, and decrypt aggregate Paillier ciphertexts",
                cid="CS",
            )

        t1 = time.perf_counter()
        cfg = cfg or {}
        packing_cfg = cfg.get("crypto", {}).get("packing", {}) or {}
        if bool(packing_cfg.get("enabled", False)):
            if dim is None:
                raise ValueError("dim is required when Paillier packing is enabled")
            slot_bits = int(packing_cfg.get("slot_bits", 40))
            q = int(cfg.get("encoding", {}).get("q", 1000000007))
            slots = cipher_packing.slots_per_cipher(pub, slot_bits)
            xagg = cipher_packing.unpack_vector_mod_q(plain, int(dim), q, slot_bits, slots)
            unpack_detail = f"unpack {len(plain)} packed plaintexts into {int(dim)} aggregate coordinates"
        else:
            xagg = np.array(plain, dtype=np.int64)
            unpack_detail = f"convert {len(plain)} plaintext coordinates into aggregate vector"
        if timer is not None:
            timer.add(
                r,
                "cs_unpack_vector",
                time.perf_counter() - t1,
                detail=unpack_detail,
                cid="CS",
            )
        return xagg, shares
'''

    pattern = (r'    def recover_lambda_and_decrypt\(self, share_msgs: List\[Dict\[str, Any\]\], client_pubkeys: Dict\[int, str\], field_prime: int, threshold: int, paillier_keypair, cagg: List\[int\], r: int, alpha: str(?:, cfg: Dict\[str, Any\] \| None = None, dim: int \| None = None)?\):\n'
               r'.*?        return xagg, shares\n')
    s2, n = re.subn(pattern, new_func, s, flags=re.S)
    if n != 1:
        raise RuntimeError(f'failed to patch recover_lambda_and_decrypt in {path}; replacements={n}')
    path.write_text(s2, encoding='utf-8')
    print('[OK] patched entities.py: cs_decrypt_combine + cs_unpack_vector')


def patch_run_cs_server() -> None:
    path = ROOT / 'scripts/run_cs_server.py'
    if not path.exists():
        raise SystemExit(f'{path} not found')
    backup(path)
    s = path.read_text(encoding='utf-8')

    if 'timer=self.timer' not in s[s.find('recover_lambda_and_decrypt'):s.find('recover_lambda_and_decrypt')+1000]:
        # Insert timer argument after dim=... in the recover call.
        old = '''                cfg=self.cfg,
                dim=int(get_vector(self.model).numel()),
            )
'''
        new = '''                cfg=self.cfg,
                dim=int(get_vector(self.model).numel()),
                timer=self.timer,
            )
'''
        if old in s:
            s = s.replace(old, new, 1)
        else:
            # Legacy fallback: the call may still lack cfg/dim.
            old2 = '''                cagg,
                r,
                alpha,
            )
'''
            new2 = '''                cagg,
                r,
                alpha,
                cfg=self.cfg,
                dim=int(get_vector(self.model).numel()),
                timer=self.timer,
            )
'''
            if old2 not in s:
                raise RuntimeError('failed to locate recover_lambda_and_decrypt call in run_cs_server.py')
            s = s.replace(old2, new2, 1)

    if 'cs_decode_aggregate' not in s or 'cs_model_update' not in s:
        old_update = '''            update = torch.tensor(dequantize(xagg, int(self.cfg["encoding"]["scale"])), dtype=torch.float64)
            W_next_vec = W_r_vec + float(self.cfg["federated"].get("server_lr", 1.0)) * update
            set_vector(self.model, W_next_vec)
            model_hash_next = model_hash(self.model)
'''
        new_update = '''            t_decode = time.perf_counter()
            update = torch.tensor(dequantize(xagg, int(self.cfg["encoding"]["scale"])), dtype=torch.float64)
            self.timer.add(
                r,
                "cs_decode_aggregate",
                time.perf_counter() - t_decode,
                detail="fixed-point dequantization of aggregate update and tensor conversion",
                cid="CS",
            )

            t_update = time.perf_counter()
            W_next_vec = W_r_vec + float(self.cfg["federated"].get("server_lr", 1.0)) * update
            set_vector(self.model, W_next_vec)
            model_hash_next = model_hash(self.model)
            self.timer.add(
                r,
                "cs_model_update",
                time.perf_counter() - t_update,
                detail="apply aggregate update, set model vector, and compute next model hash",
                cid="CS",
            )
'''
        if old_update not in s:
            raise RuntimeError('failed to locate decode/model update block in run_cs_server.py')
        s = s.replace(old_update, new_update, 1)

    path.write_text(s, encoding='utf-8')
    print('[OK] patched run_cs_server.py: pass timer + cs_decode_aggregate + cs_model_update')


def main() -> None:
    if not ROOT.exists():
        raise SystemExit('/root/fpa5 does not exist')
    patch_entities()
    patch_run_cs_server()
    print('[OK] CS timing patch applied. Backups use suffix .before_cs_timing')


if __name__ == '__main__':
    main()
