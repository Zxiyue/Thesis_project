#!/usr/bin/env bash
set -euo pipefail

FPA_DIR="${FPA_DIR:-/root/fpa5}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG_BASE="${CONFIG_BASE:-configs/client_scale_multiprocess_mnist_iid_p512_s40_10r_chain.yaml}"
DEVICE="${DEVICE:-cpu}"
ROUNDS="${ROUNDS:-10}"
CLIENT_LIST="${CLIENT_LIST:-5 20 50 100}"
THRESHOLD_RATIO="${THRESHOLD_RATIO:-0.6}"
PAILLIER_BITS="${PAILLIER_BITS:-512}"
SLOT_BITS="${SLOT_BITS:-40}"
MAX_CLIENT_WORKERS="${MAX_CLIENT_WORKERS:-10}"
CLIENT_MODE="${CLIENT_MODE:-individual}"
CLIENTS_PER_WORKER="${CLIENTS_PER_WORKER:-20}"
BLOCKCHAIN="${BLOCKCHAIN:-on}"
BASE_OUT="${BASE_OUT:-outputs/client_scale_multiprocess_mnist_iid_p512_s${SLOT_BITS}_${ROUNDS}r_chain}"
ZIP_OUT="${ZIP_OUT:-/root/client_scale_multiprocess_mnist_iid_p512_s${SLOT_BITS}_${ROUNDS}r_chain_results.zip}"
HARDHAT_LOG="${HARDHAT_LOG:-/root/client_scale_multiprocess_hardhat.log}"

bash "$PACK_DIR/scripts/install_client_scale_multiprocess_pack.sh"
cd "$FPA_DIR"
export PYTHONPATH="$FPA_DIR:${PYTHONPATH:-}"

if [[ -d .venv ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

# Keep each Python process from spawning BLAS/OpenMP thread pools.
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
export NUMEXPR_NUM_THREADS="${NUMEXPR_NUM_THREADS:-1}"
export TORCH_NUM_THREADS="${TORCH_NUM_THREADS:-1}"

# Matgo public dataset helper: avoid slow public Internet downloads.
if [[ ! -d /mnt/fpa5/data/MNIST && -d /root/fpa5/data/MNIST ]]; then
  echo "[INFO] Copy MNIST from /root/fpa5/data to /mnt/fpa5/data"
  mkdir -p /mnt/fpa5/data
  cp -a /root/fpa5/data/MNIST /mnt/fpa5/data/
fi
if [[ ! -d /mnt/fpa5/data/MNIST && -d /public/torchvision_datasets/MNIST ]]; then
  echo "[INFO] Copy MNIST from /public/torchvision_datasets to /mnt/fpa5/data"
  mkdir -p /mnt/fpa5/data
  cp -a /public/torchvision_datasets/MNIST /mnt/fpa5/data/
fi
if [[ ! -d /mnt/fpa5/data/MNIST ]]; then
  echo "[ERROR] MNIST not found at /mnt/fpa5/data/MNIST"
  echo "Please copy first: mkdir -p /mnt/fpa5/data && cp -a /public/torchvision_datasets/MNIST /mnt/fpa5/data/"
  exit 1
fi

rpc_ready() {
  python3 - <<'PY_RPC' >/dev/null 2>&1
import json, urllib.request
req = urllib.request.Request(
    'http://127.0.0.1:8545',
    data=json.dumps({'jsonrpc':'2.0','method':'web3_clientVersion','params':[],'id':1}).encode(),
    headers={'Content-Type':'application/json'},
)
try:
    with urllib.request.urlopen(req, timeout=2) as r:
        raise SystemExit(0 if r.status == 200 else 1)
except Exception:
    raise SystemExit(1)
PY_RPC
}

ensure_blockchain() {
  if [[ "$BLOCKCHAIN" != "on" && "$BLOCKCHAIN" != "true" && "$BLOCKCHAIN" != "1" ]]; then
    echo "[INFO] BLOCKCHAIN=$BLOCKCHAIN, running without actual chain submission."
    return 0
  fi
  echo "[INFO] Blockchain enabled. Checking Hardhat RPC http://127.0.0.1:8545 ..."
  if ! rpc_ready; then
    echo "[INFO] Starting Hardhat node in background. Log: $HARDHAT_LOG"
    nohup npx hardhat node --hostname 127.0.0.1 > "$HARDHAT_LOG" 2>&1 &
    echo $! > /root/client_scale_multiprocess_hardhat.pid
    for _ in $(seq 1 80); do
      if rpc_ready; then
        break
      fi
      sleep 1
    done
  fi
  if ! rpc_ready; then
    echo "[ERROR] Hardhat RPC is not ready. Check $HARDHAT_LOG"
    exit 1
  fi
  echo "[INFO] Hardhat RPC is ready."
}

calc_threshold() {
  local n="$1"
  python3 - <<PY_CALC
import math
n=int("$n")
ratio=float("$THRESHOLD_RATIO")
print(max(1, math.ceil(n*ratio)))
PY_CALC
}

client_key() {
  local n="$1"
  printf "c%03d" "$n"
}

make_runtime_config() {
  local n="$1"
  local threshold="$2"
  local key="$3"
  local dst="$4"
  python3 - "$CONFIG_BASE" "$dst" "$BASE_OUT/$key" "$n" "$threshold" "$ROUNDS" "$PAILLIER_BITS" "$SLOT_BITS" "$MAX_CLIENT_WORKERS" "$CLIENT_MODE" "$CLIENTS_PER_WORKER" "$BLOCKCHAIN" <<'PY_CFG'
import sys, yaml
src, dst, out_dir, n, threshold, rounds, pbits, sbits, workers, mode, clients_per_worker, chain = sys.argv[1:]
with open(src, 'r', encoding='utf-8') as f:
    cfg = yaml.safe_load(f)
cfg['output_dir'] = out_dir
cfg.setdefault('federated', {})['clients'] = int(n)
cfg['federated']['threshold'] = int(threshold)
cfg['federated']['rounds'] = int(rounds)
cfg['federated']['dropout'] = {}
cfg.setdefault('crypto', {})['paillier_bits'] = int(pbits)
cfg['crypto'].setdefault('packing', {})['enabled'] = True
cfg['crypto']['packing']['slot_bits'] = int(sbits)
cfg.setdefault('runtime', {})['device'] = 'cpu'
cfg['runtime']['max_client_workers'] = int(workers)
cfg.setdefault('distributed', {})['client_mode'] = str(mode)
cfg['distributed']['clients_per_worker'] = int(clients_per_worker)
cfg.setdefault('blockchain', {})['enabled'] = chain.lower() in {'on','true','1','yes'}
cfg['blockchain'].setdefault('rpc_url', 'http://127.0.0.1:8545')
cfg['blockchain'].setdefault('contract_json', 'outputs/contract.json')
with open(dst, 'w', encoding='utf-8') as f:
    yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=False)
print(f"[INFO] runtime config written to {dst}; clients={n}; threshold={threshold}; mode={mode}; blockchain={cfg['blockchain']['enabled']}")
PY_CFG
}

ensure_blockchain
mkdir -p "$BASE_OUT"

cat > "$BASE_OUT/run_plan.txt" <<EOF2
CLIENT_LIST=$CLIENT_LIST
ROUNDS=$ROUNDS
THRESHOLD_RATIO=$THRESHOLD_RATIO
PAILLIER_BITS=$PAILLIER_BITS
SLOT_BITS=$SLOT_BITS
MAX_CLIENT_WORKERS=$MAX_CLIENT_WORKERS
CLIENT_MODE=$CLIENT_MODE
CLIENTS_PER_WORKER=$CLIENTS_PER_WORKER
BLOCKCHAIN=$BLOCKCHAIN
BASE_OUT=$BASE_OUT
ZIP_OUT=$ZIP_OUT
HARDHAT_LOG=$HARDHAT_LOG
EOF2

for n in ${CLIENT_LIST}; do
  key="$(client_key "$n")"
  threshold="$(calc_threshold "$n")"
  out_dir="$BASE_OUT/$key"
  run_cfg="$BASE_OUT/${key}_runtime.yaml"
  echo
  echo "================ RUN multiprocess clients=${n}, threshold=${threshold}, rounds=${ROUNDS}, mode=${CLIENT_MODE}, chain=${BLOCKCHAIN} (${key}) ================"

  # Stop stale entities from a previous interrupted run using the same config, if present.
  if [[ -f "$run_cfg" ]]; then
    python scripts/stop_all_entities.py --config "$run_cfg" || true
    sleep 2
  fi
  rm -rf "$out_dir"
  mkdir -p "$out_dir"
  make_runtime_config "$n" "$threshold" "$key" "$run_cfg"

  if [[ "$BLOCKCHAIN" == "on" || "$BLOCKCHAIN" == "true" || "$BLOCKCHAIN" == "1" ]]; then
    echo "[INFO] Deploying fresh AuditBoard for clients=${n} ..."
    npx hardhat run scripts/deploy.js --network localhost
  fi

  echo "[INFO] Starting KGC/CS/Client HTTP entities ..."
  python scripts/start_all_entities.py --config "$run_cfg" --clients "$n" 2>&1 | tee "$out_dir/start_all_entities.log"

  set +e
  python scripts/start_experiment.py --config "$run_cfg" 2>&1 | tee "$out_dir/start_experiment.log"
  status=${PIPESTATUS[0]}
  set -e

  echo "[INFO] Collecting results for clients=${n} ..."
  python scripts/collect_results.py --config "$run_cfg" 2>&1 | tee "$out_dir/collect_results.log" || true

  echo "[INFO] Stopping KGC/CS/Client entities ..."
  python scripts/stop_all_entities.py --config "$run_cfg" || true
  sleep 3

  if [[ "$status" -ne 0 ]]; then
    echo "[ERROR] clients=${n} failed with status=${status}. See $out_dir/start_experiment.log"
    exit "$status"
  fi
done

python "$PACK_DIR/scripts/summarize_client_scale_multiprocess_results.py" --base-dir "$FPA_DIR/$BASE_OUT" --zip-out "$ZIP_OUT"

echo
echo "[DONE] Results package: $ZIP_OUT"
