#!/usr/bin/env bash
set -euo pipefail

FPA_DIR="${FPA_DIR:-/root/fpa5}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ ! -d "$FPA_DIR" ]]; then
  echo "[ERROR] FPA_DIR does not exist: $FPA_DIR"
  exit 1
fi

mkdir -p "$FPA_DIR/fl_audit/crypto" "$FPA_DIR/configs" "$FPA_DIR/contracts" "$FPA_DIR/scripts"
cp -f "$PACK_DIR/patch/packing.py" "$FPA_DIR/fl_audit/crypto/packing.py"
cp -f "$PACK_DIR/fpa5_patch/configs/client_scale_multiprocess_mnist_iid_p512_s40_10r_chain.yaml" "$FPA_DIR/configs/"
cp -f "$PACK_DIR/fpa5_patch/contracts/AuditBoard.sol" "$FPA_DIR/contracts/AuditBoard.sol"
cp -f "$PACK_DIR/fpa5_patch/hardhat.config.js" "$FPA_DIR/hardhat.config.js"
cp -f "$PACK_DIR/fpa5_patch/scripts/deploy.js" "$FPA_DIR/scripts/deploy.js"

# Apply Ours-packed support. The older patch script is not fully idempotent;
# if it reports that the target is already patched, verify the required markers and continue.
if ! python3 "$PACK_DIR/patch/apply_ours_packed_patch.py"; then
  echo "[WARN] apply_ours_packed_patch.py returned non-zero. Checking whether Ours-packed markers already exist ..."
  python3 - <<'PY_CHECK'
from pathlib import Path
root = Path('/root/fpa5')
entities = root / 'fl_audit/protocol/entities.py'
cs = root / 'scripts/run_cs_server.py'
kgc = root / 'scripts/run_kgc_server.py'
text = entities.read_text(encoding='utf-8')
needles = [
    'from fl_audit.crypto import packing as cipher_packing',
    'client_paillier_pack',
    'packing_enabled',
    'def make_compensation(self, r: int, D: List[int], paillier_pub, ped_params, cfg:',
    'def recover_lambda_and_decrypt(self, share_msgs:',
]
missing = [x for x in needles if x not in text]
cs_text = cs.read_text(encoding='utf-8') if cs.exists() else ''
kgc_text = kgc.read_text(encoding='utf-8') if kgc.exists() else ''
if 'cfg=self.cfg' not in cs_text:
    missing.append('run_cs_server recover cfg=self.cfg')
if 'make_compensation(r, D_r, self.pkey.public, self.ped_params, cfg=self.cfg)' not in kgc_text:
    missing.append('run_kgc_server make_compensation cfg=self.cfg')
if missing:
    raise SystemExit('[ERROR] Ours-packed patch markers missing: ' + ', '.join(missing))
print('[OK] Ours-packed patch markers already present.')
PY_CHECK
fi

echo "[OK] client_scale_multiprocess_check_pack installed into $FPA_DIR"
