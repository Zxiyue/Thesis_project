#!/usr/bin/env bash
set -euo pipefail

FPA_DIR="${FPA_DIR:-/root/fpa5}"
SLOT_BITS="${SLOT_BITS:-40}"
ROUNDS="${ROUNDS:-10}"
BASE_OUT="${BASE_OUT:-outputs/client_scale_multiprocess_mnist_iid_p512_s${SLOT_BITS}_${ROUNDS}r_chain}"
BASE="$FPA_DIR/$BASE_OUT"
LOG="${LOG:-/root/client_scale_multiprocess_suite_v1.log}"

echo "==== client scale multiprocess status ===="
echo "base: $BASE"
echo

if [[ -f "$LOG" ]]; then
  echo "---- recent suite log ----"
  tail -n 40 "$LOG" || true
  echo
fi

if [[ -d "$BASE" ]]; then
  echo "---- run directories ----"
  find "$BASE" -maxdepth 1 -type d -name 'c*' -printf '%f\n' | sort | while read -r d; do
    out="$BASE/$d"
    acc="NA"; rounds="NA"; final_acc="NA"; gas="NA"
    if [[ -f "$out/verify_result.csv" ]]; then
      acc=$(python3 - "$out/verify_result.csv" <<'PY'
import pandas as pd, sys
p=sys.argv[1]
df=pd.read_csv(p)
print(str(df.iloc[-1].get('accepted','NA')) if len(df) else 'NA')
PY
)
      rounds=$(python3 - "$out/verify_result.csv" <<'PY'
import pandas as pd, sys
p=sys.argv[1]
df=pd.read_csv(p)
print(str(df.iloc[-1].get('rounds','NA')) if len(df) else 'NA')
PY
)
    fi
    if [[ -f "$out/metrics_round.csv" ]]; then
      final_acc=$(python3 - "$out/metrics_round.csv" <<'PY'
import pandas as pd, sys
p=sys.argv[1]
df=pd.read_csv(p)
print(f"{float(df.sort_values('round').iloc[-1].get('test_accuracy',0))*100:.2f}%" if len(df) else 'NA')
PY
)
    fi
    if [[ -f "$out/blockchain_cost.csv" ]]; then
      gas=$(python3 - "$out/blockchain_cost.csv" <<'PY'
import pandas as pd, sys
p=sys.argv[1]
df=pd.read_csv(p)
if 'tx_type' in df.columns and 'gas_used' in df.columns:
    final=df[df['tx_type'].astype(str)=='FinalTx']
    print(f"{pd.to_numeric(final['gas_used'], errors='coerce').mean():.1f}" if len(final) else 'NA')
else:
    print('NA')
PY
)
    fi
    printf "%s  accepted=%s  rounds=%s  final_acc=%s  mean_FinalTx_gas=%s\n" "$d" "$acc" "$rounds" "$final_acc" "$gas"
  done
  echo
  if [[ -f "$BASE/client_scale_multiprocess_summary.csv" ]]; then
    echo "---- summary ----"
    column -s, -t "$BASE/client_scale_multiprocess_summary.csv" | sed -n '1,30p' || cat "$BASE/client_scale_multiprocess_summary.csv"
  fi
else
  echo "No base output directory yet."
fi

echo

echo "---- active processes ----"
ps -eo pid,ppid,pcpu,pmem,etime,cmd | grep -E 'run_(kgc|cs|client|client_worker)_server|start_experiment|hardhat' | grep -v grep || true
