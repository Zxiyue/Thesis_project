from __future__ import annotations
import argparse

# Conservative estimates for 512-bit Ours-packed multiprocess HTTP runs on CPU servers.
# Values are intentionally ranges because CPU/GIL/process scheduling and disk IO vary.
BASE_MIN_PER_ROUND = {
    5: 2.0,
    20: 7.0,
    50: 15.0,
    100: 30.0,
}
BASE_MAX_PER_ROUND = {
    5: 3.5,
    20: 10.0,
    50: 22.0,
    100: 43.0,
}

def interp(n: int, table: dict[int, float]) -> float:
    xs = sorted(table)
    if n in table:
        return table[n]
    if n < xs[0]:
        return table[xs[0]] * n / xs[0]
    for a, b in zip(xs, xs[1:]):
        if a <= n <= b:
            ya, yb = table[a], table[b]
            return ya + (yb - ya) * (n - a) / (b - a)
    return table[xs[-1]] * n / xs[-1]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--clients', default='5 20 50 100')
    ap.add_argument('--rounds', type=int, default=10)
    args = ap.parse_args()
    clients = [int(x) for x in args.clients.replace(',', ' ').split()]
    total_min = total_max = 0.0
    print('clients,rounds,estimate_min_minutes,estimate_max_minutes')
    for n in clients:
        mn = interp(n, BASE_MIN_PER_ROUND) * args.rounds
        mx = interp(n, BASE_MAX_PER_ROUND) * args.rounds
        total_min += mn
        total_max += mx
        print(f'{n},{args.rounds},{mn:.1f},{mx:.1f}')
    print(f'TOTAL,{args.rounds},{total_min:.1f},{total_max:.1f}')
    print(f'TOTAL_HOURS,,{total_min/60:.2f},{total_max/60:.2f}')

if __name__ == '__main__':
    main()
