from __future__ import annotations

import argparse
import json
import zipfile
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd


def read_csv(path: Path) -> pd.DataFrame:
    if path.exists() and path.stat().st_size > 0:
        try:
            return pd.read_csv(path)
        except Exception:
            return pd.DataFrame()
    return pd.DataFrame()


def fnum(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == "":
            return default
        return float(v)
    except Exception:
        return default


def inum(v: Any, default: int = 0) -> int:
    try:
        if v is None or v == "":
            return default
        return int(float(v))
    except Exception:
        return default


def summarize_one(run_dir: Path) -> Dict[str, Any]:
    key = run_dir.name
    clients = int(key[1:]) if key.startswith("c") else None
    verify = read_csv(run_dir / "verify_result.csv")
    metrics = read_csv(run_dir / "metrics_round.csv")
    runtime = read_csv(run_dir / "runtime_cost.csv")
    comm = read_csv(run_dir / "communication_cost.csv")
    comm_type = read_csv(run_dir / "communication_summary_by_type.csv")
    crypto = read_csv(run_dir / "crypto_cost.csv")
    chain = read_csv(run_dir / "blockchain_cost.csv")

    row: Dict[str, Any] = {"client_key": key, "clients": clients}
    if not verify.empty:
        row["accepted"] = bool(verify.iloc[-1].get("accepted", False))
        row["verified_rounds"] = inum(verify.iloc[-1].get("rounds", 0))
        row["latestAuditRoot"] = verify.iloc[-1].get("latestAuditRoot", "")
    else:
        row["accepted"] = False
        row["verified_rounds"] = 0
        row["latestAuditRoot"] = ""

    if not metrics.empty:
        row["completed_rounds"] = int(metrics["round"].max()) if "round" in metrics.columns else len(metrics) - 1
        final = metrics.sort_values("round").iloc[-1] if "round" in metrics.columns else metrics.iloc[-1]
        row["final_acc"] = fnum(final.get("test_accuracy", 0))
        row["best_acc"] = fnum(metrics.get("test_accuracy", pd.Series([0])).max()) if "test_accuracy" in metrics.columns else 0.0
        row["avg_effective_clients"] = fnum(metrics.get("effective_clients", pd.Series([0])).mean()) if "effective_clients" in metrics.columns else 0.0
    else:
        row["completed_rounds"] = 0
        row["final_acc"] = 0.0
        row["best_acc"] = 0.0
        row["avg_effective_clients"] = 0.0

    if not runtime.empty and "phase" in runtime.columns:
        phase_col = "phase"
        dur_col = "seconds" if "seconds" in runtime.columns else ("duration_sec" if "duration_sec" in runtime.columns else None)
        if dur_col:
            row["total_runtime_seconds_sum"] = fnum(runtime[dur_col].sum())
            for phase in [
                "start_experiment_total_wall",
                "client_paillier_encrypt",
                "client_paillier_pack",
                "client_pedersen_commit",
                "client_local_train",
                "cs_recover_decrypt",
                "cs_update_model",
                "blockchain_init_tx",
            ]:
                row[f"runtime_{phase}_sec"] = fnum(runtime.loc[runtime[phase_col] == phase, dur_col].sum())
        else:
            row["total_runtime_seconds_sum"] = 0.0
    else:
        row["total_runtime_seconds_sum"] = 0.0

    if not comm.empty:
        bytes_col = "bytes" if "bytes" in comm.columns else None
        row["total_comm_MB"] = fnum(comm[bytes_col].sum()) / 1024 / 1024 if bytes_col else 0.0
        row["message_count"] = len(comm)
        if "actual_seconds" in comm.columns:
            row["total_comm_actual_seconds"] = fnum(comm["actual_seconds"].sum())
    else:
        row["total_comm_MB"] = 0.0
        row["message_count"] = 0

    if not comm_type.empty and "payload_type" in comm_type.columns:
        for ptype in ["TrainUploadReq", "UpMsg", "MaskMsg", "AggMsg", "ShareMsg", "ModelBroadcast", "FinalConfirm"]:
            sub = comm_type[comm_type["payload_type"].astype(str) == ptype]
            if not sub.empty:
                row[f"comm_{ptype}_MB"] = fnum(sub.iloc[0].get("total_MB", 0))
                row[f"comm_{ptype}_count"] = inum(sub.iloc[0].get("count", 0))

    if not crypto.empty and "metric" in crypto.columns:
        for metric in ["model_dimension", "effective_clients", "paillier_encryptions", "paillier_ciphertexts_aggregated", "pedersen_commitments"]:
            sub = crypto[crypto["metric"].astype(str) == metric]
            if not sub.empty:
                row[f"crypto_{metric}_sum"] = fnum(sub.get("value", pd.Series([0])).sum())
                row[f"crypto_{metric}_mean"] = fnum(sub.get("value", pd.Series([0])).mean())

    if not chain.empty:
        row["chain_tx_count"] = len(chain)
        if "gas_used" in chain.columns:
            gas = pd.to_numeric(chain["gas_used"], errors="coerce")
            row["chain_total_gas"] = fnum(gas.sum())
            init = chain[chain.get("tx_type", pd.Series(dtype=str)).astype(str) == "InitTx"]
            final = chain[chain.get("tx_type", pd.Series(dtype=str)).astype(str) == "FinalTx"]
            row["init_gas"] = fnum(pd.to_numeric(init["gas_used"], errors="coerce").mean()) if not init.empty else 0.0
            row["finaltx_gas_mean"] = fnum(pd.to_numeric(final["gas_used"], errors="coerce").mean()) if not final.empty else 0.0
            row["finaltx_gas_min"] = fnum(pd.to_numeric(final["gas_used"], errors="coerce").min()) if not final.empty else 0.0
            row["finaltx_gas_max"] = fnum(pd.to_numeric(final["gas_used"], errors="coerce").max()) if not final.empty else 0.0
        if "latency_sec" in chain.columns:
            final = chain[chain.get("tx_type", pd.Series(dtype=str)).astype(str) == "FinalTx"]
            row["finaltx_latency_mean_sec"] = fnum(pd.to_numeric(final.get("latency_sec", pd.Series(dtype=float)), errors="coerce").mean()) if not final.empty else 0.0
    else:
        row["chain_tx_count"] = 0
        row["chain_total_gas"] = 0.0
        row["finaltx_gas_mean"] = 0.0

    trace_path = run_dir / "run_trace.json"
    if trace_path.exists():
        try:
            trace = json.loads(trace_path.read_text(encoding="utf-8"))
            row["distributed"] = trace.get("runtime", {}).get("distributed", "")
            row["client_mode"] = trace.get("runtime", {}).get("client_mode", "")
        except Exception:
            pass
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-dir", required=True)
    ap.add_argument("--zip-out", required=True)
    args = ap.parse_args()
    base = Path(args.base_dir)
    runs = sorted([p for p in base.iterdir() if p.is_dir() and p.name.startswith("c")]) if base.exists() else []
    rows = [summarize_one(p) for p in runs]
    summary = pd.DataFrame(rows).sort_values("clients") if rows else pd.DataFrame()
    summary_path = base / "client_scale_multiprocess_summary.csv"
    summary.to_csv(summary_path, index=False)

    gas_cols = [c for c in ["clients", "chain_tx_count", "init_gas", "finaltx_gas_mean", "finaltx_gas_min", "finaltx_gas_max", "finaltx_latency_mean_sec", "accepted"] if c in summary.columns]
    gas_path = base / "gas_by_client_count.csv"
    if gas_cols:
        summary[gas_cols].to_csv(gas_path, index=False)
    else:
        pd.DataFrame().to_csv(gas_path, index=False)

    comm_cols = [c for c in ["clients", "total_comm_MB", "message_count", "comm_UpMsg_MB", "comm_MaskMsg_MB", "comm_AggMsg_MB", "comm_ShareMsg_MB", "accepted"] if c in summary.columns]
    if comm_cols:
        summary[comm_cols].to_csv(base / "communication_by_client_count.csv", index=False)

    zip_path = Path(args.zip_out)
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in base.rglob("*"):
            if path.is_file():
                zf.write(path, path.relative_to(base.parent))
    print(f"[OK] wrote {summary_path}")
    print(f"[OK] wrote {gas_path}")
    print(f"[OK] wrote {zip_path}")


if __name__ == "__main__":
    main()
