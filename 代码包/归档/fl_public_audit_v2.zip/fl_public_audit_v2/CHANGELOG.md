# Changelog

## V2

- Fixed `FinalTx.payload()` `ComAgg` type inconsistency.
  - KGC signs `ComAgg` as a decimal string.
  - `FinalTx.__post_init__()` now normalizes `ComAgg` to `str`.
  - `FinalTx.payload()` always returns `"ComAgg": str(...)`.
  - Third-party verifier now receives canonical JSON bytes identical to the bytes signed by KGC, so ECDSA verification succeeds.
- Removed a duplicated `com_agg = pedersen.mul(...)` line in `ServerCS.aggregate()`.
- Added `tests/test_finaltx_payload.py` to validate signature/payload consistency.
