# local_lr=0.24 50轮稳定性探测实验

新增两组配置：

1. `configs/fashion_mnist_noniid_50r_lr024_nodrop.yaml`
   - Fashion-MNIST Non-IID
   - 5 clients
   - 50 rounds
   - local_lr=0.24
   - server_lr=1.0
   - dropout={}

2. `configs/fashion_mnist_noniid_50r_lr024_dropout.yaml`
   - Fashion-MNIST Non-IID
   - 5 clients
   - 50 rounds
   - local_lr=0.24
   - server_lr=1.0
   - dropout: round 10 client 2, round 25 client 4

## 使用

```bash
cd /root/fpa5
unzip -o /root/fpa_lr024_probe_pack.zip -d /root/fpa5
chmod +x run_lr024_probe.sh
```

检查数据集：

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
python3 scripts/check_dataset_loader.py --configs \
  configs/fashion_mnist_noniid_50r_lr024_nodrop.yaml \
  configs/fashion_mnist_noniid_50r_lr024_dropout.yaml
```

运行：

```bash
tmux new -s lr024probe
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_lr024_probe.sh
```

查看进度：

```bash
cd /root/fpa5
for d in outputs/fashion_mnist_noniid_50r_lr024_nodrop outputs/fashion_mnist_noniid_50r_lr024_dropout; do
  echo "================ $d ================"
  tail -n 5 "$d/metrics_round.csv" 2>/dev/null || true
  cat "$d/verify_result.csv" 2>/dev/null || true
done
```

完成后下载：

```text
/root/fashion_mnist_noniid_lr024_probe_results.zip
```
