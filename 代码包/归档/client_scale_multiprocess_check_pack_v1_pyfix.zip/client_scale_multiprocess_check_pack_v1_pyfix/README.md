# client_scale_multiprocess_check_pack_v1

本代码包用于补充运行 **客户端规模扩展性多进程/HTTP验证实验**。它不是替代当前正在跑的单机受控趋势实验，而是用更接近主实验实现方式的多实体运行模式，对代表性客户端规模进行补充验证。

## 默认实验配置

| 项目 | 默认值 |
|---|---:|
| 方案 | Ours-packed |
| 数据集 | MNIST-IID |
| 客户端数 | 5、20、50、100 |
| 轮次 | 10 |
| 门限 | `ceil(0.6 × n)` |
| Paillier | 512-bit |
| packing | enabled |
| slot_bits | 40 |
| 掉线 | 无掉线 |
| 区块链 | 开启 Hardhat 本地链 |
| 运行模式 | `individual`，即 CS + KGC + 每个客户端独立 HTTP 进程 |
| 上链内容 | 每个规模独立部署 AuditBoard，提交 InitTx + 10 个 FinalTx |

## 实验定位

该实验主要验证：

1. 多进程/HTTP 模式下，5、20、50、100 个客户端均可完成完整训练、聚合、KGC 最终声明、链上 FinalTx 写入和公开验证。
2. 与单机受控规模实验相比，通信量、accepted 状态和 FinalTx gas 趋势保持一致。
3. 链上开销由固定格式 InitTx / FinalTx 摘要声明决定，不应随客户端数量线性增长。

## 快速运行

```bash
cd /root
unzip -o client_scale_multiprocess_check_pack_v1.zip
cd /root/client_scale_multiprocess_check_pack_v1

stdbuf -oL -eL bash scripts/run_client_scale_multiprocess_suite.sh \
  | tee /root/client_scale_multiprocess_suite_v1.log
```

## 查看进度

```bash
bash /root/client_scale_multiprocess_check_pack_v1/scripts/check_client_scale_multiprocess_status.sh
```

## 预计时长

默认 5、20、50、100 客户端、10轮、512-bit、开链版，预计总时长约 **9–13 小时**。如果 100 客户端阶段进程调度较慢，可能接近 **14–16 小时**。

```bash
python3 /root/client_scale_multiprocess_check_pack_v1/scripts/estimate_client_scale_multiprocess_runtime.py
```

## 输出结果包

默认输出：

```text
/root/client_scale_multiprocess_mnist_iid_p512_s40_10r_chain_results.zip
```

主要汇总文件：

```text
/root/fpa5/outputs/client_scale_multiprocess_mnist_iid_p512_s40_10r_chain/client_scale_multiprocess_summary.csv
/root/fpa5/outputs/client_scale_multiprocess_mnist_iid_p512_s40_10r_chain/gas_by_client_count.csv
/root/fpa5/outputs/client_scale_multiprocess_mnist_iid_p512_s40_10r_chain/communication_by_client_count.csv
```

每个客户端规模单独目录：

```text
c005/
c020/
c050/
c100/
```

每个目录包含 `metrics_round.csv`、`runtime_cost.csv`、`communication_cost.csv`、`blockchain_cost.csv`、`verify_result.csv`、`run_trace.json` 和实体日志。

## 可调参数

```bash
CLIENT_LIST="5 20 50 100"
ROUNDS=10
PAILLIER_BITS=512
SLOT_BITS=40
CLIENT_MODE=individual
BLOCKCHAIN=on
THRESHOLD_RATIO=0.6
```

资源不足时可切换为 worker pool，但论文中要说明运行模式：

```bash
CLIENT_MODE=worker_pool CLIENTS_PER_WORKER=20 bash scripts/run_client_scale_multiprocess_suite.sh
```

## 注意

- 默认 `individual` 模式在 100 客户端时会启动 100 个客户端进程，加上 CS、KGC 和 Hardhat，进程数较多。建议使用 `tmux`。
- 该实验仍采用 512-bit Paillier，定位为功能性规模验证，不用于证明密码安全参数强度；2048-bit 开销已由主性能实验支撑。
- 数据集默认读取 `/mnt/fpa5/data/MNIST`，脚本会自动尝试从 `/public/torchvision_datasets/MNIST` 或 `/root/fpa5/data/MNIST` 复制。
