"""Fixed-point quantization and signed integer encoding helpers."""
from __future__ import annotations
from typing import List


def encode_update(update: List[float], scale: int) -> List[int]:
    return [int(round(x * scale)) for x in update]


def decode_update(encoded: List[int], scale: int) -> List[float]:
    return [x / scale for x in encoded]


def model_delta_to_encoded(w_prev: List[float], w_next: List[float], eta: float, scale: int) -> List[int]:
    return [int(round(((b - a) / eta) * scale)) for a, b in zip(w_prev, w_next)]
