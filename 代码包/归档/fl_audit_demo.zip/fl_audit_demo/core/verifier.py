"""Third-party verifier for the audit chain."""
from __future__ import annotations
from blockchain.audit_board import AuditBoard
from crypto.toy_signature import PublicKey, verify
from crypto.utils import H_hex


class PublicVerifier:
    def __init__(self, kgc_pk: PublicKey):
        self.kgc_pk = kgc_pk

    def verify_board(self, board: AuditBoard) -> tuple[bool, str]:
        if board.init_tx is None:
            return False, "missing InitTx"
        init = board.init_tx
        digest = H_hex(init.sysParaHash, init.Uroot, init.modelHash0, init.auditRoot0)
        if not verify(self.kgc_pk, digest, init.sigInit):
            return False, "invalid InitTx signature"
        prev_root = init.auditRoot0
        prev_model_hash = init.modelHash0
        prev_round = 0
        for tx in board.final_txs:
            if tx.r != prev_round + 1:
                return False, f"round discontinuity at {tx.r}"
            if tx.modelHashR != prev_model_hash:
                return False, f"model hash discontinuity at {tx.r}"
            expected_root = H_hex(prev_root, tx.r, tx.alpha, tx.rootUp, tx.ComAgg, tx.modelHashR, tx.modelHashNext)
            if tx.auditRoot != expected_root:
                return False, f"bad audit root at {tx.r}"
            digest = H_hex(tx.r, tx.alpha, tx.rootUp, tx.ComAgg, tx.modelHashR, tx.modelHashNext, tx.auditRoot)
            if not verify(self.kgc_pk, digest, tx.sigFinal):
                return False, f"invalid FinalTx signature at {tx.r}"
            prev_root = tx.auditRoot
            prev_model_hash = tx.modelHashNext
            prev_round = tx.r
        return True, "audit chain accepted"
