"""Cloud server role in the flow-auditable FL demo."""
from __future__ import annotations
from typing import Dict, List, Tuple

from crypto import paillier, pedersen
from crypto.toy_signature import ToySigner, verify, PublicKey
from crypto.utils import H_hex, merkle_root
from core.encoding import decode_update
from core.messages import UploadMessage, DropMessage, AggMessage, ModelMessage
from core.kgc import model_hash


class Server:
    def __init__(self, dim: int, signer: ToySigner, client_pks: Dict[str, PublicKey], kgc_pk: PublicKey, eta: float, scale: int):
        self.dim = dim
        self.signer = signer
        self.client_pks = client_pks
        self.kgc_pk = kgc_pk
        self.eta = eta
        self.scale = scale
        self.valid_uploads: Dict[int, Dict[str, UploadMessage]] = {}
        self.last_Cagg: Dict[int, List[int]] = {}
        self.last_ComAgg: Dict[int, int] = {}

    def verify_uploads(self, r: int, uploads: List[UploadMessage]) -> Tuple[Dict[str, UploadMessage], str]:
        good: Dict[str, UploadMessage] = {}
        for up in uploads:
            pk = self.client_pks.get(up.client_id)
            if pk is None:
                continue
            if up.cHash != H_hex(up.ciphertext):
                continue
            if not verify(pk, H_hex(up.receipt), up.sigUp):
                continue
            good[up.client_id] = up
        root_up = merkle_root([H_hex(good[cid].receipt) for cid in sorted(good)])
        self.valid_uploads[r] = good
        return good, root_up

    def aggregate(self, r: int, alpha: str, root_up: str, drop: DropMessage, paillier_pk: paillier.PaillierPublicKey, pp_com: pedersen.PedersenParams) -> AggMessage:
        if not verify(self.kgc_pk, H_hex(drop.r, drop.alpha, drop.D, drop.cDropHash, drop.ComDrop), drop.sigDrop):
            raise ValueError("invalid KGC drop signature")
        uploads = self.valid_uploads[r]
        Craw = paillier.add_ciphertext_vectors(paillier_pk, [u.ciphertext for u in uploads.values()])
        Cagg = [(a * b) % paillier_pk.n2 for a, b in zip(Craw, drop.Cdrop)]
        ComRaw = pedersen.mul(pp_com, [u.commitment for u in uploads.values()])
        ComAgg = (ComRaw * drop.ComDrop) % pp_com.modulus
        digest = H_hex(r, alpha, root_up, H_hex(Cagg), ComAgg)
        sig = self.signer.sign(digest)
        self.last_Cagg[r] = Cagg
        self.last_ComAgg[r] = ComAgg
        return AggMessage(r, alpha, root_up, Cagg, ComAgg, sig)

    def combine_and_update(self, r: int, alpha: str, shares: list[tuple[dict, dict]], client_pks: Dict[str, PublicKey], threshold_sim: paillier.ThresholdPaillierSimulator, current_model: List[float]) -> ModelMessage:
        Cagg = self.last_Cagg[r]
        cagg_hash = H_hex(Cagg)
        good_shares = []
        for msg, sig in shares:
            cid = msg["j"]
            pk = client_pks.get(cid)
            if pk and msg["caggHash"] == cagg_hash and verify(pk, H_hex(msg), sig):
                good_shares.append(msg["d"])
        x_agg = threshold_sim.combine(Cagg, good_shares)
        u_agg = decode_update(x_agg, self.scale)
        next_model = [w + self.eta * u for w, u in zip(current_model, u_agg)]
        mh_r = model_hash(current_model)
        mh_next = model_hash(next_model)
        digest = H_hex(r, alpha, mh_r, mh_next, H_hex(Cagg), self.last_ComAgg[r])
        sig = self.signer.sign(digest)
        return ModelMessage(r, alpha, current_model, next_model, mh_r, mh_next, sig)
