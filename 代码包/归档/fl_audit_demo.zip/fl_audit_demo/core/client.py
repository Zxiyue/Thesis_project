"""Client role in the flow-auditable FL protocol demo."""
from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, List

from crypto import paillier, pedersen
from crypto.toy_signature import ToySigner, verify
from crypto.utils import H_hex, add_vec
from core.encoding import encode_update
from core.messages import UploadMessage


@dataclass
class MaskMessage:
    r: int
    client_id: str
    alpha: str
    mask: List[int]
    rho: int
    sigMask: dict


class Client:
    def __init__(self, client_id: str, dim: int, signer: ToySigner):
        self.client_id = client_id
        self.dim = dim
        self.signer = signer
        self.saved_receipts: Dict[int, dict] = {}
        self.saved_uploads: Dict[int, UploadMessage] = {}

    def local_train(self, round_id: int, model: List[float]) -> List[float]:
        """Deterministic toy local update for reproducible demos."""
        seed = hash((self.client_id, round_id)) & 0xFFFFFFFF
        rng = random.Random(seed)
        return [rng.uniform(-0.05, 0.05) for _ in range(self.dim)]

    def build_upload(
        self,
        mask_msg: MaskMessage,
        kgc_pk,
        model_hash: str,
        model: List[float],
        scale: int,
        paillier_pk: paillier.PaillierPublicKey,
        pp_com: pedersen.PedersenParams,
    ) -> UploadMessage:
        digest = H_hex(mask_msg.r, mask_msg.client_id, mask_msg.alpha, mask_msg.mask, mask_msg.rho)
        if not verify(kgc_pk, digest, mask_msg.sigMask):
            raise ValueError(f"invalid mask signature for {self.client_id}")
        if mask_msg.client_id != self.client_id:
            raise ValueError("mask message client mismatch")

        update = self.local_train(mask_msg.r, model)
        x = encode_update(update, scale)
        x_mask = add_vec(x, mask_msg.mask)
        C = paillier.encrypt_vector(paillier_pk, x_mask)
        c_hash = H_hex(C)
        Com = pedersen.commit(pp_com, x_mask, mask_msg.rho)
        receipt = {
            "r": mask_msg.r,
            "i": self.client_id,
            "alpha": mask_msg.alpha,
            "modelHash": model_hash,
            "cHash": c_hash,
            "Com": Com,
        }
        sig_digest = H_hex(receipt)
        sig_up = self.signer.sign(sig_digest)
        up = UploadMessage(
            r=mask_msg.r,
            client_id=self.client_id,
            alpha=mask_msg.alpha,
            ciphertext=C,
            cHash=c_hash,
            commitment=Com,
            receipt=receipt,
            sigUp=sig_up,
        )
        self.saved_receipts[mask_msg.r] = receipt
        self.saved_uploads[mask_msg.r] = up
        return up

    def make_share(self, threshold_sim: paillier.ThresholdPaillierSimulator, r: int, alpha: str, Cagg: List[int]) -> tuple[dict, dict]:
        cagg_hash = H_hex(Cagg)
        share = threshold_sim.partial_decrypt_share(self.client_id, cagg_hash)
        msg = {"r": r, "j": self.client_id, "alpha": alpha, "d": share, "caggHash": cagg_hash}
        sig = self.signer.sign(H_hex(msg))
        return msg, sig
