"""Dataclasses for protocol messages and chain transactions."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional


@dataclass
class InitTx:
    sysParaHash: str
    Uroot: str
    modelHash0: str
    auditRoot0: str
    sigInit: Dict[str, Any]

    def payload(self) -> dict:
        d = asdict(self)
        d.pop("sigInit")
        return d


@dataclass
class FinalTx:
    r: int
    alpha: str
    rootUp: str
    ComAgg: int
    modelHashR: str
    modelHashNext: str
    auditRoot: str
    sigFinal: Dict[str, Any]

    def payload(self) -> dict:
        d = asdict(self)
        d.pop("sigFinal")
        return d


@dataclass
class FraudProofTx:
    r: int
    client_id: str
    receipt: Dict[str, Any]
    path: list[tuple[str, str]]
    claimType: str
    sig: Dict[str, Any]


@dataclass
class UploadMessage:
    r: int
    client_id: str
    alpha: str
    ciphertext: List[int]
    cHash: str
    commitment: int
    receipt: Dict[str, Any]
    sigUp: Dict[str, Any]


@dataclass
class DropMessage:
    r: int
    alpha: str
    D: List[str]
    Cdrop: List[int]
    cDropHash: str
    ComDrop: int
    sigDrop: Dict[str, Any]


@dataclass
class AggMessage:
    r: int
    alpha: str
    rootUp: str
    Cagg: List[int]
    ComAgg: int
    sigAgg: Optional[Dict[str, Any]] = None


@dataclass
class ModelMessage:
    r: int
    alpha: str
    W_r: List[float]
    W_next: List[float]
    modelHashR: str
    modelHashNext: str
    sigModel: Optional[Dict[str, Any]] = None
