"""KGC role: parameters, masks, compensation, final declaration."""
from __future__ import annotations

import random
from dataclasses import asdict
from typing import Dict, List, Tuple

from crypto import paillier, pedersen
from crypto.toy_signature import ToySigner, PublicKey, verify
from crypto.utils import H_hex, merkle_root, sum_vec
from core.client import MaskMessage
from core.encoding import model_delta_to_encoded
from core.messages import InitTx, FinalTx, UploadMessage, DropMessage, ModelMessage


def model_hash(model: List[float]) -> str:
    rounded = [round(x, 12) for x in model]
    return H_hex("MODEL", rounded)


class KGC:
    def __init__(self, dim: int, clients: Dict[str, PublicKey], threshold: int, scale: int, eta: float):
        self.dim = dim
        self.clients = clients
        self.threshold = threshold
        self.scale = scale
        self.eta = eta
        self.signer = ToySigner("KGC")
        self.pp_com = pedersen.setup(dim)
        self.paillier_kp = paillier.keygen(64)
        self.threshold_paillier = paillier.ThresholdPaillierSimulator(self.paillier_kp, threshold)
        self.U = sorted(clients.keys())
        self.masks: Dict[tuple[int, str], List[int]] = {}
        self.rhos: Dict[tuple[int, str], int] = {}
        self.verified_uploads: Dict[int, Dict[str, UploadMessage]] = {}
        self.round_roots: Dict[int, str] = {}
        self.round_comagg: Dict[int, int] = {}
        self.current_model: List[float] = [0.0] * dim
        self.current_model_hash = model_hash(self.current_model)
        self.audit_root = ""

    def sys_params(self) -> dict:
        return {
            "M": "toy-linear-vector-model",
            "d": self.dim,
            "R": "demo",
            "eta": self.eta,
            "s": self.scale,
            "q": "signed-small-demo",
            "pk_p": {"n": self.paillier_kp.pk.n, "g": self.paillier_kp.pk.g},
            "n_clients": len(self.U),
            "t": self.threshold,
            "pp_com": {"modulus": self.pp_com.modulus, "g_vec": self.pp_com.g_vec, "h": self.pp_com.h},
        }

    def user_root(self) -> str:
        leaves = [H_hex(i, self.clients[i].y) for i in self.U]
        return merkle_root(leaves)

    def make_init_tx(self) -> InitTx:
        sys_hash = H_hex(self.sys_params())
        Uroot = self.user_root()
        self.audit_root = H_hex("AUDIT_INIT", sys_hash, Uroot, self.current_model_hash)
        digest = H_hex(sys_hash, Uroot, self.current_model_hash, self.audit_root)
        sig = self.signer.sign(digest)
        return InitTx(sys_hash, Uroot, self.current_model_hash, self.audit_root, sig)

    def round_alpha(self, r: int) -> str:
        return H_hex(r, self.current_model_hash, self.user_root())

    def _zero_sum_vectors(self, r: int, bound: int = 5) -> dict[str, List[int]]:
        rng = random.Random(100000 + r)
        masks: dict[str, List[int]] = {}
        acc = [0] * self.dim
        for cid in self.U[:-1]:
            v = [rng.randint(-bound, bound) for _ in range(self.dim)]
            masks[cid] = v
            acc = [a + b for a, b in zip(acc, v)]
        masks[self.U[-1]] = [-x for x in acc]
        return masks

    def _zero_sum_scalars(self, r: int, bound: int = 20) -> dict[str, int]:
        rng = random.Random(200000 + r)
        rhos: dict[str, int] = {}
        acc = 0
        for cid in self.U[:-1]:
            rho = rng.randint(-bound, bound)
            rhos[cid] = rho
            acc += rho
        rhos[self.U[-1]] = -acc
        return rhos

    def make_mask_messages(self, r: int, alpha: str) -> dict[str, MaskMessage]:
        masks = self._zero_sum_vectors(r)
        rhos = self._zero_sum_scalars(r)
        out = {}
        for cid in self.U:
            self.masks[(r, cid)] = masks[cid]
            self.rhos[(r, cid)] = rhos[cid]
            digest = H_hex(r, cid, alpha, masks[cid], rhos[cid])
            sig = self.signer.sign(digest)
            out[cid] = MaskMessage(r, cid, alpha, masks[cid], rhos[cid], sig)
        return out

    def verify_uploads(self, r: int, uploads: List[UploadMessage]) -> Tuple[Dict[str, UploadMessage], str]:
        good: Dict[str, UploadMessage] = {}
        for up in uploads:
            pk = self.clients.get(up.client_id)
            if not pk:
                continue
            if up.cHash != H_hex(up.ciphertext):
                continue
            expected_receipt = {
                "r": up.r,
                "i": up.client_id,
                "alpha": up.alpha,
                "modelHash": up.receipt["modelHash"],
                "cHash": up.cHash,
                "Com": up.commitment,
            }
            if up.receipt != expected_receipt:
                continue
            if not verify(pk, H_hex(up.receipt), up.sigUp):
                continue
            good[up.client_id] = up
        leaves = [H_hex(good[cid].receipt) for cid in sorted(good)]
        root = merkle_root(leaves)
        self.verified_uploads[r] = good
        self.round_roots[r] = root
        return good, root

    def build_drop_message(self, r: int, alpha: str, good_uploads: Dict[str, UploadMessage]) -> DropMessage:
        D = [cid for cid in self.U if cid not in good_uploads]
        m_drop = sum_vec([self.masks[(r, cid)] for cid in D], self.dim) if D else [0] * self.dim
        rho_drop = sum(self.rhos[(r, cid)] for cid in D) if D else 0
        Cdrop = paillier.encrypt_vector(self.paillier_kp.pk, m_drop)
        cdrop_hash = H_hex(Cdrop)
        ComDrop = pedersen.commit(self.pp_com, m_drop, rho_drop)
        digest = H_hex(r, alpha, D, cdrop_hash, ComDrop)
        sig = self.signer.sign(digest)
        return DropMessage(r, alpha, D, Cdrop, cdrop_hash, ComDrop, sig)

    def verify_aggregate(self, r: int, Cagg: List[int], ComAgg: int, drop: DropMessage) -> bool:
        uploads = self.verified_uploads[r]
        Craw = paillier.add_ciphertext_vectors(self.paillier_kp.pk, [u.ciphertext for u in uploads.values()])
        expected_Cagg = [(a * b) % self.paillier_kp.pk.n2 for a, b in zip(Craw, drop.Cdrop)]
        ComRaw = pedersen.mul(self.pp_com, [u.commitment for u in uploads.values()])
        expected_ComAgg = (ComRaw * drop.ComDrop) % self.pp_com.modulus
        ok = expected_Cagg == Cagg and expected_ComAgg == ComAgg
        if ok:
            self.round_comagg[r] = ComAgg
        return ok

    def make_final_tx(self, r: int, alpha: str, model_msg: ModelMessage) -> FinalTx:
        if model_msg.r != r or model_msg.alpha != alpha:
            raise ValueError("model message does not match round")
        if model_msg.modelHashR != self.current_model_hash:
            raise ValueError("modelHash_r is not current")
        if model_hash(model_msg.W_r) != model_msg.modelHashR:
            raise ValueError("W_r hash mismatch")
        if model_hash(model_msg.W_next) != model_msg.modelHashNext:
            raise ValueError("W_next hash mismatch")

        x_model = model_delta_to_encoded(model_msg.W_r, model_msg.W_next, self.eta, self.scale)
        ComAgg = self.round_comagg[r]
        if pedersen.commit(self.pp_com, x_model, 0) != ComAgg:
            raise ValueError("model difference does not open ComAgg")

        root_up = self.round_roots[r]
        audit_root = H_hex(self.audit_root, r, alpha, root_up, ComAgg, model_msg.modelHashR, model_msg.modelHashNext)
        digest = H_hex(r, alpha, root_up, ComAgg, model_msg.modelHashR, model_msg.modelHashNext, audit_root)
        sig = self.signer.sign(digest)
        tx = FinalTx(r, alpha, root_up, ComAgg, model_msg.modelHashR, model_msg.modelHashNext, audit_root, sig)
        self.audit_root = audit_root
        self.current_model = model_msg.W_next
        self.current_model_hash = model_msg.modelHashNext
        return tx
