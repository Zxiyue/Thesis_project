"""Run a complete demo round of the flow-auditable federated learning scheme."""
from __future__ import annotations

from blockchain.audit_board import AuditBoard
from core.client import Client
from core.kgc import KGC
from core.server import Server
from core.verifier import PublicVerifier
from crypto.toy_signature import ToySigner


def main() -> None:
    dim = 4
    n_clients = 5
    threshold = 3
    scale = 1000
    eta = 1.0
    rounds = 3

    client_signers = {f"C{i}": ToySigner(f"C{i}") for i in range(1, n_clients + 1)}
    clients = {cid: Client(cid, dim, signer) for cid, signer in client_signers.items()}
    client_pks = {cid: signer.pk for cid, signer in client_signers.items()}

    kgc = KGC(dim=dim, clients=client_pks, threshold=threshold, scale=scale, eta=eta)
    server_signer = ToySigner("CS")
    server = Server(dim, server_signer, client_pks, kgc.signer.pk, eta=eta, scale=scale)

    board = AuditBoard(kgc.signer.pk)
    init_tx = kgc.make_init_tx()
    board.submit_init(init_tx)
    print("InitTx accepted")

    for r in range(1, rounds + 1):
        print(f"\n--- round {r} ---")
        alpha = kgc.round_alpha(r)
        masks = kgc.make_mask_messages(r, alpha)

        # Simulate one client dropout in round 2 only.
        active_ids = list(clients.keys())
        if r == 2:
            active_ids.remove("C5")

        uploads = [clients[cid].build_upload(masks[cid], kgc.signer.pk, kgc.current_model_hash, kgc.current_model, scale, kgc.paillier_kp.pk, kgc.pp_com) for cid in active_ids]

        cs_good, cs_root = server.verify_uploads(r, uploads)
        kgc_good, kgc_root = kgc.verify_uploads(r, uploads)
        assert cs_root == kgc_root
        print(f"valid uploads: {sorted(kgc_good)} rootUp={kgc_root[:12]}...")

        drop = kgc.build_drop_message(r, alpha, kgc_good)
        agg = server.aggregate(r, alpha, cs_root, drop, kgc.paillier_kp.pk, kgc.pp_com)
        if not kgc.verify_aggregate(r, agg.Cagg, agg.ComAgg, drop):
            raise RuntimeError("KGC aggregate verification failed")
        print("aggregate verified by KGC")

        shares = [clients[cid].make_share(kgc.threshold_paillier, r, alpha, agg.Cagg) for cid in active_ids[:threshold]]
        model_msg = server.combine_and_update(r, alpha, shares, client_pks, kgc.threshold_paillier, kgc.current_model)

        final_tx = kgc.make_final_tx(r, alpha, model_msg)
        board.submit_final(final_tx)
        print(f"FinalTx accepted auditRoot={final_tx.auditRoot[:12]}... modelNext={final_tx.modelHashNext[:12]}...")

    ok, reason = PublicVerifier(kgc.signer.pk).verify_board(board)
    print("\nVerifier:", ok, reason)


if __name__ == "__main__":
    main()
