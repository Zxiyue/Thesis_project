"""Toy Schnorr-like signatures for demo purposes.

This is NOT a production signature scheme. It only provides a clean sign/verify
interface for the protocol prototype without third-party dependencies.
"""
from __future__ import annotations

import secrets
from dataclasses import dataclass
from .utils import H_int

# A large prime modulus used only for demonstration arithmetic.
P = 208351617316091241234326746312124448251235562226470491514186331217050270460481
ORDER = P - 1
G = 5


@dataclass(frozen=True)
class PublicKey:
    y: int


@dataclass(frozen=True)
class SecretKey:
    x: int


class ToySigner:
    def __init__(self, name: str):
        self.name = name
        x = secrets.randbelow(ORDER - 2) + 2
        self.sk = SecretKey(x)
        self.pk = PublicKey(pow(G, x, P))

    def sign(self, message_digest: str) -> dict:
        k = secrets.randbelow(ORDER - 2) + 2
        R = pow(G, k, P)
        e = H_int("sig", self.name, self.pk.y, R, message_digest, modulus=ORDER)
        s = (k + e * self.sk.x) % ORDER
        return {"name": self.name, "R": R, "s": s}


def verify(pk: PublicKey, message_digest: str, signature: dict) -> bool:
    try:
        R = int(signature["R"])
        s = int(signature["s"])
        name = signature.get("name", "")
        e = H_int("sig", name, pk.y, R, message_digest, modulus=ORDER)
        left = pow(G, s, P)
        right = (R * pow(pk.y, e, P)) % P
        return left == right
    except Exception:
        return False
