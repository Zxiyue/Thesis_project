"""Pedersen vector commitment demo implementation."""
from __future__ import annotations

from dataclasses import dataclass
from typing import List
from .utils import H_int, prod

P = 208351617316091241234326746312124448251235562226470491514186331217050270460481
ORDER = P - 1


@dataclass
class PedersenParams:
    modulus: int
    order: int
    g_vec: List[int]
    h: int


def setup(dim: int) -> PedersenParams:
    # Deterministically derive generators. This is for a demo only.
    g_vec = []
    for j in range(dim):
        base = H_int("pedersen-g", j, modulus=P - 3) + 2
        g_vec.append(pow(base, 2, P))
    h_base = H_int("pedersen-h", dim, modulus=P - 3) + 2
    h = pow(h_base, 2, P)
    return PedersenParams(P, ORDER, g_vec, h)


def commit(pp: PedersenParams, vector: List[int], rho: int) -> int:
    if len(vector) != len(pp.g_vec):
        raise ValueError("vector dimension mismatch")
    terms = []
    for g, x in zip(pp.g_vec, vector):
        terms.append(pow(g, x % pp.order, pp.modulus))
    terms.append(pow(pp.h, rho % pp.order, pp.modulus))
    return prod(terms, pp.modulus)


def mul(pp: PedersenParams, commitments: List[int]) -> int:
    return prod(commitments, pp.modulus)
