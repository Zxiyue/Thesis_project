"""Utility functions for the FL audit demo.

This module is intentionally lightweight and dependency-free. It is suitable for
experiments and protocol-flow demonstrations, not for production cryptography.
"""
from __future__ import annotations

import hashlib
import json
import secrets
from typing import Any, Iterable, List


def canonical(obj: Any) -> bytes:
    """Return a deterministic JSON byte representation for hashing/signing."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")


def H_bytes(*items: Any) -> bytes:
    h = hashlib.sha256()
    for item in items:
        if isinstance(item, bytes):
            b = item
        elif isinstance(item, str):
            b = item.encode("utf-8")
        else:
            b = canonical(item)
        h.update(len(b).to_bytes(8, "big"))
        h.update(b)
    return h.digest()


def H_hex(*items: Any) -> str:
    return H_bytes(*items).hex()


def H_int(*items: Any, modulus: int) -> int:
    return int.from_bytes(H_bytes(*items), "big") % modulus


def rand_coprime(n: int) -> int:
    import math
    while True:
        x = secrets.randbelow(n - 2) + 2
        if math.gcd(x, n) == 1:
            return x


def prod(values: Iterable[int], modulus: int) -> int:
    acc = 1
    for v in values:
        acc = (acc * v) % modulus
    return acc


def add_vec(a: List[int], b: List[int]) -> List[int]:
    return [x + y for x, y in zip(a, b)]


def sub_vec(a: List[float], b: List[float]) -> List[float]:
    return [x - y for x, y in zip(a, b)]


def sum_vec(vectors: Iterable[List[int]], dim: int) -> List[int]:
    acc = [0] * dim
    for v in vectors:
        acc = [x + y for x, y in zip(acc, v)]
    return acc


def scalar_mul_vec(v: List[float], scalar: float) -> List[float]:
    return [x * scalar for x in v]


def merkle_root(leaves: List[str]) -> str:
    """Compute a Merkle root from hex-string leaves.

    Leaves are sorted outside by caller when deterministic set roots are needed.
    Empty tree uses a fixed domain-separated value.
    """
    if not leaves:
        return H_hex("EMPTY_MERKLE_TREE")
    level = [H_hex("leaf", leaf) for leaf in leaves]
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        next_level = []
        for i in range(0, len(level), 2):
            next_level.append(H_hex("node", level[i], level[i + 1]))
        level = next_level
    return level[0]


def merkle_path(leaves: List[str], index: int) -> list[tuple[str, str]]:
    """Return Merkle path for a leaf index.

    Each path element is (sibling_hash, side), where side is 'L' if sibling is
    on the left and 'R' if sibling is on the right.
    """
    if index < 0 or index >= len(leaves):
        raise IndexError("leaf index out of range")
    level = [H_hex("leaf", leaf) for leaf in leaves]
    path: list[tuple[str, str]] = []
    idx = index
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        sibling = idx ^ 1
        side = "L" if sibling < idx else "R"
        path.append((level[sibling], side))
        idx //= 2
        next_level = []
        for i in range(0, len(level), 2):
            next_level.append(H_hex("node", level[i], level[i + 1]))
        level = next_level
    return path


def verify_merkle_path(leaf: str, path: list[tuple[str, str]], root: str) -> bool:
    cur = H_hex("leaf", leaf)
    for sibling, side in path:
        if side == "L":
            cur = H_hex("node", sibling, cur)
        else:
            cur = H_hex("node", cur, sibling)
    return cur == root
