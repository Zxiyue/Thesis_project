"""Small Paillier implementation for protocol demonstration.

This file implements ordinary Paillier encryption and a simulated threshold
recovery interface. It is not hardened and uses small defaults for fast demos.
"""
from __future__ import annotations

import math
import secrets
from dataclasses import dataclass
from typing import List
from .utils import rand_coprime


def is_probable_prime(n: int, rounds: int = 12) -> bool:
    if n < 2:
        return False
    small = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
    for p in small:
        if n % p == 0:
            return n == p
    d = n - 1
    s = 0
    while d % 2 == 0:
        s += 1
        d //= 2
    for _ in range(rounds):
        a = secrets.randbelow(n - 3) + 2
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for __ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def gen_prime(bits: int) -> int:
    while True:
        x = secrets.randbits(bits) | (1 << (bits - 1)) | 1
        if is_probable_prime(x):
            return x


def lcm(a: int, b: int) -> int:
    return abs(a * b) // math.gcd(a, b)


def invmod(a: int, m: int) -> int:
    return pow(a, -1, m)


def L(u: int, n: int) -> int:
    return (u - 1) // n


def encode_signed(m: int, n: int) -> int:
    return m % n


def decode_signed(m: int, n: int) -> int:
    return m - n if m > n // 2 else m


@dataclass
class PaillierPublicKey:
    n: int
    g: int

    @property
    def n2(self) -> int:
        return self.n * self.n


@dataclass
class PaillierPrivateKey:
    lam: int
    mu: int


@dataclass
class PaillierKeypair:
    pk: PaillierPublicKey
    sk: PaillierPrivateKey


def keygen(bits: int = 64) -> PaillierKeypair:
    p = gen_prime(bits // 2)
    q = gen_prime(bits // 2)
    while q == p:
        q = gen_prime(bits // 2)
    n = p * q
    g = n + 1
    lam = lcm(p - 1, q - 1)
    mu = invmod(L(pow(g, lam, n * n), n), n)
    return PaillierKeypair(PaillierPublicKey(n, g), PaillierPrivateKey(lam, mu))


def encrypt(pk: PaillierPublicKey, m: int) -> int:
    n = pk.n
    n2 = pk.n2
    r = rand_coprime(n)
    mm = encode_signed(m, n)
    return (pow(pk.g, mm, n2) * pow(r, n, n2)) % n2


def decrypt(kp: PaillierKeypair, c: int) -> int:
    n = kp.pk.n
    m = (L(pow(c, kp.sk.lam, n * n), n) * kp.sk.mu) % n
    return decode_signed(m, n)


def add_ciphertexts(pk: PaillierPublicKey, ciphertexts: List[int]) -> int:
    acc = 1
    for c in ciphertexts:
        acc = (acc * c) % pk.n2
    return acc


def encrypt_vector(pk: PaillierPublicKey, vector: List[int]) -> List[int]:
    return [encrypt(pk, x) for x in vector]


def decrypt_vector(kp: PaillierKeypair, vector_c: List[int]) -> List[int]:
    return [decrypt(kp, c) for c in vector_c]


def add_ciphertext_vectors(pk: PaillierPublicKey, vectors: List[List[int]]) -> List[int]:
    if not vectors:
        raise ValueError("at least one ciphertext vector is required")
    dim = len(vectors[0])
    out = []
    for j in range(dim):
        out.append(add_ciphertexts(pk, [v[j] for v in vectors]))
    return out


class ThresholdPaillierSimulator:
    """Simulated threshold recovery wrapper.

    Clients produce signed 'share messages', and the server can decrypt only after
    collecting >= t shares. The actual Paillier decryption uses the private key
    internally for a runnable prototype. Do not use for real threshold security.
    """
    def __init__(self, keypair: PaillierKeypair, threshold: int):
        self.keypair = keypair
        self.threshold = threshold

    def partial_decrypt_share(self, client_id: str, cagg_hash: str) -> dict:
        return {"client_id": client_id, "cagg_hash": cagg_hash, "share": f"share:{client_id}:{cagg_hash}"}

    def combine(self, ciphertext_vector: List[int], shares: List[dict]) -> List[int]:
        if len(shares) < self.threshold:
            raise ValueError("not enough shares to combine")
        return decrypt_vector(self.keypair, ciphertext_vector)
