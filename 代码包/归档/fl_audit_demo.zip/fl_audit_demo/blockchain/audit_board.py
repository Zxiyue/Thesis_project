"""In-memory smart-contract-style audit board.

The board enforces three fixed on-chain cases:
1. InitTx
2. FinalTx_r
3. FraudProofTx
"""
from __future__ import annotations
from typing import Dict, List, Any

from crypto.toy_signature import PublicKey, verify
from crypto.utils import H_hex, verify_merkle_path
from core.messages import InitTx, FinalTx, FraudProofTx


class AuditBoard:
    def __init__(self, kgc_pk: PublicKey):
        self.kgc_pk = kgc_pk
        self.init_tx: InitTx | None = None
        self.final_txs: list[FinalTx] = []
        self.fraud_txs: list[FraudProofTx] = []
        self.latest_round = 0
        self.latest_audit_root: str | None = None
        self.latest_model_hash: str | None = None

    def submit_init(self, tx: InitTx) -> None:
        if self.init_tx is not None:
            raise ValueError("InitTx already exists")
        digest = H_hex(tx.sysParaHash, tx.Uroot, tx.modelHash0, tx.auditRoot0)
        if not verify(self.kgc_pk, digest, tx.sigInit):
            raise ValueError("invalid InitTx signature")
        expected_root = H_hex("AUDIT_INIT", tx.sysParaHash, tx.Uroot, tx.modelHash0)
        if tx.auditRoot0 != expected_root:
            raise ValueError("invalid auditRoot0")
        self.init_tx = tx
        self.latest_round = 0
        self.latest_audit_root = tx.auditRoot0
        self.latest_model_hash = tx.modelHash0

    def submit_final(self, tx: FinalTx) -> None:
        if self.init_tx is None:
            raise ValueError("InitTx must be submitted first")
        if tx.r != self.latest_round + 1:
            raise ValueError("round is not continuous")
        if tx.modelHashR != self.latest_model_hash:
            raise ValueError("model hash chain is broken")
        expected_root = H_hex(
            self.latest_audit_root,
            tx.r,
            tx.alpha,
            tx.rootUp,
            tx.ComAgg,
            tx.modelHashR,
            tx.modelHashNext,
        )
        if tx.auditRoot != expected_root:
            raise ValueError("invalid auditRoot")
        digest = H_hex(
            tx.r,
            tx.alpha,
            tx.rootUp,
            tx.ComAgg,
            tx.modelHashR,
            tx.modelHashNext,
            tx.auditRoot,
        )
        if not verify(self.kgc_pk, digest, tx.sigFinal):
            raise ValueError("invalid FinalTx signature")
        self.final_txs.append(tx)
        self.latest_round = tx.r
        self.latest_audit_root = tx.auditRoot
        self.latest_model_hash = tx.modelHashNext

    def submit_fraud_proof(self, tx: FraudProofTx) -> bool:
        if tx.r < 1 or tx.r > len(self.final_txs):
            raise ValueError("unknown round")
        final_tx = self.final_txs[tx.r - 1]
        leaf = H_hex(tx.receipt)
        ok = verify_merkle_path(leaf, tx.path, final_tx.rootUp)
        self.fraud_txs.append(tx)
        return ok

    def export_chain(self) -> dict:
        return {
            "init": self.init_tx,
            "final": self.final_txs,
            "fraud": self.fraud_txs,
        }
