from __future__ import annotations

from typing import List
import torch
from torch import nn


class LogisticRegressionMNIST(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(28 * 28, 10)

    def forward(self, x):
        x = x.view(x.size(0), -1).to(self.linear.weight.dtype)
        return self.linear(x)


def make_model(name: str = "logistic_regression") -> nn.Module:
    if name != "logistic_regression":
        raise ValueError("V1 supports model.name=logistic_regression")
    return LogisticRegressionMNIST().double()


def get_vector(model: nn.Module) -> torch.Tensor:
    parts = [p.detach().cpu().reshape(-1).double() for p in model.parameters()]
    return torch.cat(parts)


def set_vector(model: nn.Module, vector: torch.Tensor) -> None:
    vector = vector.detach().cpu().double()
    idx = 0
    with torch.no_grad():
        for p in model.parameters():
            n = p.numel()
            p.copy_(vector[idx:idx+n].reshape_as(p).to(device=p.device, dtype=p.dtype))
            idx += n


def evaluate(model: nn.Module, loader, device: str = "cpu") -> tuple[float, float]:
    model.to(device)
    model.eval()
    criterion = nn.CrossEntropyLoss(reduction="sum")
    total_loss = 0.0
    correct = 0
    total = 0
    with torch.no_grad():
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            logits = model(x)
            total_loss += float(criterion(logits, y).item())
            pred = logits.argmax(dim=1)
            correct += int((pred == y).sum().item())
            total += int(y.numel())
    return total_loss / max(total, 1), correct / max(total, 1)
