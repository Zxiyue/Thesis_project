#!/usr/bin/env bash
set -euo pipefail
export DIM_CASES="${REAL_CASES:-real:logistic=logistic_regression:7850 real:mlp=mlp:12730 real:tiny=tiny_cnn:6794 real:small=small_cnn:26666 real:largecnn=larger_cnn:80602}"
export BASE_OUT="${BASE_OUT:-outputs/model_dim_real_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_v2}"
export ZIP_OUT="${ZIP_OUT:-/root/model_dim_real_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_v2_results.zip}"
export SUITE_LOG="${SUITE_LOG:-/root/model_dim_real_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_v2.log}"
bash "$(dirname "$0")/run_model_dim_multiprocess_full.sh"
