#!/usr/bin/env python3
from __future__ import annotations
import argparse, re, zipfile
from pathlib import Path
import pandas as pd


def read_csv(p: Path) -> pd.DataFrame:
    try: return pd.read_csv(p)
    except Exception: return pd.DataFrame()

def find_col(df, names):
    lower={c.lower():c for c in df.columns}
    for n in names:
        if n.lower() in lower: return lower[n.lower()]
    for c in df.columns:
        for n in names:
            if n.lower() in c.lower(): return c
    return None

def boolish(x): return str(x).strip().lower() in {'true','1','yes','y','accepted'}
def safe(x): return re.sub(r'[^A-Za-z0-9]+','_',str(x)).strip('_')[:72] or 'unknown'

def infer_dim(model):
    s=str(model or '').lower().replace('-','_')
    fixed={'tiny_cnn':6794,'cnn_tiny':6794,'logistic_regression':7850,'linear':7850,'softmax':7850,'logistic':7850,'mlp':12730,'mlp16':12730,'small_mlp':12730,'small_cnn':26666,'cnn_small':26666,'larger_cnn':80602,'large_cnn':80602,'cnn_large':80602,'cnn':80602}
    if s in fixed: return fixed[s]
    m=re.match(r'^(synthetic|syn|pad|padded)(?:_?d)?_?(\d+)(k?)$',s)
    if m:
        v=int(m.group(2)); return v*1000 if m.group(3)=='k' else v
    return None

def parse_yaml(txt):
    row={}
    for k,pat,typ in [('clients',r'clients:\s*(\d+)',int),('rounds_configured',r'rounds:\s*(\d+)',int),('threshold',r'threshold:\s*(\d+)',int),('paillier_bits',r'paillier_bits:\s*(\d+)',int),('slot_bits',r'slot_bits:\s*(\d+)',int),('expected_dim',r'expected_dim:\s*(\d+)',int)]:
        m=re.search(pat,txt)
        if m: row[k]=typ(m.group(1))
    for key,out in [('name','model'),('dimension_group','dimension_group'),('case_label','case_label')]:
        m=re.search(rf'{key}:\s*([A-Za-z0-9_\-]+)',txt)
        if m: row[out]=m.group(1)
    return row

def summarize_one(run_dir: Path):
    row={'case':run_dir.name,'run_dir':str(run_dir)}
    cfgs=list(run_dir.parent.glob(f'{run_dir.name}_runtime.yaml'))+list(run_dir.glob('*runtime*.yaml'))
    if cfgs: row.update(parse_yaml(cfgs[0].read_text(encoding='utf-8',errors='ignore')))
    row.setdefault('model',run_dir.name)
    row.setdefault('dimension_group','synthetic' if 'synthetic' in str(row['model']).lower() else 'real')
    if 'case_label' not in row:
        row['case_label']=run_dir.name
    if row.get('expected_dim',0): row['model_dim_actual']=int(row['expected_dim'])
    else:
        d=infer_dim(row.get('model'))
        if d: row['model_dim_actual']=d

    vr=read_csv(run_dir/'verify_result.csv')
    if not vr.empty:
        for c in vr.columns:
            v=vr.iloc[-1][c]
            if c.lower() in {'accepted','verify_accepted','third_party_accepted'}: row['accepted']=boolish(v)
            elif c.lower() in {'completed','success'}: row['completed']=boolish(v)
            else: row[f'verify_{c}']=v
    met=read_csv(run_dir/'metrics_round.csv')
    if met.empty: met=read_csv(run_dir/'metrics.csv')
    if not met.empty:
        rc=find_col(met,['round','r'])
        if rc:
            rr=pd.to_numeric(met[rc],errors='coerce').dropna(); row['rounds_completed']=int(rr.max()) if len(rr) else len(met)
        else: row['rounds_completed']=len(met)
        ac=find_col(met,['test_acc','accuracy','acc']); lc=find_col(met,['test_loss','loss'])
        if ac:
            s=pd.to_numeric(met[ac],errors='coerce').dropna(); row['final_accuracy']=float(s.iloc[-1]) if len(s) else 0.0
        if lc:
            s=pd.to_numeric(met[lc],errors='coerce').dropna(); row['final_loss']=float(s.iloc[-1]) if len(s) else 0.0
    else: row['rounds_completed']=0

    comm=read_csv(run_dir/'communication_cost.csv')
    if not comm.empty:
        bc=find_col(comm,['bytes','size_bytes','actual_bytes','total_bytes']); pc=find_col(comm,['payload_type','type','message_type'])
        if bc:
            b=pd.to_numeric(comm[bc],errors='coerce').fillna(0); row['comm_rows']=len(comm); row['total_comm_MB']=float(b.sum()/1024/1024)
            row['comm_MB_per_round']=row['total_comm_MB']/max(1,int(row.get('rounds_completed') or row.get('rounds_configured') or 1))
        if bc and pc:
            temp=comm.assign(_bytes=pd.to_numeric(comm[bc],errors='coerce').fillna(0))
            for k,v in temp.groupby(pc)['_bytes'].sum().items(): row['comm_MB_'+safe(k)]=float(v/1024/1024)

    gas=read_csv(run_dir/'blockchain_cost.csv')
    if not gas.empty:
        gc=find_col(gas,['gas_used','gas','gasUsed']); tc=find_col(gas,['tx_type','type','name'])
        if gc:
            g=pd.to_numeric(gas[gc],errors='coerce').fillna(0); row['chain_tx_count']=len(gas); row['total_gas']=int(g.sum())
            if tc:
                tx=gas[tc].astype(str); init=gas[tx.str.contains('Init',case=False,na=False)]; final=gas[tx.str.contains('Final',case=False,na=False)]
                if len(init): row['init_tx_gas']=int(pd.to_numeric(init[gc],errors='coerce').dropna().iloc[0])
                if len(final):
                    fg=pd.to_numeric(final[gc],errors='coerce').dropna(); row['finaltx_count']=len(final); row['avg_finaltx_gas']=float(fg.mean()) if len(fg) else 0.0

    rt=read_csv(run_dir/'runtime_cost.csv')
    if not rt.empty:
        sc=find_col(rt,['stage']); sec=find_col(rt,['seconds'])
        if sc and sec:
            rt=rt.copy(); rt['_sec']=pd.to_numeric(rt[sec],errors='coerce')
            for stage, vals in rt.groupby(sc)['_sec'].agg(['sum','mean','count']).iterrows():
                sn=safe(stage); row[f'runtime_sum_{sn}']=float(vals['sum']) if pd.notna(vals['sum']) else 0.0; row[f'runtime_mean_{sn}']=float(vals['mean']) if pd.notna(vals['mean']) else 0.0; row[f'runtime_count_{sn}']=int(vals['count'])
    return row

def md_table(df, cols):
    cols=[c for c in cols if c in df.columns]
    if not cols: return ''
    def fmt(x): return f'{x:.4f}'.rstrip('0').rstrip('.') if isinstance(x,float) else str(x)
    lines=['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']
    for _,r in df[cols].iterrows(): lines.append('| '+' | '.join(fmt(r[c]) for c in cols)+' |')
    return '\n'.join(lines)

def write_md(base, summary):
    cols=['dimension_group','case_label','case','model','model_dim_actual','clients','threshold','rounds_completed','accepted','final_accuracy','total_comm_MB','comm_MB_per_round','runtime_mean_start_experiment_total_wall','avg_finaltx_gas','total_gas']
    parts=['# Model Dimension Multiprocess Experiment Summary\n','Synthetic cases are dimension-only padded-vector workloads and should not be used for accuracy comparison.\n','## All cases\n',md_table(summary,cols)]
    for group in ['real','synthetic']:
        if 'dimension_group' in summary.columns:
            sub=summary[summary['dimension_group']==group]
            if not sub.empty:
                parts += [f'## {group} cases\n',md_table(sub,cols)]
    (base/'model_dim_result_analysis.md').write_text('\n\n'.join(parts),encoding='utf-8')

def zip_dir(base, zip_out, extra):
    zip_out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(zip_out,'w',zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(base.rglob('*')):
            if p.is_file(): zf.write(p,arcname=str(base.name+'/'+p.relative_to(base).as_posix()))
        for e in extra:
            p=Path(e)
            if p.exists() and p.is_file(): zf.write(p,arcname=str(base.name+'/logs/'+p.name))
    print('[OK] zip written:',zip_out)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--base-dir',required=True); ap.add_argument('--zip-out',required=True); ap.add_argument('--extra-log',action='append',default=[]); args=ap.parse_args()
    base=Path(args.base_dir).resolve();
    if not base.exists(): raise SystemExit(f'[ERROR] base-dir not found: {base}')
    runs=sorted([p for p in base.iterdir() if p.is_dir() and p.name.startswith('d')])
    summary=pd.DataFrame([summarize_one(p) for p in runs])
    if not summary.empty:
        summary['_g']=summary.get('dimension_group','real').map({'real':0,'synthetic':1,'smoke':2}).fillna(9) if 'dimension_group' in summary.columns else 0
        summary['_d']=pd.to_numeric(summary.get('model_dim_actual',0),errors='coerce')
        summary=summary.sort_values(['_g','_d','case']).drop(columns=['_g','_d'])
    summary.to_csv(base/'model_dim_summary.csv',index=False)
    if not summary.empty and 'dimension_group' in summary.columns:
        for g in ['real','synthetic']:
            sub=summary[summary['dimension_group']==g]
            if not sub.empty: sub.to_csv(base/f'model_dim_summary_{g}.csv',index=False)
    if not summary.empty:
        for name, cols in {
            'gas_by_model_dim.csv':['dimension_group','case_label','case','model','model_dim_actual','chain_tx_count','init_tx_gas','finaltx_count','avg_finaltx_gas','total_gas'],
            'communication_by_model_dim.csv':['dimension_group','case_label','case','model','model_dim_actual','total_comm_MB','comm_MB_per_round','comm_MB_UpMsg','comm_MB_AggMsg','comm_rows'],
            'runtime_by_model_dim.csv':[c for c in summary.columns if c in ['dimension_group','case_label','case','model','model_dim_actual','rounds_completed','accepted'] or c.startswith('runtime_mean_') or c.startswith('runtime_sum_')],
        }.items(): summary[[c for c in cols if c in summary.columns]].to_csv(base/name,index=False)
    write_md(base,summary)
    zip_dir(base,Path(args.zip_out),args.extra_log)
    print('[OK] summary rows:',len(summary))
    if not summary.empty: print(summary[[c for c in ['dimension_group','case_label','model','model_dim_actual','accepted','total_comm_MB','avg_finaltx_gas'] if c in summary.columns]].to_string(index=False))
if __name__=='__main__': main()
