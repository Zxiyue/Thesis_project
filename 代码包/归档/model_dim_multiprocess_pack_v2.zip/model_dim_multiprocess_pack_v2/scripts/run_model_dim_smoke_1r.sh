#!/usr/bin/env bash
set -euo pipefail
export ROUNDS="${ROUNDS:-1}"
export DIM_CASES="${DIM_CASES:-synthetic:smoke_syn100k=synthetic_100000:100000}"
export BASE_OUT="${BASE_OUT:-outputs/model_dim_smoke_syn100k_multiprocess_mnist_iid_c10_t6_p512_s40_1r_chain_v2}"
export ZIP_OUT="${ZIP_OUT:-/root/model_dim_smoke_syn100k_multiprocess_mnist_iid_c10_t6_p512_s40_1r_chain_v2_results.zip}"
export SUITE_LOG="${SUITE_LOG:-/root/model_dim_smoke_syn100k_multiprocess_mnist_iid_c10_t6_p512_s40_1r_chain_v2.log}"
bash "$(dirname "$0")/run_model_dim_multiprocess_full.sh"
