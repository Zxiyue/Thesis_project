#!/usr/bin/env bash
set -euo pipefail
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ -x "$FPA5_ROOT/.venv/bin/python" ]]; then PY="$FPA5_ROOT/.venv/bin/python"; elif [[ -x "$FPA5_ROOT/.venv/bin/python3" ]]; then PY="$FPA5_ROOT/.venv/bin/python3"; else PY=python3; fi
export FPA5_ROOT
"$PY" "$PACK_DIR/scripts/patch_model_dim_support.py"
