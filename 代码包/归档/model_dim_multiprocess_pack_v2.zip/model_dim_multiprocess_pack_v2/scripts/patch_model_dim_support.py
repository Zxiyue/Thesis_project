#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path

FPA5_ROOT = Path('/root/fpa5')
MODEL_PY = FPA5_ROOT / 'fl_audit' / 'model.py'
PATCH_BEGIN = '# === DIM_EXPERIMENT_PATCH_BEGIN ==='
PATCH_END = '# === DIM_EXPERIMENT_PATCH_END ==='

PATCH_BLOCK = r'''
# === DIM_EXPERIMENT_PATCH_BEGIN ===

class MLPMNIST(nn.Module):
    # Linear(784 -> 16) + ReLU + Linear(16 -> 10), dim = 12730.
    def __init__(self, hidden: int = 16):
        super().__init__()
        self.net = nn.Sequential(
            nn.Flatten(),
            nn.Linear(28 * 28, int(hidden)),
            nn.ReLU(),
            nn.Linear(int(hidden), 10),
        )

    def forward(self, x):
        x = x.to(next(self.parameters()).dtype)
        return self.net(x)


class LargerCNNMNIST(nn.Module):
    # Conv(1->16) + Conv(16->32) + FC(1568->48) + FC(48->10), dim ≈ 80602.
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(16, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(32 * 7 * 7, 48),
            nn.ReLU(),
            nn.Linear(48, 10),
        )

    def forward(self, x):
        x = x.to(next(self.parameters()).dtype)
        return self.classifier(self.features(x))


class SyntheticPaddedMNISTModel(nn.Module):
    # Synthetic dimension workload. Base classifier has 805 params; padding reaches target_dim.
    # Padding is not used in forward path, so this isolates protocol overhead caused by vector dimension d.
    BASE_DIM = 28 * 28 * 1 + 1 + 1 * 10 + 10

    def __init__(self, target_dim: int):
        super().__init__()
        target_dim = int(target_dim)
        if target_dim < self.BASE_DIM:
            raise ValueError(f'synthetic target_dim must be >= {self.BASE_DIM}, got {target_dim}')
        self.target_dim = target_dim
        self.linear1 = nn.Linear(28 * 28, 1)
        self.linear2 = nn.Linear(1, 10)
        pad = target_dim - self.BASE_DIM
        self.padding = nn.Parameter(torch.zeros(pad, dtype=torch.double), requires_grad=False)

    def forward(self, x):
        x = x.view(x.size(0), -1).to(self.linear1.weight.dtype)
        x = torch.relu(self.linear1(x))
        return self.linear2(x)


def _parse_synthetic_dim(name: str) -> int | None:
    s = str(name).lower().replace('-', '_')
    m = re.match(r'^(synthetic|syn|pad|padded)(?:_?d)?_?(\d+)(k?)$', s)
    if not m:
        return None
    value = int(m.group(2))
    if m.group(3) == 'k':
        value *= 1000
    return value


def make_model(name: str = "logistic_regression") -> nn.Module:
    name_raw = str(name)
    name_l = name_raw.lower().replace('-', '_')
    synth_dim = _parse_synthetic_dim(name_l)
    if synth_dim is not None:
        model = SyntheticPaddedMNISTModel(synth_dim)
    elif name_l in {"logistic_regression", "linear", "softmax", "logistic"}:
        model = LogisticRegressionMNIST()
    elif name_l in {"mlp", "mlp16", "small_mlp"}:
        model = MLPMNIST(hidden=16)
    elif name_l in {"tiny_cnn", "cnn_tiny"}:
        model = TinyCNNMNIST()
    elif name_l in {"small_cnn", "cnn_small"}:
        model = SmallCNNMNIST()
    elif name_l in {"larger_cnn", "large_cnn", "cnn_large", "cnn"}:
        model = LargerCNNMNIST()
    else:
        raise ValueError("Unsupported model.name=%r. Use logistic_regression, mlp, tiny_cnn, small_cnn, larger_cnn/cnn, or synthetic_1000/synthetic_5000/.../synthetic_100000." % name_raw)
    return model.double()
# === DIM_EXPERIMENT_PATCH_END ===
'''


def remove_old_patch(s: str) -> str:
    pat = re.compile(re.escape(PATCH_BEGIN) + r'.*?' + re.escape(PATCH_END) + r'\n?', re.S)
    return pat.sub('', s)


def replace_make_model(s: str) -> str:
    pat = re.compile(r'\ndef make_model\(.*?\).*?(?=\n\ndef get_vector\()', re.S)
    if pat.search(s):
        return pat.sub('\n' + PATCH_BLOCK.rstrip() + '\n', s)
    marker = '\ndef get_vector('
    if marker in s:
        return s.replace(marker, '\n' + PATCH_BLOCK.rstrip() + '\n' + marker, 1)
    raise RuntimeError('Could not find make_model/get_vector location in fl_audit/model.py')


def ensure_imports(s: str) -> str:
    head = '\n'.join(s.split('\n')[:50])
    if 'import re' not in head:
        if 'import io\n' in s:
            s = s.replace('import io\n', 'import io\nimport re\n', 1)
        else:
            s = 'import re\n' + s
    return s


def main():
    if not MODEL_PY.exists():
        raise SystemExit(f'[ERROR] model.py not found: {MODEL_PY}')
    s = MODEL_PY.read_text(encoding='utf-8')
    original = s
    s = ensure_imports(s)
    s = remove_old_patch(s)
    s = replace_make_model(s)
    if s != original:
        backup = MODEL_PY.with_suffix('.py.bak_dim_experiment')
        if not backup.exists():
            backup.write_text(original, encoding='utf-8')
        MODEL_PY.write_text(s, encoding='utf-8')
        print(f'[OK] patched model support: {MODEL_PY}')
        print(f'[INFO] backup: {backup}')
    else:
        print('[INFO] model support already patched')

    import sys
    sys.path.insert(0, str(FPA5_ROOT))
    from fl_audit.model import make_model, get_vector
    names = [
        'logistic_regression', 'mlp', 'tiny_cnn', 'small_cnn', 'larger_cnn', 'cnn',
        'synthetic_1000', 'synthetic_5000', 'synthetic_10000', 'synthetic_20000',
        'synthetic_50000', 'synthetic_100000'
    ]
    print('[INFO] model dimension probe:')
    for name in names:
        m = make_model(name)
        print(f'[CHECK] {name}: dim={get_vector(m).numel()}')


if __name__ == '__main__':
    main()
