#!/usr/bin/env bash
set -euo pipefail
export DIM_CASES="${SYN_CASES:-synthetic:syn1k=synthetic_1000:1000 synthetic:syn5k=synthetic_5000:5000 synthetic:syn10k=synthetic_10000:10000 synthetic:syn20k=synthetic_20000:20000 synthetic:syn50k=synthetic_50000:50000 synthetic:syn100k=synthetic_100000:100000}"
export BASE_OUT="${BASE_OUT:-outputs/model_dim_synthetic_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_v2}"
export ZIP_OUT="${ZIP_OUT:-/root/model_dim_synthetic_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_v2_results.zip}"
export SUITE_LOG="${SUITE_LOG:-/root/model_dim_synthetic_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_v2.log}"
bash "$(dirname "$0")/run_model_dim_multiprocess_full.sh"
