"""Executable demo for the current verifiable federated audit scheme.

Run:
    python main.py

This is a demonstration prototype, not a production cryptographic system.
"""
from __future__ import annotations

import random
from typing import Dict, List

import config
from blockchain.audit_board import AuditBoard
from crypto.hash_utils import hash_join, sha256_hex
from crypto.signature import generate_keypair, verify
from entities.client import Client
from entities.kgc import KGC
from entities.server import Server
from entities.verifier import Verifier


def model_hash(model: List[int]) -> str:
    return sha256_hex({"model": model})


def main() -> None:
    random.seed(config.RANDOM_SEED)

    print("=== Verifiable Federated Audit Demo ===")
    print("Note: ordinary Paillier + Shamir-demo recovery is used for executable demonstration.\n")

    # 0. Entity setup.
    kgc = KGC(
        dim=config.MODEL_DIM,
        n_clients=config.NUM_CLIENTS,
        threshold=config.THRESHOLD,
        mask_bound=config.MASK_BOUND,
    )
    server = Server(sig_key=generate_keypair(256), threshold=config.THRESHOLD, shamir_prime=kgc.shamir_prime)

    clients: Dict[int, Client] = {}
    for cid in range(1, config.NUM_CLIENTS + 1):
        clients[cid] = Client(
            cid=cid,
            sig_key=generate_keypair(256),
            share=kgc.shares[cid - 1],
            dim=config.MODEL_DIM,
            update_bound=config.LOCAL_UPDATE_BOUND,
        )
    client_pubs = {cid: c.public_key for cid, c in clients.items()}
    all_client_ids = sorted(clients)

    # 1. InitTx.
    model = [0] * config.MODEL_DIM
    model_hash_0 = model_hash(model)
    uroot = kgc.compute_uroot(client_pubs)
    sys_para = {
        "M": "demo_linear_vector_model",
        "d": config.MODEL_DIM,
        "R": config.ROUNDS,
        "eta": config.LEARNING_RATE,
        "s": config.ENCODING_SCALE,
        "q": config.ENCODING_MODULUS,
        "pk_p": kgc.paillier.public.to_dict(),
        "n_u": config.NUM_CLIENTS,
        "t": config.THRESHOLD,
        "pp_com": kgc.pedersen.to_dict(),
    }
    init_tx = kgc.make_init_tx(sys_para, uroot, model_hash_0)
    board = AuditBoard(kgc.public_key)
    if not board.submit_init(init_tx, sys_para):
        raise SystemExit("InitTx rejected")
    previous_audit_root = init_tx["auditRoot_0"]

    # 2. Rounds.
    for r in range(1, config.ROUNDS + 1):
        print(f"\n--- Round {r} ---")
        model_hash_r = model_hash(model)
        uroot_r = uroot  # current main scheme sets U_r = U.
        alpha = kgc.make_round_alpha(r, model_hash_r, uroot_r)
        mask_messages = kgc.make_mask_messages(r, alpha, all_client_ids)

        # Simulate dropouts while keeping at least t online clients.
        drop_count = random.randint(0, min(config.MAX_DROPS_PER_ROUND, config.NUM_CLIENTS - config.THRESHOLD))
        dropped = sorted(random.sample(all_client_ids, drop_count)) if drop_count else []
        online_ids = [cid for cid in all_client_ids if cid not in dropped]
        print(f"planned clients U_r = {all_client_ids}")
        print(f"dropped clients D_r = {dropped if dropped else 'none'}")

        uploads = []
        for cid in online_ids:
            uploads.append(
                clients[cid].train_and_upload(
                    round_id=r,
                    alpha=alpha,
                    model_hash=model_hash_r,
                    model=model,
                    mask_msg=mask_messages[cid],
                    kgc_pub=kgc.public_key,
                    paillier_pub=kgc.paillier.public,
                    pedersen_params=kgc.pedersen,
                )
            )

        cs_valid_uploads = server.verify_uploads(uploads, client_pubs)
        kgc_valid_uploads = kgc.verify_uploads(uploads, client_pubs)
        if [m["i"] for m in cs_valid_uploads] != [m["i"] for m in kgc_valid_uploads]:
            raise RuntimeError("CS/KGC valid upload set mismatch")
        if len(cs_valid_uploads) < config.THRESHOLD:
            raise RuntimeError("not enough valid uploads for threshold recovery")

        root_up = server.build_root_up(cs_valid_uploads)
        raw = server.raw_aggregate(kgc.paillier.public, kgc.pedersen, cs_valid_uploads)
        drop_msg = kgc.make_drop_message(r, alpha, all_client_ids, [m["i"] for m in cs_valid_uploads])
        if not verify(kgc.public_key, drop_msg["sigDrop"], {k: drop_msg[k] for k in ["r", "alpha", "D", "Cdrop", "cDropHash", "ComDrop"]}):
            raise RuntimeError("invalid KGC drop signature")

        agg = server.finalize_aggregate(kgc.paillier.public, kgc.pedersen, r, alpha, root_up, raw, drop_msg)
        if not verify(server.public_key, agg["sigAgg"], agg["AggMsg"]):
            raise RuntimeError("invalid CS aggregate signature")

        # Online clients generate demo decryption shares for Cagg.
        share_msgs = [clients[cid].make_share_message(r, alpha, agg["AggMsg"]["caggHash"]) for cid in online_ids]
        x_agg = server.recover_plaintext(
            pub=kgc.paillier.public,
            share_messages=share_msgs,
            client_pubs=client_pubs,
            cagg_hash=agg["AggMsg"]["caggHash"],
            cagg_vec=agg["Cagg_vec"],
        )

        expected_sum = [0] * config.MODEL_DIM
        for msg in cs_valid_uploads:
            for j, val in enumerate(msg["_demo_x"]):
                expected_sum[j] += val
        print(f"recovered xAgg_r     = {x_agg}")
        print(f"expected demo sum    = {expected_sum}")
        if x_agg != expected_sum:
            raise RuntimeError("plaintext recovery mismatch")

        # Model update.
        model_next = [model[j] + config.LEARNING_RATE * x_agg[j] for j in range(config.MODEL_DIM)]
        model_hash_next = model_hash(model_next)
        model_signed = server.make_model_msg(
            round_id=r,
            alpha=alpha,
            model_hash=model_hash_r,
            model_hash_next=model_hash_next,
            cagg_hash=agg["AggMsg"]["caggHash"],
            com_agg=agg["ComAgg"],
        )

        # KGC publishes FinalTx only after all checks pass.
        final_tx = kgc.verify_and_make_final_tx(
            round_id=r,
            alpha=alpha,
            root_up=root_up,
            com_raw=raw["ComRaw"],
            drop_msg=drop_msg,
            com_agg=agg["ComAgg"],
            x_agg=x_agg,
            model_hash_r=model_hash_r,
            model_hash_next=model_hash_next,
            previous_audit_root=previous_audit_root,
            model_msg_signed=model_signed,
            server_pub=server.public_key,
        )
        if not board.submit_final(final_tx):
            raise RuntimeError("FinalTx rejected by AuditBoard")
        previous_audit_root = final_tx["auditRoot"]
        model = model_next
        print("commitment check      = PASS")
        print("FinalTx published     = PASS")

    # 3. Public verification.
    print("\n--- Public verification ---")
    verifier = Verifier(kgc.public_key)
    ok = verifier.verify_board(board, sys_para, expected_rounds=config.ROUNDS)
    print("Final model:", model)
    print("Audit result:", "PASS" if ok else "FAIL")


if __name__ == "__main__":
    main()
