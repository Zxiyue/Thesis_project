"""In-memory smart-contract-like audit board.

The real paper scheme writes InitTx and FinalTx_r through fixed smart contract
interfaces. This file simulates those checks in Python.
"""
from __future__ import annotations

from typing import Any, Dict, List

from crypto.hash_utils import hash_join, sha256_hex
from crypto.signature import RSAPublicKey, verify
from protocol.messages import final_payload


class AuditBoard:
    def __init__(self, kgc_pub: RSAPublicKey):
        self.kgc_pub = kgc_pub
        self.init_tx: Dict[str, Any] | None = None
        self.final_txs: List[Dict[str, Any]] = []
        self.latest_round = 0
        self.latest_audit_root: str | None = None
        self.latest_model_hash: str | None = None

    def submit_init(self, tx: Dict[str, Any], sys_para: Dict[str, Any]) -> bool:
        if self.init_tx is not None:
            print("[AuditBoard] init rejected: already initialized")
            return False
        payload = {
            "sysParaHash": tx["sysParaHash"],
            "Uroot": tx["Uroot"],
            "modelHash_0": tx["modelHash_0"],
            "auditRoot_0": tx["auditRoot_0"],
        }
        if sha256_hex(sys_para) != tx["sysParaHash"]:
            print("[AuditBoard] init rejected: sysParaHash mismatch")
            return False
        expected_root = hash_join("AUDIT_INIT", tx["sysParaHash"], tx["Uroot"], tx["modelHash_0"])
        if expected_root != tx["auditRoot_0"]:
            print("[AuditBoard] init rejected: auditRoot_0 mismatch")
            return False
        if not verify(self.kgc_pub, tx["sigInit"], payload):
            print("[AuditBoard] init rejected: KGC signature invalid")
            return False
        self.init_tx = tx
        self.latest_audit_root = tx["auditRoot_0"]
        self.latest_model_hash = tx["modelHash_0"]
        print("[AuditBoard] InitTx accepted.")
        return True

    def submit_final(self, tx: Dict[str, Any]) -> bool:
        if self.init_tx is None:
            print("[AuditBoard] FinalTx rejected: no init")
            return False
        if tx["r"] != self.latest_round + 1:
            print("[AuditBoard] FinalTx rejected: round is not continuous")
            return False
        if tx["modelHash_r"] != self.latest_model_hash:
            print("[AuditBoard] FinalTx rejected: model hash chain broken")
            return False
        expected_root = hash_join(
            self.latest_audit_root,
            tx["r"],
            tx["alpha"],
            tx["rootUp"],
            tx["ComAgg"],
            tx["modelHash_r"],
            tx["modelHash_next"],
        )
        if expected_root != tx["auditRoot"]:
            print("[AuditBoard] FinalTx rejected: audit root mismatch")
            return False
        if not verify(self.kgc_pub, tx["sigFinal"], final_payload(tx)):
            print("[AuditBoard] FinalTx rejected: KGC signature invalid")
            return False
        self.final_txs.append(tx)
        self.latest_round = tx["r"]
        self.latest_audit_root = tx["auditRoot"]
        self.latest_model_hash = tx["modelHash_next"]
        print(f"[AuditBoard] FinalTx round {tx['r']} accepted.")
        return True

    def get_chain(self) -> List[Dict[str, Any]]:
        return list(self.final_txs)
