"""Small message constructors."""
from __future__ import annotations

from typing import Any, Dict

from crypto.hash_utils import sha256_hex


def receipt_hash(receipt: Dict[str, Any], sig_up: str) -> str:
    return sha256_hex({"receipt": receipt, "sigUp": sig_up})


def final_payload(final_tx: Dict[str, Any]) -> Dict[str, Any]:
    """Return FinalTx fields excluding the signature."""
    return {
        "r": final_tx["r"],
        "alpha": final_tx["alpha"],
        "rootUp": final_tx["rootUp"],
        "ComAgg": final_tx["ComAgg"],
        "modelHash_r": final_tx["modelHash_r"],
        "modelHash_next": final_tx["modelHash_next"],
        "auditRoot": final_tx["auditRoot"],
    }
