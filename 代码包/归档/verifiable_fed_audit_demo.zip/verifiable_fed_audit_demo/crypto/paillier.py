"""Minimal Paillier implementation for protocol demonstration.

This is not threshold Paillier. The demo combines it with Shamir shares of
lambda to emulate the threshold recovery flow used by the paper scheme.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Iterable, List

from .math_utils import lcm, modinv, random_prime


@dataclass
class PaillierPublicKey:
    n: int
    g: int

    @property
    def n2(self) -> int:
        return self.n * self.n

    def to_dict(self) -> dict:
        return {"n": str(self.n), "g": str(self.g)}


@dataclass
class PaillierPrivateKey:
    lam: int
    mu: int


@dataclass
class PaillierKeypair:
    public: PaillierPublicKey
    private: PaillierPrivateKey
    p: int
    q: int


def generate_keypair(bits: int = 256) -> PaillierKeypair:
    while True:
        p = random_prime(bits // 2)
        q = random_prime(bits // 2)
        if p == q:
            continue
        n = p * q
        g = n + 1
        lam = lcm(p - 1, q - 1)
        try:
            mu = modinv(lam % n, n)  # valid when g=n+1
        except ValueError:
            continue
        return PaillierKeypair(PaillierPublicKey(n, g), PaillierPrivateKey(lam, mu), p, q)


def encode_signed(m: int, n: int) -> int:
    return m % n


def decode_signed(m: int, n: int) -> int:
    # demo assumes all plaintext sums are much smaller than n/2 in magnitude
    return m - n if m > n // 2 else m


def encrypt(pub: PaillierPublicKey, m: int) -> int:
    m_mod = encode_signed(m, pub.n)
    while True:
        r = random.randrange(1, pub.n)
        if math.gcd(r, pub.n) == 1:
            break
    return (pow(pub.g, m_mod, pub.n2) * pow(r, pub.n, pub.n2)) % pub.n2


def encrypt_vector(pub: PaillierPublicKey, vec: Iterable[int]) -> List[int]:
    return [encrypt(pub, int(x)) for x in vec]


def add_ciphertexts(pub: PaillierPublicKey, ciphertexts: Iterable[int]) -> int:
    out = 1
    for c in ciphertexts:
        out = (out * c) % pub.n2
    return out


def add_vectors(pub: PaillierPublicKey, vectors: Iterable[List[int]]) -> List[int]:
    vectors = list(vectors)
    if not vectors:
        raise ValueError("no vectors to aggregate")
    dim = len(vectors[0])
    return [add_ciphertexts(pub, [v[j] for v in vectors]) for j in range(dim)]


def decrypt_with_lambda(pub: PaillierPublicKey, lam: int, c: int) -> int:
    x = pow(c, lam, pub.n2)
    L = (x - 1) // pub.n
    mu = modinv(lam % pub.n, pub.n)
    return decode_signed((L * mu) % pub.n, pub.n)


def decrypt_vector_with_lambda(pub: PaillierPublicKey, lam: int, cvec: Iterable[int]) -> List[int]:
    return [decrypt_with_lambda(pub, lam, c) for c in cvec]
