"""Shamir secret sharing demo for Paillier lambda.

This simulates the threshold recovery stage. It is intentionally simpler than
real threshold Paillier partial decryption.
"""
from __future__ import annotations

import random
from typing import Iterable, List, Tuple

from .math_utils import modinv

Share = Tuple[int, int]


def split_secret(secret: int, n: int, t: int, prime: int) -> List[Share]:
    coeffs = [secret] + [random.randrange(0, prime) for _ in range(t - 1)]
    shares = []
    for x in range(1, n + 1):
        y = 0
        power = 1
        for c in coeffs:
            y = (y + c * power) % prime
            power = (power * x) % prime
        shares.append((x, y))
    return shares


def recover_secret(shares: Iterable[Share], prime: int) -> int:
    shares = list(shares)
    total = 0
    for i, (xi, yi) in enumerate(shares):
        num = 1
        den = 1
        for j, (xj, _) in enumerate(shares):
            if i == j:
                continue
            num = (num * (-xj)) % prime
            den = (den * (xi - xj)) % prime
        lagrange = num * modinv(den, prime)
        total = (total + yi * lagrange) % prime
    return total
