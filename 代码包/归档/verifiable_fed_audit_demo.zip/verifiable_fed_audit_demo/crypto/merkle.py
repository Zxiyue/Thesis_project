"""Merkle tree helper."""
from __future__ import annotations

from typing import Iterable, List, Tuple

from .hash_utils import hash_join, sha256_hex


def merkle_root(leaves: Iterable[str]) -> str:
    level = sorted(list(leaves))
    if not level:
        return sha256_hex("EMPTY_MERKLE_ROOT")
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        nxt = []
        for i in range(0, len(level), 2):
            nxt.append(hash_join(level[i], level[i + 1]))
        level = nxt
    return level[0]


def merkle_path(leaves: List[str], target_leaf: str) -> List[Tuple[str, str]]:
    # deterministic sorted tree
    level = sorted(leaves)
    idx = level.index(target_leaf)
    path: List[Tuple[str, str]] = []
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        sibling_idx = idx ^ 1
        side = "left" if sibling_idx < idx else "right"
        path.append((level[sibling_idx], side))
        idx //= 2
        nxt = []
        for i in range(0, len(level), 2):
            nxt.append(hash_join(level[i], level[i + 1]))
        level = nxt
    return path


def verify_path(leaf: str, path: List[Tuple[str, str]], root: str) -> bool:
    cur = leaf
    for sibling, side in path:
        if side == "left":
            cur = hash_join(sibling, cur)
        else:
            cur = hash_join(cur, sibling)
    return cur == root
