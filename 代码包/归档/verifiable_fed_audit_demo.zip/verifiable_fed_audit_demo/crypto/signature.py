"""Toy RSA signatures for demo purposes only.

The goal is to make the protocol executable without external dependencies.
Do not use this code as a real signature library.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from .hash_utils import sha256_int
from .math_utils import modinv, random_prime


@dataclass(frozen=True)
class RSAPublicKey:
    n: int
    e: int

    def to_dict(self) -> dict:
        return {"n": str(self.n), "e": str(self.e)}


@dataclass(frozen=True)
class RSAPrivateKey:
    n: int
    d: int
    e: int

    @property
    def public(self) -> RSAPublicKey:
        return RSAPublicKey(self.n, self.e)


def generate_keypair(bits: int = 256) -> RSAPrivateKey:
    e = 65537
    while True:
        p = random_prime(bits // 2)
        q = random_prime(bits // 2)
        if p == q:
            continue
        phi = (p - 1) * (q - 1)
        if math.gcd(e, phi) == 1:
            n = p * q
            d = modinv(e, phi)
            return RSAPrivateKey(n=n, d=d, e=e)


def sign(priv: RSAPrivateKey, message: Any) -> str:
    digest = sha256_int(message) % priv.n
    sig = pow(digest, priv.d, priv.n)
    return hex(sig)


def verify(pub: RSAPublicKey, signature_hex: str, message: Any) -> bool:
    try:
        sig = int(signature_hex, 16)
    except Exception:
        return False
    digest = sha256_int(message) % pub.n
    return pow(sig, pub.e, pub.n) == digest
