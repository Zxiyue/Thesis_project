"""Pedersen-style vector commitment used for the demo.

This is a lightweight demonstrator. It preserves the homomorphic equations
used by the protocol, but is not intended as a production parameter generator.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Iterable, List

from .math_utils import random_prime


@dataclass
class PedersenParams:
    modulus: int
    order: int
    generators: List[int]
    h: int

    def to_dict(self) -> dict:
        return {
            "modulus": str(self.modulus),
            "order": str(self.order),
            "generators": [str(g) for g in self.generators],
            "h": str(self.h),
        }


def generate_params(dim: int, bits: int = 256) -> PedersenParams:
    p = random_prime(bits)
    order = p - 1
    gens = []
    used = set()
    for _ in range(dim):
        while True:
            g = random.randrange(2, p - 1)
            if g not in used and pow(g, 2, p) != 1:
                used.add(g)
                gens.append(g)
                break
    while True:
        h = random.randrange(2, p - 1)
        if h not in used and pow(h, 2, p) != 1:
            break
    return PedersenParams(p, order, gens, h)


def commit(params: PedersenParams, vector: Iterable[int], rho: int) -> int:
    out = 1
    for x, g in zip(vector, params.generators):
        out = (out * pow(g, int(x) % params.order, params.modulus)) % params.modulus
    out = (out * pow(params.h, rho % params.order, params.modulus)) % params.modulus
    return out


def multiply(params: PedersenParams, *commitments: int) -> int:
    out = 1
    for c in commitments:
        out = (out * c) % params.modulus
    return out
