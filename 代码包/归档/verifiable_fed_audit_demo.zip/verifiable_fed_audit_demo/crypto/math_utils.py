"""Small math utilities. Suitable for demonstrations, not production crypto."""
from __future__ import annotations

import math
import random
from typing import Iterable, Tuple


def egcd(a: int, b: int) -> Tuple[int, int, int]:
    if b == 0:
        return (a, 1, 0)
    g, x1, y1 = egcd(b, a % b)
    return (g, y1, x1 - (a // b) * y1)


def modinv(a: int, m: int) -> int:
    a %= m
    g, x, _ = egcd(a, m)
    if g != 1:
        raise ValueError(f"inverse does not exist for {a} mod {m}")
    return x % m


def lcm(a: int, b: int) -> int:
    return abs(a * b) // math.gcd(a, b)


def is_probable_prime(n: int, rounds: int = 12) -> bool:
    if n < 2:
        return False
    small_primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
    for p in small_primes:
        if n == p:
            return True
        if n % p == 0:
            return False
    # write n-1 = d * 2^s
    d = n - 1
    s = 0
    while d % 2 == 0:
        s += 1
        d //= 2
    for _ in range(rounds):
        a = random.randrange(2, n - 2)
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def random_prime(bits: int) -> int:
    if bits < 8:
        raise ValueError("bits must be >= 8")
    while True:
        n = random.getrandbits(bits)
        n |= (1 << (bits - 1)) | 1
        if is_probable_prime(n):
            return n


def prod(values: Iterable[int], mod: int | None = None) -> int:
    out = 1
    for v in values:
        out *= v
        if mod is not None:
            out %= mod
    return out
