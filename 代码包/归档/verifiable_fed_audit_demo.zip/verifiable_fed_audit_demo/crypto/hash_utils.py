"""Hash and serialization helpers for the demo.

This module intentionally uses deterministic JSON serialization so that
all protocol entities hash exactly the same byte representation.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any


def canonical(obj: Any) -> str:
    """Return a stable JSON representation of an object."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_hex(obj: Any) -> str:
    """Hash any JSON-serializable object and return a hex digest."""
    if isinstance(obj, bytes):
        data = obj
    elif isinstance(obj, str):
        data = obj.encode("utf-8")
    else:
        data = canonical(obj).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def sha256_int(obj: Any) -> int:
    return int(sha256_hex(obj), 16)


def hash_join(*items: Any) -> str:
    """Hash a tuple of items. This mimics H(a||b||c) in the paper."""
    return sha256_hex(list(items))
