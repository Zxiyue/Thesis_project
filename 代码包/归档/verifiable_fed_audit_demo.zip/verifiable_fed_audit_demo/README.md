# Verifiable Federated Audit Demo

这是一个用于演示当前论文方案主流程的 Python 可运行原型。它模拟：

- KGC 初始化系统参数、客户端集合、Pedersen 参数和 Paillier 公钥；
- 初始化声明 `InitTx` 写入模拟智能合约公告板；
- 每轮生成零和更新掩码和零和承诺随机数；
- 客户端训练、量化、加掩码、Paillier 加密、Pedersen 承诺、生成上传收据；
- CS 验证上传、构造 `rootUp_r`、密文聚合和承诺聚合；
- KGC 根据掉线集合生成密文补偿和承诺补偿；
- CS 恢复聚合明文并更新模型；
- KGC 检查 `ComAgg_r = PedCom(xAgg_r; 0)`，通过后发布 `FinalTx_r`；
- 模拟智能合约 `AuditBoard` 检查签名、轮次连续性、模型哈希连续性和链式审计根；
- 验证者 V 对完整审计链进行最终验证。

## 重要说明

本项目只用于论文方案流程演示，不是生产级密码系统实现：

1. 使用普通 Paillier 加密演示同态聚合；
2. 使用 Shamir 份额恢复 Paillier 私钥参数来模拟门限恢复流程；
3. 使用 toy RSA 签名实现消息认证演示；
4. Pedersen 参数生成和群选择用于演示同态承诺关系，不应用于真实系统。

## 运行方式

无需额外依赖，只需 Python 3.10+：

```bash
python main.py
```

预期输出示例：

```text
[AuditBoard] InitTx accepted.
--- Round 1 ---
recovered xAgg_r     = [...]
expected demo sum    = [...]
[AuditBoard] FinalTx round 1 accepted.
commitment check      = PASS
FinalTx published     = PASS
...
[Verifier] audit chain verification: PASS (3 rounds)
Audit result: PASS
```

## 当前链上字段

初始化声明：

```text
InitTx = (sysParaHash, Uroot, modelHash_0, auditRoot_0, sigInit)
```

每轮最终声明：

```text
FinalTx_r = (r, alpha_r, rootUp_r, ComAgg_r, modelHash_r, modelHash_{r+1}, auditRoot_r, sigFinal_r)
```

链式审计根：

```text
auditRoot_r = H(auditRoot_{r-1} || r || alpha_r || rootUp_r || ComAgg_r || modelHash_r || modelHash_{r+1})
```

当前主方案不使用 `ResultMap_r` 或 `verifyFlag_r`。只有 KGC 完成全部检查后，才生成并发布 `FinalTx_r`。
