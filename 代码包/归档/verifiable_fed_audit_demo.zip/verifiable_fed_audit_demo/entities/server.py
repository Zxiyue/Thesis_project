"""Aggregation server entity."""
from __future__ import annotations

from typing import Any, Dict, List

from crypto.hash_utils import sha256_hex
from crypto.merkle import merkle_root
from crypto.paillier import PaillierPublicKey, add_vectors, decrypt_vector_with_lambda
from crypto.pedersen import PedersenParams, multiply
from crypto.shamir_demo import recover_secret
from crypto.signature import RSAPrivateKey, RSAPublicKey, sign, verify
from protocol.messages import receipt_hash


class Server:
    def __init__(self, sig_key: RSAPrivateKey, threshold: int, shamir_prime: int):
        self.sig_key = sig_key
        self.threshold = threshold
        self.shamir_prime = shamir_prime

    @property
    def public_key(self) -> RSAPublicKey:
        return self.sig_key.public

    def verify_uploads(self, uploads: List[Dict[str, Any]], client_pubs: Dict[int, RSAPublicKey]) -> List[Dict[str, Any]]:
        valid = []
        for msg in uploads:
            cid = msg["i"]
            receipt = msg["Receipt"]
            if sha256_hex([int(x) for x in msg["C"]]) != msg["cHash"]:
                continue
            if receipt["cHash"] != msg["cHash"] or receipt["Com"] != msg["Com"]:
                continue
            if not verify(client_pubs[cid], msg["sigUp"], receipt):
                continue
            valid.append(msg)
        return sorted(valid, key=lambda x: x["i"])

    def build_root_up(self, valid_uploads: List[Dict[str, Any]]) -> str:
        leaves = [receipt_hash(m["Receipt"], m["sigUp"]) for m in valid_uploads]
        return merkle_root(leaves)

    def raw_aggregate(self, pub: PaillierPublicKey, params: PedersenParams, valid_uploads: List[Dict[str, Any]]) -> Dict[str, Any]:
        c_vectors = [[int(x) for x in m["C"]] for m in valid_uploads]
        c_raw = add_vectors(pub, c_vectors)
        com_raw = multiply(params, *[int(m["Com"]) for m in valid_uploads])
        return {"Craw": c_raw, "ComRaw": com_raw}

    def finalize_aggregate(
        self,
        pub: PaillierPublicKey,
        params: PedersenParams,
        round_id: int,
        alpha: str,
        root_up: str,
        raw: Dict[str, Any],
        drop_msg: Dict[str, Any],
    ) -> Dict[str, Any]:
        c_drop = [int(x) for x in drop_msg["Cdrop"]]
        c_agg = [(raw["Craw"][j] * c_drop[j]) % pub.n2 for j in range(len(c_drop))]
        com_agg = multiply(params, raw["ComRaw"], int(drop_msg["ComDrop"]))
        agg_msg = {
            "r": round_id,
            "alpha": alpha,
            "rootUp": root_up,
            "Cagg": [str(c) for c in c_agg],
            "caggHash": sha256_hex(c_agg),
            "ComAgg": str(com_agg),
        }
        sig_agg = sign(self.sig_key, agg_msg)
        return {"AggMsg": agg_msg, "sigAgg": sig_agg, "Cagg_vec": c_agg, "ComAgg": com_agg}

    def recover_plaintext(
        self,
        pub: PaillierPublicKey,
        share_messages: List[Dict[str, Any]],
        client_pubs: Dict[int, RSAPublicKey],
        cagg_hash: str,
        cagg_vec: List[int],
    ) -> List[int]:
        good_shares = []
        for sm in share_messages:
            payload = {"r": sm["r"], "j": sm["j"], "alpha": sm["alpha"], "share": tuple(sm["share"]), "caggHash": sm["caggHash"]}
            # The received share may be a list after JSON-like transport. Normalize for signature check.
            signed_payload = {"r": sm["r"], "j": sm["j"], "alpha": sm["alpha"], "share": sm["share"], "caggHash": sm["caggHash"]}
            if sm["caggHash"] != cagg_hash:
                continue
            if verify(client_pubs[sm["j"]], sm["sigShare"], signed_payload):
                good_shares.append(tuple(sm["share"]))
        if len(good_shares) < self.threshold:
            raise ValueError("not enough valid decryption shares")
        lam = recover_secret(good_shares[: self.threshold], self.shamir_prime)
        return decrypt_vector_with_lambda(pub, lam, cagg_vec)

    def make_model_msg(self, round_id: int, alpha: str, model_hash: str, model_hash_next: str, cagg_hash: str, com_agg: int) -> Dict[str, Any]:
        msg = {
            "r": round_id,
            "alpha": alpha,
            "modelHash_r": model_hash,
            "modelHash_next": model_hash_next,
            "caggHash": cagg_hash,
            "ComAgg": str(com_agg),
        }
        return {"ModelMsg": msg, "sigModel": sign(self.sig_key, msg)}
