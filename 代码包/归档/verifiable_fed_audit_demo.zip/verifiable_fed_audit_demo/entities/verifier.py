"""Public verifier."""
from __future__ import annotations

from typing import Any, Dict, List

from blockchain.audit_board import AuditBoard
from crypto.hash_utils import hash_join, sha256_hex
from crypto.signature import RSAPublicKey, verify
from protocol.messages import final_payload


class Verifier:
    def __init__(self, kgc_pub: RSAPublicKey):
        self.kgc_pub = kgc_pub

    def verify_board(self, board: AuditBoard, sys_para: Dict[str, Any], expected_rounds: int | None = None) -> bool:
        if board.init_tx is None:
            print("[Verifier] FAIL: no InitTx")
            return False
        init = board.init_tx
        init_payload = {
            "sysParaHash": init["sysParaHash"],
            "Uroot": init["Uroot"],
            "modelHash_0": init["modelHash_0"],
            "auditRoot_0": init["auditRoot_0"],
        }
        if sha256_hex(sys_para) != init["sysParaHash"]:
            print("[Verifier] FAIL: sysParaHash mismatch")
            return False
        if init["auditRoot_0"] != hash_join("AUDIT_INIT", init["sysParaHash"], init["Uroot"], init["modelHash_0"]):
            print("[Verifier] FAIL: auditRoot_0 mismatch")
            return False
        if not verify(self.kgc_pub, init["sigInit"], init_payload):
            print("[Verifier] FAIL: invalid InitTx signature")
            return False

        prev_root = init["auditRoot_0"]
        prev_model_next = init["modelHash_0"]
        prev_round = 0
        for tx in board.get_chain():
            if tx["r"] != prev_round + 1:
                print(f"[Verifier] FAIL: round continuity at {tx['r']}")
                return False
            if tx["modelHash_r"] != prev_model_next:
                print(f"[Verifier] FAIL: model hash continuity at {tx['r']}")
                return False
            expected = hash_join(prev_root, tx["r"], tx["alpha"], tx["rootUp"], tx["ComAgg"], tx["modelHash_r"], tx["modelHash_next"])
            if expected != tx["auditRoot"]:
                print(f"[Verifier] FAIL: audit root mismatch at {tx['r']}")
                return False
            if not verify(self.kgc_pub, tx["sigFinal"], final_payload(tx)):
                print(f"[Verifier] FAIL: invalid FinalTx signature at {tx['r']}")
                return False
            prev_root = tx["auditRoot"]
            prev_model_next = tx["modelHash_next"]
            prev_round = tx["r"]
        if expected_rounds is not None and len(board.get_chain()) != expected_rounds:
            print("[Verifier] FAIL: missing final rounds")
            return False
        print(f"[Verifier] audit chain verification: PASS ({len(board.get_chain())} rounds)")
        return True
