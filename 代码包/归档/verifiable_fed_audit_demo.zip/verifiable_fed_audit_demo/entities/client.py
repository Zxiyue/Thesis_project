"""Client entity."""
from __future__ import annotations

import random
from typing import Any, Dict, List, Tuple

from crypto.hash_utils import sha256_hex
from crypto.paillier import PaillierPublicKey, encrypt_vector
from crypto.pedersen import PedersenParams, commit
from crypto.signature import RSAPrivateKey, sign, verify
from protocol.messages import receipt_hash


class Client:
    def __init__(self, cid: int, sig_key: RSAPrivateKey, share: Tuple[int, int], dim: int, update_bound: int):
        self.cid = cid
        self.sig_key = sig_key
        self.share = share
        self.dim = dim
        self.update_bound = update_bound
        self.local_receipts: Dict[int, Dict[str, Any]] = {}

    @property
    def public_key(self):
        return self.sig_key.public

    def make_local_update(self, round_id: int, model: List[int]) -> List[int]:
        # Deterministic-ish local update for repeatable demos under global seed.
        return [random.randint(-self.update_bound, self.update_bound) for _ in range(self.dim)]

    def verify_mask_message(self, kgc_pub, msg: Dict[str, Any]) -> bool:
        payload = {
            "r": msg["r"],
            "i": msg["i"],
            "alpha": msg["alpha"],
            "m": msg["m"],
            "rho": msg["rho"],
        }
        return msg["i"] == self.cid and verify(kgc_pub, msg["sigMask"], payload)

    def train_and_upload(
        self,
        round_id: int,
        alpha: str,
        model_hash: str,
        model: List[int],
        mask_msg: Dict[str, Any],
        kgc_pub,
        paillier_pub: PaillierPublicKey,
        pedersen_params: PedersenParams,
    ) -> Dict[str, Any]:
        if not self.verify_mask_message(kgc_pub, mask_msg):
            raise ValueError(f"client {self.cid}: invalid mask message")
        x = self.make_local_update(round_id, model)
        m = mask_msg["m"]
        rho = mask_msg["rho"]
        x_mask = [x[j] + m[j] for j in range(self.dim)]
        c_vec = encrypt_vector(paillier_pub, x_mask)
        c_hash = sha256_hex(c_vec)
        com = commit(pedersen_params, x_mask, rho)
        receipt = {
            "r": round_id,
            "i": self.cid,
            "alpha": alpha,
            "modelHash_r": model_hash,
            "cHash": c_hash,
            "Com": str(com),
        }
        sig_up = sign(self.sig_key, receipt)
        up_msg = {
            "r": round_id,
            "i": self.cid,
            "alpha": alpha,
            "C": [str(c) for c in c_vec],
            "cHash": c_hash,
            "Com": str(com),
            "Receipt": receipt,
            "sigUp": sig_up,
            # Demo-only clear fields used to check expected sums in logs.
            "_demo_x": x,
            "_demo_xMask": x_mask,
        }
        self.local_receipts[round_id] = {"receipt": receipt, "sigUp": sig_up, "leaf": receipt_hash(receipt, sig_up)}
        return up_msg

    def make_share_message(self, round_id: int, alpha: str, cagg_hash: str) -> Dict[str, Any]:
        payload = {"r": round_id, "j": self.cid, "alpha": alpha, "share": self.share, "caggHash": cagg_hash}
        return {**payload, "sigShare": sign(self.sig_key, payload)}
