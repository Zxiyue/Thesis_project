"""KGC entity: setup, masks, compensation, and FinalTx generation."""
from __future__ import annotations

import random
from typing import Any, Dict, List

from crypto.hash_utils import hash_join, sha256_hex
from crypto.merkle import merkle_root
from crypto.paillier import PaillierKeypair, PaillierPublicKey, encrypt_vector, generate_keypair as gen_paillier
from crypto.pedersen import PedersenParams, commit, generate_params, multiply
from crypto.shamir_demo import split_secret
from crypto.signature import RSAPrivateKey, RSAPublicKey, generate_keypair as gen_sig_keypair, sign, verify
from protocol.messages import final_payload, receipt_hash


class KGC:
    def __init__(self, dim: int, n_clients: int, threshold: int, mask_bound: int):
        self.dim = dim
        self.n_clients = n_clients
        self.threshold = threshold
        self.mask_bound = mask_bound
        self.sig_key: RSAPrivateKey = gen_sig_keypair(256)
        self.paillier: PaillierKeypair = gen_paillier(256)
        self.pedersen: PedersenParams = generate_params(dim, 256)
        # Shamir prime must be larger than Paillier lambda. Use a probable prime with larger bit length.
        from crypto.math_utils import random_prime

        self.shamir_prime = random_prime(self.paillier.public.n.bit_length() + 32)
        self.shares = split_secret(self.paillier.private.lam, n_clients, threshold, self.shamir_prime)
        self.round_masks: Dict[int, Dict[int, List[int]]] = {}
        self.round_rhos: Dict[int, Dict[int, int]] = {}

    @property
    def public_key(self) -> RSAPublicKey:
        return self.sig_key.public

    def public_params(self) -> Dict[str, Any]:
        return {
            "paillier_pk": self.paillier.public.to_dict(),
            "pedersen_pp": self.pedersen.to_dict(),
            "threshold": self.threshold,
            "num_clients": self.n_clients,
        }

    def compute_uroot(self, client_pubs: Dict[int, RSAPublicKey]) -> str:
        leaves = [sha256_hex({"i": i, "pkSig": client_pubs[i].to_dict()}) for i in sorted(client_pubs)]
        return merkle_root(leaves)

    def make_init_tx(self, sys_para: Dict[str, Any], uroot: str, model_hash_0: str) -> Dict[str, Any]:
        sys_para_hash = sha256_hex(sys_para)
        audit_root_0 = hash_join("AUDIT_INIT", sys_para_hash, uroot, model_hash_0)
        payload = {
            "sysParaHash": sys_para_hash,
            "Uroot": uroot,
            "modelHash_0": model_hash_0,
            "auditRoot_0": audit_root_0,
        }
        return {**payload, "sigInit": sign(self.sig_key, payload)}

    def make_round_alpha(self, round_id: int, model_hash: str, uroot_r: str) -> str:
        return hash_join(round_id, model_hash, uroot_r)

    def generate_zero_sum_masks(self, round_id: int, client_ids: List[int]) -> Dict[int, Dict[str, Any]]:
        masks: Dict[int, List[int]] = {}
        rhos: Dict[int, int] = {}
        # n-1 random vector masks, last is negative sum.
        running = [0] * self.dim
        for cid in client_ids[:-1]:
            vec = [random.randint(-self.mask_bound, self.mask_bound) for _ in range(self.dim)]
            masks[cid] = vec
            running = [running[j] + vec[j] for j in range(self.dim)]
        masks[client_ids[-1]] = [-x for x in running]
        rho_sum = 0
        for cid in client_ids[:-1]:
            rho = random.randrange(0, self.pedersen.order)
            rhos[cid] = rho
            rho_sum = (rho_sum + rho) % self.pedersen.order
        rhos[client_ids[-1]] = (-rho_sum) % self.pedersen.order
        self.round_masks[round_id] = masks
        self.round_rhos[round_id] = rhos
        return {cid: {"m": masks[cid], "rho": rhos[cid]} for cid in client_ids}

    def make_mask_messages(self, round_id: int, alpha: str, client_ids: List[int]) -> Dict[int, Dict[str, Any]]:
        mask_data = self.generate_zero_sum_masks(round_id, client_ids)
        messages = {}
        for cid, data in mask_data.items():
            payload = {"r": round_id, "i": cid, "alpha": alpha, "m": data["m"], "rho": data["rho"]}
            messages[cid] = {**payload, "sigMask": sign(self.sig_key, payload)}
        return messages

    def verify_uploads(self, uploads: List[Dict[str, Any]], client_pubs: Dict[int, RSAPublicKey]) -> List[Dict[str, Any]]:
        valid = []
        for msg in uploads:
            cid = msg["i"]
            receipt = msg["Receipt"]
            if sha256_hex([int(x) for x in msg["C"]]) != msg["cHash"]:
                continue
            if receipt["cHash"] != msg["cHash"] or receipt["Com"] != msg["Com"]:
                continue
            if verify(client_pubs[cid], msg["sigUp"], receipt):
                valid.append(msg)
        return sorted(valid, key=lambda x: x["i"])

    def make_drop_message(
        self,
        round_id: int,
        alpha: str,
        all_client_ids: List[int],
        valid_client_ids: List[int],
    ) -> Dict[str, Any]:
        dropped = sorted(list(set(all_client_ids) - set(valid_client_ids)))
        m_drop = [0] * self.dim
        rho_drop = 0
        for cid in dropped:
            m = self.round_masks[round_id][cid]
            m_drop = [m_drop[j] + m[j] for j in range(self.dim)]
            rho_drop = (rho_drop + self.round_rhos[round_id][cid]) % self.pedersen.order
        c_drop = encrypt_vector(self.paillier.public, m_drop)
        com_drop = commit(self.pedersen, m_drop, rho_drop)
        payload = {
            "r": round_id,
            "alpha": alpha,
            "D": dropped,
            "Cdrop": [str(c) for c in c_drop],
            "cDropHash": sha256_hex(c_drop),
            "ComDrop": str(com_drop),
        }
        return {**payload, "sigDrop": sign(self.sig_key, payload), "_demo_mDrop": m_drop, "_demo_rhoDrop": rho_drop}

    def verify_and_make_final_tx(
        self,
        round_id: int,
        alpha: str,
        root_up: str,
        com_raw: int,
        drop_msg: Dict[str, Any],
        com_agg: int,
        x_agg: List[int],
        model_hash_r: str,
        model_hash_next: str,
        previous_audit_root: str,
        model_msg_signed: Dict[str, Any],
        server_pub: RSAPublicKey,
    ) -> Dict[str, Any]:
        # 1. Verify CS model message signature (chain-off evidence, not stored on-chain).
        if not verify(server_pub, model_msg_signed["sigModel"], model_msg_signed["ModelMsg"]):
            raise ValueError("KGC rejected: invalid CS model signature")
        mm = model_msg_signed["ModelMsg"]
        if mm["r"] != round_id or mm["alpha"] != alpha:
            raise ValueError("KGC rejected: model message state mismatch")
        if mm["modelHash_r"] != model_hash_r or mm["modelHash_next"] != model_hash_next:
            raise ValueError("KGC rejected: model hash mismatch")
        if int(mm["ComAgg"]) != com_agg:
            raise ValueError("KGC rejected: ComAgg mismatch")

        # 2. Verify ComAgg = ComRaw * ComDrop.
        expected_com_agg = multiply(self.pedersen, com_raw, int(drop_msg["ComDrop"]))
        if expected_com_agg != com_agg:
            raise ValueError("KGC rejected: aggregate commitment equation failed")
        # 3. Verify ComAgg = PedCom(xAgg; 0).
        if commit(self.pedersen, x_agg, 0) != com_agg:
            raise ValueError("KGC rejected: opening equation ComAgg=PedCom(xAgg;0) failed")

        audit_root = hash_join(previous_audit_root, round_id, alpha, root_up, str(com_agg), model_hash_r, model_hash_next)
        payload = {
            "r": round_id,
            "alpha": alpha,
            "rootUp": root_up,
            "ComAgg": str(com_agg),
            "modelHash_r": model_hash_r,
            "modelHash_next": model_hash_next,
            "auditRoot": audit_root,
        }
        return {**payload, "sigFinal": sign(self.sig_key, payload)}
