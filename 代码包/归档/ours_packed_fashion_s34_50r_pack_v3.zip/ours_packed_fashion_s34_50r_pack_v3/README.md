# Ours-packed Fashion-MNIST 2048-bit slot_bits=34 50-round experiments v3

v3 fixes the v2 issue where CS timing code could be inserted into `make_compensation`, causing `NameError: name 'timer' is not defined`.

Run:

```bash
cd /root
unzip -o ours_packed_fashion_s34_50r_pack_v3.zip
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
DATASETS="fashion_iid fashion_noniid" stdbuf -oL -eL \
  /root/ours_packed_fashion_s34_50r_pack_v3/scripts/run_ours_packed_fashion_s34_50r.sh \
  | tee /root/packed50_fashion_iid_noniid_v3.log
```

Status:

```bash
/root/ours_packed_fashion_s34_50r_pack_v3/scripts/check_ours_packed_fashion_s34_50r_status.sh
```

Combined output:

```text
/root/ours_packed_fashion_s34_50r_results.zip
```
