# FL Public Audit V1：真实联邦训练公开审计实验项目

本项目用于论文实验数据采集。它不是流程演示脚本，而是一个可复现实验工程，包含：

- MNIST 真实数据集训练；
- 多客户端联邦学习；
- 真实 ECDSA 签名；
- 真实 Merkle Root / Merkle Path；
- 大整数 Paillier 加密与同态聚合；
- Pedersen 向量承诺；
- Shamir 门限恢复实验模块；
- Hardhat + Solidity 智能合约公告板；
- `InitTx / FinalTx_r / FraudProofTx` 三类链上接口；
- 运行时间、密码开销、链上 Gas、准确率、审计链验证结果导出。

> 说明：V1 已使用真实数据、真实训练、真实签名、真实承诺、真实 Paillier 大整数加密、真实本地链交易。门限恢复部分采用 Shamir 共享 Paillier 私钥参数并门限重构后解密，用于实验测量和协议流程闭环；若论文需要严格的标准门限 Paillier 部分解密与 Combine，可在 V2 中替换 `fl_audit/crypto/shamir_recovery.py` 和恢复逻辑。

## 1. 环境准备

推荐：

- Python 3.10 或 3.11
- VSCode + Python 插件
- Node.js LTS
- Git

创建 Python 虚拟环境：

```bash
python -m venv .venv
```

Windows PowerShell：

```powershell
.\.venv\Scripts\Activate.ps1
```

macOS / Linux：

```bash
source .venv/bin/activate
```

安装 Python 依赖：

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

安装 Hardhat 依赖：

```bash
npm install
```

## 2. 启动本地区块链并部署合约

打开第一个终端：

```bash
npx hardhat node
```

打开第二个终端，在项目根目录执行：

```bash
npx hardhat compile
npx hardhat run scripts/deploy.js --network localhost
```

部署结果会保存到：

```text
outputs/contract.json
```

## 3. 运行正式实验

IID 数据划分：

```bash
python run.py --config configs/mnist_iid.yaml
```

Non-IID 数据划分：

```bash
python run.py --config configs/mnist_noniid.yaml
```

如果只想先测试训练和密码流程，不写入链上，可使用：

```bash
python run.py --config configs/mnist_iid.yaml --no-blockchain
```

## 4. 输出文件

每次实验会输出到配置文件中的 `output_dir`，例如：

```text
outputs/mnist_iid/
  metrics_round.csv       每轮准确率、损失、有效客户端数、掉线数
  runtime_cost.csv        各阶段运行时间
  crypto_cost.csv         加密、承诺、聚合等密码对象数量
  blockchain_cost.csv     InitTx / FinalTx 的真实交易哈希、区块高度、Gas、确认延迟
  audit_chain.csv         每轮 alpha、rootUp、ComAggHash、modelHash、auditRoot
  verify_result.csv       第三方验证结果
  summary_tables.xlsx     论文可直接整理的汇总表格
  run_trace.json          关键过程轨迹
```

## 5. 方案字段对应

初始化声明：

```text
InitTx=(sysParaHash,Uroot,modelHash_0,auditRoot_0,sigInit)
```

每轮最终声明：

```text
FinalTx_r=(r,alpha_r,rootUp_r,ComAgg_r,modelHash_r,modelHash_{r+1},auditRoot_r,sigFinal_r)
```

链式审计根：

```text
auditRoot_r=H(auditRoot_{r-1}||r||alpha_r||rootUp_r||ComAggHash_r||modelHash_r||modelHash_{r+1})
```

KGC 最终模型差分验证：

```text
uModel_r=(W_{r+1}-W_r)/server_lr
xModel_r=E_q(uModel_r)
ComAgg_r == PedCom(xModel_r;0)
```

第三方验证：

```text
1. 验证 KGC 对 InitTx / FinalTx_r 的签名；
2. 验证 r 连续；
3. 验证 modelHash_r 与上一轮 modelHash_{r+1} 连续；
4. 验证 auditRoot_r 连续。
```

## 6. 建议实验配置

为了先获得论文表格，建议按以下顺序跑：

1. `configs/mnist_iid.yaml`，客户端数 5，轮次 3；
2. 修改 clients 为 10、20，记录扩展性；
3. 修改 dropout 设置，记录掉线率影响；
4. 跑 `configs/mnist_noniid.yaml`，对比 IID 与 Non-IID。

## 7. 注意事项

- Paillier 对每个模型参数逐坐标加密，维度越高越慢。
- Logistic Regression MNIST 的模型维度为 7850，适合做第一版实验。
- `paillier_bits=512` 用于本地实验速度；论文安全讨论中可说明实际部署可提高到 1024/2048 bits。
- Hardhat 本地链用于获得真实交易、真实 Gas 和真实区块数据；不是 Python 字典模拟。
