from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict


@dataclass
class InitTx:
    sysParaHash: str
    Uroot: str
    modelHash0: str
    auditRoot0: str
    sigInit: str

    def payload(self) -> Dict[str, Any]:
        d = asdict(self)
        d.pop("sigInit")
        return d


@dataclass
class FinalTx:
    r: int
    alpha: str
    rootUp: str
    ComAgg: int
    ComAggHash: str
    modelHashR: str
    modelHashNext: str
    auditRoot: str
    sigFinal: str

    def payload(self) -> Dict[str, Any]:
        d = asdict(self)
        d.pop("sigFinal")
        return d


@dataclass
class FraudProofTx:
    r: int
    client_id: int
    receipt: Dict[str, Any]
    path: list
    claimType: str
    sigClient: str
