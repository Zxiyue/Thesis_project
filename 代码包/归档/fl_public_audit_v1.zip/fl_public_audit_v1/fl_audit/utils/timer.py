from __future__ import annotations

import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class TimerRecorder:
    rows: List[dict] = field(default_factory=list)

    @contextmanager
    def record(self, round_id: int, stage: str, detail: str = ""):
        start = time.perf_counter()
        try:
            yield
        finally:
            end = time.perf_counter()
            self.rows.append({
                "round": round_id,
                "stage": stage,
                "detail": detail,
                "seconds": end - start,
            })
