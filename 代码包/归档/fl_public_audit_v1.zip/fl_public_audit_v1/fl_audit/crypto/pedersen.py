from __future__ import annotations

from dataclasses import dataclass
from typing import List
import secrets

from fl_audit.crypto.number import gen_prime


@dataclass
class PedersenParams:
    p: int
    q: int
    g_vec: List[int]
    h: int


def make_params(dim: int, bits: int = 521) -> PedersenParams:
    # For experiment speed, generate a prime p and use q=p-1 as exponent modulus.
    # Production deployments should replace this with a vetted prime-order group.
    p = gen_prime(bits)
    q = p - 1
    bases = set()
    g_vec = []
    while len(g_vec) < dim + 1:
        b = secrets.randbelow(p - 3) + 2
        if b in bases:
            continue
        bases.add(b)
        if len(g_vec) < dim:
            g_vec.append(b)
        else:
            h = b
    return PedersenParams(p=p, q=q, g_vec=g_vec, h=h)


def commit(params: PedersenParams, x: List[int], rho: int) -> int:
    if len(x) != len(params.g_vec):
        raise ValueError(f"dimension mismatch: {len(x)} != {len(params.g_vec)}")
    acc = 1
    for gj, xj in zip(params.g_vec, x):
        acc = (acc * pow(gj, xj % params.q, params.p)) % params.p
    acc = (acc * pow(params.h, rho % params.q, params.p)) % params.p
    return acc


def mul(params: PedersenParams, values: List[int]) -> int:
    acc = 1
    for v in values:
        acc = (acc * v) % params.p
    return acc
