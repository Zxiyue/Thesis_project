"""Verbose execution demo for the flow-auditable FL protocol.

This script prints the concrete runtime data produced at each protocol stage,
so it is easier to inspect how InitTx, upload receipts, rootUp, ComAgg,
auditRoot, FinalTx and public verification are generated.

The code is a protocol-flow demo only. It uses toy signatures and a simulated
threshold Paillier interface for readability and fast local execution.
"""
from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from typing import Any, Dict, List

from blockchain.audit_board import AuditBoard
from core.client import Client
from core.kgc import KGC, model_hash
from core.server import Server
from core.verifier import PublicVerifier
from core.encoding import encode_update, decode_update, model_delta_to_encoded
from crypto import paillier, pedersen
from crypto.toy_signature import ToySigner
from crypto.utils import H_hex, merkle_root, sum_vec


def normalize(obj: Any) -> Any:
    if is_dataclass(obj):
        return normalize(asdict(obj))
    if isinstance(obj, dict):
        return {str(k): normalize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [normalize(v) for v in obj]
    return obj


def dump(title: str, obj: Any) -> None:
    print(f"\n[{title}]")
    print(json.dumps(normalize(obj), ensure_ascii=False, indent=2, sort_keys=True))


def line(title: str) -> None:
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


def main() -> None:
    # Keep the dimensions small so every vector, ciphertext and commitment can be printed.
    dim = 4
    n_clients = 5
    threshold = 3
    scale = 1000
    eta = 1.0
    rounds = 3

    line("0. Demo configuration")
    dump("configuration", {
        "dim": dim,
        "n_clients": n_clients,
        "threshold": threshold,
        "scale": scale,
        "eta": eta,
        "rounds": rounds,
        "note": "Round 2 simulates dropout of C5. Other rounds use all clients.",
    })

    client_signers = {f"C{i}": ToySigner(f"C{i}") for i in range(1, n_clients + 1)}
    clients = {cid: Client(cid, dim, signer) for cid, signer in client_signers.items()}
    client_pks = {cid: signer.pk for cid, signer in client_signers.items()}

    kgc = KGC(dim=dim, clients=client_pks, threshold=threshold, scale=scale, eta=eta)
    server_signer = ToySigner("CS")
    server = Server(dim, server_signer, client_pks, kgc.signer.pk, eta=eta, scale=scale)
    board = AuditBoard(kgc.signer.pk)

    line("1. System initialization")
    dump("client public keys", {cid: asdict(pk) for cid, pk in client_pks.items()})
    dump("KGC public key", asdict(kgc.signer.pk))
    dump("CS public key", asdict(server_signer.pk))
    dump("Pedersen public parameters pp_com", kgc.pp_com)
    dump("Paillier public key pk_p", kgc.paillier_kp.pk)
    dump("initial model W0", kgc.current_model)
    dump("modelHash_0", kgc.current_model_hash)
    dump("U", kgc.U)
    dump("Uroot", kgc.user_root())
    dump("sysPara", kgc.sys_params())
    dump("sysParaHash", H_hex(kgc.sys_params()))

    init_tx = kgc.make_init_tx()
    dump("InitTx", init_tx)
    board.submit_init(init_tx)
    dump("AuditBoard after submit_init", {
        "init": board.init_tx,
        "latest_round": board.latest_round,
        "latest_audit_root": board.latest_audit_root,
        "latest_model_hash": board.latest_model_hash,
    })

    for r in range(1, rounds + 1):
        line(f"2. Round {r}: round initialization")
        alpha = kgc.round_alpha(r)
        Uroot_r = kgc.user_root()
        dump("round state", {
            "r": r,
            "U_r": kgc.U,
            "Uroot_r": Uroot_r,
            "W_r": kgc.current_model,
            "modelHash_r": kgc.current_model_hash,
            "alpha_r = H(r||modelHash_r||Uroot_r)": alpha,
        })

        masks = kgc.make_mask_messages(r, alpha)
        mask_sum = sum_vec([masks[cid].mask for cid in kgc.U], dim)
        rho_sum = sum(masks[cid].rho for cid in kgc.U)
        dump("zero-sum check", {
            "sum_i m_i,r": mask_sum,
            "sum_i rho_i,r": rho_sum,
        })
        dump("MaskMsg_i,r for every client", {cid: masks[cid] for cid in kgc.U})

        line(f"3. Round {r}: client training, encryption, commitment and upload")
        active_ids = list(clients.keys())
        if r == 2:
            active_ids.remove("C5")
        dump("active clients for this round", active_ids)
        dump("dropout clients for this round", [cid for cid in kgc.U if cid not in active_ids])

        uploads = []
        upload_debug: Dict[str, Any] = {}
        for cid in active_ids:
            client = clients[cid]
            update = client.local_train(r, kgc.current_model)
            x = encode_update(update, scale)
            x_mask = [a + b for a, b in zip(x, masks[cid].mask)]
            up = client.build_upload(
                masks[cid],
                kgc.signer.pk,
                kgc.current_model_hash,
                kgc.current_model,
                scale,
                kgc.paillier_kp.pk,
                kgc.pp_com,
            )
            uploads.append(up)
            upload_debug[cid] = {
                "local real update u_i,r": update,
                "encoded update x_i,r": x,
                "mask m_i,r": masks[cid].mask,
                "masked update xMask_i,r": x_mask,
                "rho_i,r": masks[cid].rho,
                "ciphertext C_i,r": up.ciphertext,
                "cHash_i,r": up.cHash,
                "Com_i,r": up.commitment,
                "Receipt_i,r": up.receipt,
                "sigUp_i,r": up.sigUp,
                "check Com_i,r == PedCom(xMask_i,r;rho_i,r)": pedersen.commit(kgc.pp_com, x_mask, masks[cid].rho) == up.commitment,
                "check cHash_i,r == H(C_i,r)": H_hex(up.ciphertext) == up.cHash,
            }
        dump("client upload details", upload_debug)

        line(f"4. Round {r}: CS and KGC verify uploads and construct rootUp_r")
        cs_good, cs_root = server.verify_uploads(r, uploads)
        kgc_good, kgc_root = kgc.verify_uploads(r, uploads)
        sorted_good = sorted(kgc_good)
        receipt_leaves = [H_hex(kgc_good[cid].receipt) for cid in sorted_good]
        dump("CS upload verification result", {
            "valid set by CS": sorted(cs_good),
            "rootUp_r by CS": cs_root,
        })
        dump("KGC upload verification result", {
            "valid set by KGC": sorted_good,
            "Receipt leaf list H(Receipt_i,r), sorted by client id": receipt_leaves,
            "rootUp_r by KGC": kgc_root,
            "CS root == KGC root": cs_root == kgc_root,
        })
        assert cs_root == kgc_root

        line(f"5. Round {r}: dropout compensation")
        drop = kgc.build_drop_message(r, alpha, kgc_good)
        D = drop.D
        m_drop = sum_vec([kgc.masks[(r, cid)] for cid in D], dim) if D else [0] * dim
        rho_drop = sum(kgc.rhos[(r, cid)] for cid in D) if D else 0
        dump("DropMsg_r", drop)
        dump("dropout compensation details", {
            "D_r = U_r - U_r,1": D,
            "mDrop_r = sum_{j in D_r} m_j,r": m_drop,
            "rhoDrop_r = sum_{j in D_r} rho_j,r": rho_drop,
            "Cdrop_r": drop.Cdrop,
            "cDropHash_r": drop.cDropHash,
            "ComDrop_r": drop.ComDrop,
            "check cDropHash_r == H(Cdrop_r)": H_hex(drop.Cdrop) == drop.cDropHash,
            "check ComDrop_r == PedCom(mDrop_r;rhoDrop_r)": pedersen.commit(kgc.pp_com, m_drop, rho_drop) == drop.ComDrop,
        })

        line(f"6. Round {r}: CS homomorphic aggregation and commitment aggregation")
        Craw = paillier.add_ciphertext_vectors(kgc.paillier_kp.pk, [u.ciphertext for u in cs_good.values()])
        ComRaw = pedersen.mul(kgc.pp_com, [u.commitment for u in cs_good.values()])
        agg = server.aggregate(r, alpha, cs_root, drop, kgc.paillier_kp.pk, kgc.pp_com)
        expected_Cagg = [(a * b) % kgc.paillier_kp.pk.n2 for a, b in zip(Craw, drop.Cdrop)]
        expected_ComAgg = (ComRaw * drop.ComDrop) % kgc.pp_com.modulus
        dump("aggregation details", {
            "Craw_r = product C_i,r": Craw,
            "ComRaw_r = product Com_i,r": ComRaw,
            "Cagg_r = Craw_r * Cdrop_r": agg.Cagg,
            "ComAgg_r = ComRaw_r * ComDrop_r": agg.ComAgg,
            "sigAgg_r": agg.sigAgg,
            "check Cagg_r formula": expected_Cagg == agg.Cagg,
            "check ComAgg_r formula": expected_ComAgg == agg.ComAgg,
        })
        kgc_agg_ok = kgc.verify_aggregate(r, agg.Cagg, agg.ComAgg, drop)
        dump("KGC aggregate verification", {
            "verify_aggregate result": kgc_agg_ok,
            "round_comagg stored by KGC": kgc.round_comagg.get(r),
        })
        if not kgc_agg_ok:
            raise RuntimeError("KGC aggregate verification failed")

        line(f"7. Round {r}: partial decrypt shares")
        share_clients = active_ids[:threshold]
        shares = [clients[cid].make_share(kgc.threshold_paillier, r, alpha, agg.Cagg) for cid in share_clients]
        dump("share clients", share_clients)
        dump("ShareMsg_j,r and sigShare_j,r", [
            {"ShareMsg": msg, "sigShare": sig} for msg, sig in shares
        ])

        line(f"8. Round {r}: CS combines shares and updates model")
        x_agg = kgc.threshold_paillier.combine(agg.Cagg, [msg["d"] for msg, _ in shares])
        u_agg = decode_update(x_agg, scale)
        expected_next_model = [w + eta * u for w, u in zip(kgc.current_model, u_agg)]
        model_msg = server.combine_and_update(r, alpha, shares, client_pks, kgc.threshold_paillier, kgc.current_model)
        dump("recovered aggregate and model update", {
            "xAgg_r = Combine(shares)": x_agg,
            "uAgg_r = D_q(xAgg_r)": u_agg,
            "W_r": kgc.current_model,
            "W_next expected = W_r + eta*uAgg_r": expected_next_model,
            "ModelMsg_r from CS": model_msg,
            "check W_next formula": expected_next_model == model_msg.W_next,
            "check modelHash_r": model_hash(model_msg.W_r) == model_msg.modelHashR,
            "check modelHash_next": model_hash(model_msg.W_next) == model_msg.modelHashNext,
            "check ComAgg_r == PedCom(xAgg_r;0) at CS side": pedersen.commit(kgc.pp_com, x_agg, 0) == agg.ComAgg,
        })

        line(f"9. Round {r}: KGC final consistency check and FinalTx generation")
        x_model = model_delta_to_encoded(model_msg.W_r, model_msg.W_next, eta, scale)
        kgc_model_commit = pedersen.commit(kgc.pp_com, x_model, 0)
        dump("KGC model-difference verification input", {
            "ModelMsg_r": model_msg,
            "xModel_r = E_q((W_next-W_r)/eta)": x_model,
            "PedCom(xModel_r;0)": kgc_model_commit,
            "ComAgg_r already verified earlier": kgc.round_comagg[r],
            "check PedCom(xModel_r;0) == ComAgg_r": kgc_model_commit == kgc.round_comagg[r],
        })
        final_tx = kgc.make_final_tx(r, alpha, model_msg)
        dump("FinalTx_r", final_tx)
        board.submit_final(final_tx)
        dump("AuditBoard after submit_final", {
            "latest_round": board.latest_round,
            "latest_audit_root": board.latest_audit_root,
            "latest_model_hash": board.latest_model_hash,
            "number_of_final_txs": len(board.final_txs),
        })

    line("10. Public verifier")
    ok, reason = PublicVerifier(kgc.signer.pk).verify_board(board)
    dump("public verification result", {
        "accepted": ok,
        "reason": reason,
        "InitTx": board.init_tx,
        "FinalTx list": board.final_txs,
    })


if __name__ == "__main__":
    main()
