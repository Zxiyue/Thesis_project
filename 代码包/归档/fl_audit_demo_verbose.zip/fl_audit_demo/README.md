# Flow-Auditable Federated Learning Demo

This project is a runnable prototype matching the current scheme design:

- fixed-point encoding;
- zero-sum update masks;
- Paillier encrypted aggregation;
- Pedersen vector commitments with zero-randomness final aggregate commitment;
- KGC dropout compensation and final confirmation;
- smart-contract-style audit board with only three on-chain cases:
  `InitTx`, `FinalTx_r`, and `FraudProofTx`;
- audit root chain;
- third-party verification of `FinalTx_r` continuity.

## Important security note

This is a protocol-flow demonstration, not production cryptography. It uses:

- a toy Schnorr-like signature implementation;
- ordinary Paillier encryption;
- a simulated threshold recovery wrapper.

For a real deployment, replace these modules with audited libraries and a real threshold Paillier implementation.

## Project structure

```text
fl_audit_demo/
├── blockchain/
│   └── audit_board.py        # smart-contract-style audit board
├── core/
│   ├── client.py             # client training/upload/share logic
│   ├── encoding.py           # quantization and model-difference encoding
│   ├── kgc.py                # KGC masks, compensation, final tx
│   ├── messages.py           # dataclasses for protocol messages
│   ├── server.py             # CS aggregation and model update
│   └── verifier.py           # public verifier
├── crypto/
│   ├── paillier.py           # demo Paillier + simulated threshold wrapper
│   ├── pedersen.py           # Pedersen vector commitment
│   ├── toy_signature.py      # demo signatures
│   └── utils.py              # hashing, Merkle tree, helpers
├── demo.py                   # runnable end-to-end demo
└── requirements.txt          # no external dependency
```

## Run

```bash
python demo.py
```

Expected output includes accepted `InitTx`, accepted `FinalTx` for each round, and final verifier acceptance.

## How this maps to the scheme

### On-chain statements

`AuditBoard` accepts only three fixed statement types:

```python
submit_init(InitTx)
submit_final(FinalTx)
submit_fraud_proof(FraudProofTx)
```

### Final round statement

```python
FinalTx_r = (
    r,
    alpha_r,
    rootUp_r,
    ComAgg_r,
    modelHash_r,
    modelHash_{r+1},
    auditRoot_r,
    sigFinal_r,
)
```

### Audit root chain

```python
auditRoot_r = H(
    auditRoot_{r-1},
    r,
    alpha_r,
    rootUp_r,
    ComAgg_r,
    modelHash_r,
    modelHash_{r+1},
)
```

### Final KGC check

KGC does not require CS to send `xAgg_r` directly. Instead, CS sends `W_r` and `W_{r+1}`. KGC computes:

```python
xModel_r = E_q((W_{r+1} - W_r) / eta)
```

and checks:

```python
ComAgg_r == PedCom(xModel_r, 0)
```

Only after that does KGC submit `FinalTx_r`.

## Verbose protocol inspection

To print the concrete runtime data at every protocol stage, run:

```bash
python demo_verbose.py
```

This prints system parameters, `InitTx`, per-client masks, uploads, receipts, ciphertexts, Pedersen commitments, `rootUp_r`, dropout compensation, `Cagg_r`, `ComAgg_r`, decryption shares, model hashes, `FinalTx_r`, audit roots, and the final public verification result.

To save the full output:

```bash
python demo_verbose.py > verbose_run_log.txt
```
