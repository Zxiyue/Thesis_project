# VRAC-FL Comparison and Ablation Pack v1

本包用于补齐以下 8 组对比/消融实验，并提供一个不计入“8组”的共享完整方案对照：

1. E1 FedAvg；
2. E2 Privacy-only：门限 Paillier + 零和掩码，不做 Pedersen 和链上审计；
3. E3 只链上模型 Hash；
4. E4 无 Pedersen 向量承诺；
5. E5 无 KGC 独立掉线集合；
6. E6 无 FaultTx；
7. E7 无掉线单位元补偿优化；
8. E8 无 ModelSync 签名；
9. CONTROL：完整 VRAC-FL，512-bit、20轮配对对照。

## 最终轮数与密钥口径

- E1 FedAvg：50轮，不涉及 Paillier；
- E2 Privacy-only：50轮、2048-bit；
- E3–E8：统一 20轮、512-bit；
- CONTROL：20轮、512-bit；
- Full VRAC-FL 的 2048-bit、50轮主结果继续使用现有 Ours-basic/Ours-packed 结果，不因本包重复运行。

## 为什么采用共享 20 轮更新轨迹

E3–E8 都不改变本地优化器和数据划分。为保证不同弱化版本接收到完全相同的客户端更新，本包先用真实 MNIST 和 TinyCNN-6794 训练一次 20 轮，保存每轮五个客户端的加权量化更新；随后各消融版本在同一轨迹上执行实际的：

- 512-bit 门限 Paillier 加密、聚合、部分解密与 Combine；
- 零和掩码；
- Pedersen 向量承诺（未消融时）；
- ECDSA 上传收据和 ModelSync 来源认证测试；
- FinalTx、FaultTx 或 HashTx 的 Hardhat 真实上链。

这种 paired trace-replay 设计可以消除本地训练随机波动，并把实验重点放到密码、通信和审计组件本身。

## 模型

`TinyCNN6794` 的参数量严格为 6,794，与当前项目 tiny-CNN 维度口径一致：

- Conv(1→2, 3×3)
- MaxPool
- Conv(2→14, 3×3)
- MaxPool
- FC(350→18)
- FC(18→10)

## 代码执行边界

- E1、E2 为本包内的实际训练代码；
- E3–E8 为真实 MNIST 更新轨迹上的密码协议配对实验，不伪造准确率；
- E2 使用研究原型门限 Paillier参考实现，2048-bit 安全素数首次生成会较慢，之后从缓存读取；
- 本包不是生产密码库；固定 512-bit 参数仅用于功能与消融实验；
- Hardhat 合约仅允许 KGC 账户提交 FinalTx、HashTx 和 FaultTx；FaultTx 不推进成功审计根。

## 快速安装

```bash
cd /root
unzip -o vracfl_comparison_ablation_pack_v1.zip
cd vracfl_comparison_ablation_pack_v1
bash scripts/install.sh
```

安装后实际目录默认为：

```text
/root/fpa5/ablation_pack_v1
```

详细运行方式见《云服务器执行说明.md》。
