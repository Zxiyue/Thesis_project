#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import random
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import Sequence

import numpy as np
import torch

from common import Timer, seed_everything, write_csv, write_json
from model_data import (
    TinyCNN6794, assign_flat_model, build_data, evaluate, flatten_model,
    model_hash, parameter_count, train_local,
)
from threshold_paillier import PublicKey, ThresholdPaillier, ciphertext_bytes, encrypt_int, load_or_generate_factors


def _encrypt_vector_worker(args: tuple[int, int, list[int]]) -> list[int]:
    n, n2, values = args
    pk = PublicKey(n, n2)
    return [encrypt_int(pk, int(v)) for v in values]


def zero_sum_masks(n_clients: int, dimension: int, bound: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    masks = rng.integers(-bound, bound + 1, size=(n_clients - 1, dimension), dtype=np.int64)
    last = -masks.sum(axis=0, dtype=np.int64)
    return np.vstack([masks, last])


def main() -> None:
    ap = argparse.ArgumentParser(description="Privacy-only 50-round baseline: TPHE + zero-sum masks, no Pedersen or chain")
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--dataset", default="mnist")
    ap.add_argument("--split", choices=["iid", "noniid"], default="iid")
    ap.add_argument("--data-root", default="/root/fpa5/data")
    ap.add_argument("--rounds", type=int, default=50)
    ap.add_argument("--clients", type=int, default=5)
    ap.add_argument("--threshold", type=int, default=3)
    ap.add_argument("--paillier-bits", type=int, default=2048)
    ap.add_argument("--key-cache", default="/root/fpa5/cache/threshold_paillier_p2048.json")
    ap.add_argument("--local-epochs", type=int, default=1)
    ap.add_argument("--batch-size", type=int, default=64)
    ap.add_argument("--test-batch-size", type=int, default=512)
    ap.add_argument("--lr", type=float, default=0.20)
    ap.add_argument("--momentum", type=float, default=0.0)
    ap.add_argument("--scale", type=int, default=10000)
    ap.add_argument("--mask-bound", type=int, default=64)
    ap.add_argument("--seed", type=int, default=20260714)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--max-samples-per-client", type=int, default=0)
    ap.add_argument("--encrypt-workers", type=int, default=5)
    ap.add_argument("--dimension-limit", type=int, default=0, help="smoke test only; 0 uses all 6794 coordinates")
    ap.add_argument("--download", action="store_true")
    args = ap.parse_args()

    if args.threshold > args.clients:
        raise ValueError("threshold cannot exceed clients")
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    seed_everything(args.seed)
    device = torch.device(args.device)

    _, _, parts, loaders, test_loader = build_data(
        args.dataset, Path(args.data_root), args.split, args.clients,
        args.batch_size, args.test_batch_size, args.seed,
        args.max_samples_per_client, args.download,
    )
    sample_counts = np.asarray([len(p) for p in parts], dtype=np.int64)
    weights = sample_counts.astype(np.float64) / sample_counts.sum()

    p, q, keygen_s = load_or_generate_factors(args.paillier_bits, Path(args.key_cache))
    tp = ThresholdPaillier(p, q, args.clients, args.threshold, args.seed)
    model = TinyCNN6794().to(device)
    full_dim = parameter_count(model)
    dimension = full_dim if args.dimension_limit <= 0 else min(full_dim, args.dimension_limit)
    if dimension != full_dim:
        print(f"[WARN] dimension-limit={dimension}; this is smoke mode and does not update the full model", flush=True)

    metrics = []
    runtime_rows = []
    crypto_rows = []
    comm_rows = []
    verify_rows = []
    total_started = time.perf_counter()
    acc0, loss0 = evaluate(model, test_loader, device)
    metrics.append({"round": 0, "test_accuracy": acc0, "test_loss": loss0, "model_hash": model_hash(model)})

    pool = ProcessPoolExecutor(max_workers=max(1, args.encrypt_workers)) if args.encrypt_workers > 1 else None
    try:
        for rnd in range(1, args.rounds + 1):
            round_started = time.perf_counter()
            prev_flat = flatten_model(model)
            deltas = []
            train_times = []
            local_losses = []
            for cid, loader in enumerate(loaders, start=1):
                with Timer() as t:
                    delta, local_loss = train_local(model, loader, device, args.lr, args.local_epochs, args.momentum)
                qvec = torch.round(delta[:dimension] * float(weights[cid - 1]) * args.scale).to(torch.int64).cpu().numpy()
                deltas.append(qvec)
                train_times.append(t.elapsed)
                local_losses.append(local_loss)
            qmat = np.stack(deltas, axis=0).astype(np.int64)
            masks = zero_sum_masks(args.clients, dimension, args.mask_bound, args.seed + rnd * 1009)
            masked = qmat + masks

            with Timer() as enc_timer:
                jobs = [(tp.n, tp.n2, masked[cid].astype(object).tolist()) for cid in range(args.clients)]
                if pool is None:
                    encrypted = [_encrypt_vector_worker(x) for x in jobs]
                else:
                    encrypted = list(pool.map(_encrypt_vector_worker, jobs))
            with Timer() as agg_timer:
                cagg = tp.add_vectors(encrypted)
            with Timer() as share_timer:
                share_vectors = {
                    cid: tp.partial_decrypt_vector(cid, cagg)
                    for cid in range(1, args.threshold + 1)
                }
            with Timer() as combine_timer:
                recovered = np.asarray(tp.combine_vector(share_vectors), dtype=np.int64)
            expected = qmat.sum(axis=0, dtype=np.int64)
            verified = bool(np.array_equal(recovered, expected))
            if not verified:
                mismatch = int(np.flatnonzero(recovered != expected)[0]) if np.any(recovered != expected) else -1
                raise RuntimeError(f"privacy-only aggregate mismatch at round {rnd}, coordinate {mismatch}")

            if dimension == full_dim:
                next_flat = prev_flat + torch.from_numpy(recovered.astype(np.float64) / float(args.scale)).to(prev_flat.dtype)
                assign_flat_model(model, next_flat)
                acc, test_loss = evaluate(model, test_loader, device)
            else:
                acc, test_loss = float("nan"), float("nan")
            round_wall = time.perf_counter() - round_started
            metrics.append({
                "round": rnd,
                "test_accuracy": acc,
                "test_loss": test_loss,
                "mean_local_loss": float(np.mean(local_losses)),
                "model_hash": model_hash(model),
            })
            runtime_rows.append({
                "round": rnd,
                "local_train_sum_s": float(sum(train_times)),
                "local_train_parallel_wall_proxy_s": float(max(train_times)),
                "protocol_wall_s": enc_timer.elapsed + agg_timer.elapsed + share_timer.elapsed + combine_timer.elapsed,
                "round_wall_s": round_wall,
            })
            crypto_rows.extend([
                {"round": rnd, "operation": "paillier_encrypt", "seconds": enc_timer.elapsed, "count": args.clients * dimension},
                {"round": rnd, "operation": "cipher_aggregate", "seconds": agg_timer.elapsed, "count": dimension},
                {"round": rnd, "operation": "partial_decrypt", "seconds": share_timer.elapsed, "count": args.threshold * dimension},
                {"round": rnd, "operation": "threshold_combine", "seconds": combine_timer.elapsed, "count": dimension},
                {"round": rnd, "operation": "pedersen_commit", "seconds": 0.0, "count": 0},
                {"round": rnd, "operation": "blockchain", "seconds": 0.0, "count": 0},
            ])
            cbytes = ciphertext_bytes(tp.public_key)
            comm_rows.extend([
                {"round": rnd, "payload_type": "UpMsgCipher", "messages": args.clients, "bytes": args.clients * dimension * cbytes},
                {"round": rnd, "payload_type": "DecryptShare", "messages": args.threshold, "bytes": args.threshold * dimension * cbytes},
                {"round": rnd, "payload_type": "AuditBoard", "messages": 0, "bytes": 0},
            ])
            verify_rows.append({
                "round": rnd,
                "aggregate_recovered": verified,
                "pedersen_checked": False,
                "chain_checked": False,
                "accepted": verified,
            })
            print(json.dumps({
                "round": rnd, "accuracy": acc, "encrypt_s": enc_timer.elapsed,
                "combine_s": combine_timer.elapsed, "round_wall_s": round_wall,
            }), flush=True)
    finally:
        if pool is not None:
            pool.shutdown(wait=True, cancel_futures=False)

    total_wall = time.perf_counter() - total_started
    write_csv(out / "metrics_round.csv", metrics)
    write_csv(out / "runtime_cost.csv", runtime_rows)
    write_csv(out / "crypto_cost.csv", crypto_rows)
    write_csv(out / "communication_cost.csv", comm_rows)
    write_csv(out / "verify_result.csv", verify_rows)
    summary = {
        "experiment": "Privacy-only",
        "definition": "threshold Paillier + zero-sum masks; no Pedersen, FinalTx, FaultTx, or auditRoot",
        "dataset": args.dataset,
        "split": args.split,
        "rounds": args.rounds,
        "clients": args.clients,
        "threshold": args.threshold,
        "paillier_bits_actual": tp.n.bit_length(),
        "requested_paillier_bits": args.paillier_bits,
        "dimension": dimension,
        "model_dimension": full_dim,
        "keygen_s_excluded": keygen_s,
        "final_accuracy": metrics[-1]["test_accuracy"],
        "total_wall_s": total_wall,
        "accepted": all(bool(r["accepted"]) for r in verify_rows),
        "chain_gas": 0,
    }
    write_json(out / "summary.json", summary)
    write_json(out / "run_trace.json", {"summary": summary, "runtime": runtime_rows, "verify": verify_rows})
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
