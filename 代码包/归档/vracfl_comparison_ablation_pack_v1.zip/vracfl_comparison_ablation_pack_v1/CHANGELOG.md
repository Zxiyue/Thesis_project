# Changelog

## v1

- 固定“主性能50轮、其他消融20轮”的实验矩阵；
- 新增精确6794参数TinyCNN；
- 新增FedAvg 50轮基线；
- 新增Privacy-only 2048-bit 50轮基线；
- 新增共享MNIST 20轮更新轨迹；
- 新增Full、Hash-only、No-Pedersen、No-KGC-set、No-FaultTx、No-unit-opt、No-ModelSync-signature七个512-bit协议运行模式；
- 新增KGC-only AblationAuditBoard合约；
- 新增FinalTx、HashTx、FaultTx Gas和延迟统计；
- 新增聚合篡改、掉线集合、FaultTx可见性和ModelSync来源冒充安全探针；
- 新增自动汇总与结果打包脚本。
