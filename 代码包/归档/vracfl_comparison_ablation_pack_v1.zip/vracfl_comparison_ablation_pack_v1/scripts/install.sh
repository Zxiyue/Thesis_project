#!/usr/bin/env bash
set -euo pipefail

PACK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
TARGET="${TARGET_DIR:-$FPA5_ROOT/ablation_pack_v1}"
PYTHON_BIN="${PYTHON_BIN:-$FPA5_ROOT/.venv/bin/python3}"

if [[ ! -d "$FPA5_ROOT" ]]; then
  echo "[ERROR] fpa5 root not found: $FPA5_ROOT" >&2
  exit 1
fi
if [[ ! -x "$PYTHON_BIN" ]]; then
  PYTHON_BIN=python3
fi

rm -rf "$TARGET"
mkdir -p "$TARGET"
cp -a "$PACK_ROOT"/. "$TARGET"/
chmod +x "$TARGET"/scripts/*.sh "$TARGET"/src/*.py

# Locate and patch the existing Hardhat project.
HH_DIR="${HARDHAT_DIR:-}"
if [[ -z "$HH_DIR" ]]; then
  while IFS= read -r cfg; do
    HH_DIR="$(dirname "$cfg")"
    break
  done < <(find "$FPA5_ROOT" -maxdepth 5 -type f \( -name 'hardhat.config.js' -o -name 'hardhat.config.cjs' -o -name 'hardhat.config.ts' \) | sort)
fi
if [[ -n "$HH_DIR" && -d "$HH_DIR" ]]; then
  mkdir -p "$HH_DIR/contracts" "$HH_DIR/scripts"
  cp -f "$PACK_ROOT/blockchain_patch/contracts/AblationAuditBoard.sol" "$HH_DIR/contracts/"
  cp -f "$PACK_ROOT/blockchain_patch/scripts/ablation_deploy.js" "$HH_DIR/scripts/"
  cp -f "$PACK_ROOT/blockchain_patch/scripts/ablation_action.js" "$HH_DIR/scripts/"
  echo "$HH_DIR" > "$TARGET/.hardhat_dir"
  echo "[INFO] compiling contract in $HH_DIR"
  (cd "$HH_DIR" && npx hardhat compile)
else
  echo "[WARN] Hardhat project not found. Protocol computation can run, but chain replay will be skipped until HARDHAT_DIR is set."
fi

mkdir -p "$FPA5_ROOT/cache" "$FPA5_ROOT/outputs"

# Only install missing packages; this normally reuses the existing fpa5 venv.
"$PYTHON_BIN" - <<'PY'
mods = ['numpy','yaml','cryptography','torch','torchvision','sympy']
missing=[]
for m in mods:
    try: __import__(m)
    except Exception: missing.append(m)
print('missing=' + ','.join(missing))
PY

echo "[DONE] installed to $TARGET"
echo "PYTHON_BIN=$PYTHON_BIN"
echo "Next: cd $TARGET && bash scripts/preflight.sh"
