#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
bash "$ROOT/scripts/run_main_performance_50r.sh"
bash "$ROOT/scripts/run_ablation_20r.sh"
