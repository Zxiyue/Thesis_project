#!/usr/bin/env bash
set -euo pipefail
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
OUT_ROOT="${OUT_ROOT:-$FPA5_ROOT/outputs/comparison_ablation_v1}"
echo "output_root=$OUT_ROOT"
find "$OUT_ROOT" -maxdepth 3 -type f \( -name summary.json -o -name chain_result.json -o -name '*.log' \) -printf '%TY-%Tm-%Td %TH:%TM %p\n' 2>/dev/null | sort || true
echo "--- running processes ---"
ps -eo pid,etime,%cpu,%mem,cmd | grep -E 'run_(fedavg|privacy_only|ablation_20r|build_update_trace)' | grep -v grep || true
