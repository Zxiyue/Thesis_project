#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path
import pandas as pd


def read_csv(p: Path) -> pd.DataFrame:
    try:
        return pd.read_csv(p)
    except Exception:
        return pd.DataFrame()


def find_col(df: pd.DataFrame, names: list[str]) -> str | None:
    lower = {c.lower(): c for c in df.columns}
    for n in names:
        if n.lower() in lower:
            return lower[n.lower()]
    for c in df.columns:
        cl = c.lower()
        for n in names:
            if n.lower() in cl:
                return c
    return None


def boolish(x):
    if isinstance(x, bool):
        return x
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return None
    return str(x).strip().lower() in {'true', '1', 'yes', 'y', 'accepted'}


def safe_name(x: object, limit: int = 64) -> str:
    return re.sub(r'[^A-Za-z0-9]+', '_', str(x)).strip('_')[:limit] or 'unknown'


def infer_dim_from_model(model: str | None) -> int | None:
    if not model:
        return None
    s = str(model).lower().replace('-', '_')
    fixed = {
        'tiny_cnn': 6794,
        'cnn_tiny': 6794,
        'cnn': 6794,
        'logistic_regression': 7850,
        'linear': 7850,
        'softmax': 7850,
        'logistic': 7850,
        'mlp': 12730,
        'mlp16': 12730,
        'small_mlp': 12730,
        'small_cnn': 26666,
        'cnn_small': 26666,
    }
    if s in fixed:
        return fixed[s]
    m = re.match(r'^(synthetic|syn|pad|padded)(?:_?d)?_?(\d+)(k?)$', s)
    if m:
        v = int(m.group(2))
        if m.group(3) == 'k':
            v *= 1000
        return v
    return None


def parse_runtime_yaml_text(txt: str) -> dict:
    row = {}
    patterns = [
        ('clients', r'clients:\s*(\d+)', int),
        ('rounds_configured', r'rounds:\s*(\d+)', int),
        ('threshold', r'threshold:\s*(\d+)', int),
        ('paillier_bits', r'paillier_bits:\s*(\d+)', int),
        ('slot_bits', r'slot_bits:\s*(\d+)', int),
        ('expected_dim', r'expected_dim:\s*(\d+)', int),
    ]
    for key, pat, typ in patterns:
        m = re.search(pat, txt)
        if m:
            row[key] = typ(m.group(1))
    m = re.search(r'model:\s*\n(?:\s+[^\n]+\n)*?\s+name:\s*([A-Za-z0-9_\-]+)', txt)
    if m:
        row['model'] = m.group(1)
    return row


def summarize_one(run_dir: Path) -> dict:
    row = {'case': run_dir.name, 'run_dir': str(run_dir)}
    cfg_candidates = list(run_dir.parent.glob(f'{run_dir.name}_runtime.yaml')) + list(run_dir.glob('*runtime*.yaml'))
    if cfg_candidates:
        row.update(parse_runtime_yaml_text(cfg_candidates[0].read_text(encoding='utf-8', errors='ignore')))
    if 'model' not in row:
        # case name e.g., d006794_tiny
        row['model'] = run_dir.name
    inferred = infer_dim_from_model(row.get('model'))
    if inferred is not None:
        row['model_dim_expected'] = int(inferred)
    if row.get('expected_dim', 0):
        row['model_dim_expected'] = int(row['expected_dim'])

    vr = read_csv(run_dir / 'verify_result.csv')
    if not vr.empty:
        for col in vr.columns:
            val = vr.iloc[-1][col]
            if col.lower() in {'accepted', 'verify_accepted', 'third_party_accepted'}:
                row['accepted'] = boolish(val)
            elif col.lower() in {'completed', 'success'}:
                row['completed'] = boolish(val)
            else:
                row[f'verify_{col}'] = val

    metrics = read_csv(run_dir / 'metrics.csv')
    if metrics.empty:
        metrics = read_csv(run_dir / 'metrics_round.csv')
    if not metrics.empty:
        rcol = find_col(metrics, ['round', 'r'])
        if rcol:
            rr = pd.to_numeric(metrics[rcol], errors='coerce').dropna()
            row['rounds_completed'] = int(rr.max()) if len(rr) else len(metrics)
        else:
            row['rounds_completed'] = len(metrics)
        acc_col = find_col(metrics, ['test_acc', 'accuracy', 'acc'])
        loss_col = find_col(metrics, ['test_loss', 'loss'])
        if acc_col:
            accs = pd.to_numeric(metrics[acc_col], errors='coerce').dropna()
            row['final_accuracy'] = float(accs.iloc[-1]) if len(accs) else 0.0
        if loss_col:
            losses = pd.to_numeric(metrics[loss_col], errors='coerce').dropna()
            row['final_loss'] = float(losses.iloc[-1]) if len(losses) else 0.0
    else:
        row.setdefault('rounds_completed', 0)

    comm = read_csv(run_dir / 'communication_cost.csv')
    if not comm.empty:
        bytes_col = find_col(comm, ['bytes', 'size_bytes', 'actual_bytes', 'total_bytes'])
        ptype_col = find_col(comm, ['payload_type', 'type', 'message_type'])
        sec_col = find_col(comm, ['actual_seconds', 'seconds', 'elapsed_seconds'])
        if bytes_col:
            b = pd.to_numeric(comm[bytes_col], errors='coerce').fillna(0)
            row['comm_rows'] = len(comm)
            row['total_comm_bytes'] = int(b.sum())
            row['total_comm_MB'] = float(b.sum() / 1024 / 1024)
            rounds = int(row.get('rounds_completed', row.get('rounds_configured', 1)) or 1)
            row['comm_MB_per_round'] = row['total_comm_MB'] / max(1, rounds)
        if sec_col:
            secs = pd.to_numeric(comm[sec_col], errors='coerce').dropna()
            row['comm_actual_seconds_sum'] = float(secs.sum()) if len(secs) else 0.0
        if ptype_col and bytes_col:
            temp = comm.assign(_bytes=pd.to_numeric(comm[bytes_col], errors='coerce').fillna(0))
            grp = temp.groupby(ptype_col)['_bytes'].sum().sort_values(ascending=False)
            for ptype, val in grp.items():
                row['comm_MB_' + safe_name(ptype, 60)] = float(val / 1024 / 1024)

    bc = read_csv(run_dir / 'blockchain_cost.csv')
    if not bc.empty:
        gas_col = find_col(bc, ['gas_used', 'gas', 'gasUsed'])
        tx_col = find_col(bc, ['tx_type', 'type', 'name'])
        if gas_col:
            gas = pd.to_numeric(bc[gas_col], errors='coerce').fillna(0)
            row['chain_tx_count'] = int(len(bc))
            row['total_gas'] = int(gas.sum())
            if tx_col:
                txs = bc[tx_col].astype(str)
                init = bc[txs.str.contains('Init', case=False, na=False)]
                final = bc[txs.str.contains('Final', case=False, na=False)]
                if len(init):
                    row['init_tx_gas'] = int(pd.to_numeric(init[gas_col], errors='coerce').dropna().iloc[0])
                if len(final):
                    fg = pd.to_numeric(final[gas_col], errors='coerce').dropna()
                    row['finaltx_count'] = int(len(final))
                    row['avg_finaltx_gas'] = float(fg.mean()) if len(fg) else 0.0
                    row['min_finaltx_gas'] = int(fg.min()) if len(fg) else 0
                    row['max_finaltx_gas'] = int(fg.max()) if len(fg) else 0

    rt = read_csv(run_dir / 'runtime_cost.csv')
    if not rt.empty:
        stage_col = find_col(rt, ['stage'])
        sec_col = find_col(rt, ['seconds'])
        if stage_col and sec_col:
            rt = rt.copy()
            rt['_sec'] = pd.to_numeric(rt[sec_col], errors='coerce')
            grp = rt.groupby(stage_col)['_sec'].agg(['sum', 'mean', 'count'])
            for stage, vals in grp.iterrows():
                sn = safe_name(stage, 72)
                row[f'runtime_sum_{sn}'] = float(vals['sum']) if pd.notna(vals['sum']) else 0.0
                row[f'runtime_mean_{sn}'] = float(vals['mean']) if pd.notna(vals['mean']) else 0.0
                row[f'runtime_count_{sn}'] = int(vals['count'])
            if 'client_upload_parallel_wall' in grp.index:
                row['total_upload_wall_sum'] = float(grp.loc['client_upload_parallel_wall', 'sum'])

    crypto = read_csv(run_dir / 'crypto_cost.csv')
    if not crypto.empty:
        metric_col = find_col(crypto, ['metric', 'stage', 'name'])
        value_col = find_col(crypto, ['value', 'seconds', 'count'])
        if metric_col and value_col:
            for metric, sub in crypto.groupby(metric_col):
                vals = pd.to_numeric(sub[value_col], errors='coerce').dropna()
                if len(vals):
                    row['crypto_mean_' + safe_name(metric, 72)] = float(vals.mean())
                    row['crypto_sum_' + safe_name(metric, 72)] = float(vals.sum())
            # Prefer recorded model dimension if available.
            for metric, sub in crypto.groupby(metric_col):
                if 'dimension' in str(metric).lower() or 'model_dim' in str(metric).lower():
                    vals = pd.to_numeric(sub[value_col], errors='coerce').dropna()
                    if len(vals):
                        row['model_dim_actual'] = int(round(float(vals.mean())))
                        break

    if 'model_dim_actual' not in row and 'model_dim_expected' in row:
        row['model_dim_actual'] = row['model_dim_expected']
    return row


def md_table(df: pd.DataFrame, cols: list[str]) -> str:
    cols = [c for c in cols if c in df.columns]
    if not cols:
        return ''
    tmp = df[cols].copy()
    def fmt(x):
        if isinstance(x, float):
            return f'{x:.4f}'.rstrip('0').rstrip('.')
        return str(x)
    rows = []
    header = '| ' + ' | '.join(cols) + ' |'
    sep = '| ' + ' | '.join(['---'] * len(cols)) + ' |'
    rows.extend([header, sep])
    for _, r in tmp.iterrows():
        rows.append('| ' + ' | '.join(fmt(r[c]) for c in cols) + ' |')
    return '\n'.join(rows)


def write_markdown(base_dir: Path, summary: pd.DataFrame) -> None:
    md = []
    md.append('# Model Dimension Multiprocess Experiment Summary\n')
    md.append('This report is generated from result CSV files. Synthetic cases are padded-vector dimension experiments for cryptographic scalability, not accuracy-oriented model architecture comparisons.\n')
    if not summary.empty:
        cols = ['case','model','model_dim_actual','clients','threshold','rounds_completed','accepted','total_comm_MB','comm_MB_per_round','runtime_mean_start_experiment_total_wall','avg_finaltx_gas','total_gas']
        md.append(md_table(summary, cols))
        if 'model_dim_actual' in summary.columns and 'total_comm_MB' in summary.columns and len(summary) >= 2:
            x = pd.to_numeric(summary['model_dim_actual'], errors='coerce')
            y = pd.to_numeric(summary['total_comm_MB'], errors='coerce')
            ok = x.notna() & y.notna()
            if ok.sum() >= 2:
                import numpy as np
                coef = np.polyfit(x[ok].astype(float), y[ok].astype(float), 1)
                pred = coef[0] * x[ok].astype(float) + coef[1]
                ss_res = float(((y[ok].astype(float) - pred) ** 2).sum())
                ss_tot = float(((y[ok].astype(float) - y[ok].astype(float).mean()) ** 2).sum())
                r2 = 1 - ss_res / ss_tot if ss_tot else 1.0
                md.append(f'\nCommunication linear fit: total_comm_MB ≈ {coef[0]:.6f} × d + {coef[1]:.4f}, R²={r2:.6f}.\n')
    (base_dir / 'model_dim_result_analysis.md').write_text('\n\n'.join(md), encoding='utf-8')


def write_zip(base_dir: Path, zip_out: Path, extra_files: list[Path] | None = None) -> None:
    zip_out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_out, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(base_dir.rglob('*')):
            if p.is_file():
                zf.write(p, arcname=str(base_dir.name + '/' + p.relative_to(base_dir).as_posix()))
        for p in extra_files or []:
            if p.exists() and p.is_file():
                zf.write(p, arcname=str(base_dir.name + '/logs/' + p.name))
    print(f'[OK] zip written: {zip_out}')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base-dir', required=True)
    ap.add_argument('--zip-out', required=True)
    ap.add_argument('--extra-log', action='append', default=[])
    args = ap.parse_args()

    base_dir = Path(args.base_dir).resolve()
    if not base_dir.exists():
        raise SystemExit(f'[ERROR] base-dir not found: {base_dir}')
    runs = sorted([p for p in base_dir.iterdir() if p.is_dir() and p.name.startswith('d')])
    rows = [summarize_one(p) for p in runs]
    summary = pd.DataFrame(rows)
    if not summary.empty:
        if 'model_dim_actual' in summary.columns:
            summary['_dim_sort'] = pd.to_numeric(summary['model_dim_actual'], errors='coerce')
            summary = summary.sort_values(['_dim_sort', 'case']).drop(columns=['_dim_sort'])
        summary.to_csv(base_dir / 'model_dim_summary.csv', index=False)
        gas_cols = [c for c in ['case','model','model_dim_actual','chain_tx_count','init_tx_gas','finaltx_count','avg_finaltx_gas','total_gas'] if c in summary.columns]
        summary[gas_cols].to_csv(base_dir / 'gas_by_model_dim.csv', index=False)
        comm_cols = [c for c in ['case','model','model_dim_actual','total_comm_MB','comm_MB_per_round','comm_MB_UpMsg','comm_MB_AggMsg','comm_rows'] if c in summary.columns]
        summary[comm_cols].to_csv(base_dir / 'communication_by_model_dim.csv', index=False)
        runtime_cols = [c for c in summary.columns if c.startswith('runtime_mean_') or c.startswith('runtime_sum_')]
        keep = [c for c in ['case','model','model_dim_actual','rounds_completed','accepted'] if c in summary.columns] + runtime_cols
        summary[keep].to_csv(base_dir / 'runtime_by_model_dim.csv', index=False)
    else:
        pd.DataFrame().to_csv(base_dir / 'model_dim_summary.csv', index=False)
    write_markdown(base_dir, summary)
    write_zip(base_dir, Path(args.zip_out), [Path(x) for x in args.extra_log])
    print('[OK] summary rows:', len(summary))
    if not summary.empty:
        print(summary[[c for c in ['case','model','model_dim_actual','accepted','total_comm_MB','runtime_mean_start_experiment_total_wall','avg_finaltx_gas'] if c in summary.columns]].to_string(index=False))


if __name__ == '__main__':
    main()
