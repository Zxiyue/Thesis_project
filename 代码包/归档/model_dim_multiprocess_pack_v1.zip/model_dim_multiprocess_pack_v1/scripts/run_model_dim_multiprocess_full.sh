#!/usr/bin/env bash
set -euo pipefail

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
CLIENTS="${CLIENTS:-10}"
THRESHOLD="${THRESHOLD:-6}"
ROUNDS="${ROUNDS:-10}"
PAILLIER_BITS="${PAILLIER_BITS:-512}"
SLOT_BITS="${SLOT_BITS:-40}"
BLOCKCHAIN="${BLOCKCHAIN:-on}"
CLIENT_MODE="${CLIENT_MODE:-individual}"
CLIENTS_PER_WORKER="${CLIENTS_PER_WORKER:-20}"
DATASET_DIR="${DATASET_DIR:-/mnt/fpa5/data}"
BASE_OUT="${BASE_OUT:-outputs/model_dim_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain}"
ZIP_OUT="${ZIP_OUT:-/root/model_dim_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_results.zip}"
SUITE_LOG="${SUITE_LOG:-/root/model_dim_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain.log}"
CLEAN_BASE_OUT="${CLEAN_BASE_OUT:-1}"
# Format: case=model:expected_dim . The run order is ascending dimension.
DIM_CASES="${DIM_CASES:-tiny=tiny_cnn:6794 logistic=logistic_regression:7850 syn10k=synthetic_10000:10000 mlp=mlp:12730 small=small_cnn:26666 syn50k=synthetic_50000:50000 syn100k=synthetic_100000:100000}"

if [[ ! -d "$FPA5_ROOT" ]]; then
  echo "[ERROR] FPA5_ROOT not found: $FPA5_ROOT" >&2
  exit 1
fi

cd "$FPA5_ROOT"
if [[ -x "$FPA5_ROOT/.venv/bin/python" ]]; then
  PY="$FPA5_ROOT/.venv/bin/python"
elif [[ -x "$FPA5_ROOT/.venv/bin/python3" ]]; then
  PY="$FPA5_ROOT/.venv/bin/python3"
elif command -v python3 >/dev/null 2>&1; then
  PY="$(command -v python3)"
elif command -v python >/dev/null 2>&1; then
  PY="$(command -v python)"
else
  echo "[ERROR] python not found" >&2
  exit 1
fi

mkdir -p "$(dirname "$SUITE_LOG")"
echo "[INFO] using python: $PY" | tee "$SUITE_LOG"
echo "[INFO] dim cases: $DIM_CASES" | tee -a "$SUITE_LOG"
echo "[INFO] clients=$CLIENTS; threshold=$THRESHOLD; rounds=$ROUNDS; mode=$CLIENT_MODE; chain=$BLOCKCHAIN" | tee -a "$SUITE_LOG"

export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
export NUMEXPR_NUM_THREADS="${NUMEXPR_NUM_THREADS:-1}"
export TORCH_NUM_THREADS="${TORCH_NUM_THREADS:-1}"
export PYTHONDONTWRITEBYTECODE=1
export FPA5_ROOT

kill_old_ports() {
  local pids
  pids=$(ss -ltnp 2>/dev/null | grep -E '127\.0\.0\.1:(9200|9300|94[0-9]{2}|9500)\b' | sed -n 's/.*pid=\([0-9]\+\).*/\1/p' | sort -u || true)
  if [[ -n "${pids:-}" ]]; then
    echo "[INFO] killing old endpoint pids: $pids" | tee -a "$SUITE_LOG"
    for p in $pids; do kill -9 "$p" 2>/dev/null || true; done
  fi
}

patch_start_timeout() {
  "$PY" - <<'PY'
from pathlib import Path
import os
p = Path(os.environ.get('FPA5_ROOT', '/root/fpa5')) / 'scripts/start_all_entities.py'
if not p.exists():
    print('[WARN] start_all_entities.py not found')
    raise SystemExit(0)
s = p.read_text(encoding='utf-8')
s2 = s.replace('timeout: float = 60.0', 'timeout: float = 600.0')
s2 = s2.replace('timeout: float = 300.0', 'timeout: float = 600.0')
if s2 != s:
    p.write_text(s2, encoding='utf-8')
    print('[OK] patched start_all_entities health timeout to 600s')
else:
    print('[INFO] health timeout already patched or target not found')
PY
}

ensure_hardhat_node() {
  if [[ "$BLOCKCHAIN" != "on" ]]; then
    return 0
  fi
  if curl -s --max-time 2 -H 'Content-Type: application/json' \
      --data '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}' \
      http://127.0.0.1:8545 >/dev/null 2>&1; then
    echo "[INFO] Hardhat node already running" | tee -a "$SUITE_LOG"
    return 0
  fi
  echo "[INFO] starting Hardhat node ..." | tee -a "$SUITE_LOG"
  nohup npx hardhat node --hostname 127.0.0.1 > /root/hardhat_model_dim.log 2>&1 &
  echo $! > /root/hardhat_model_dim.pid
  for i in $(seq 1 60); do
    if curl -s --max-time 2 -H 'Content-Type: application/json' \
        --data '{"jsonrpc":"2.0","method":"eth_chainId","params":[],"id":1}' \
        http://127.0.0.1:8545 >/dev/null 2>&1; then
      echo "[OK] Hardhat node is ready" | tee -a "$SUITE_LOG"
      return 0
    fi
    sleep 1
  done
  echo "[ERROR] Hardhat node not ready; check /root/hardhat_model_dim.log" >&2
  exit 1
}

deploy_contract() {
  if [[ "$BLOCKCHAIN" != "on" ]]; then
    return 0
  fi
  echo "[INFO] Deploying fresh AuditBoard ..." | tee -a "$SUITE_LOG"
  npx hardhat run scripts/deploy.js --network localhost 2>&1 | tee -a "$SUITE_LOG"
}

case_dir_name() {
  local label="$1"
  local dim="$2"
  printf 'd%06d_%s' "$dim" "$label"
}

run_one() {
  local entry="$1"
  local label="${entry%%=*}"
  local rest="${entry#*=}"
  local model="${rest%%:*}"
  local dim="${rest##*:}"
  local case_id
  case_id=$(case_dir_name "$label" "$dim")
  local out_dir="${BASE_OUT}/${case_id}"
  local cfg="${BASE_OUT}/${case_id}_runtime.yaml"

  echo "" | tee -a "$SUITE_LOG"
  echo "================ RUN model-dim clients=${CLIENTS}, threshold=${THRESHOLD}, rounds=${ROUNDS}, model=${model}, dim=${dim}, mode=${CLIENT_MODE}, chain=${BLOCKCHAIN} (${case_id}) ================" | tee -a "$SUITE_LOG"

  mkdir -p "$(dirname "$cfg")"
  "$PY" "$PACK_DIR/scripts/generate_model_dim_runtime_config.py" \
    --out "$cfg" \
    --output-dir "$out_dir" \
    --clients "$CLIENTS" \
    --rounds "$ROUNDS" \
    --threshold "$THRESHOLD" \
    --model "$model" \
    --expected-dim "$dim" \
    --paillier-bits "$PAILLIER_BITS" \
    --slot-bits "$SLOT_BITS" \
    --blockchain "$BLOCKCHAIN" \
    --client-mode "$CLIENT_MODE" \
    --clients-per-worker "$CLIENTS_PER_WORKER" \
    --dataset-dir "$DATASET_DIR" 2>&1 | tee -a "$SUITE_LOG"

  deploy_contract
  kill_old_ports

  echo "[INFO] Starting KGC/CS/Client HTTP entities ..." | tee -a "$SUITE_LOG"
  "$PY" scripts/start_all_entities.py --config "$cfg" --clients "$CLIENTS" 2>&1 | tee -a "$SUITE_LOG"

  set +e
  echo "[INFO] Starting CS-driven experiment ..." | tee -a "$SUITE_LOG"
  "$PY" scripts/start_experiment.py --config "$cfg" 2>&1 | tee -a "$SUITE_LOG"
  local run_rc=${PIPESTATUS[0]}

  echo "[INFO] Collecting results ..." | tee -a "$SUITE_LOG"
  "$PY" scripts/collect_results.py --config "$cfg" 2>&1 | tee -a "$SUITE_LOG"
  local collect_rc=${PIPESTATUS[0]}

  echo "[INFO] Stopping entities ..." | tee -a "$SUITE_LOG"
  "$PY" scripts/stop_all_entities.py --config "$cfg" 2>&1 | tee -a "$SUITE_LOG"
  kill_old_ports
  set -e

  if [[ "$run_rc" -ne 0 || "$collect_rc" -ne 0 ]]; then
    echo "[ERROR] ${case_id} failed: run_rc=${run_rc}, collect_rc=${collect_rc}" | tee -a "$SUITE_LOG"
    return 1
  fi
  echo "[OK] ${case_id} finished" | tee -a "$SUITE_LOG"
  return 0
}

main() {
  patch_start_timeout
  echo "[INFO] patching model.py for MLP and synthetic dimension support ..." | tee -a "$SUITE_LOG"
  "$PY" "$PACK_DIR/scripts/patch_model_dim_support.py" 2>&1 | tee -a "$SUITE_LOG"
  kill_old_ports
  ensure_hardhat_node

  if [[ "$CLEAN_BASE_OUT" == "1" ]]; then
    echo "[INFO] cleaning base output: $FPA5_ROOT/$BASE_OUT" | tee -a "$SUITE_LOG"
    rm -rf "$FPA5_ROOT/$BASE_OUT"
  fi
  mkdir -p "$FPA5_ROOT/$BASE_OUT"

  local failed=0
  for entry in $DIM_CASES; do
    if ! run_one "$entry"; then
      failed=1
      echo "[WARN] stop suite after failure at case=$entry" | tee -a "$SUITE_LOG"
      break
    fi
  done

  echo "[INFO] Summarizing model-dimension results ..." | tee -a "$SUITE_LOG"
  "$PY" "$PACK_DIR/scripts/summarize_model_dim_results.py" \
    --base-dir "$FPA5_ROOT/$BASE_OUT" \
    --zip-out "$ZIP_OUT" \
    --extra-log "$SUITE_LOG" 2>&1 | tee -a "$SUITE_LOG" || true

  echo "[INFO] zip_out: $ZIP_OUT" | tee -a "$SUITE_LOG"
  ls -lh "$ZIP_OUT" 2>/dev/null | tee -a "$SUITE_LOG" || true

  if [[ "$failed" -ne 0 ]]; then
    exit 1
  fi
}

main "$@"
