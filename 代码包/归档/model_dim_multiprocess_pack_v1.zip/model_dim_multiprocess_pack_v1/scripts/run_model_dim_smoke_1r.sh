#!/usr/bin/env bash
set -euo pipefail

# Boundary smoke test: heaviest synthetic dimension, n=10, t=6, 1 round, multiprocess HTTP, chain on.
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$PACK_DIR"

export CLIENTS="${CLIENTS:-10}"
export THRESHOLD="${THRESHOLD:-6}"
export ROUNDS="${ROUNDS:-1}"
export CLIENT_MODE="${CLIENT_MODE:-individual}"
export BLOCKCHAIN="${BLOCKCHAIN:-on}"
export PAILLIER_BITS="${PAILLIER_BITS:-512}"
export SLOT_BITS="${SLOT_BITS:-40}"
export DIM_CASES="${DIM_CASES:-syn100k=synthetic_100000:100000}"
export BASE_OUT="${BASE_OUT:-outputs/model_dim_multiprocess_smoke_mnist_iid_c10_t6_p512_s40_1r_chain}"
export ZIP_OUT="${ZIP_OUT:-/root/model_dim_multiprocess_smoke_mnist_iid_c10_t6_p512_s40_1r_chain_results.zip}"
export SUITE_LOG="${SUITE_LOG:-/root/model_dim_multiprocess_smoke_mnist_iid_c10_t6_p512_s40_1r_chain.log}"
export CLEAN_BASE_OUT="${CLEAN_BASE_OUT:-1}"

bash scripts/run_model_dim_multiprocess_full.sh
