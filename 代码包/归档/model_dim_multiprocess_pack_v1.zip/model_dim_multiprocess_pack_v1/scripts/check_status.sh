#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE:-/root/fpa5/outputs/model_dim_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain}"
echo "[INFO] base: $BASE"
if [[ ! -d "$BASE" ]]; then
  echo "[WARN] base directory not found"
  exit 0
fi
for d in "$BASE"/d*; do
  [[ -d "$d" ]] || continue
  echo "===== $(basename "$d") ====="
  if [[ -f "$d/verify_result.csv" ]]; then
    tail -n +1 "$d/verify_result.csv"
  else
    echo "verify_result.csv missing"
  fi
  if [[ -f "$d/blockchain_cost.csv" ]]; then
    echo "tx_count=$(($(wc -l < "$d/blockchain_cost.csv")-1))"
    tail -n 3 "$d/blockchain_cost.csv"
  fi
  if [[ -f "$d/metrics_round.csv" ]]; then
    echo "metrics tail:"
    tail -n 2 "$d/metrics_round.csv"
  elif [[ -f "$d/metrics.csv" ]]; then
    echo "metrics tail:"
    tail -n 2 "$d/metrics.csv"
  fi
  if [[ -f "$d/crypto_cost.csv" ]]; then
    echo "crypto dimension rows:"
    grep -i "dimension\|model_dim" "$d/crypto_cost.csv" | tail -n 3 || true
  fi
done
