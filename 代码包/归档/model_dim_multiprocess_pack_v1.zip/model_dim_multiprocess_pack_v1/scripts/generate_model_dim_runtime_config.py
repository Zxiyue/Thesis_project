#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import yaml


def parse_args():
    ap = argparse.ArgumentParser(description='Generate runtime config for model-dimension multiprocess experiment.')
    ap.add_argument('--out', required=True)
    ap.add_argument('--output-dir', required=True)
    ap.add_argument('--clients', type=int, default=10)
    ap.add_argument('--rounds', type=int, default=10)
    ap.add_argument('--threshold', type=int, default=6)
    ap.add_argument('--model', required=True)
    ap.add_argument('--expected-dim', type=int, default=0)
    ap.add_argument('--paillier-bits', type=int, default=512)
    ap.add_argument('--slot-bits', type=int, default=40)
    ap.add_argument('--blockchain', choices=['on', 'off'], default='on')
    ap.add_argument('--client-mode', choices=['individual', 'worker_pool'], default='individual')
    ap.add_argument('--clients-per-worker', type=int, default=20)
    ap.add_argument('--dataset-dir', default='/mnt/fpa5/data')
    ap.add_argument('--seed', type=int, default=20260708)
    return ap.parse_args()


def main():
    args = parse_args()
    if args.threshold < 1 or args.threshold > args.clients:
        raise SystemExit(f'[ERROR] threshold must be in [1, clients], got threshold={args.threshold}, clients={args.clients}')

    cfg = {
        'seed': args.seed,
        'output_dir': args.output_dir,
        'dataset': {
            'name': 'MNIST',
            'data_dir': args.dataset_dir,
            'iid': True,
            'shards_per_client': 2,
            'download': False,
        },
        'federated': {
            'clients': args.clients,
            'rounds': args.rounds,
            'threshold': args.threshold,
            'local_epochs': 1,
            'batch_size': 64,
            'local_lr': 0.05,
            'server_lr': 1.0,
            'dropout': {},
        },
        'model': {
            'name': args.model,
            'expected_dim': int(args.expected_dim or 0),
            'dimension_experiment': True,
        },
        'encoding': {'scale': 10000, 'q': 1000000007},
        'crypto': {
            'paillier_bits': args.paillier_bits,
            'pedersen_prime_bits': 521,
            'pedersen_window': 0,
            'slot_bits': args.slot_bits,
            'packing_enabled': True,
        },
        'blockchain': {
            'enabled': args.blockchain == 'on',
            'rpc_url': 'http://127.0.0.1:8545',
            'contract_json': 'outputs/contract.json',
        },
        'communication': {
            'enabled': True,
            'mode': 'http',
            'record_actual_time': True,
            'timeout_seconds': 3600,
        },
        'distributed': {
            'enabled': True,
            'client_mode': args.client_mode,
            'host': '127.0.0.1',
            'kgc_port': 9200,
            'cs_port': 9300,
            'client_base_port': 9400,
            'worker_base_port': 9500,
            'clients_per_worker': args.clients_per_worker,
        },
        'logging': {'verbose': True, 'save_trace': True},
        'runtime': {
            'device': 'cpu',
            'parallel_clients': True,
            'max_client_workers': min(args.clients, 32),
            'num_workers': 0,
            'pin_memory': False,
            'test_batch_size': 256,
        },
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False), encoding='utf-8')
    print(f'[OK] runtime config written: {out}; clients={args.clients}; threshold={args.threshold}; rounds={args.rounds}; chain={args.blockchain}; mode={args.client_mode}; model={args.model}; expected_dim={args.expected_dim}')


if __name__ == '__main__':
    main()
