# 模型维度 d 对比实验代码包 v1

本包用于在已有 `/root/fpa5` 项目环境上运行模型维度对比实验。

## 1. 历史实验依据

前面已经完成：

1. 客户端数量扩展性实验：`5,10,20,40,60,80,100`，多进程 HTTP，开链，10 轮，均 accepted=True。
2. 门限参数 t 对比实验：`n=20,t=4/8/12/16/20`，多进程 HTTP，开链，10 轮，均 accepted=True。

因此本实验继续保持同一口径：多进程 HTTP、individual 客户端、blockchain=on、Paillier 512-bit、slot_bits=40。

## 2. synthetic 是什么

`synthetic_10000`、`synthetic_50000`、`synthetic_100000` 是合成维度实验。

它不是更换真实 CNN 结构，而是在一个可训练的 MNIST logistic classifier 后面附加一个 padding 参数向量，使协议看到的模型向量维度恰好为指定的 d。这样可以隔离测试：

- Paillier 加密开销随 d 的变化；
- Pedersen 承诺开销随 d 的变化；
- UpMsg / AggMsg 通信量随 d 的变化；
- 链上 FinalTx gas 是否仍保持稳定。

因此 synthetic 主要用于密码模块扩展性和通信扩展性，不用于说明模型准确率提升。

## 3. 默认实验配置

```text
clients = 10
threshold = 6
rounds = 10
dataset = MNIST-IID
paillier_bits = 512
slot_bits = 40
blockchain = on
client_mode = individual
dropout = 0
```

默认模型/维度实验点：

| case | model.name | 预期维度 d | 类型 |
|---|---|---:|---|
| tiny | tiny_cnn | 6794 | 真实模型 |
| logistic | logistic_regression | 7850 | 真实模型 |
| syn10k | synthetic_10000 | 10000 | 合成维度 |
| mlp | mlp | 12730 | 真实模型补充 |
| small | small_cnn | 26666 | 真实模型 |
| syn50k | synthetic_50000 | 50000 | 合成维度 |
| syn100k | synthetic_100000 | 100000 | 合成维度 |

## 4. 为什么用 10 轮

模型维度实验关注的是链下计算与通信开销随维度 d 的变化，不主要关注模型最终收敛精度。10 轮足以统计每轮平均通信、加密/承诺耗时和链上 gas，并且与已经完成的客户端数量实验、门限参数实验保持一致。

## 5. 本包内置修复

1. 自动使用 `/root/fpa5/.venv/bin/python`，避免 `python: command not found`。
2. 自动将 `start_all_entities.py` 的 health timeout 补到 600 秒。
3. 自动清理 `9200、9300、9401-9500` 端口残留进程。
4. 自动限制 OMP/OpenBLAS/MKL/NumExpr/PyTorch 线程数为 1。
5. 汇总脚本不使用 `pandas.to_markdown()`，不依赖 `tabulate`。
6. 汇总脚本对 runtime/crypto 数值字段使用 `pd.to_numeric(errors="coerce")`。
7. 自动 patch `/root/fpa5/fl_audit/model.py`，增加 `mlp` 与 `synthetic_10000/50000/100000` 支持，并保留 `.bak_dim_experiment` 备份。

## 6. 运行方式

先运行最重维度 smoke：

```bash
bash scripts/run_model_dim_smoke_1r.sh
```

smoke 使用 `synthetic_100000, n=10, t=6, 1r`。若通过，再运行完整实验：

```bash
bash scripts/run_model_dim_multiprocess_full.sh
```

建议在 tmux 中运行完整实验。

## 7. 可覆盖参数

```bash
DIM_CASES="tiny=tiny_cnn:6794 syn10k=synthetic_10000:10000" ROUNDS=10 bash scripts/run_model_dim_multiprocess_full.sh
```

常用覆盖项：

```text
CLIENTS
THRESHOLD
ROUNDS
DIM_CASES
PAILLIER_BITS
SLOT_BITS
BLOCKCHAIN
CLIENT_MODE
BASE_OUT
ZIP_OUT
SUITE_LOG
DATASET_DIR
```

## 8. 输出位置

默认输出目录：

```text
/root/fpa5/outputs/model_dim_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain
```

默认结果包：

```text
/root/model_dim_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_results.zip
```

默认日志：

```text
/root/model_dim_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain.log
```

汇总表：

```text
model_dim_summary.csv
gas_by_model_dim.csv
communication_by_model_dim.csv
runtime_by_model_dim.csv
model_dim_result_analysis.md
```
