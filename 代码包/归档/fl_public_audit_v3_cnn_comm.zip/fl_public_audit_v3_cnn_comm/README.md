# FL Public Audit V3: CNN + Communication Profiling

This version upgrades the experiment from a linear MNIST classifier to a compact CNN and adds logical communication-cost profiling.

## Main changes

- `model.name: tiny_cnn` by default. Available options: `logistic_regression`, `tiny_cnn`, `small_cnn`.
- `tiny_cnn` parameter dimension is 6794, which is smaller than the linear baseline dimension 7850.
- Client-side timing remains fine-grained: local training, quantization, Paillier encryption, Pedersen commitment, signing, packing.
- New `communication_cost.csv` records logical Client/CS/KGC/Blockchain communication payload bytes and estimated communication time.
- Optional parallel client upload generation is controlled by:

```yaml
runtime:
  parallel_clients: true
  max_client_workers: 5
```

## Communication model

The project still runs on one machine by default, but communication is no longer ignored. For every logical message, the program records:

- link, e.g., `C1->CS`, `KGC->CS`, `CS->C1`
- payload type, e.g., `UpMsg`, `AggMsg`, `ModelBroadcast`
- payload bytes
- estimated transfer time

The estimate uses:

```text
time = latency_ms / 1000 + bytes * 8 / (bandwidth_mbps * 1e6)
```

The default config does not sleep for the estimated delay. To emulate network delay, set:

```yaml
communication:
  apply_delay: true
```

## Run

No blockchain:

```bash
python run.py --config configs/mnist_noniid.yaml --no-blockchain
```

With Hardhat blockchain:

```bash
npx hardhat node
npx hardhat run scripts/deploy.js --network localhost
python run.py --config configs/mnist_noniid.yaml
```

## Outputs

- `metrics_round.csv`: test loss/accuracy by round
- `runtime_cost.csv`: fine-grained runtime cost
- `communication_cost.csv`: logical communication bytes and estimated latency
- `crypto_cost.csv`: crypto operation counts
- `blockchain_cost.csv`: transaction hash, gas, block number, latency
- `audit_chain.csv`: alpha, rootUp, ComAggHash, model hashes, audit roots
- `verify_result.csv`: third-party audit verification result
- `summary_tables.xlsx`: all tables in one workbook
