from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Dict, List


def json_size_bytes(obj: Any) -> int:
    """Return canonical JSON serialized size in bytes."""
    return len(json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8"))


@dataclass
class CommunicationProfiler:
    """Record logical communication payload size and estimated network latency.

    This does not require multiple physical machines. It computes the bytes that
    would be sent among Client/CS/KGC/BC and estimates the transfer time by:

        time = latency_ms/1000 + bytes * 8 / (bandwidth_mbps * 1e6)

    If apply_delay=true in config, the estimated delay is also slept to emulate
    network transmission.
    """

    cfg: Dict[str, Any]

    def __post_init__(self) -> None:
        c = self.cfg.get("communication", {}) or {}
        self.enabled = bool(c.get("enabled", True))
        self.bandwidth_mbps = float(c.get("bandwidth_mbps", 100.0))
        self.latency_ms = float(c.get("latency_ms", 5.0))
        self.apply_delay = bool(c.get("apply_delay", False))
        self.rows: List[Dict[str, Any]] = []

    def estimate_seconds(self, payload_bytes: int, messages: int = 1) -> float:
        if not self.enabled:
            return 0.0
        latency = (self.latency_ms / 1000.0) * max(messages, 1)
        transfer = (float(payload_bytes) * 8.0) / max(self.bandwidth_mbps * 1_000_000.0, 1.0)
        return latency + transfer

    def record(self, round_id: int, link: str, payload_type: str, payload: Any = None,
               bytes_count: int | None = None, messages: int = 1, note: str = "") -> float:
        if not self.enabled:
            return 0.0
        payload_bytes = int(bytes_count if bytes_count is not None else json_size_bytes(payload))
        seconds = self.estimate_seconds(payload_bytes, messages=messages)
        self.rows.append({
            "round": round_id,
            "link": link,
            "payload_type": payload_type,
            "messages": int(messages),
            "bytes": int(payload_bytes),
            "bandwidth_mbps": self.bandwidth_mbps,
            "latency_ms": self.latency_ms,
            "estimated_seconds": float(seconds),
            "note": note,
        })
        if self.apply_delay and seconds > 0:
            time.sleep(seconds)
        return seconds

    def record_many(self, round_id: int, rows: List[Dict[str, Any]]) -> None:
        for row in rows:
            self.record(round_id=round_id, **row)
