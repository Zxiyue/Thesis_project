from __future__ import annotations

from dataclasses import dataclass
from typing import List
import hashlib

from fl_audit.crypto.number import gen_prime


@dataclass
class PedersenParams:
    p: int
    q: int
    g_vec: List[int]
    h: int


def _hash_to_base(p: int, domain: str, index: int) -> int:
    """Derive a deterministic non-zero base in Z_p^*.

    The V1/V2 implementation generated dim+1 random bases and stored them in a
    set to avoid duplicates. For real MNIST models, dim is thousands of
    parameters; repeatedly storing/checking large integers can trigger
    MemoryError on some Windows/Python environments. This hash-to-base method is
    deterministic, memory-stable, and sufficient for experiment reproducibility.

    Note: this remains an experiment implementation over Z_p^*. A production
    system should replace it with a vetted prime-order group and independent
    generators produced by a standard hash-to-group procedure.
    """
    counter = 0
    while True:
        digest = hashlib.sha256(f"{domain}|{index}|{counter}".encode("utf-8")).digest()
        # Map to [2, p-2] to avoid 0 and 1.
        b = 2 + (int.from_bytes(digest, "big") % (p - 3))
        if 1 < b < p - 1:
            return b
        counter += 1


def make_params(dim: int, bits: int = 521) -> PedersenParams:
    if dim <= 0:
        raise ValueError("Pedersen dimension must be positive")
    if bits < 128:
        raise ValueError("pedersen_prime_bits should be at least 128 for experiments")

    # For experiment speed, generate a prime p and use q=p-1 as exponent modulus.
    # This avoids the V1 random-base set and prevents MemoryError for large models.
    p = gen_prime(bits)
    q = p - 1
    g_vec = [_hash_to_base(p, "pedersen-g", j) for j in range(dim)]
    h = _hash_to_base(p, "pedersen-h", dim)
    return PedersenParams(p=p, q=q, g_vec=g_vec, h=h)


def commit(params: PedersenParams, x: List[int], rho: int) -> int:
    if len(x) != len(params.g_vec):
        raise ValueError(f"dimension mismatch: {len(x)} != {len(params.g_vec)}")
    acc = 1
    for gj, xj in zip(params.g_vec, x):
        acc = (acc * pow(gj, int(xj) % params.q, params.p)) % params.p
    acc = (acc * pow(params.h, int(rho) % params.q, params.p)) % params.p
    return acc


def mul(params: PedersenParams, values: List[int]) -> int:
    acc = 1
    for v in values:
        acc = (acc * int(v)) % params.p
    return acc
