# Ours-packed 2048-bit slot_bits=34 50-round final experiments

本包用于下一步正式实验：在 Ours-basic 公开审计流程基础上启用 BatchCrypt-style / lossless Paillier ciphertext packing。

## 实验配置

- Ours-packed
- Paillier bits = 2048
- slot_bits = 34
- pack_size = auto
- local_lr = 0.20
- server_lr = 1.0
- rounds = 50
- clients = 5
- parallel HTTP
- Hardhat audit board
- 默认保留 50r 主实验中的 dropout schedule：第 10 轮 C2 掉线，第 25 轮 C4 掉线

生成配置：

- `configs/ours_packed_mnist_iid_50r_p2048_s34_final.yaml`
- `configs/ours_packed_mnist_noniid_50r_p2048_s34_final.yaml`

输出目录：

- `outputs/ours_packed_mnist_iid_50r_p2048_s34_final`
- `outputs/ours_packed_mnist_noniid_50r_p2048_s34_final`

## 1. 解压

```bash
cd /root
unzip -o ours_packed_s34_50r_final_pack.zip
```

## 2. 应用补丁并生成配置

如果前面已经应用过 `ours_packed_slotbits_test_pack` 的补丁，这一步再次执行也可以；脚本会保留备份。

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

python3 /root/ours_packed_s34_50r_final_pack/patch/apply_ours_packed_patch.py
python3 /root/ours_packed_s34_50r_final_pack/config_tools/make_ours_packed_s34_50r_configs.py
chmod +x /root/ours_packed_s34_50r_final_pack/scripts/*.sh
```

检查配置：

```bash
grep -nE "output_dir|rounds|paillier_bits|packing|slot_bits|pack_size|dropout|local_lr|parallel_clients|timeout_seconds" \
  configs/ours_packed_mnist_iid_50r_p2048_s34_final.yaml \
  configs/ours_packed_mnist_noniid_50r_p2048_s34_final.yaml
```

## 3. Hardhat 前台运行

根据你的偏好，本包不在后台自动启动实验。Hardhat 建议在另一个 tmux/终端前台运行：

```bash
tmux new -s hardhat
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
npx hardhat node | tee /root/hardhat.log
```

## 4. 前台启动 50轮实验

建议先跑 MNIST-IID：

```bash
tmux new -s packed50
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

DATASETS="mnist_iid" stdbuf -oL -eL \
  /root/ours_packed_s34_50r_final_pack/scripts/run_ours_packed_s34_50r_final.sh \
  | tee /root/packed50_iid.log
```

IID 成功后再跑 Non-IID：

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

DATASETS="mnist_noniid" stdbuf -oL -eL \
  /root/ours_packed_s34_50r_final_pack/scripts/run_ours_packed_s34_50r_final.sh \
  | tee /root/packed50_noniid.log
```

也可以两组顺序跑：

```bash
DATASETS="mnist_iid mnist_noniid" stdbuf -oL -eL \
  /root/ours_packed_s34_50r_final_pack/scripts/run_ours_packed_s34_50r_final.sh \
  | tee /root/packed50_all.log
```

## 5. 另开窗口查看状态

```bash
/root/ours_packed_s34_50r_final_pack/scripts/check_ours_packed_s34_50r_status.sh
```

或：

```bash
tail -n 120 /root/packed50_iid.log
```

## 6. 汇总分析

```bash
cd /root/fpa5
python3 /root/ours_packed_s34_50r_final_pack/scripts/analyze_ours_packed_s34_50r.py \
  | tee /root/ours_packed_s34_50r_analysis.csv
```

## 7. 结果包

单组结果：

- `/root/ours_packed_mnist_iid_50r_p2048_s34_final_results.zip`
- `/root/ours_packed_mnist_noniid_50r_p2048_s34_final_results.zip`

合并结果：

- `/root/ours_packed_s34_50r_final_results.zip`

完成后上传对应 zip 给我分析。
