# Client Scale Experiment Pack v1

This pack runs the Ours-packed client-scale functional scalability experiment.

Default setting:

- Scheme: Ours-packed
- Dataset: MNIST-IID
- Clients: 5, 10, 20, 50, 100
- Threshold: ceil(0.6 × clients)
- Rounds: 5
- Paillier: 512-bit functional setting
- Packing: enabled, slot_bits=40, pack_size=auto
- Dropout: none
- Blockchain: disabled; audit-chain verification is executed locally
- Max client workers: 10

The purpose is to show how communication, ciphertext count, client-side crypto cost, CS aggregation cost, and audit checks change as the number of clients increases. It is not used to evaluate 2048-bit security-parameter absolute overhead.

## Estimated runtime

Default full run `CLIENT_LIST="5 10 20 50 100" ROUNDS=5` is expected to take about **3.5–5 hours** on the current CPU server. The estimate is based on the completed 10-client 512-bit dropout experiment.

Run the estimator:

```bash
python scripts/estimate_client_scale_runtime.py --clients "5 10 20 50 100" --rounds 5
```

## Run

```bash
cd /root
unzip -o client_scale_pack_v1.zip
cd /root/client_scale_pack_v1

stdbuf -oL -eL bash scripts/run_client_scale_suite.sh \
  | tee /root/client_scale_suite_v1.log
```

## Smoke run

```bash
ROUNDS=2 CLIENT_LIST="5 10 20" bash scripts/run_client_scale_suite.sh
```

## Check status

```bash
bash /root/client_scale_pack_v1/scripts/check_client_scale_status.sh
```

## Output

The combined result package will be:

```text
/root/client_scale_mnist_iid_p512_5r_results.zip
```

Main summary files:

- `client_scale_summary.csv`
- `client_scale_summary.md`
- `client_scale_summary.json`

Each client-count directory also contains raw CSV files such as `runtime_cost.csv`, `communication_cost.csv`, `crypto_cost.csv`, `metrics_round.csv`, and `verify_result.csv`.
