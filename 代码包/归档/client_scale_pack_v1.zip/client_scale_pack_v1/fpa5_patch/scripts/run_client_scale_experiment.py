from __future__ import annotations

import argparse
import hashlib
import math
import random
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import yaml

from fl_audit.data import make_loaders
from fl_audit.model import make_model, get_vector, set_vector, evaluate, serialize_model_state
from fl_audit.protocol.entities import Client, KGC, ServerCS, model_sync_signed_payload
from fl_audit.protocol.verifier import verify_chain, verify_init
from fl_audit.crypto import pedersen
from fl_audit.crypto.merkle import MerkleTree
from fl_audit.crypto.signature import verify_obj, sign_obj
from fl_audit.encoding import dequantize, quantize
from fl_audit.utils.codec import bytes32_hex
from fl_audit.utils.timer import TimerRecorder
from fl_audit.utils.export import ensure_dir, save_json, save_csv, save_excel
from fl_audit.network import CommunicationProfiler, json_size_bytes, canonical_json_bytes


class ExpectedAbort(Exception):
    def __init__(self, stage: str, reason: str, round_id: int):
        super().__init__(reason)
        self.stage = stage
        self.reason = reason
        self.round_id = int(round_id)


def parse_args():
    ap = argparse.ArgumentParser(description="Run Ours-packed client-scale experiments with no dropout.")
    ap.add_argument("--config", default="configs/client_scale_mnist_iid_p512_packed.yaml")
    ap.add_argument("--dropout-rate", type=float, default=None, help="Dropout rate in percent, e.g. 20 for 20%")
    ap.add_argument("--output-dir", default=None)
    ap.add_argument("--rounds", type=int, default=None)
    ap.add_argument("--clients", type=int, default=None)
    ap.add_argument("--threshold", type=int, default=None)
    ap.add_argument("--paillier-bits", type=int, default=None)
    ap.add_argument("--slot-bits", type=int, default=None)
    ap.add_argument("--device", default=None)
    return ap.parse_args()


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def resolve_device(cfg: dict) -> str:
    requested = str(cfg.get("runtime", {}).get("device", "auto")).lower()
    if requested == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    if requested.startswith("cuda") and not torch.cuda.is_available():
        print("[WARN] CUDA was requested but is not available. Falling back to CPU.")
        return "cpu"
    return requested


def model_wire_payload(payload_type: str, r: int, model_hash_value: str, model_bytes: bytes, extra: dict | None = None) -> bytes:
    meta = {
        "payload_type": payload_type,
        "r": r,
        "modelHash": model_hash_value,
        "modelBytesLength": len(model_bytes),
        "modelBytesSha256": hashlib.sha256(model_bytes).hexdigest(),
    }
    if extra:
        meta.update(extra)
    meta_bytes = canonical_json_bytes(meta)
    return len(meta_bytes).to_bytes(8, byteorder="big", signed=False) + meta_bytes + model_bytes


def merkle_root_for_ids(ids: List[int], label: str = "D") -> str:
    leaves = [bytes32_hex({"set": label, "i": int(i)}) for i in sorted(ids)]
    return MerkleTree(leaves).root


def dropout_ids_for_round(n: int, k: int, r: int) -> List[int]:
    """Deterministic rotating dropout: R1=C1..Ck, R2=C2..C(k+1), ..."""
    if k <= 0:
        return []
    if k >= n:
        return list(range(1, n + 1))
    return sorted([((r + j - 2) % n) + 1 for j in range(1, k + 1)])


def format_rate(rate: float) -> str:
    if abs(rate - int(rate)) < 1e-9:
        return f"d{int(rate):02d}"
    return "d" + str(rate).replace(".", "p")


def run_once(cfg: dict, out_dir: Path) -> Dict[str, Any]:
    set_seed(int(cfg.get("seed", 42)))
    device = resolve_device(cfg)
    timer = TimerRecorder()
    comm = CommunicationProfiler(cfg)

    n_clients = int(cfg["federated"]["clients"])
    threshold = int(cfg["federated"]["threshold"])
    rounds = int(cfg["federated"]["rounds"])
    rate = float(cfg.get("dropout_experiment", {}).get("rate", 0.0))
    dropout_count = int(math.floor(rate * n_clients / 100.0 + 1e-9))
    online_count = n_clients - dropout_count
    expected_fail = bool(cfg.get("dropout_experiment", {}).get("expected_fail_when_below_threshold", True)) and online_count < threshold

    print(f"[dropout] rate={rate:g}%, clients={n_clients}, dropout_count={dropout_count}, online_count={online_count}, threshold={threshold}, expected_fail={expected_fail}")
    print(f"[runtime] torch_device={device}, cuda_available={torch.cuda.is_available()}")
    print(f"[crypto] paillier_bits={cfg.get('crypto',{}).get('paillier_bits')}, packing={cfg.get('crypto',{}).get('packing')}")

    train_loaders, test_loader, partitions = make_loaders(cfg)
    model = make_model(cfg["model"]["name"])
    dim = int(get_vector(model).numel())
    clients = [Client(cid=i) for i in range(1, n_clients + 1)]
    clients_by_id = {c.cid: c for c in clients}
    kgc = KGC()
    cs = ServerCS()
    client_pubkeys = {c.cid: c.public_key for c in clients}

    with timer.record(0, "setup", "KGC parameters, Paillier, Pedersen, InitTx"):
        setup = kgc.setup(clients, model, cfg)
    init_tx = setup["initTx"]
    pkey = setup["paillier"]
    ped_params = setup["pedersen"]
    U = setup["U"]
    Uroot = setup["Uroot"]

    init_ok = verify_init(init_tx, kgc.public_key, setup["sysPara"])
    if not init_ok:
        raise RuntimeError("InitTx verification failed")

    metrics_rows: List[Dict[str, Any]] = []
    crypto_rows: List[Dict[str, Any]] = []
    audit_rows: List[Dict[str, Any]] = []
    round_rows: List[Dict[str, Any]] = []
    sync_rows: List[Dict[str, Any]] = []
    compensation_rows: List[Dict[str, Any]] = []
    final_txs = []
    trace = {
        "initTx": init_tx.__dict__,
        "rounds": [],
        "dropout_experiment": {
            "rate": rate,
            "clients": n_clients,
            "threshold": threshold,
            "rounds": rounds,
            "dropout_count": dropout_count,
            "online_count": online_count,
            "schedule": "rotating",
            "expected_fail": expected_fail,
        },
        "runtime": {"device": device, "parallel_clients": cfg.get("runtime", {}).get("parallel_clients", False)},
    }

    prev_audit_root = init_tx.auditRoot0
    current_model_hash = init_tx.modelHash0
    for c in clients:
        c.receive_model_broadcast(model, current_model_hash)

    total_samples = sum(len(loader.dataset) for loader in train_loaders.values())
    loss0, acc0 = evaluate(model, test_loader, device=device)
    metrics_rows.append({"round": 0, "test_loss": loss0, "test_accuracy": acc0, "effective_clients": 0, "dropout_clients": 0})

    aborted: Optional[ExpectedAbort] = None
    unexpected_exception = ""

    try:
        for r in range(1, rounds + 1):
            print(f"\n========== DROPOUT ROUND {r}/{rounds}; rate={rate:g}% ==========")
            D_planned = dropout_ids_for_round(n_clients, dropout_count, r)
            active_clients = [c for c in clients if c.cid not in set(D_planned)]
            threshold_met = len(active_clients) >= threshold
            if not threshold_met:
                raise ExpectedAbort(
                    "threshold_check",
                    f"online clients {len(active_clients)} < threshold {threshold}; planned_dropout={D_planned}",
                    r,
                )

            round_trace = {"round": r, "planned_dropout": D_planned}
            W_r_vec = get_vector(model).clone().double()
            with timer.record(r, "round_init", "alpha, zero-sum masks, zero-sum rho"):
                alpha, masks, rhos = kgc.init_round(r, current_model_hash, U, Uroot, dim, ped_params, int(cfg.get("seed", 42)))
            round_trace["alpha"] = alpha

            for cid in U:
                mask_payload = {"r": r, "i": cid, "alpha": alpha, "m": masks[cid].tolist(), "rho": str(rhos[cid])}
                comm.record(r, f"KGC->C{cid}", "MaskMsg", payload=mask_payload, note="private mask and Pedersen randomness")

            up_msgs = []
            client_stats = []
            current_model_bytes = serialize_model_state(model)

            for c in active_clients:
                old_hash = c.local_model_hash
                sync_performed = c.needs_model_sync(current_model_hash)
                sync_verified = False
                if sync_performed:
                    sync_req = c.make_model_sync_request(r, current_model_hash)
                    comm.record(r, f"C{c.cid}->CS", "ModelSyncReq", payload=sync_req, note="client requests current model because local hash is stale")
                    sync_payload = model_sync_signed_payload(r, c.cid, current_model_hash, current_model_bytes)
                    sig_sync_cs = sign_obj(cs.keypair.private_key, sync_payload)
                    sync_resp = {
                        "r": r,
                        "client_id": c.cid,
                        "modelHash": current_model_hash,
                        "modelBytesLength": sync_payload["modelBytesLength"],
                        "modelBytesSha256": sync_payload["modelBytesSha256"],
                        "modelBytes": current_model_bytes,
                        "sigSyncCS": sig_sync_cs,
                    }
                    sync_resp_wire = model_wire_payload(
                        "ModelSyncResp", r, current_model_hash, current_model_bytes,
                        extra={"client_id": c.cid, "modelBytesLength": sync_payload["modelBytesLength"], "modelBytesSha256": sync_payload["modelBytesSha256"], "sigSyncCS": sig_sync_cs},
                    )
                    comm.record(r, f"CS->C{c.cid}", "ModelSyncResp", payload=sync_resp_wire, note="signed current round model bytes for stale reconnecting client")
                    c.sync_model_from_server(sync_resp, model_template=model, cs_public_key=cs.public_key)
                    sync_verified = True
                sync_rows.append({
                    "round": r,
                    "client_id": c.cid,
                    "old_local_model_hash": old_hash,
                    "target_modelHash_r": current_model_hash,
                    "sync_performed": sync_performed,
                    "sigSyncCS_verified": sync_verified,
                })

            def _client_upload(c: Client):
                return c.make_upload(
                    r, alpha, current_model_hash, c.local_model, train_loaders[c.cid], total_samples, cfg,
                    masks[c.cid], rhos[c.cid], pkey.public, ped_params, timer=timer, device=device,
                )

            parallel_clients = bool(cfg.get("runtime", {}).get("parallel_clients", False))
            max_workers = int(cfg.get("runtime", {}).get("max_client_workers", len(active_clients) or 1))
            if parallel_clients and len(active_clients) > 1:
                with timer.record(r, "client_upload_parallel_wall", "wall-clock time for parallel client upload generation"):
                    with ThreadPoolExecutor(max_workers=max_workers) as ex:
                        futures = {ex.submit(_client_upload, c): c.cid for c in active_clients}
                        for fut in as_completed(futures):
                            msg, stat = fut.result()
                            up_msgs.append(msg)
                            client_stats.append(stat)
            else:
                with timer.record(r, "client_upload_sequential_wall", "wall-clock time for sequential client upload generation"):
                    for c in active_clients:
                        msg, stat = _client_upload(c)
                        up_msgs.append(msg)
                        client_stats.append(stat)

            up_msgs = sorted(up_msgs, key=lambda m: int(m["i"]))
            client_stats = sorted(client_stats, key=lambda z: int(z["cid"]))
            for msg in up_msgs:
                cid = int(msg["i"])
                up_size = json_size_bytes(msg)
                comm.record(r, f"C{cid}->CS", "UpMsg", bytes_count=up_size, note="ciphertext vector, commitment, receipt and signature")
                comm.record(r, f"C{cid}->KGC", "UpMsg", bytes_count=up_size, note="copy for KGC-side upload verification")

            with timer.record(r, "kgc_upload_verify", "signatures and rootUp"):
                valid_msgs, root_up = kgc.verify_uploads_and_root(r, up_msgs, client_pubkeys)
            U_r_kgc = sorted([int(m["i"]) for m in valid_msgs])
            D_r_kgc = sorted(list(set(U) - set(U_r_kgc)))
            rootD_kgc = merkle_root_for_ids(D_r_kgc, label="D_kgc")
            rootD_cs = merkle_root_for_ids(D_planned, label="D_kgc")
            rootD_match = rootD_cs == rootD_kgc
            if not rootD_match:
                raise RuntimeError(f"dropout set mismatch: planned={D_planned}, kgc={D_r_kgc}")

            with timer.record(r, "kgc_compensation", "mDrop, rhoDrop, Cdrop, ComDrop"):
                m_drop, rho_drop, cdrop, com_drop = kgc.make_compensation(r, D_r_kgc, pkey.public, ped_params, cfg=cfg)
            drop_payload = {"r": r, "alpha": alpha, "D": D_r_kgc, "rootD": rootD_kgc, "identityOptimized": len(D_r_kgc) == 0, "Cdrop": [] if len(D_r_kgc) == 0 else [str(c) for c in cdrop], "ComDrop": str(com_drop)}
            comm.record(r, "KGC->CS", "DropMsg", payload=drop_payload, note="dropout compensation; compact identity when no dropout")

            with timer.record(r, "cs_aggregate", "Craw/Cagg and ComRaw/ComAgg"):
                craw, cagg, com_raw, com_agg = cs.aggregate(valid_msgs, cdrop, com_drop, pkey.public, ped_params)
            cagg_hash = bytes32_hex([str(c) for c in cagg])
            agg_payload = {"r": r, "alpha": alpha, "rootUp": root_up, "CaggHash": cagg_hash, "ComAgg": str(com_agg)}
            sig_agg = sign_obj(cs.keypair.private_key, agg_payload)
            if not verify_obj(cs.public_key, sig_agg, agg_payload):
                raise RuntimeError("sigAgg failed")
            agg_msg_payload = {"r": r, "alpha": alpha, "rootUp": root_up, "Cagg": [str(c) for c in cagg], "CaggHash": cagg_hash, "ComAgg": str(com_agg), "sigAgg": sig_agg}
            agg_size = json_size_bytes(agg_msg_payload)
            for cid in U_r_kgc:
                comm.record(r, f"CS->C{cid}", "AggMsg", bytes_count=agg_size, note="aggregate ciphertext vector for partial decryption")
            comm.record(r, "CS->KGC", "AggMsg", bytes_count=agg_size, note="aggregate transcript for KGC checking")

            with timer.record(r, "share_generation", "threshold shares"):
                share_msgs = [c.make_decryption_share(r, alpha, cagg_hash) for c in active_clients]
            for sm in share_msgs:
                cid = int(sm["ShareMsg"]["j"])
                comm.record(r, f"C{cid}->CS", "ShareMsg", payload=sm, note="threshold decryption share message")
            if len(share_msgs) < threshold:
                raise ExpectedAbort("threshold_check", f"share messages {len(share_msgs)} < threshold {threshold}", r)

            with timer.record(r, "combine_decrypt", "Shamir reconstruct lambda and decrypt aggregate vector"):
                xagg, used_shares = cs.recover_lambda_and_decrypt(
                    share_msgs, client_pubkeys, setup["shareField"], threshold, pkey, cagg, r, alpha, cfg=cfg, dim=dim
                )

            with timer.record(r, "cs_open_check", "ComAgg == PedCom(xAgg;0)"):
                com_check = pedersen.commit(ped_params, xagg.tolist(), 0)
                if com_check != com_agg:
                    raise RuntimeError(f"CS open check failed: ComAgg != PedCom(xAgg;0)")

            with timer.record(r, "model_update", "apply decoded aggregate update"):
                update = torch.tensor(dequantize(xagg, int(cfg["encoding"]["scale"])), dtype=torch.float64)
                W_next_vec = W_r_vec + float(cfg["federated"].get("server_lr", 1.0)) * update
                set_vector(model, W_next_vec)
                model_hash_next = bytes32_hex(get_vector(model).numpy().tolist())

            model_payload = {"r": r, "alpha": alpha, "modelHashR": current_model_hash, "modelHashNext": model_hash_next, "CaggHash": cagg_hash, "ComAgg": str(com_agg)}
            sig_model = sign_obj(cs.keypair.private_key, model_payload)
            if not verify_obj(cs.public_key, sig_model, model_payload):
                raise RuntimeError("sigModel failed")

            next_model_bytes = serialize_model_state(model)
            model_msg_wire = model_wire_payload("ModelMsg", r, model_hash_next, next_model_bytes, extra={"modelHashR": current_model_hash, "CaggHash": cagg_hash, "sigModel": sig_model})
            comm.record(r, "CS->KGC", "ModelMsg", payload=model_msg_wire, note="model hashes plus serialized W_next state_dict")
            for cid in U_r_kgc:
                broadcast_wire = model_wire_payload("ModelBroadcast", r, model_hash_next, next_model_bytes, extra={"modelHashR": current_model_hash, "client_id": cid, "sigModel": sig_model})
                comm.record(r, f"CS->C{cid}", "ModelBroadcast", payload=broadcast_wire, note="new global model broadcast with serialized W_next state_dict")
                clients_by_id[cid].receive_model_broadcast(model, model_hash_next)

            with timer.record(r, "kgc_final_model_check", "model diff -> xModel -> PedCom check"):
                u_model = (get_vector(model).double() - W_r_vec) / float(cfg["federated"].get("server_lr", 1.0))
                x_model = quantize(u_model.numpy(), int(cfg["encoding"]["scale"]))
                diff = np.abs(x_model - xagg)
                mismatch = int((diff != 0).sum())
                if mismatch != 0:
                    raise RuntimeError(f"KGC model diff encoding mismatch at {mismatch} coordinates")
                if pedersen.commit(ped_params, x_model.tolist(), 0) != com_agg:
                    raise RuntimeError("KGC model differential commitment check failed")

            with timer.record(r, "kgc_final_tx", "auditRoot and FinalTx"):
                final_tx = kgc.final_confirm(r, alpha, root_up, com_agg, current_model_hash, model_hash_next, prev_audit_root)
                final_txs.append(final_tx)
                prev_audit_root = final_tx.auditRoot
                current_model_hash = model_hash_next

            loss, acc = evaluate(model, test_loader, device=device)
            metrics_rows.append({"round": r, "test_loss": loss, "test_accuracy": acc, "effective_clients": len(U_r_kgc), "dropout_clients": len(D_r_kgc)})
            audit_rows.append({"round": r, "alpha": alpha, "rootUp": root_up, "rootD": rootD_kgc, "ComAggHash": final_tx.ComAggHash, "modelHashR": final_tx.modelHashR, "modelHashNext": final_tx.modelHashNext, "auditRoot": final_tx.auditRoot, "sigFinal_len": len(final_tx.sigFinal)})

            packing_meta = (client_stats[0] if client_stats else {})
            pack_enabled = bool(packing_meta.get("packing_enabled", False))
            packing_cipher_count = int(packing_meta.get("packing_cipher_count", len(cagg))) if client_stats else len(cagg)
            compensation_encryptions = packing_cipher_count if len(D_r_kgc) > 0 else 0
            compensation_commitments = 1 if len(D_r_kgc) > 0 else 0
            crypto_rows.extend([
                {"round": r, "metric": "model_dimension", "value": dim},
                {"round": r, "metric": "model_name", "value": cfg["model"]["name"]},
                {"round": r, "metric": "effective_clients", "value": len(U_r_kgc)},
                {"round": r, "metric": "dropout_clients", "value": len(D_r_kgc)},
                {"round": r, "metric": "packing_enabled", "value": 1 if pack_enabled else 0},
                {"round": r, "metric": "packing_slot_bits", "value": int(packing_meta.get("packing_slot_bits", 0) or 0)},
                {"round": r, "metric": "packing_slots_per_cipher", "value": int(packing_meta.get("packing_slots_per_cipher", 0) or 0)},
                {"round": r, "metric": "packing_cipher_count_per_client", "value": packing_cipher_count},
                {"round": r, "metric": "pedersen_commitments", "value": len(U_r_kgc) + compensation_commitments + 2},
                {"round": r, "metric": "paillier_encryptions", "value": len(U_r_kgc) * packing_cipher_count + compensation_encryptions},
                {"round": r, "metric": "paillier_ciphertexts_aggregated", "value": len(U_r_kgc) * packing_cipher_count},
                {"round": r, "metric": "compensation_encryptions", "value": compensation_encryptions},
                {"round": r, "metric": "compensation_identity_optimized", "value": 1 if len(D_r_kgc) == 0 else 0},
            ])
            round_rows.append({
                "round": r,
                "dropout_rate": rate,
                "dropout_clients": " ".join(map(str, D_r_kgc)),
                "dropout_count": len(D_r_kgc),
                "online_count": len(U_r_kgc),
                "threshold": threshold,
                "threshold_met": True,
                "rootD_match": rootD_match,
                "combine_success": True,
                "round_accepted": True,
                "model_sync_count": sum(1 for row in sync_rows if int(row["round"]) == r and row["sync_performed"]),
            })
            compensation_rows.append({
                "round": r,
                "dropout_rate": rate,
                "dropout_count": len(D_r_kgc),
                "identity_optimized": len(D_r_kgc) == 0,
                "compensation_cipher_count": compensation_encryptions,
                "rootD_match": rootD_match,
                "com_check_pass": True,
            })
            round_trace.update({"rootUp": root_up, "rootD": rootD_kgc, "ComAggHash": final_tx.ComAggHash, "modelHashNext": model_hash_next, "auditRoot": final_tx.auditRoot, "clientStats": client_stats})
            trace["rounds"].append(round_trace)
            print(f"round={r}, acc={acc:.4f}, online={len(U_r_kgc)}, dropout={D_r_kgc}, sync={round_rows[-1]['model_sync_count']}, auditRoot={final_tx.auditRoot[:18]}...")

    except ExpectedAbort as e:
        aborted = e
        round_rows.append({
            "round": e.round_id,
            "dropout_rate": rate,
            "dropout_clients": " ".join(map(str, dropout_ids_for_round(n_clients, dropout_count, e.round_id))),
            "dropout_count": dropout_count,
            "online_count": online_count,
            "threshold": threshold,
            "threshold_met": False,
            "rootD_match": "",
            "combine_success": False,
            "round_accepted": False,
            "model_sync_count": "",
        })
        print(f"[EXPECTED_ABORT] stage={e.stage}, round={e.round_id}, reason={e.reason}")
    except Exception as e:
        unexpected_exception = traceback.format_exc()
        print(unexpected_exception)

    chain_ok = verify_chain(init_tx, final_txs, kgc.public_key) if final_txs else False
    completed_rounds = len(final_txs)
    if unexpected_exception:
        accepted = False
        status = "unexpected_exception"
        reason = unexpected_exception.splitlines()[-1] if unexpected_exception.splitlines() else "unexpected exception"
    elif aborted is not None:
        accepted = False
        status = "expected_abort" if expected_fail else "unexpected_abort"
        reason = aborted.reason
    else:
        accepted = bool(chain_ok and completed_rounds == rounds)
        status = "accepted" if accepted else "chain_verify_failed"
        reason = "all rounds accepted" if accepted else "verify_chain failed or incomplete rounds"

    final_acc = metrics_rows[-1].get("test_accuracy", "") if metrics_rows else ""
    best_acc = max((float(row.get("test_accuracy", 0.0)) for row in metrics_rows), default=0.0) if metrics_rows else ""
    total_comm_bytes = sum(int(row.get("bytes", 0) or 0) for row in comm.rows)
    total_wall_time = sum(float(row.get("seconds", 0.0) or 0.0) for row in timer.rows)
    sync_count = sum(1 for row in sync_rows if row.get("sync_performed") is True)
    sync_verified = sum(1 for row in sync_rows if row.get("sigSyncCS_verified") is True)
    result = {
        "dropout_rate": rate,
        "dropout_count_per_round": dropout_count,
        "online_count_per_round": online_count,
        "clients": n_clients,
        "threshold": threshold,
        "rounds_target": rounds,
        "rounds_completed": completed_rounds,
        "accepted": accepted,
        "status": status,
        "abort_round": aborted.round_id if aborted else "",
        "abort_stage": aborted.stage if aborted else "",
        "reason": reason,
        "expected_fail": expected_fail,
        "final_acc": final_acc,
        "best_acc": best_acc,
        "total_comm_mb": total_comm_bytes / (1024 * 1024),
        "total_wall_time_s_sum_timer": total_wall_time,
        "avg_round_time_s_sum_timer": total_wall_time / max(completed_rounds, 1) if completed_rounds else "",
        "model_sync_req_count": sync_count,
        "model_sync_verified_count": sync_verified,
        "model_dimension": dim,
        "paillier_bits": int(cfg["crypto"].get("paillier_bits", 0)),
        "packing_enabled": bool(cfg.get("crypto", {}).get("packing", {}).get("enabled", False)),
        "slot_bits": int(cfg.get("crypto", {}).get("packing", {}).get("slot_bits", 0) or 0),
    }

    verify_rows = [{"accepted": accepted, "status": status, "rounds": completed_rounds, "latestAuditRoot": final_txs[-1].auditRoot if final_txs else init_tx.auditRoot0}]
    save_csv(metrics_rows, out_dir / "metrics_round.csv")
    save_csv(timer.rows, out_dir / "runtime_cost.csv")
    save_csv(crypto_rows, out_dir / "crypto_cost.csv")
    save_csv(comm.rows, out_dir / "communication_cost.csv")
    save_csv(audit_rows, out_dir / "audit_chain.csv")
    save_csv(round_rows, out_dir / "dropout_round_status.csv")
    save_csv(sync_rows, out_dir / "model_sync_events.csv")
    save_csv(compensation_rows, out_dir / "compensation_status.csv")
    save_csv(verify_rows, out_dir / "verify_result.csv")
    save_csv([result], out_dir / "dropout_result.csv")
    save_excel({
        "metrics_round": metrics_rows,
        "runtime_cost": timer.rows,
        "crypto_cost": crypto_rows,
        "communication_cost": comm.rows,
        "audit_chain": audit_rows,
        "dropout_round_status": round_rows,
        "model_sync_events": sync_rows,
        "compensation_status": compensation_rows,
        "verify_result": verify_rows,
        "dropout_result": [result],
    }, out_dir / "summary_tables.xlsx")
    trace["dropout_result"] = result
    if unexpected_exception:
        trace["unexpected_exception"] = unexpected_exception
    save_json(trace, out_dir / "run_trace.json")
    print(f"[RESULT] {result}")
    print(f"Outputs saved to: {out_dir}")
    return result


def main():
    args = parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    cfg.setdefault("dropout_experiment", {})
    if args.dropout_rate is not None:
        cfg["dropout_experiment"]["rate"] = float(args.dropout_rate)
    if args.rounds is not None:
        cfg.setdefault("federated", {})["rounds"] = int(args.rounds)
    if args.clients is not None:
        cfg.setdefault("federated", {})["clients"] = int(args.clients)
    if args.threshold is not None:
        cfg.setdefault("federated", {})["threshold"] = int(args.threshold)
    if args.paillier_bits is not None:
        cfg.setdefault("crypto", {})["paillier_bits"] = int(args.paillier_bits)
    if args.slot_bits is not None:
        cfg.setdefault("crypto", {}).setdefault("packing", {})["slot_bits"] = int(args.slot_bits)
    if args.device is not None:
        cfg.setdefault("runtime", {})["device"] = args.device
    cfg.setdefault("federated", {})["dropout"] = {}

    if args.output_dir is not None:
        out_dir = ensure_dir(args.output_dir)
    else:
        rate_key = format_rate(float(cfg.get("dropout_experiment", {}).get("rate", 0)))
        base = Path(cfg.get("output_dir", "outputs/dropout_rate"))
        out_dir = ensure_dir(base / rate_key)
    run_once(cfg, out_dir)


if __name__ == "__main__":
    main()
