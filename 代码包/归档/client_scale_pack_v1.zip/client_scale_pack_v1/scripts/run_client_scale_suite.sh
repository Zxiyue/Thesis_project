#!/usr/bin/env bash
set -euo pipefail

FPA_DIR="${FPA_DIR:-/root/fpa5}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${CONFIG:-configs/client_scale_mnist_iid_p512_packed.yaml}"
DEVICE="${DEVICE:-cpu}"
ROUNDS="${ROUNDS:-5}"
CLIENT_LIST="${CLIENT_LIST:-5 10 20 50 100}"
THRESHOLD_RATIO="${THRESHOLD_RATIO:-0.6}"
PAILLIER_BITS="${PAILLIER_BITS:-512}"
SLOT_BITS="${SLOT_BITS:-40}"
MAX_CLIENT_WORKERS="${MAX_CLIENT_WORKERS:-10}"
BASE_OUT="${BASE_OUT:-outputs/client_scale_mnist_iid_p512_${ROUNDS}r}"
ZIP_OUT="${ZIP_OUT:-/root/client_scale_mnist_iid_p512_${ROUNDS}r_results.zip}"

bash "$PACK_DIR/scripts/install_client_scale_pack.sh"
cd "$FPA_DIR"
export PYTHONPATH="$FPA_DIR:${PYTHONPATH:-}"

if [[ -d .venv ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

# Matgo public dataset helper: avoid slow公网 downloads.
if [[ ! -d /mnt/fpa5/data/MNIST && -d /root/fpa5/data/MNIST ]]; then
  echo "[INFO] Copy MNIST from /root/fpa5/data to /mnt/fpa5/data"
  mkdir -p /mnt/fpa5/data
  cp -a /root/fpa5/data/MNIST /mnt/fpa5/data/
fi
if [[ ! -d /mnt/fpa5/data/MNIST && -d /public/torchvision_datasets/MNIST ]]; then
  echo "[INFO] Copy MNIST from /public/torchvision_datasets to /mnt/fpa5/data"
  mkdir -p /mnt/fpa5/data
  cp -a /public/torchvision_datasets/MNIST /mnt/fpa5/data/
fi
if [[ ! -d /mnt/fpa5/data/MNIST ]]; then
  echo "[ERROR] MNIST not found at /mnt/fpa5/data/MNIST"
  echo "Please copy Matgo public dataset first: cp -a /public/torchvision_datasets/MNIST /mnt/fpa5/data/"
  exit 1
fi

mkdir -p "$BASE_OUT"

calc_threshold() {
  local n="$1"
  python3 - <<PY
import math
n=int("$n")
ratio=float("$THRESHOLD_RATIO")
print(max(1, math.ceil(n*ratio)))
PY
}

client_key() {
  local n="$1"
  printf "c%03d" "$n"
}

# Save run metadata.
cat > "$BASE_OUT/run_plan.txt" <<EOF
CLIENT_LIST=$CLIENT_LIST
ROUNDS=$ROUNDS
THRESHOLD_RATIO=$THRESHOLD_RATIO
PAILLIER_BITS=$PAILLIER_BITS
SLOT_BITS=$SLOT_BITS
MAX_CLIENT_WORKERS=$MAX_CLIENT_WORKERS
BASE_OUT=$BASE_OUT
EOF

for n in ${CLIENT_LIST}; do
  key="$(client_key "$n")"
  threshold="$(calc_threshold "$n")"
  out_dir="$BASE_OUT/$key"
  echo
  echo "================ RUN clients=${n}, threshold=${threshold}, rounds=${ROUNDS} (${key}) ================"
  rm -rf "$out_dir"
  mkdir -p "$out_dir"
  cmd=(python scripts/run_client_scale_experiment.py
    --config "$CONFIG"
    --dropout-rate 0
    --rounds "$ROUNDS"
    --clients "$n"
    --threshold "$threshold"
    --paillier-bits "$PAILLIER_BITS"
    --slot-bits "$SLOT_BITS"
    --device "$DEVICE"
    --output-dir "$out_dir")
  echo "${cmd[*]}"
  # The config's max_client_workers remains 10 by default. It is intentionally capped to reduce overload on CPU servers.
  "${cmd[@]}" 2>&1 | tee "$out_dir.log"
done

python "$PACK_DIR/scripts/summarize_client_scale_results.py" --base-dir "$FPA_DIR/$BASE_OUT" --zip-out "$ZIP_OUT"

echo
echo "[DONE] Results package: $ZIP_OUT"
