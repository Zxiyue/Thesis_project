#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, zipfile
from pathlib import Path
import pandas as pd


def safe_read_csv(p: Path) -> pd.DataFrame:
    try:
        return pd.read_csv(p)
    except Exception:
        return pd.DataFrame()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base-dir', required=True)
    ap.add_argument('--zip-out', required=True)
    args = ap.parse_args()
    base=Path(args.base_dir)
    rows=[]
    stage_rows=[]
    crypto_rows=[]
    comm_rows=[]
    for d in sorted([x for x in base.iterdir() if x.is_dir()]):
        res=safe_read_csv(d/'dropout_result.csv')
        if res.empty:
            continue
        r=res.iloc[0].to_dict()
        n=int(r.get('clients', d.name.lstrip('c') or 0))
        runtime=safe_read_csv(d/'runtime_cost.csv')
        comm=safe_read_csv(d/'communication_cost.csv')
        crypto=safe_read_csv(d/'crypto_cost.csv')
        metrics=safe_read_csv(d/'metrics_round.csv')
        upload_wall=float(runtime.loc[runtime.get('stage','')=='client_upload_parallel_wall','seconds'].sum()) if not runtime.empty else 0.0
        paillier=float(runtime.loc[runtime.get('stage','')=='client_paillier_encrypt','seconds'].sum()) if not runtime.empty else 0.0
        pedersen=float(runtime.loc[runtime.get('stage','')=='client_pedersen_commit','seconds'].sum()) if not runtime.empty else 0.0
        train=float(runtime.loc[runtime.get('stage','')=='client_local_train','seconds'].sum()) if not runtime.empty else 0.0
        csagg=float(runtime.loc[runtime.get('stage','')=='cs_aggregate','seconds'].sum()) if not runtime.empty else 0.0
        combine=float(runtime.loc[runtime.get('stage','')=='combine_decrypt','seconds'].sum()) if not runtime.empty else 0.0
        opencheck=float(runtime.loc[runtime.get('stage','')=='cs_open_check','seconds'].sum()) if not runtime.empty else 0.0
        kgccheck=float(runtime.loc[runtime.get('stage','')=='kgc_final_model_check','seconds'].sum()) if not runtime.empty else 0.0
        ctmp={}
        if not comm.empty:
            ctmp=comm.groupby('type')['bytes'].sum().to_dict()
        kr=[]
        if not crypto.empty and {'metric','value'}.issubset(crypto.columns):
            for m in ['packing_cipher_count_per_client','paillier_encryptions','paillier_ciphertexts_aggregated','pedersen_commitments','model_dimension']:
                sub=crypto[crypto['metric']==m]
                if not sub.empty:
                    kr.append((m, float(pd.to_numeric(sub['value'], errors='coerce').mean())))
        kdict=dict(kr)
        completed=int(r.get('rounds_completed',0) or 0)
        rows.append({
            'clients': n,
            'threshold': int(r.get('threshold',0) or 0),
            'rounds_target': int(r.get('rounds_target',0) or 0),
            'rounds_completed': completed,
            'accepted': bool(r.get('accepted', False)),
            'status': r.get('status',''),
            'final_acc_pct': round(float(r.get('final_acc',0) or 0)*100, 2),
            'best_acc_pct': round(float(r.get('best_acc',0) or 0)*100, 2),
            'total_comm_mb': round(float(r.get('total_comm_mb',0) or 0), 3),
            'comm_per_round_mb': round(float(r.get('total_comm_mb',0) or 0)/max(completed,1), 3) if completed else 0,
            'timer_sum_h': round(float(r.get('total_wall_time_s_sum_timer',0) or 0)/3600, 3),
            'avg_timer_sum_per_round_s': round(float(r.get('avg_round_time_s_sum_timer',0) or 0), 3) if completed else '',
            'client_upload_parallel_wall_s': round(upload_wall, 3),
            'avg_upload_wall_per_round_s': round(upload_wall/max(completed,1), 3) if completed else '',
            'client_paillier_encrypt_s': round(paillier, 3),
            'client_pedersen_commit_s': round(pedersen, 3),
            'client_local_train_s': round(train, 3),
            'cs_aggregate_s': round(csagg, 3),
            'combine_decrypt_s': round(combine, 3),
            'cs_open_check_s': round(opencheck, 3),
            'kgc_final_model_check_s': round(kgccheck, 3),
            'packing_cipher_count_per_client': int(kdict.get('packing_cipher_count_per_client',0) or 0),
            'paillier_encryptions_per_round': int(kdict.get('paillier_encryptions',0) or 0),
            'ciphertexts_aggregated_per_round': int(kdict.get('paillier_ciphertexts_aggregated',0) or 0),
            'pedersen_commitments_per_round': int(kdict.get('pedersen_commitments',0) or 0),
            'model_dimension': int(kdict.get('model_dimension',0) or 0),
            'upmsg_mb': round(float(ctmp.get('UpMsg',0))/(1024*1024),3),
            'aggmsg_mb': round(float(ctmp.get('AggMsg',0))/(1024*1024),3),
            'sharemsg_mb': round(float(ctmp.get('ShareMsg',0))/(1024*1024),3),
            'modelbroadcast_mb': round(float(ctmp.get('ModelBroadcast',0))/(1024*1024),3),
            'result_dir': str(d),
        })
    df=pd.DataFrame(rows).sort_values('clients') if rows else pd.DataFrame()
    out_csv=base/'client_scale_summary.csv'
    df.to_csv(out_csv, index=False, encoding='utf-8-sig')
    md=base/'client_scale_summary.md'
    if not df.empty:
        keep=['clients','threshold','rounds_completed','accepted','final_acc_pct','total_comm_mb','comm_per_round_mb','avg_upload_wall_per_round_s','paillier_encryptions_per_round','packing_cipher_count_per_client']
        text='# Client-scale experiment summary\n\n'
        text += df[keep].to_markdown(index=False) + '\n\n'
        text += 'Notes: Paillier is 512-bit functional setting; use this experiment for scalability trends, not security-parameter absolute overhead.\n'
        md.write_text(text, encoding='utf-8')
    else:
        md.write_text('# Client-scale experiment summary\n\nNo completed result found.\n', encoding='utf-8')
    summary_json=base/'client_scale_summary.json'
    summary_json.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
    zip_out=Path(args.zip_out)
    with zipfile.ZipFile(zip_out, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in base.rglob('*'):
            if p.is_file():
                z.write(p, p.relative_to(base.parent))
    print(f'[SUMMARY] {out_csv}')
    print(f'[SUMMARY] {md}')
    print(f'[ZIP] {zip_out}')

if __name__ == '__main__':
    main()
