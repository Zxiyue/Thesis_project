#!/usr/bin/env bash
set -euo pipefail
FPA_DIR="${FPA_DIR:-/root/fpa5}"
ROUNDS="${ROUNDS:-5}"
BASE_OUT="${BASE_OUT:-outputs/client_scale_mnist_iid_p512_${ROUNDS}r}"
BASE="$FPA_DIR/$BASE_OUT"

echo "[STATUS] base=$BASE"
if [[ ! -d "$BASE" ]]; then
  echo "not started"
  exit 0
fi

find "$BASE" -maxdepth 2 -name 'dropout_result.csv' | sort | while read -r f; do
  d="$(basename "$(dirname "$f")")"
  echo "--- $d ---"
  python3 - <<PY
import pandas as pd
f='$f'
df=pd.read_csv(f)
cols=['clients','threshold','rounds_completed','accepted','status','final_acc','total_comm_mb','total_wall_time_s_sum_timer']
print(df[[c for c in cols if c in df.columns]].to_string(index=False))
PY
done

if [[ -f "$BASE/client_scale_summary.csv" ]]; then
  echo
  echo "[SUMMARY]"
  cat "$BASE/client_scale_summary.csv"
fi
