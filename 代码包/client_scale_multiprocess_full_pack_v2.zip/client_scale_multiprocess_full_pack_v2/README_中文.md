# client_scale_multiprocess_full_pack_v1

用途：重新运行“客户端数量对比实验”，全程使用 **多进程 HTTP + 开链 + individual 客户端进程**。

默认实验配置：

- 数据集：MNIST-IID
- 客户端数量：5、10、20、40、60、80、100
- 训练轮次：10
- 客户端模式：individual，即每个客户端一个独立 HTTP 服务进程
- 区块链：on，Hardhat 本地链，每个客户端规模重新部署 AuditBoard
- Paillier：512-bit
- Packed slot bits：40
- 掉线：无
- 门限：ceil(0.6 × clients)，即 5→3、10→6、20→12、40→24、60→36、80→48、100→60
- 输出目录：`/root/fpa5/outputs/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain`
- 输出压缩包：`/root/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain_results.zip`

## 1. 解压

```bash
cd /root
unzip -o client_scale_multiprocess_full_pack_v1.zip
cd /root/client_scale_multiprocess_full_pack_v1
```

## 2. 先做 c100 smoke 测试

建议先测试 100 客户端 1 轮能否完整启动、上链和验证：

```bash
bash scripts/run_c100_smoke_1r.sh
```

完成后检查：

```bash
BASE=/root/fpa5/outputs/client_scale_multiprocess_c100_smoke_p512_s40_1r_chain/c100
cat "$BASE/verify_result.csv"
cat "$BASE/blockchain_cost.csv"
ls -lh /root/client_scale_multiprocess_c100_smoke_p512_s40_1r_chain_results.zip
```

正常应看到 `accepted=True`，并且有 1 个 InitTx 和 1 个 FinalTx。

## 3. 正式完整运行

推荐用 tmux：

```bash
tmux new -s client_scale_full
cd /root/client_scale_multiprocess_full_pack_v1
bash scripts/run_client_scale_multiprocess_full.sh
```

退出 tmux 但不中断任务：

```text
Ctrl+B，然后按 D
```

重新进入：

```bash
tmux attach -t client_scale_full
```

## 4. 监控资源

另开终端：

```bash
watch -n 5 "free -h && echo && ps -eo pid,pcpu,pmem,etime,cmd --sort=-pmem | head -25"
```

查看端口数量：

```bash
ss -ltnp | grep -E ':9200|:9300|:94[0-9]{2}|:9500' | wc -l
```

c100 individual 阶段正常接近 102 个服务端口/进程：1 KGC + 1 CS + 100 Client。

## 5. 跑完检查

```bash
ls -lh /root/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain_results.zip

BASE=/root/fpa5/outputs/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain
for d in c005 c010 c020 c040 c060 c080 c100; do
  echo "===== $d ====="
  cat "$BASE/$d/verify_result.csv" 2>/dev/null || echo "missing verify_result.csv"
done
```

每个客户端规模正常应有：

- `accepted=True`
- 10 轮完成
- 1 个 InitTx
- 10 个 FinalTx

## 6. 结果文件

正式完整实验结束后，主要保存：

```text
/root/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain_results.zip
/root/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain.log
```

结果目录内还会生成：

```text
client_scale_multiprocess_summary.csv
gas_by_client_count.csv
communication_by_client_count.csv
runtime_by_client_count.csv
client_scale_multiprocess_summary.md
```

## 7. 可调环境变量

正式脚本支持以下变量覆盖默认值：

```bash
CLIENT_LIST="5 10 20 40 60 80 100"
ROUNDS=10
PAILLIER_BITS=512
SLOT_BITS=40
BLOCKCHAIN=on
CLIENT_MODE=individual
FPA5_ROOT=/root/fpa5
BASE_OUT=outputs/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain
ZIP_OUT=/root/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain_results.zip
```

例如只跑 100 客户端 2 轮：

```bash
CLIENT_LIST="100" ROUNDS=2 BASE_OUT="outputs/c100_test_2r" ZIP_OUT="/root/c100_test_2r.zip" \
  bash scripts/run_client_scale_multiprocess_full.sh
```

## 8. 注意

- 这版脚本会自动把 `/root/fpa5/scripts/start_all_entities.py` 的 health timeout 补到 600 秒。
- 这版脚本会自动限制 OpenMP/OpenBLAS/MKL/PyTorch 线程数为 1，避免 100 个客户端进程过度抢线程。
- 这版脚本会自动清理 9200、9300、9401–9500 端口残留进程。
- 如果 c100 仍失败，先看日志，不要反复重跑：

```bash
find /root/fpa5/outputs/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain/c100 \
  -type f -name "*.log" -print -exec tail -n 80 {} \;
```
