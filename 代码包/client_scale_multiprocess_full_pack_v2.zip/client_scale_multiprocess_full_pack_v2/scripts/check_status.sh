#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="${BASE_DIR:-/root/fpa5/outputs/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain}"
echo "===== resources ====="
free -h || true
echo
echo "===== endpoint ports ====="
ss -ltnp | grep -E ':9200|:9300|:94[0-9]{2}|:9500' || true
echo
echo "===== verify results ====="
for d in "$BASE_DIR"/c???; do
  [[ -d "$d" ]] || continue
  echo "--- $(basename "$d") ---"
  cat "$d/verify_result.csv" 2>/dev/null || echo "no verify_result.csv yet"
done
echo
echo "===== latest log tail ====="
tail -n 80 /root/client_scale_multiprocess_full_mnist_iid_p512_s40_10r_chain.log 2>/dev/null || true
