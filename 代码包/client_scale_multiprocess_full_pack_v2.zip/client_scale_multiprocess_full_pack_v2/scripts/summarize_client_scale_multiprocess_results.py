#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import os
import re
import zipfile
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd


def fnum(x: Any, default: float = 0.0) -> float:
    try:
        if x is None or x == '':
            return default
        if isinstance(x, str) and x.lower() in {'nan', 'none', 'null'}:
            return default
        y = float(x)
        if math.isnan(y) or math.isinf(y):
            return default
        return y
    except Exception:
        return default


def inum(x: Any, default: int = 0) -> int:
    try:
        if x is None or x == '':
            return default
        return int(float(x))
    except Exception:
        return default


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists() or path.stat().st_size == 0:
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()


def read_json(path: Path) -> Dict[str, Any]:
    if not path.exists() or path.stat().st_size == 0:
        return {}
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return {}


def find_col(df: pd.DataFrame, candidates: List[str]) -> str | None:
    for c in candidates:
        if c in df.columns:
            return c
    return None


def bool_from_any(x: Any) -> bool:
    s = str(x).strip().lower()
    return s in {'true', '1', 'yes', 'y', 'accepted'}


def summarize_one(run_dir: Path) -> Dict[str, Any]:
    m = re.search(r'c(\d+)$', run_dir.name)
    clients = int(m.group(1)) if m else 0
    row: Dict[str, Any] = {
        'case': run_dir.name,
        'clients': clients,
        'threshold_expected': math.ceil(clients * 0.6) if clients else '',
        'run_dir': str(run_dir),
    }

    verify = read_csv(run_dir / 'verify_result.csv')
    if not verify.empty:
        last = verify.iloc[-1].to_dict()
        for k, v in last.items():
            lk = str(k).strip()
            if lk not in row:
                row[lk] = v
        if 'accepted' in verify.columns:
            row['accepted'] = bool_from_any(verify['accepted'].iloc[-1])
    else:
        row['accepted'] = False

    metrics = read_csv(run_dir / 'metrics_round.csv')
    if not metrics.empty:
        rcol = find_col(metrics, ['round', 'r'])
        if rcol:
            row['rounds_completed'] = int(pd.to_numeric(metrics[rcol], errors='coerce').dropna().max()) if len(pd.to_numeric(metrics[rcol], errors='coerce').dropna()) else len(metrics)
        else:
            row['rounds_completed'] = len(metrics)
        acc_col = find_col(metrics, ['test_acc', 'accuracy', 'acc'])
        loss_col = find_col(metrics, ['test_loss', 'loss'])
        if acc_col:
            row['final_accuracy'] = fnum(pd.to_numeric(metrics[acc_col], errors='coerce').dropna().iloc[-1] if len(pd.to_numeric(metrics[acc_col], errors='coerce').dropna()) else 0)
        if loss_col:
            row['final_loss'] = fnum(pd.to_numeric(metrics[loss_col], errors='coerce').dropna().iloc[-1] if len(pd.to_numeric(metrics[loss_col], errors='coerce').dropna()) else 0)
    else:
        row.setdefault('rounds_completed', 0)

    comm = read_csv(run_dir / 'communication_cost.csv')
    if not comm.empty:
        bytes_col = find_col(comm, ['bytes', 'size_bytes', 'actual_bytes', 'total_bytes'])
        ptype_col = find_col(comm, ['payload_type', 'type', 'message_type'])
        sec_col = find_col(comm, ['actual_seconds', 'seconds', 'elapsed_seconds'])
        if bytes_col:
            b = pd.to_numeric(comm[bytes_col], errors='coerce').fillna(0)
            row['comm_rows'] = len(comm)
            row['total_comm_bytes'] = int(b.sum())
            row['total_comm_MB'] = float(b.sum() / 1024 / 1024)
            if row.get('rounds_completed'):
                row['comm_MB_per_round'] = row['total_comm_MB'] / max(1, int(row.get('rounds_completed', 1)))
        if sec_col:
            secs = pd.to_numeric(comm[sec_col], errors='coerce').dropna()
            row['comm_actual_seconds_sum'] = float(secs.sum()) if len(secs) else 0.0
        if ptype_col and bytes_col:
            grp = comm.assign(_bytes=pd.to_numeric(comm[bytes_col], errors='coerce').fillna(0)).groupby(ptype_col)['_bytes'].sum().sort_values(ascending=False)
            for ptype, val in grp.head(8).items():
                key = 'comm_MB_' + re.sub(r'[^A-Za-z0-9]+', '_', str(ptype)).strip('_')[:40]
                row[key] = float(val / 1024 / 1024)

    bc = read_csv(run_dir / 'blockchain_cost.csv')
    if not bc.empty:
        gas_col = find_col(bc, ['gas_used', 'gas', 'gasUsed'])
        tx_col = find_col(bc, ['tx_type', 'type', 'name'])
        lat_col = find_col(bc, ['latency_seconds', 'seconds', 'actual_seconds'])
        if gas_col:
            gas = pd.to_numeric(bc[gas_col], errors='coerce').fillna(0)
            row['chain_tx_count'] = len(bc)
            row['total_gas'] = int(gas.sum())
            if tx_col:
                txs = bc[tx_col].astype(str)
                init_mask = txs.str.contains('Init', case=False, na=False)
                final_mask = txs.str.contains('Final', case=False, na=False)
                row['init_tx_count'] = int(init_mask.sum())
                row['finaltx_count'] = int(final_mask.sum())
                if init_mask.any():
                    row['init_tx_gas'] = int(pd.to_numeric(bc.loc[init_mask, gas_col], errors='coerce').fillna(0).iloc[0])
                if final_mask.any():
                    final_gas = pd.to_numeric(bc.loc[final_mask, gas_col], errors='coerce').dropna()
                    row['avg_finaltx_gas'] = float(final_gas.mean()) if len(final_gas) else 0.0
                    row['min_finaltx_gas'] = int(final_gas.min()) if len(final_gas) else 0
                    row['max_finaltx_gas'] = int(final_gas.max()) if len(final_gas) else 0
            else:
                row['avg_tx_gas'] = float(gas.mean())
        if lat_col:
            lat = pd.to_numeric(bc[lat_col], errors='coerce').dropna()
            row['chain_latency_seconds_sum'] = float(lat.sum()) if len(lat) else 0.0

    rt = read_csv(run_dir / 'runtime_cost.csv')
    if not rt.empty:
        metric_col = find_col(rt, ['metric', 'name', 'stage'])
        val_col = find_col(rt, ['value', 'seconds', 'time_seconds'])
        if metric_col and val_col:
            rt2 = rt.copy()
            rt2['_value'] = pd.to_numeric(rt2[val_col], errors='coerce')
            total = rt2['_value'].dropna().sum()
            row['runtime_numeric_sum'] = float(total)
            for metric, sub in rt2.groupby(metric_col):
                vals = sub['_value'].dropna()
                if not len(vals):
                    continue
                key = 'runtime_mean_' + re.sub(r'[^A-Za-z0-9]+', '_', str(metric)).strip('_')[:50]
                row[key] = float(vals.mean())

    crypto = read_csv(run_dir / 'crypto_cost.csv')
    if not crypto.empty:
        metric_col = find_col(crypto, ['metric', 'name', 'stage'])
        val_col = find_col(crypto, ['value', 'seconds', 'time_seconds'])
        if metric_col and val_col:
            c2 = crypto.copy()
            c2['_value'] = pd.to_numeric(c2[val_col], errors='coerce')
            row['crypto_numeric_sum'] = float(c2['_value'].dropna().sum())
            for metric, sub in c2.groupby(metric_col):
                vals = sub['_value'].dropna()
                if not len(vals):
                    continue
                key = 'crypto_mean_' + re.sub(r'[^A-Za-z0-9]+', '_', str(metric)).strip('_')[:50]
                row[key] = float(vals.mean())

    trace = read_json(run_dir / 'run_trace.json')
    if trace:
        row['trace_completed'] = bool(trace.get('completed', False))
        row['trace_accepted'] = bool(trace.get('accepted', False))
        if 'rounds' in trace and isinstance(trace['rounds'], list):
            row['trace_round_count'] = len(trace['rounds'])

    return row


def df_to_markdown_no_tabulate(df: pd.DataFrame) -> str:
    """Render a small DataFrame as a GitHub-style markdown table without tabulate."""
    if df is None or len(df) == 0:
        return '(No summary rows found.)'
    cols = list(df.columns)
    rows = []
    for _, r in df.iterrows():
        rows.append([str(r.get(c, '') if pd.notna(r.get(c, '')) else '') for c in cols])
    widths = []
    for i, c in enumerate(cols):
        widths.append(max(len(str(c)), *(len(row[i]) for row in rows)) if rows else len(str(c)))
    def fmt(vals):
        return '| ' + ' | '.join(str(v).ljust(widths[i]) for i, v in enumerate(vals)) + ' |'
    out = [fmt(cols), '| ' + ' | '.join('-' * w for w in widths) + ' |']
    out += [fmt(row) for row in rows]
    return '\n'.join(out)


def write_markdown(base_dir: Path, summary: pd.DataFrame) -> None:
    md = []
    md.append('# Client Scale Multiprocess Summary\n')
    md.append(f'- Base dir: `{base_dir}`')
    md.append(f'- Runs: {len(summary)}')
    if len(summary):
        ok = summary['accepted'].astype(str).str.lower().isin(['true', '1']).sum() if 'accepted' in summary.columns else 0
        md.append(f'- Accepted runs: {ok}/{len(summary)}')
    md.append('\n## Key table\n')
    keys = [c for c in ['case','clients','threshold_expected','rounds_completed','accepted','final_accuracy','total_comm_MB','comm_MB_per_round','init_tx_gas','finaltx_count','avg_finaltx_gas','total_gas'] if c in summary.columns]
    if keys and len(summary):
        md.append(df_to_markdown_no_tabulate(summary[keys]))
    else:
        md.append('(No summary rows found.)')
    md.append('\n')
    (base_dir / 'client_scale_multiprocess_summary.md').write_text('\n'.join(md), encoding='utf-8')


def zip_dir(base_dir: Path, zip_out: Path, extra_files: list[Path] | None = None) -> None:
    zip_out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_out, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(base_dir.rglob('*')):
            if p.is_file():
                zf.write(p, arcname=str(base_dir.name + '/' + p.relative_to(base_dir).as_posix()))
        for p in extra_files or []:
            if p.exists() and p.is_file():
                zf.write(p, arcname=str(base_dir.name + '/logs/' + p.name))
    print(f'[OK] zip written: {zip_out}')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base-dir', required=True)
    ap.add_argument('--zip-out', required=True)
    ap.add_argument('--extra-log', action='append', default=[])
    args = ap.parse_args()

    base_dir = Path(args.base_dir).resolve()
    runs = sorted([p for p in base_dir.iterdir() if p.is_dir() and re.match(r'c\d+$', p.name)], key=lambda p: int(p.name[1:])) if base_dir.exists() else []
    rows = [summarize_one(p) for p in runs]
    summary = pd.DataFrame(rows)
    if len(summary):
        summary = summary.sort_values('clients')
    base_dir.mkdir(parents=True, exist_ok=True)
    summary.to_csv(base_dir / 'client_scale_multiprocess_summary.csv', index=False)

    if len(summary):
        gas_cols = [c for c in ['case','clients','init_tx_gas','finaltx_count','avg_finaltx_gas','min_finaltx_gas','max_finaltx_gas','total_gas','chain_tx_count','chain_latency_seconds_sum'] if c in summary.columns]
        if gas_cols:
            summary[gas_cols].to_csv(base_dir / 'gas_by_client_count.csv', index=False)
        comm_cols = [c for c in summary.columns if c in ['case','clients','rounds_completed','total_comm_bytes','total_comm_MB','comm_MB_per_round','comm_actual_seconds_sum'] or c.startswith('comm_MB_')]
        if comm_cols:
            summary[comm_cols].to_csv(base_dir / 'communication_by_client_count.csv', index=False)
        runtime_cols = [c for c in summary.columns if c in ['case','clients','runtime_numeric_sum','crypto_numeric_sum'] or c.startswith('runtime_mean_') or c.startswith('crypto_mean_')]
        if runtime_cols:
            summary[runtime_cols].to_csv(base_dir / 'runtime_by_client_count.csv', index=False)

    write_markdown(base_dir, summary)
    print(summary.to_string(index=False) if len(summary) else '[WARN] no cNNN run directories found')
    extra = [Path(x) for x in args.extra_log]
    zip_dir(base_dir, Path(args.zip_out), extra_files=extra)


if __name__ == '__main__':
    main()
