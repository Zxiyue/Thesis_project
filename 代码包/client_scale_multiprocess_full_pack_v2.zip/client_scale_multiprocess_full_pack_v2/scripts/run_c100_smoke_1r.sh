#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export CLIENT_LIST="${CLIENT_LIST:-100}"
export ROUNDS="${ROUNDS:-1}"
export CLIENT_MODE="${CLIENT_MODE:-individual}"
export BLOCKCHAIN="${BLOCKCHAIN:-on}"
export PAILLIER_BITS="${PAILLIER_BITS:-512}"
export SLOT_BITS="${SLOT_BITS:-40}"
export BASE_OUT="${BASE_OUT:-outputs/client_scale_multiprocess_c100_smoke_p512_s40_1r_chain}"
export ZIP_OUT="${ZIP_OUT:-/root/client_scale_multiprocess_c100_smoke_p512_s40_1r_chain_results.zip}"
export SUITE_LOG="${SUITE_LOG:-/root/client_scale_multiprocess_c100_smoke_1r.log}"
export CLEAN_BASE_OUT="${CLEAN_BASE_OUT:-1}"
bash "$SCRIPT_DIR/run_client_scale_multiprocess_full.sh"
