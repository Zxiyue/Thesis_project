# Ours-basic MNIST-IID 50r Paillier-2048 clean integrated timing pack

This package resets `/root/fpa5` protocol files to un-packed Ours-basic core, integrates CS timing fields directly into the restored Ours-basic code, generates a clean MNIST-IID 50-round Paillier-2048 config, and runs the experiment in foreground.

It is used as the un-packed Ours-basic baseline to compare with Ours-packed 2048-bit s34/auto.

## It will restore these files

- `fl_audit/protocol/entities.py`
- `scripts/run_kgc_server.py`
- `scripts/run_cs_server.py`

Restore priority:
1. Use `/root/fpa5/*.before_ours_packed` backups if present.
2. Fallback to packaged pristine Ours-basic files.

Then it integrates these timing fields into the Ours-basic code:

- `cs_decrypt_combine`
- `cs_unpack_vector`
- `cs_decode_aggregate`
- `cs_model_update`

For un-packed Ours-basic, `cs_unpack_vector` means converting coordinate-wise decrypted plaintexts to the aggregate vector; it is expected to be near zero.

## Experiment

- Dataset: MNIST-IID
- Rounds: 50
- Paillier bits: 2048
- Packing: disabled
- local_lr: 0.20
- parallel clients: true
- output: `outputs/ours_basic_mnist_iid_50r_lr020_p2048_clean_timing`

## Run

```bash
cd /root
unzip -o ours_basic_iid_p2048_50r_clean_integrated_pack.zip

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

stdbuf -oL -eL /root/ours_basic_iid_p2048_50r_clean_integrated_pack/scripts/run_ours_basic_iid_p2048_50r_clean_integrated.sh
```

## Check status in another terminal

```bash
/root/ours_basic_iid_p2048_50r_clean_integrated_pack/scripts/check_ours_basic_iid_p2048_clean_status.sh
```

## Result zip

After successful completion:

```text
/root/ours_basic_mnist_iid_50r_p2048_clean_integrated_timing_results.zip
```
