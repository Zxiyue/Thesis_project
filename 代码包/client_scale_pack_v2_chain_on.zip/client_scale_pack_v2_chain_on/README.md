# client_scale_pack_v2_chain_on

Ours-packed client-scale scalability experiment package aligned with the current protocol design in `流程验证联邦学习.docx`.

## Default setting

| item | value |
|---|---:|
| scheme | Ours-packed |
| dataset | MNIST-IID |
| clients | 5, 10, 20, 40, 60, 80, 100 |
| rounds | 10 |
| threshold | ceil(0.6 * n) |
| Paillier | 512-bit functional setting |
| slot_bits | 40 |
| dropout | none |
| blockchain | ON, Hardhat local AuditBoard |
| on-chain tx | InitTx + 10 * FinalTx for each client scale |

This experiment is for scalability trends. It uses 512-bit Paillier to reduce running cost; the main performance/security-parameter experiments use 2048-bit Paillier.

## Run

```bash
cd /root
unzip -o client_scale_pack_v2_chain_on.zip
cd /root/client_scale_pack_v2_chain_on

stdbuf -oL -eL bash scripts/run_client_scale_suite.sh \
  | tee /root/client_scale_suite_v2_chain.log
```

## Status

```bash
bash /root/client_scale_pack_v2_chain_on/scripts/check_client_scale_status.sh
```

## Runtime estimate

```bash
python /root/client_scale_pack_v2_chain_on/scripts/estimate_client_scale_runtime.py
```

Default conservative estimate: about 15-23 hours on the current CPU server.

## Output

```text
/root/client_scale_mnist_iid_p512_s40_10r_chain_results.zip
```

Main summary files inside the result directory:

- `client_scale_summary.csv`: client count vs communication/time/crypto/blockchain summary.
- `gas_by_client_count.csv`: client count vs InitTx/FinalTx gas.
- each `cXXX/blockchain_cost.csv`: per-transaction gas and latency.
- each `cXXX/runtime_cost.csv`: local training, encryption, commitment, aggregation, combine, chain tx timings.
- each `cXXX/communication_cost.csv`: message-level communication cost.
- each `cXXX/verify_result.csv`: chain verification result.

## Custom examples

Smoke run:

```bash
ROUNDS=2 CLIENT_LIST="5 10" bash scripts/run_client_scale_suite.sh
```

Run without launching blockchain, for debugging only:

```bash
BLOCKCHAIN=off ROUNDS=2 CLIENT_LIST="5" bash scripts/run_client_scale_suite.sh
```
