#!/usr/bin/env python3
from __future__ import annotations
import argparse, math

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--clients', default='5 10 20 40 60 80 100')
    ap.add_argument('--rounds', type=int, default=10)
    ap.add_argument('--max-workers', type=int, default=10)
    args = ap.parse_args()
    ns=[int(x) for x in args.clients.replace(',', ' ').split()]
    # Empirical anchor from completed dropout experiment: c10, p512, packed, MNIST-IID, 20 rounds,
    # client_upload_parallel_wall ~= 147.7 s/round with max_client_workers=10.
    # For larger n with worker cap=10, crypto-dominated work grows approximately by waves.
    base_per_round_c10=147.7
    rows=[]
    total=0.0
    for n in ns:
        if n <= 10:
            per_round=max(60.0, base_per_round_c10*(0.45+0.055*n))  # c5 roughly lower, c10 anchor
        else:
            # scale by number of 10-client waves with a small efficiency correction
            waves=math.ceil(n/10)
            per_round=base_per_round_c10*waves*0.82
        wall=per_round*args.rounds
        # add setup/eval/check overhead and uncertainty
        low=wall*1.40/60
        high=wall*2.10/60
        rows.append((n, per_round/60, low, high))
        total += wall
    print('Estimated runtime for client-scale suite (functional p512, chain-on setting)')
    print('clients, est_min_per_round, est_total_low_min, est_total_high_min')
    for n,pr,lo,hi in rows:
        print(f'{n},{pr:.1f},{lo:.1f},{hi:.1f}')
    print(f'TOTAL_LOW_HOURS,{total*1.40/3600:.2f}')
    print(f'TOTAL_HIGH_HOURS,{total*2.10/3600:.2f}')
    print('Note: estimates are based on completed p512 runs; Hardhat overhead is included only as a small transaction overhead. Actual time depends on CPU cores and load.')
if __name__ == '__main__':
    main()
