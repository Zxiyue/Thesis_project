#!/usr/bin/env bash
set -euo pipefail
FPA_DIR="${FPA_DIR:-/root/fpa5}"
ROUNDS="${ROUNDS:-10}"
SLOT_BITS="${SLOT_BITS:-40}"
BASE_OUT="${BASE_OUT:-outputs/client_scale_mnist_iid_p512_s${SLOT_BITS}_${ROUNDS}r_chain}"
BASE="$FPA_DIR/$BASE_OUT"

echo "[STATUS] base=$BASE"
if [[ ! -d "$BASE" ]]; then
  echo "not started"
  exit 0
fi

find "$BASE" -maxdepth 2 -name 'dropout_result.csv' | sort | while read -r f; do
  d="$(basename "$(dirname "$f")")"
  echo "--- $d ---"
  python3 - <<PY
import pandas as pd
f='$f'
df=pd.read_csv(f)
cols=['clients','threshold','rounds_completed','accepted','status','final_acc','total_comm_mb','avg_final_tx_gas','min_final_tx_gas','max_final_tx_gas','total_wall_time_s_sum_timer']
print(df[[c for c in cols if c in df.columns]].to_string(index=False))
PY
  if [[ -f "$(dirname "$f")/blockchain_cost.csv" ]]; then
    echo "blockchain_cost: $(dirname "$f")/blockchain_cost.csv"
  fi
done

if [[ -f "$BASE/client_scale_summary.csv" ]]; then
  echo
  echo "[SUMMARY] $BASE/client_scale_summary.csv"
  cat "$BASE/client_scale_summary.csv"
fi
if [[ -f "$BASE/gas_by_client_count.csv" ]]; then
  echo
  echo "[GAS] $BASE/gas_by_client_count.csv"
  cat "$BASE/gas_by_client_count.csv"
fi
