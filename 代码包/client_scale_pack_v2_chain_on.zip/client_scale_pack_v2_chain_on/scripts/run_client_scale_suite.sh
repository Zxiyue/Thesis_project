#!/usr/bin/env bash
set -euo pipefail

FPA_DIR="${FPA_DIR:-/root/fpa5}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${CONFIG:-configs/client_scale_mnist_iid_p512_packed.yaml}"
DEVICE="${DEVICE:-cpu}"
ROUNDS="${ROUNDS:-10}"
CLIENT_LIST="${CLIENT_LIST:-5 10 20 40 60 80 100}"
THRESHOLD_RATIO="${THRESHOLD_RATIO:-0.6}"
PAILLIER_BITS="${PAILLIER_BITS:-512}"
SLOT_BITS="${SLOT_BITS:-40}"
MAX_CLIENT_WORKERS="${MAX_CLIENT_WORKERS:-10}"
BLOCKCHAIN="${BLOCKCHAIN:-on}"
BASE_OUT="${BASE_OUT:-outputs/client_scale_mnist_iid_p512_s${SLOT_BITS}_${ROUNDS}r_chain}"
ZIP_OUT="${ZIP_OUT:-/root/client_scale_mnist_iid_p512_s${SLOT_BITS}_${ROUNDS}r_chain_results.zip}"
HARDHAT_LOG="${HARDHAT_LOG:-/root/client_scale_hardhat_v2.log}"

bash "$PACK_DIR/scripts/install_client_scale_pack.sh"
cd "$FPA_DIR"
export PYTHONPATH="$FPA_DIR:${PYTHONPATH:-}"

if [[ -d .venv ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

# Matgo public dataset helper: avoid slow public Internet downloads.
if [[ ! -d /mnt/fpa5/data/MNIST && -d /root/fpa5/data/MNIST ]]; then
  echo "[INFO] Copy MNIST from /root/fpa5/data to /mnt/fpa5/data"
  mkdir -p /mnt/fpa5/data
  cp -a /root/fpa5/data/MNIST /mnt/fpa5/data/
fi
if [[ ! -d /mnt/fpa5/data/MNIST && -d /public/torchvision_datasets/MNIST ]]; then
  echo "[INFO] Copy MNIST from /public/torchvision_datasets to /mnt/fpa5/data"
  mkdir -p /mnt/fpa5/data
  cp -a /public/torchvision_datasets/MNIST /mnt/fpa5/data/
fi
if [[ ! -d /mnt/fpa5/data/MNIST ]]; then
  echo "[ERROR] MNIST not found at /mnt/fpa5/data/MNIST"
  echo "Please copy Matgo public dataset first: cp -a /public/torchvision_datasets/MNIST /mnt/fpa5/data/"
  exit 1
fi

rpc_ready() {
  python3 - <<'PY_RPC' >/dev/null 2>&1
import json, urllib.request
req = urllib.request.Request(
    'http://127.0.0.1:8545',
    data=json.dumps({'jsonrpc':'2.0','method':'web3_clientVersion','params':[],'id':1}).encode(),
    headers={'Content-Type':'application/json'},
)
try:
    with urllib.request.urlopen(req, timeout=2) as r:
        raise SystemExit(0 if r.status == 200 else 1)
except Exception:
    raise SystemExit(1)
PY_RPC
}

ensure_blockchain() {
  if [[ "$BLOCKCHAIN" != "on" && "$BLOCKCHAIN" != "true" && "$BLOCKCHAIN" != "1" ]]; then
    echo "[INFO] BLOCKCHAIN=$BLOCKCHAIN, running local audit-chain verification only."
    return 0
  fi
  echo "[INFO] Blockchain enabled. Checking Hardhat RPC http://127.0.0.1:8545 ..."
  if ! rpc_ready; then
    echo "[INFO] Starting Hardhat node in background. Log: $HARDHAT_LOG"
    nohup npx hardhat node --hostname 127.0.0.1 > "$HARDHAT_LOG" 2>&1 &
    echo $! > /root/client_scale_hardhat_v2.pid
    for _ in $(seq 1 60); do
      if rpc_ready; then
        break
      fi
      sleep 1
    done
  fi
  if ! rpc_ready; then
    echo "[ERROR] Hardhat RPC is not ready. Check $HARDHAT_LOG"
    exit 1
  fi
  echo "[INFO] Hardhat RPC is ready. A fresh AuditBoard contract will be deployed before each client-scale run."
}

ensure_blockchain
mkdir -p "$BASE_OUT"

# Build a runtime config so BLOCKCHAIN=off can really disable chain submission.
RUNTIME_CONFIG="$BASE_OUT/runtime_config.yaml"
python3 - "$CONFIG" "$RUNTIME_CONFIG" "$BLOCKCHAIN" <<'PY_CFG'
import sys, yaml
src, dst, flag = sys.argv[1], sys.argv[2], sys.argv[3]
with open(src, 'r', encoding='utf-8') as f:
    cfg = yaml.safe_load(f)
enabled = flag.lower() in {'on', 'true', '1', 'yes'}
cfg.setdefault('blockchain', {})['enabled'] = enabled
cfg['blockchain'].setdefault('rpc_url', 'http://127.0.0.1:8545')
cfg['blockchain'].setdefault('contract_json', 'outputs/contract.json')
with open(dst, 'w', encoding='utf-8') as f:
    yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=False)
print(f"[INFO] runtime config written to {dst}; blockchain.enabled={enabled}")
PY_CFG

calc_threshold() {
  local n="$1"
  python3 - <<PY_CALC
import math
n=int("$n")
ratio=float("$THRESHOLD_RATIO")
print(max(1, math.ceil(n*ratio)))
PY_CALC
}

client_key() {
  local n="$1"
  printf "c%03d" "$n"
}

cat > "$BASE_OUT/run_plan.txt" <<EOF2
CLIENT_LIST=$CLIENT_LIST
ROUNDS=$ROUNDS
THRESHOLD_RATIO=$THRESHOLD_RATIO
PAILLIER_BITS=$PAILLIER_BITS
SLOT_BITS=$SLOT_BITS
MAX_CLIENT_WORKERS=$MAX_CLIENT_WORKERS
BLOCKCHAIN=$BLOCKCHAIN
BASE_OUT=$BASE_OUT
ZIP_OUT=$ZIP_OUT
HARDHAT_LOG=$HARDHAT_LOG
EOF2

for n in ${CLIENT_LIST}; do
  key="$(client_key "$n")"
  threshold="$(calc_threshold "$n")"
  out_dir="$BASE_OUT/$key"
  echo
  echo "================ RUN clients=${n}, threshold=${threshold}, rounds=${ROUNDS}, chain=${BLOCKCHAIN} (${key}) ================"
  rm -rf "$out_dir"
  mkdir -p "$out_dir"
  if [[ "$BLOCKCHAIN" == "on" || "$BLOCKCHAIN" == "true" || "$BLOCKCHAIN" == "1" ]]; then
    echo "[INFO] Deploying fresh AuditBoard for clients=${n} ..."
    npx hardhat run scripts/deploy.js --network localhost
  fi
  cmd=(python scripts/run_client_scale_experiment.py
    --config "$RUNTIME_CONFIG"
    --dropout-rate 0
    --rounds "$ROUNDS"
    --clients "$n"
    --threshold "$threshold"
    --paillier-bits "$PAILLIER_BITS"
    --slot-bits "$SLOT_BITS"
    --device "$DEVICE"
    --output-dir "$out_dir")
  echo "${cmd[*]}"
  # The config's max_client_workers remains capped at 10 to reduce overload on CPU servers.
  "${cmd[@]}" 2>&1 | tee "$out_dir.log"
done

python "$PACK_DIR/scripts/summarize_client_scale_results.py" --base-dir "$FPA_DIR/$BASE_OUT" --zip-out "$ZIP_OUT"

echo
echo "[DONE] Results package: $ZIP_OUT"
