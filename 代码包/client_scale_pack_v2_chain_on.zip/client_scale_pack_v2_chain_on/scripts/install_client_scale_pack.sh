#!/usr/bin/env bash
set -euo pipefail

FPA_DIR="${FPA_DIR:-/root/fpa5}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ ! -d "$FPA_DIR" ]]; then
  echo "[ERROR] FPA_DIR not found: $FPA_DIR"
  echo "Please set FPA_DIR=/path/to/fpa5 and rerun."
  exit 1
fi

mkdir -p "$FPA_DIR/scripts" "$FPA_DIR/configs" "$FPA_DIR/contracts" "$FPA_DIR/fl_audit/blockchain"

echo "[STEP] Reset core protocol files to pristine Ours-basic base"
python3 "$PACK_DIR/patch/reset_to_pristine_base.py"
echo "[STEP] Apply Ours-packed patch"
python3 "$PACK_DIR/patch/apply_ours_packed_patch.py"

cp -f "$PACK_DIR/fpa5_patch/scripts/run_client_scale_experiment.py" "$FPA_DIR/scripts/run_client_scale_experiment.py"
cp -f "$PACK_DIR/fpa5_patch/configs/client_scale_mnist_iid_p512_packed.yaml" "$FPA_DIR/configs/client_scale_mnist_iid_p512_packed.yaml"

# Install/refresh blockchain helper files used by the chain-on scalability experiment.
cp -f "$PACK_DIR/fpa5_patch/contracts/AuditBoard.sol" "$FPA_DIR/contracts/AuditBoard.sol"
cp -f "$PACK_DIR/fpa5_patch/scripts/deploy.js" "$FPA_DIR/scripts/deploy.js"
cp -f "$PACK_DIR/fpa5_patch/hardhat.config.js" "$FPA_DIR/hardhat.config.js"
cp -f "$PACK_DIR/fpa5_patch/fl_audit/blockchain/contract_client.py" "$FPA_DIR/fl_audit/blockchain/contract_client.py"
cp -f "$PACK_DIR/fpa5_patch/fl_audit/blockchain/__init__.py" "$FPA_DIR/fl_audit/blockchain/__init__.py"

chmod +x "$FPA_DIR/scripts/run_client_scale_experiment.py" || true

echo "[OK] Client-scale chain-on runner installed into $FPA_DIR"
echo "     - scripts/run_client_scale_experiment.py"
echo "     - configs/client_scale_mnist_iid_p512_packed.yaml"
echo "     - contracts/AuditBoard.sol"
echo "     - scripts/deploy.js"
