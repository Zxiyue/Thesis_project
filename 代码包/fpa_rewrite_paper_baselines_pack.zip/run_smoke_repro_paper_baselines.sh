#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}
python3 scripts/run_repro_baseline.py --config configs/smoke_repro_priverifl_a_mnist_iid_2r.yaml
python3 scripts/run_repro_baseline.py --config configs/smoke_repro_rtpfl_mnist_iid_dropout_2r.yaml
