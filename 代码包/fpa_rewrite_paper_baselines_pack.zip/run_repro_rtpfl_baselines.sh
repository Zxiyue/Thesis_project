#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}
python3 scripts/run_repro_baseline.py --config configs/baseline_repro_rtpfl_mnist_iid_50r.yaml
python3 scripts/run_repro_baseline.py --config configs/baseline_repro_rtpfl_mnist_iid_dropout_50r.yaml
cd /root
zip -qr repro_rtpfl_baseline_results.zip \
  fpa5/outputs/baseline_repro_rtpfl_mnist_iid_50r \
  fpa5/outputs/baseline_repro_rtpfl_mnist_iid_dropout_50r
