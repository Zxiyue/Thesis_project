# 重写后的论文对比方案实验包

本包用于替换之前的 `style baseline` 和上一版不够准确的 `full baseline`。新增两个更贴近论文流程的复现实验：

1. `PriVeriFL-A-reproduction`
2. `RTP-FL-reproduction`

## 一、相对旧 baseline 的主要变化

### 1. PriVeriFL-A-reproduction

旧版本问题：使用二进制 low_bits 切分，并在服务器侧直接解密 Paillier 聚合结果。

重写后实现：

- 按论文流程执行 `m_i <- m_i * 10^8`；
- 按十进制小数敏感位切分：`A_i, B_i <- split(m_i)`；
- `A_i` 使用 BatchCrypt-style signed packing + Paillier 加密；
- `B_i` 使用 AES-GCM 对称加密；
- 聚合器对 `A_i` 密文执行 `PHE.Mul(vhat_ij, n_i)` 和同态加法；
- 聚合器解密 `B_i` 后计算 `M_B=sum_i B_i*n_i`；
- 模拟参与方侧执行 `PHE.Dec`、decode、combine；
- 验证 `H.Hash(M') = H.Eval(h_i,n_i)`；
- 分别对 `h_i` 和 `n_i` 生成签名并验证。

正式配置默认使用 `paillier_bits=2048`，与 PriVeriFL 论文实验安全参数一致。但 2048-bit Paillier 会明显变慢，建议先跑 smoke test。

### 2. RTP-FL-reproduction

旧版本问题：只是普通 Shamir/bivariate repair 近似，没有实现 regenerating-code-based repair，也没有实现论文 Algorithm 1 的向量式部分解密。

重写后实现：

- 使用 Paillier 加密聚合；
- 使用 `(N,k,d)` product-matrix MBR regenerating code 生成 repairable private-key segments；
- 参数对应 `alpha=d, beta=1, t=kd-k(k-1)/2`；
- 记录生成矩阵 `G` 和右逆矩阵块 `R_i`；
- 任意 `d` 个正常客户端为掉线客户端提供 `beta=1` repair symbol；
- 修复掉线客户端私钥段；
- 按论文 Algorithm 1 思路执行 `c_i=c^{s_i R_i}` 向量式部分解密，并通过 Hadamard product 合成 `c^{Delta*gammaM}` 后解密；
- 记录 `repair_symbols`、`repaired_private_key_segments` 和 `paper_partial_decryption_ciphertexts`。

说明：这是可运行的实验复现代码，不是生产级密码库。有限域线性化多项式与 product-matrix MBR 采用工程化实现，以便和现有 FL 实验框架对接。

## 二、上传和解压

把本压缩包上传到服务器：

```bash
/root/fpa_rewrite_paper_baselines_pack.zip
```

解压到 `/root/fpa5`：

```bash
cd /root/fpa5
unzip -o /root/fpa_rewrite_paper_baselines_pack.zip -d /root/fpa5
chmod +x run_repro_priverifl_a_baselines.sh
chmod +x run_repro_rtpfl_baselines.sh
chmod +x run_all_repro_paper_baselines.sh
chmod +x run_smoke_repro_paper_baselines.sh
```

## 三、先运行 smoke test

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_smoke_repro_paper_baselines.sh
```

检查结果：

```bash
cat outputs/smoke_repro_priverifl_a_mnist_iid_2r/verify_result.csv
cat outputs/smoke_repro_rtpfl_mnist_iid_dropout_2r/verify_result.csv
```

应看到 `accepted=True`。

## 四、正式运行

### 只跑 PriVeriFL-A reproduction

```bash
tmux new -s repropriveri
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_repro_priverifl_a_baselines.sh
```

完成后下载：

```text
/root/repro_priverifl_a_baseline_results.zip
```

### 只跑 RTP-FL reproduction

```bash
tmux new -s reprortpfl
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_repro_rtpfl_baselines.sh
```

完成后下载：

```text
/root/repro_rtpfl_baseline_results.zip
```

### 全部运行

```bash
tmux new -s reprobaselines
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_all_repro_paper_baselines.sh
```

完成后下载：

```text
/root/repro_paper_baseline_all_results.zip
```

## 五、监控进度

```bash
cd /root/fpa5
for d in outputs/baseline_repro_priverifl_a_mnist_iid_50r \
         outputs/baseline_repro_priverifl_a_mnist_noniid_50r \
         outputs/baseline_repro_rtpfl_mnist_iid_50r \
         outputs/baseline_repro_rtpfl_mnist_iid_dropout_50r; do
  echo "================ $d ================"
  tail -n 5 "$d/metrics_round.csv" 2>/dev/null || true
  cat "$d/verify_result.csv" 2>/dev/null || true
  tail -n 5 "$d/baseline_cost.csv" 2>/dev/null || true
done
```

## 六、配置说明

### PriVeriFL-A reproduction

正式配置：

```text
configs/baseline_repro_priverifl_a_mnist_iid_50r.yaml
configs/baseline_repro_priverifl_a_mnist_noniid_50r.yaml
```

关键参数：

```yaml
crypto:
  paillier_bits: 2048
baseline:
  scheme: priverifl_a_repro
  priverifl_a:
    decimal_digits: 8
    decimal_scale: 100000000
    sensitive_digits: 2
    payload_bits: auto
    slot_bits: auto
    pack_size: auto
```

### RTP-FL reproduction

正式配置：

```text
configs/baseline_repro_rtpfl_mnist_iid_50r.yaml
configs/baseline_repro_rtpfl_mnist_iid_dropout_50r.yaml
```

关键参数：

```yaml
crypto:
  paillier_bits: 512
baseline:
  scheme: rtpfl_repro
  rtpfl:
    N: 5
    k: 3
    d: 3
    decimal_scale: 10000
    decrypt_mode: paper_hadamard
```

RTP-FL 默认先用 512-bit 是因为 Algorithm-1-like partial decryption 对每个坐标需要多次模幂运算，2048-bit 会非常慢。若只做密码开销单点测试，可以把 `paillier_bits` 改成 2048。PriVeriFL-A 正式配置默认是 2048-bit，但 smoke test 使用 512-bit。

## 七、论文命名建议

建议在论文实验表中命名为：

```text
PriVeriFL-A reproduction
RTP-FL reproduction
```

不要再使用之前的：

```text
PriVeriFL-A-style
RTP-FL-style
```

同时建议在实验设置中加一句：

```text
For reproducible real-data FL comparison, we re-implement the main protocol mechanisms described in PriVeriFL-A and RTP-FL, while adapting cryptographic engineering details to the same Python FL framework used by our prototype.
```

中文意思：为了真实数据联邦学习对比，本文按论文描述重写 PriVeriFL-A 与 RTP-FL 的主要协议机制，并将工程实现适配到本文原型所使用的 Python 实验框架中。
