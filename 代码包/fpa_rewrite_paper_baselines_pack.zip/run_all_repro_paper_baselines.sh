#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}
./run_repro_priverifl_a_baselines.sh
./run_repro_rtpfl_baselines.sh
cd /root
zip -qr repro_paper_baseline_all_results.zip \
  repro_priverifl_a_baseline_results.zip \
  repro_rtpfl_baseline_results.zip
