# 继续补充 local_lr 敏感性实验

本补丁新增两组真实数据实验：

- `local_lr = 0.25`
- `local_lr = 0.30`

统一设置：

- 数据集：Fashion-MNIST
- 划分：Non-IID
- 客户端：5
- 门限：3
- 轮次：30
- `server_lr = 1.0`
- 掉线：无，`dropout: {}`
- 模型：`tiny_cnn`

## 使用

在服务器执行：

```bash
cd /root/fpa5
unzip -o /root/fpa_local_lr_extend2_pack.zip -d /root/fpa5
chmod +x run_local_lr_sensitivity_extend2.sh
```

检查：

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
python3 scripts/check_dataset_loader.py --configs configs/sensitivity_local_lr_0_25.yaml configs/sensitivity_local_lr_0_30.yaml
```

运行：

```bash
tmux new -s localextend2
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_local_lr_sensitivity_extend2.sh
```

完成后下载：

```text
/root/local_lr_sensitivity_extend2_results.zip
```
