# Changelog

## v2

- 新增 `AuditBoardFaultTx.sol`，仅KGC可生成FaultTx。
- FaultTx不推进成功轮次、模型哈希和审计根。
- 新增集合协调成功、失败、忽略KGC集合和协调响应篡改。
- 新增传输篡改份额、错误但有效签名份额和门限不足。
- 为上一版完整MNIST攻击结果增加真实Hardhat链上FaultTx/FinalTx记录。
- 新增Gas、延迟、KGC权限、重放和链隔离检查。
