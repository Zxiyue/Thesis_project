#!/usr/bin/env bash
set -euo pipefail

FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
MODE="${MODE:-all}"
OUTPUT_DIR="${OUTPUT_DIR:-outputs/attack_faulttx_mnist_iid_suite}"
ZIP_OUT="${ZIP_OUT:-/root/attack_faulttx_mnist_iid_suite_results.zip}"
ONLY="${SCENARIOS:-}"
REUSE="${REUSE_BASE_RESULTS:-}"
INCLUDE_LEGACY="${INCLUDE_LEGACY_DROPOUT:-0}"

[[ -f "$FPA5_ROOT/.faulttx_hardhat_dir" ]] || { echo "[ERROR] run installer first"; exit 1; }
HH_DIR="$(cat "$FPA5_ROOT/.faulttx_hardhat_dir")"

python3 - <<'PY'
import socket,sys
s=socket.socket(); s.settimeout(1)
try:
    s.connect(('127.0.0.1',8545))
except Exception:
    print('[ERROR] Hardhat RPC 127.0.0.1:8545 is not running. Start it in another tmux.', file=sys.stderr)
    sys.exit(1)
finally:
    s.close()
PY

cd "$FPA5_ROOT"
if [[ -f .venv/bin/activate ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

ARGS=(
  python scripts/run_attack_faulttx_suite.py
  --hardhat-dir "$HH_DIR"
  --output-dir "$OUTPUT_DIR"
  --mode "$MODE"
  --zip-out "$ZIP_OUT"
)
[[ -n "$ONLY" ]] && ARGS+=(--only "$ONLY")
[[ -n "$REUSE" ]] && ARGS+=(--reuse-base-results "$REUSE")
[[ "$INCLUDE_LEGACY" == "1" ]] && ARGS+=(--include-legacy-dropout-detector)

"${ARGS[@]}"
echo "[RESULT ZIP] $ZIP_OUT"
