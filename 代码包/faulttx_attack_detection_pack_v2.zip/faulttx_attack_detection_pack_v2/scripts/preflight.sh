#!/usr/bin/env bash
set -euo pipefail
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"

echo "=== FaultTx attack-suite preflight ==="
[[ -d "$FPA5_ROOT" ]] || { echo "missing $FPA5_ROOT"; exit 1; }
[[ -f "$FPA5_ROOT/.faulttx_hardhat_dir" ]] || { echo "run installer first"; exit 1; }
HH_DIR="$(cat "$FPA5_ROOT/.faulttx_hardhat_dir")"
echo "FPA5_ROOT=$FPA5_ROOT"
echo "HARDHAT_DIR=$HH_DIR"
python3 --version
node --version
npx hardhat --version || true

if [[ -f "$FPA5_ROOT/scripts/run_attack_detection.py" ]]; then echo "v1_runner=OK"; else echo "v1_runner=MISSING"; fi
if [[ -f "$FPA5_ROOT/configs/attack_detection_mnist_iid_quick.yaml" ]]; then echo "v1_config=OK"; else echo "v1_config=MISSING"; fi
if [[ -f /mnt/fpa5/data/MNIST/processed/training.pt || -f /mnt/fpa5/data/MNIST/raw/train-images-idx3-ubyte ]]; then
  echo "MNIST=/mnt/fpa5/data/MNIST OK"
elif [[ -d "$FPA5_ROOT/data/MNIST" ]]; then
  echo "MNIST=$FPA5_ROOT/data/MNIST OK (config path may need adjustment)"
else
  echo "MNIST=MISSING"
fi

python3 - <<'PY'
import socket
s=socket.socket(); s.settimeout(1)
try:
    s.connect(('127.0.0.1',8545)); print('hardhat_rpc=UP')
except Exception:
    print('hardhat_rpc=DOWN (start npx hardhat node before the suite)')
finally:
    s.close()
PY
