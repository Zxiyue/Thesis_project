#!/usr/bin/env bash
set -euo pipefail
MODE=protocol-only OUTPUT_DIR="${OUTPUT_DIR:-outputs/attack_faulttx_protocol_only}" ZIP_OUT="${ZIP_OUT:-/root/attack_faulttx_protocol_only_results.zip}" \
  "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/run_attack_faulttx_suite.sh"
