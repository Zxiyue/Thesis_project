#!/usr/bin/env bash
set -euo pipefail
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
OUTPUT_DIR="${OUTPUT_DIR:-outputs/attack_faulttx_mnist_iid_suite}"
cd "$FPA5_ROOT"
if [[ -f .venv/bin/activate ]]; then source .venv/bin/activate; fi
python scripts/check_attack_faulttx_status.py --output-dir "$OUTPUT_DIR"
