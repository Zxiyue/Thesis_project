#!/usr/bin/env bash
set -euo pipefail
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"
OUTPUT_DIR="${OUTPUT_DIR:-outputs/attack_faulttx_mnist_iid_suite}"
ZIP_OUT="${ZIP_OUT:-/root/attack_faulttx_mnist_iid_suite_results.zip}"
cd "$FPA5_ROOT"
if [[ -f .venv/bin/activate ]]; then source .venv/bin/activate; fi
python scripts/summarize_attack_faulttx_results.py --input-dir "$OUTPUT_DIR" --zip-out "$ZIP_OUT"
ls -lh "$ZIP_OUT"
