#!/usr/bin/env bash
set -euo pipefail

PACK_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_ROOT="${FPA5_ROOT:-/root/fpa5}"

if [[ ! -d "$FPA5_ROOT" ]]; then
  echo "[ERROR] fpa5 root not found: $FPA5_ROOT" >&2
  exit 1
fi

mkdir -p "$FPA5_ROOT/scripts" "$FPA5_ROOT/configs"
cp -f "$PACK_ROOT"/fpa5_patch/scripts/*.py "$FPA5_ROOT/scripts/"
cp -f "$PACK_ROOT"/fpa5_patch/configs/*.yaml "$FPA5_ROOT/configs/"
chmod +x "$FPA5_ROOT"/scripts/*.py

# Locate the existing Hardhat project.  The original project may place it in
# blockchain/, hardhat/, chain/, or directly under fpa5/.
HH_DIR="${HARDHAT_DIR:-}"
if [[ -z "$HH_DIR" ]]; then
  while IFS= read -r candidate; do
    HH_DIR="$(dirname "$candidate")"
    break
  done < <(find "$FPA5_ROOT" -maxdepth 4 -type f \( -name 'hardhat.config.js' -o -name 'hardhat.config.cjs' -o -name 'hardhat.config.ts' \) | sort)
fi
if [[ -z "$HH_DIR" || ! -d "$HH_DIR" ]]; then
  echo "[ERROR] no Hardhat project found under $FPA5_ROOT" >&2
  exit 1
fi

echo "$HH_DIR" > "$FPA5_ROOT/.faulttx_hardhat_dir"
mkdir -p "$HH_DIR/contracts" "$HH_DIR/scripts"
cp -f "$PACK_ROOT/blockchain_patch/contracts/AuditBoardFaultTx.sol" "$HH_DIR/contracts/"
cp -f "$PACK_ROOT/blockchain_patch/scripts/faulttx_deploy.js" "$HH_DIR/scripts/"
cp -f "$PACK_ROOT/blockchain_patch/scripts/faulttx_action.js" "$HH_DIR/scripts/"

# Preserve the enum manifest alongside outputs/scripts for later paper tables.
mkdir -p "$FPA5_ROOT/faulttx_manifests"
cp -f "$PACK_ROOT"/manifests/*.json "$FPA5_ROOT/faulttx_manifests/"

# Avoid another slow online MNIST download when Matgo public data has already
# been copied to /root/fpa5/data.
if [[ -d "$FPA5_ROOT/data/MNIST" && ! -e /mnt/fpa5/data ]]; then
  mkdir -p /mnt/fpa5
  ln -s "$FPA5_ROOT/data" /mnt/fpa5/data
fi

if [[ -f "$FPA5_ROOT/scripts/run_attack_detection.py" ]]; then
  echo "[OK] found v1 full-FL attack runner"
else
  echo "[WARN] v1 full-FL attack runner is missing."
  echo "       Protocol-only mode can still run. For all scenarios, install attack_detection_pack_v1"
  echo "       or use REUSE_BASE_RESULTS=<old result zip>."
fi
if [[ -f "$FPA5_ROOT/configs/attack_detection_mnist_iid_quick.yaml" ]]; then
  echo "[OK] found v1 quick config"
else
  echo "[WARN] v1 quick config is missing; full-FL rerun will not start."
fi

cd "$HH_DIR"
echo "[INFO] compiling AuditBoardFaultTx in: $HH_DIR"
npx hardhat compile

echo "[DONE] installed FaultTx attack pack"
echo "FPA5_ROOT=$FPA5_ROOT"
echo "HARDHAT_DIR=$HH_DIR"
echo "Next: start 'npx hardhat node' in a separate tmux, then run scripts/run_attack_faulttx_suite.sh"
