# FaultTx Attack Detection Pack v2

这是上一版 `attack_detection_pack_v1` 的扩展包，用于验证修改后的：

- KGC-only FaultTx；
- CS/KGC掉线集合协调；
- 以KGC生成补偿时保存的集合为准；
- 同轮补传原始UpMsg并重新聚合；
- 错误解密份额与门限不足；
- FaultTx与成功审计根隔离；
- FaultTx Gas和确认延迟。

## 包内实验

### 完整MNIST训练场景

`normal`、`omit_uploaded_client`、`tamper_aggregate`、`wrong_model_publish`、`fake_model_sync_resp`、`forged_finaltx`。

这些场景调用服务器已安装的上一版 `scripts/run_attack_detection.py`。

### 新增密码协议场景

`dropout_reconciliation_success`、`dropout_reconciliation_failed`、`ignore_kgc_dropout_set`、`tamper_coordination_response`、`tampered_decryption_share`、`wrong_signed_decryption_share`、`threshold_unreached`。

这些场景使用实际 ECDSA、512-bit 门限Paillier、零和掩码和Pedersen向量承诺，不生成模拟准确率。

## 快速开始

```bash
cd /root
unzip -o faulttx_attack_detection_pack_v2.zip
cd faulttx_attack_detection_pack_v2
bash scripts/install_faulttx_attack_pack.sh
```

之后按《云服务器执行说明.md》启动 Hardhat 节点并运行实验。

## 重要边界

`wrong_signed_decryption_share` 明确验证当前方案的边界：客户端签名只能证明份额来源，不能单独证明份额值计算正确。错误但有效签名的份额在 Combine 后由 Pedersen 聚合一致性检查拒绝。若论文需要在份额阶段识别并归责这种错误，需要额外引入可验证解密份额证明；本包没有擅自改变主方案。

## 测试密钥说明

协议扩展层使用固定的测试安全素数以保证重复运行速度和可复现性。这些参数只用于512-bit功能实验，不能作为生产密钥。论文中应说明攻击检测实验用于验证控制逻辑，不用于证明密码参数安全强度。
