#!/usr/bin/env python3
"""Replay a scenario chain plan on the experimental Hardhat AuditBoardFaultTx."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, Mapping


def _last_json(stdout: str) -> Dict[str, Any]:
    for line in reversed(stdout.splitlines()):
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            return json.loads(line)
    raise RuntimeError(f"Hardhat command returned no JSON line:\n{stdout[-4000:]}")


def _run_hardhat(hardhat_dir: Path, script_name: str, env: Mapping[str, str]) -> Dict[str, Any]:
    merged = os.environ.copy()
    merged.update({k: str(v) for k, v in env.items()})
    cmd = ["npx", "hardhat", "run", f"scripts/{script_name}", "--network", "localhost"]
    started = time.perf_counter()
    proc = subprocess.run(
        cmd,
        cwd=str(hardhat_dir),
        env=merged,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    elapsed = time.perf_counter() - started
    if proc.returncode != 0:
        raise RuntimeError(f"Hardhat command failed ({proc.returncode}): {' '.join(cmd)}\n{proc.stdout}")
    out = _last_json(proc.stdout)
    out["wallLatencySeconds"] = elapsed
    out["rawTail"] = "\n".join(proc.stdout.splitlines()[-20:])
    return out


def deploy(hardhat_dir: Path, state_file: Path) -> Dict[str, Any]:
    return _run_hardhat(
        hardhat_dir,
        "faulttx_deploy.js",
        {"FAULT_BOARD_STATE": str(state_file)},
    )


def action(hardhat_dir: Path, state_file: Path, action_name: str, values: Mapping[str, Any]) -> Dict[str, Any]:
    env = {"FAULT_BOARD_STATE": str(state_file), "FAULT_ACTION": action_name}
    env.update({k: str(v) for k, v in values.items()})
    return _run_hardhat(hardhat_dir, "faulttx_action.js", env)


def status(hardhat_dir: Path, state_file: Path) -> Dict[str, Any]:
    return action(hardhat_dir, state_file, "status", {})


def replay(plan_path: Path, output_dir: Path, hardhat_dir: Path, unauthorized_test: bool = True) -> Dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    state_file = output_dir / "fault_board_state.json"
    deployment = deploy(hardhat_dir, state_file)

    init = plan["init"]
    init_receipt = action(
        hardhat_dir,
        state_file,
        "init",
        {
            "SYS_PARA_HASH": init["sysParaHash"],
            "U_ROOT": init["uRoot"],
            "MODEL_HASH0": init["modelHash0"],
            "AUDIT_ROOT0": init["auditRoot0"],
        },
    )
    initial_status = status(hardhat_dir, state_file)
    action_rows = []
    fault_isolation_ok = True
    final_continuity_ok = True

    for index, item in enumerate(plan.get("actions", []), start=1):
        before = status(hardhat_dir, state_file)
        if item["type"] == "fault":
            receipt = action(
                hardhat_dir,
                state_file,
                "fault",
                {
                    "FAULT_ROUND": item["round"],
                    "FAULT_ATTEMPT": item.get("attempt", 1),
                    "FAULT_ALPHA": item["alpha"],
                    "FAULT_TYPE": item["faultTypeCode"],
                    "FAULT_STAGE": item["failureStageCode"],
                    "FAULT_RESOLUTION": item["resolutionCode"],
                    "FAULT_EVIDENCE_HASH": item["evidenceHash"],
                    "FAULT_ANCHOR_AUDIT_ROOT": before["latestAuditRoot"],
                },
            )
            after = status(hardhat_dir, state_file)
            isolated = (
                before["latestAuditRoot"] == after["latestAuditRoot"]
                and before["latestFinalRound"] == after["latestFinalRound"]
                and before["currentModelHash"] == after["currentModelHash"]
            )
            fault_isolation_ok = fault_isolation_ok and isolated
            action_rows.append({
                "index": index,
                "type": "fault",
                "faultType": item["faultType"],
                "failureStage": item["failureStage"],
                "resolution": item["resolution"],
                "txHash": receipt.get("txHash", ""),
                "gasUsed": int(receipt.get("gasUsed", 0)),
                "wallLatencySeconds": receipt.get("wallLatencySeconds", 0.0),
                "auditRootBefore": before["latestAuditRoot"],
                "auditRootAfter": after["latestAuditRoot"],
                "faultIsolationPassed": isolated,
            })
        elif item["type"] == "final":
            prev_root = item.get("prevAuditRoot", before["latestAuditRoot"])
            prev_model = item.get("modelHashPrev", before["currentModelHash"])
            receipt = action(
                hardhat_dir,
                state_file,
                "final",
                {
                    "FINAL_ROUND": item["round"],
                    "FINAL_ALPHA": item["alpha"],
                    "FINAL_ROOT_UP": item["rootUp"],
                    "FINAL_COM_AGG_HASH": item["comAggHash"],
                    "FINAL_MODEL_PREV": prev_model,
                    "FINAL_MODEL_NEXT": item["modelHashNext"],
                    "FINAL_PREV_AUDIT_ROOT": prev_root,
                    "FINAL_AUDIT_ROOT": item["auditRoot"],
                },
            )
            after = status(hardhat_dir, state_file)
            continuity = (
                int(after["latestFinalRound"]) == int(item["round"])
                and after["latestAuditRoot"].lower() == item["auditRoot"].lower()
                and after["currentModelHash"].lower() == item["modelHashNext"].lower()
            )
            final_continuity_ok = final_continuity_ok and continuity
            action_rows.append({
                "index": index,
                "type": "final",
                "faultType": "",
                "failureStage": "",
                "resolution": "",
                "txHash": receipt.get("txHash", ""),
                "gasUsed": int(receipt.get("gasUsed", 0)),
                "wallLatencySeconds": receipt.get("wallLatencySeconds", 0.0),
                "auditRootBefore": before["latestAuditRoot"],
                "auditRootAfter": after["latestAuditRoot"],
                "faultIsolationPassed": "",
                "finalContinuityPassed": continuity,
            })
        else:
            raise ValueError(f"unknown chain-plan action: {item}")

    final_status = status(hardhat_dir, state_file)
    unauthorized = None
    if unauthorized_test:
        unauthorized = action(
            hardhat_dir,
            state_file,
            "unauthorized-fault",
            {
                "FAULT_ALPHA": init["auditRoot0"],
                "FAULT_EVIDENCE_HASH": init["sysParaHash"],
                "FAULT_ANCHOR_AUDIT_ROOT": final_status["latestAuditRoot"],
            },
        )

    expected = plan.get("expected", {})
    count_ok = (
        int(final_status["faultCount"]) == int(expected.get("faultTxCount", final_status["faultCount"]))
        and int(final_status["latestFinalRound"]) == int(expected.get("finalTxCount", final_status["latestFinalRound"]))
    )
    unauthorized_ok = bool(unauthorized is None or unauthorized.get("rejected"))
    passed = fault_isolation_ok and final_continuity_ok and count_ok and unauthorized_ok
    result = {
        "scenario": plan.get("scenario", plan_path.parent.name),
        "passed": passed,
        "deployment": deployment,
        "initReceipt": init_receipt,
        "initialStatus": initial_status,
        "actions": action_rows,
        "finalStatus": final_status,
        "faultIsolationPassed": fault_isolation_ok,
        "finalContinuityPassed": final_continuity_ok,
        "countExpectationPassed": count_ok,
        "unauthorizedKGCOnlyPassed": unauthorized_ok,
        "unauthorizedTest": unauthorized,
    }
    (output_dir / "chain_result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    # CSVs are intentionally simple so they can be merged with the existing v1 outputs.
    import csv
    with (output_dir / "chain_transactions.csv").open("w", newline="", encoding="utf-8-sig") as f:
        fields = [
            "index", "type", "faultType", "failureStage", "resolution", "txHash",
            "gasUsed", "wallLatencySeconds", "auditRootBefore", "auditRootAfter",
            "faultIsolationPassed", "finalContinuityPassed",
        ]
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(action_rows)
    print(json.dumps({"scenario": result["scenario"], "passed": passed, "finalStatus": final_status}, ensure_ascii=False))
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--hardhat-dir", required=True)
    ap.add_argument("--skip-unauthorized-test", action="store_true")
    args = ap.parse_args()
    replay(
        Path(args.plan),
        Path(args.output_dir),
        Path(args.hardhat_dir),
        unauthorized_test=not args.skip_unauthorized_test,
    )


if __name__ == "__main__":
    main()
