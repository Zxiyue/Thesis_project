#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--output-dir", default="outputs/attack_faulttx_mnist_iid_suite")
args = ap.parse_args()
root = Path(args.output_dir)
print(f"output_dir={root.resolve()}")
manifest = root / "suite_manifest.json"
if not manifest.exists():
    print("suite not started")
    raise SystemExit(0)
scenarios = json.loads(manifest.read_text(encoding="utf-8"))["scenarios"]
for s in scenarios:
    d = root / s
    result = d / "attack_result.csv"
    chain = d / "chain" / "chain_result.json"
    status = "NOT_STARTED"
    detail = ""
    if result.exists():
        with result.open("r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
        if rows:
            status = "PROTOCOL_DONE"
            detail = f"detected={rows[0].get('detected')} accepted={rows[0].get('accepted')}"
    if chain.exists():
        c = json.loads(chain.read_text(encoding="utf-8"))
        status = "DONE" if c.get("passed") else "CHAIN_FAILED"
        detail += f" faultCount={c.get('finalStatus',{}).get('faultCount')} finalRound={c.get('finalStatus',{}).get('latestFinalRound')}"
    print(f"{s:38s} {status:14s} {detail}")
