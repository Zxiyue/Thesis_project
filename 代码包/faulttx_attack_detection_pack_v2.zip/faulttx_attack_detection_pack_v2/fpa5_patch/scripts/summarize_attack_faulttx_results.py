#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import statistics
import zipfile
from pathlib import Path
from typing import Any, Dict, List


def read_one_csv(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    return rows[0] if rows else {}


def boolish(v: Any) -> bool:
    return str(v).strip().lower() in {"1", "true", "yes"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input-dir", required=True)
    ap.add_argument("--zip-out", default="")
    args = ap.parse_args()
    root = Path(args.input_dir).resolve()
    manifest = json.loads((root / "suite_manifest.json").read_text(encoding="utf-8"))
    rows: List[Dict[str, Any]] = []
    chain_tx_rows: List[Dict[str, Any]] = []

    for scenario in manifest["scenarios"]:
        d = root / scenario
        ar = read_one_csv(d / "attack_result.csv")
        chain_path = d / "chain" / "chain_result.json"
        chain = json.loads(chain_path.read_text(encoding="utf-8")) if chain_path.exists() else {}
        final_status = chain.get("finalStatus", {})
        actions = chain.get("actions", [])
        faults = [x for x in actions if x.get("type") == "fault"]
        finals = [x for x in actions if x.get("type") == "final"]
        fault_gas = sum(int(x.get("gasUsed", 0)) for x in faults)
        final_gas = sum(int(x.get("gasUsed", 0)) for x in finals)
        fault_lat = sum(float(x.get("wallLatencySeconds", 0)) for x in faults)
        final_lat = sum(float(x.get("wallLatencySeconds", 0)) for x in finals)
        row = {
            "scenario": scenario,
            "execution_mode": ar.get("execution_mode", "full_fl_v1"),
            "detected": ar.get("detected", ""),
            "accepted": ar.get("accepted", ""),
            "detection_stage": ar.get("detection_stage", ""),
            "reason": ar.get("reason", ""),
            "rounds_completed": ar.get("rounds_completed", ""),
            "valid_share_count": ar.get("valid_share_count", ""),
            "combine_executed": ar.get("combine_executed", ""),
            "fault_resolution": ar.get("fault_resolution", faults[0].get("resolution", "") if faults else ""),
            "faulttx_count": int(final_status.get("faultCount", len(faults))) if final_status else len(faults),
            "finaltx_count": int(final_status.get("latestFinalRound", len(finals))) if final_status else len(finals),
            "fault_type": faults[0].get("faultType", "") if faults else "",
            "fault_stage": faults[0].get("failureStage", "") if faults else "",
            "faulttx_gas": fault_gas,
            "finaltx_gas": final_gas,
            "faulttx_latency_s": round(fault_lat, 6),
            "finaltx_latency_s": round(final_lat, 6),
            "fault_isolation_passed": chain.get("faultIsolationPassed", False),
            "final_continuity_passed": chain.get("finalContinuityPassed", False),
            "kgc_only_passed": chain.get("unauthorizedKGCOnlyPassed", "not_retested"),
            "chain_passed": chain.get("passed", False),
        }
        # Expected semantic checks.
        if scenario == "normal":
            semantic = boolish(row["accepted"]) and row["faulttx_count"] == 0 and row["finaltx_count"] >= 1
        elif scenario in {"dropout_reconciliation_success", "tampered_decryption_share"}:
            semantic = boolish(row["accepted"]) and row["faulttx_count"] == 1 and row["finaltx_count"] == 1
        elif scenario == "forged_finaltx":
            semantic = row["faulttx_count"] == 1 and row["finaltx_count"] >= 1
        else:
            semantic = (not boolish(row["accepted"])) and row["faulttx_count"] == 1
        row["semantic_expectation_passed"] = semantic
        row["scenario_passed"] = bool(row["chain_passed"] and semantic)
        rows.append(row)
        for x in actions:
            chain_tx_rows.append({"scenario": scenario, **x})

    summary_csv = root / "attack_faulttx_summary.csv"
    fields = list(rows[0].keys()) if rows else []
    with summary_csv.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)

    tx_csv = root / "chain_transaction_costs.csv"
    if chain_tx_rows:
        tx_fields = []
        for r in chain_tx_rows:
            for k in r:
                if k not in tx_fields:
                    tx_fields.append(k)
        with tx_csv.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=tx_fields, extrasaction="ignore")
            w.writeheader(); w.writerows(chain_tx_rows)

    fault_gases = [r["faulttx_gas"] for r in rows if r["faulttx_gas"] > 0]
    final_gases = [r["finaltx_gas"] for r in rows if r["finaltx_gas"] > 0]
    all_passed = all(r["scenario_passed"] for r in rows) if rows else False
    md = [
        "# Attack Detection + KGC-only FaultTx Summary",
        "",
        f"- Scenarios: {len(rows)}",
        f"- All scenarios passed: **{all_passed}**",
        f"- FaultTx submitter: **KGC only**",
        f"- Mean FaultTx gas: {statistics.mean(fault_gases):.2f}" if fault_gases else "- Mean FaultTx gas: N/A",
        f"- Mean FinalTx gas (scenario sums): {statistics.mean(final_gases):.2f}" if final_gases else "- Mean FinalTx gas: N/A",
        "",
        "| Scenario | Mode | Detected | Accepted | Fault type | Resolution | FaultTx | FinalTx | Fault isolation | Chain pass |",
        "|---|---|---:|---:|---|---|---:|---:|---:|---:|",
    ]
    for r in rows:
        md.append(
            f"| {r['scenario']} | {r['execution_mode']} | {r['detected']} | {r['accepted']} | "
            f"{r['fault_type']} | {r['fault_resolution']} | {r['faulttx_count']} | "
            f"{r['finaltx_count']} | {r['fault_isolation_passed']} | {r['scenario_passed']} |"
        )
    (root / "attack_faulttx_summary.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    (root / "attack_faulttx_summary.json").write_text(json.dumps({
        "allPassed": all_passed,
        "rows": rows,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    zip_out = Path(args.zip_out).resolve() if args.zip_out else root.parent / f"{root.name}_results.zip"
    with zipfile.ZipFile(zip_out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for path in root.rglob("*"):
            if path.is_file() and "_reuse_v1" not in path.parts:
                zf.write(path, arcname=str(Path(root.name) / path.relative_to(root)))
    print(json.dumps({"summary": str(summary_csv), "zip": str(zip_out), "allPassed": all_passed}, ensure_ascii=False))


if __name__ == "__main__":
    main()
