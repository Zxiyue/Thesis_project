#!/usr/bin/env python3
"""Build a FaultTx/FinalTx chain plan from a v1 full-FL attack result directory."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Any, Dict

FAULT_TYPES = {
    "omit_uploaded_client": ("OMITTED_VALID_UPLOAD", 4, "AGGREGATE_OPEN_CHECK", 3, "ATTACK_CONFIRMED", 3),
    "forged_dropout_set": ("SET_VIEW_MISMATCH", 1, "DROPOUT_COMPENSATION", 1, "ABORTED", 2),
    "tamper_aggregate": ("AGGREGATE_INCONSISTENCY", 5, "AGGREGATE_OPEN_CHECK", 3, "REJECTED", 4),
    "wrong_model_publish": ("MODEL_PUBLISH_INCONSISTENCY", 6, "KGC_MODEL_CHECK", 4, "REJECTED", 4),
    "fake_model_sync_resp": ("MODEL_SYNC_INTEGRITY_FAILURE", 7, "MODEL_SYNC_VERIFY", 5, "REJECTED", 4),
    "forged_finaltx": ("TRANSCRIPT_TAMPER", 10, "PUBLIC_CHAIN_VERIFY", 8, "REJECTED", 4),
}


def canonical_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex(obj: Any) -> str:
    return "0x" + hashlib.sha256(canonical_bytes(obj)).hexdigest()


def read_one_csv(path: Path) -> Dict[str, str]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    return rows[0] if rows else {}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario-dir", required=True)
    ap.add_argument("--scenario", required=True)
    args = ap.parse_args()
    d = Path(args.scenario_dir)
    scenario = args.scenario
    trace = json.loads((d / "run_trace.json").read_text(encoding="utf-8"))
    result = read_one_csv(d / "attack_result.csv")
    init_tx = trace["initTx"]
    actions = []
    current_model = init_tx["modelHash0"]
    current_audit = init_tx["auditRoot0"]
    rounds = trace.get("rounds", [])
    for row in rounds:
        if not all(k in row for k in ["round", "alpha", "rootUp", "ComAggHash", "modelHashNext", "auditRoot"]):
            continue
        actions.append({
            "type": "final",
            "round": int(row["round"]),
            "alpha": row["alpha"],
            "rootUp": row["rootUp"],
            "comAggHash": row["ComAggHash"],
            "modelHashPrev": current_model,
            "modelHashNext": row["modelHashNext"],
            "prevAuditRoot": current_audit,
            "auditRoot": row["auditRoot"],
        })
        current_model = row["modelHashNext"]
        current_audit = row["auditRoot"]

    if scenario != "normal":
        if scenario not in FAULT_TYPES:
            raise ValueError(f"no FaultTx mapping for base scenario {scenario}")
        ft_name, ft_code, st_name, st_code, rs_name, rs_code = FAULT_TYPES[scenario]
        detection_round = int(float(result.get("detection_round") or result.get("attack_round") or 1))
        alpha = None
        for row in rounds:
            if int(row.get("round", -1)) == detection_round:
                alpha = row.get("alpha")
                break
        if not alpha:
            alpha = rounds[-1].get("alpha") if rounds else init_tx["auditRoot0"]
        evidence = {
            "scenario": scenario,
            "attackResult": result,
            "roundCount": len(rounds),
            "traceDigest": sha256_hex(trace),
        }
        actions.append({
            "type": "fault",
            "round": detection_round,
            "attempt": 1,
            "alpha": alpha,
            "faultType": ft_name,
            "faultTypeCode": ft_code,
            "failureStage": st_name,
            "failureStageCode": st_code,
            "resolution": rs_name,
            "resolutionCode": rs_code,
            "evidenceHash": sha256_hex(evidence),
            "evidence": evidence,
        })

    plan = {
        "scenario": scenario,
        "init": {
            "sysParaHash": init_tx["sysParaHash"],
            "uRoot": init_tx["Uroot"],
            "modelHash0": init_tx["modelHash0"],
            "auditRoot0": init_tx["auditRoot0"],
        },
        "actions": actions,
        "expected": {
            "faultTxCount": 0 if scenario == "normal" else 1,
            "finalTxCount": len(rounds),
            "faultDoesNotAdvanceAuditRoot": True,
        },
    }
    out = d / "chain_plan.json"
    out.write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    print(out)


if __name__ == "__main__":
    main()
