#!/usr/bin/env python3
"""Complete attack-detection + KGC-only FaultTx suite orchestrator."""
from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Dict, Iterable, List, Optional

from build_base_chain_plan import main as _unused_main  # noqa: F401
from faulttx_chain_bridge import replay as replay_chain
from protocol_extension_scenarios import PROTOCOL_SCENARIOS, run_scenario as run_protocol_scenario

BASE_SCENARIOS = [
    "normal",
    "omit_uploaded_client",
    "tamper_aggregate",
    "wrong_model_publish",
    "fake_model_sync_resp",
    "forged_finaltx",
]
BASE_ATTACK_ROUND = {
    "normal": 1,
    "omit_uploaded_client": 1,
    "tamper_aggregate": 1,
    "wrong_model_publish": 1,
    "fake_model_sync_resp": 3,
    "forged_finaltx": 2,
}


def run_cmd(cmd: List[str], *, cwd: Optional[Path] = None, log_path: Optional[Path] = None) -> None:
    if log_path:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("w", encoding="utf-8") as log:
            proc = subprocess.run(cmd, cwd=str(cwd) if cwd else None, stdout=log, stderr=subprocess.STDOUT)
    else:
        proc = subprocess.run(cmd, cwd=str(cwd) if cwd else None)
    if proc.returncode != 0:
        raise RuntimeError(f"command failed ({proc.returncode}): {' '.join(cmd)}")


def find_reuse_root(extracted: Path) -> Path:
    candidates = list(extracted.rglob("attack_detection_summary.csv"))
    if not candidates:
        raise FileNotFoundError("reuse zip does not contain attack_detection_summary.csv")
    return candidates[0].parent


def copy_reused_scenario(reuse_root: Path, scenario: str, target: Path) -> None:
    src = reuse_root / scenario
    if not src.exists():
        raise FileNotFoundError(f"reuse result missing scenario directory: {src}")
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(src, target)
    log_src = reuse_root / f"{scenario}.log"
    if log_src.exists():
        shutil.copy2(log_src, target.parent / f"{scenario}.log")


def build_base_plan(script_dir: Path, scenario_dir: Path, scenario: str) -> None:
    run_cmd([
        sys.executable,
        str(script_dir / "build_base_chain_plan.py"),
        "--scenario-dir", str(scenario_dir),
        "--scenario", scenario,
    ])


def select_scenarios(mode: str, only: Optional[str], include_legacy: bool) -> List[str]:
    if mode == "base-only":
        items = list(BASE_SCENARIOS)
    elif mode == "protocol-only":
        items = list(PROTOCOL_SCENARIOS)
    else:
        items = list(BASE_SCENARIOS) + list(PROTOCOL_SCENARIOS)
    if include_legacy and mode != "protocol-only":
        items.insert(2, "forged_dropout_set")
        BASE_ATTACK_ROUND["forged_dropout_set"] = 1
    if only:
        requested = [x.strip() for x in only.split(",") if x.strip()]
        unknown = sorted(set(requested) - set(items))
        if unknown:
            raise ValueError(f"unknown/unavailable scenarios: {unknown}; available={items}")
        items = requested
    return items


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output-dir", default="outputs/attack_faulttx_mnist_iid_suite")
    ap.add_argument("--hardhat-dir", required=True)
    ap.add_argument("--base-runner", default="scripts/run_attack_detection.py")
    ap.add_argument("--base-config", default="configs/attack_detection_mnist_iid_quick.yaml")
    ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--mode", choices=["all", "base-only", "protocol-only"], default="all")
    ap.add_argument("--only", default="")
    ap.add_argument("--reuse-base-results", default="")
    ap.add_argument("--include-legacy-dropout-detector", action="store_true")
    ap.add_argument("--protocol-dimension", type=int, default=32)
    ap.add_argument("--seed", type=int, default=20260714)
    ap.add_argument("--zip-out", default="/root/attack_faulttx_mnist_iid_suite_results.zip")
    args = ap.parse_args()

    fpa5_root = Path.cwd()
    output_root = Path(args.output_dir)
    if not output_root.is_absolute():
        output_root = fpa5_root / output_root
    output_root.mkdir(parents=True, exist_ok=True)
    script_dir = Path(__file__).resolve().parent
    hardhat_dir = Path(args.hardhat_dir).resolve()
    base_runner = Path(args.base_runner)
    if not base_runner.is_absolute():
        base_runner = fpa5_root / base_runner
    base_config = Path(args.base_config)
    if not base_config.is_absolute():
        base_config = fpa5_root / base_config

    scenarios = select_scenarios(args.mode, args.only or None, args.include_legacy_dropout_detector)
    (output_root / "suite_manifest.json").write_text(json.dumps({
        "scenarios": scenarios,
        "mode": args.mode,
        "baseRunner": str(base_runner),
        "baseConfig": str(base_config),
        "hardhatDir": str(hardhat_dir),
        "reuseBaseResults": args.reuse_base_results,
        "faultTxSubmitter": "KGC_ONLY",
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    reuse_root: Optional[Path] = None
    if args.reuse_base_results:
        reuse_zip = Path(args.reuse_base_results).resolve()
        reuse_extract = output_root / "_reuse_v1"
        if reuse_extract.exists():
            shutil.rmtree(reuse_extract)
        reuse_extract.mkdir(parents=True)
        with zipfile.ZipFile(reuse_zip) as zf:
            zf.extractall(reuse_extract)
        reuse_root = find_reuse_root(reuse_extract)

    chain_failures: List[str] = []
    for idx, scenario in enumerate(scenarios):
        print(f"\n================ RUN {scenario} ================", flush=True)
        scenario_dir = output_root / scenario
        if scenario_dir.exists():
            shutil.rmtree(scenario_dir)
        scenario_dir.mkdir(parents=True, exist_ok=True)

        if scenario in BASE_SCENARIOS or scenario == "forged_dropout_set":
            if reuse_root is not None:
                copy_reused_scenario(reuse_root, scenario, scenario_dir)
                print(f"[reuse] copied v1 full-FL result for {scenario}", flush=True)
            else:
                if not base_runner.exists():
                    raise FileNotFoundError(
                        f"base v1 runner not found: {base_runner}. Install attack_detection_pack_v1 first, "
                        "or pass --reuse-base-results <v1 result zip>."
                    )
                if not base_config.exists():
                    raise FileNotFoundError(f"base v1 config not found: {base_config}")
                cmd = [
                    sys.executable, str(base_runner),
                    "--config", str(base_config),
                    "--scenario", scenario,
                    "--attack-round", str(BASE_ATTACK_ROUND[scenario]),
                    "--target-client", "2",
                    "--rounds", str(args.rounds),
                    "--device", args.device,
                    "--output-dir", str(scenario_dir),
                ]
                run_cmd(cmd, cwd=fpa5_root, log_path=output_root / f"{scenario}.log")
            build_base_plan(script_dir, scenario_dir, scenario)
        else:
            run_protocol_scenario(
                scenario,
                scenario_dir,
                seed=args.seed,
                dimension=args.protocol_dimension,
            )

        chain_dir = scenario_dir / "chain"
        try:
            chain_result = replay_chain(
                scenario_dir / "chain_plan.json",
                chain_dir,
                hardhat_dir,
                unauthorized_test=(idx == 0),
            )
            if not chain_result.get("passed"):
                chain_failures.append(scenario)
        except Exception as exc:
            chain_failures.append(scenario)
            (chain_dir / "chain_error.txt").parent.mkdir(parents=True, exist_ok=True)
            (chain_dir / "chain_error.txt").write_text(str(exc), encoding="utf-8")
            print(f"[chain-error] {scenario}: {exc}", flush=True)

    summary_cmd = [
        sys.executable,
        str(script_dir / "summarize_attack_faulttx_results.py"),
        "--input-dir", str(output_root),
        "--zip-out", str(Path(args.zip_out).resolve()),
    ]
    run_cmd(summary_cmd, cwd=fpa5_root)
    if chain_failures:
        print(f"[WARN] chain validation failed for: {chain_failures}", flush=True)
    print(f"[DONE] outputs: {output_root}", flush=True)


if __name__ == "__main__":
    main()
