#!/usr/bin/env python3
"""Lightweight cryptographic protocol-extension scenarios for FaultTx experiments.

These scenarios exercise the modified control logic that did not exist in the v1
attack runner: dropout-set reconciliation, invalid decryption shares, and
threshold failure.  They use actual ECDSA signatures, a reference threshold
Paillier implementation, zero-sum masks, and Pedersen vector commitments.
They do not fabricate training accuracy; their scope is protocol correctness.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import random
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

# Fixed 512-bit functional-test Paillier modulus factors.  These are test-only
# safe primes and MUST NOT be reused by a production deployment.
TEST_SAFE_P = 106156326297970418690025119199905755623605263228620289413657912000294162649763
TEST_SAFE_Q = 109447338125132373447679735675435613082393248557899094350131151539043851016647

FAULT_TYPES = {
    "SET_VIEW_MISMATCH": 1,
    "RECONCILIATION_FAILED": 2,
    "DROPOUT_SET_ATTACK": 3,
    "OMITTED_VALID_UPLOAD": 4,
    "AGGREGATE_INCONSISTENCY": 5,
    "MODEL_PUBLISH_INCONSISTENCY": 6,
    "MODEL_SYNC_INTEGRITY_FAILURE": 7,
    "INVALID_DECRYPTION_SHARE": 8,
    "THRESHOLD_UNREACHED": 9,
    "TRANSCRIPT_TAMPER": 10,
    "COORDINATION_RESPONSE_TAMPER": 11,
    "DECRYPTION_RECOVERY_INCONSISTENCY": 12,
}

FAULT_STAGES = {
    "DROPOUT_COMPENSATION": 1,
    "COORDINATION": 2,
    "AGGREGATE_OPEN_CHECK": 3,
    "KGC_MODEL_CHECK": 4,
    "MODEL_SYNC_VERIFY": 5,
    "SHARE_VERIFY": 6,
    "SHARE_COLLECTION": 7,
    "PUBLIC_CHAIN_VERIFY": 8,
}

RESOLUTIONS = {
    "RECOVERED": 1,
    "ABORTED": 2,
    "ATTACK_CONFIRMED": 3,
    "REJECTED": 4,
}

PROTOCOL_SCENARIOS = [
    "dropout_reconciliation_success",
    "dropout_reconciliation_failed",
    "ignore_kgc_dropout_set",
    "tamper_coordination_response",
    "tampered_decryption_share",
    "wrong_signed_decryption_share",
    "threshold_unreached",
]


def canonical_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex(data: Any) -> str:
    if not isinstance(data, (bytes, bytearray)):
        data = canonical_bytes(data)
    return "0x" + hashlib.sha256(bytes(data)).hexdigest()


def int_hex(v: int) -> str:
    return hex(int(v))


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]], fieldnames: Optional[Sequence[str]] = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        ordered: List[str] = []
        for row in rows:
            for key in row.keys():
                if key not in ordered:
                    ordered.append(key)
        fieldnames = ordered
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(fieldnames), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(dict(row))


def merkle_root(leaves: Sequence[bytes], empty_label: bytes) -> str:
    if not leaves:
        return sha256_hex(empty_label)
    level = [hashlib.sha256(x).digest() for x in leaves]
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        level = [hashlib.sha256(level[i] + level[i + 1]).digest() for i in range(0, len(level), 2)]
    return "0x" + level[0].hex()


def bitmap(ids: Iterable[int], n: int) -> str:
    selected = set(ids)
    return "".join("1" if i in selected else "0" for i in range(1, n + 1))


def sign_obj(sk: ec.EllipticCurvePrivateKey, obj: Any) -> str:
    sig = sk.sign(canonical_bytes(obj), ec.ECDSA(hashes.SHA256()))
    return sig.hex()


def verify_obj(pk: ec.EllipticCurvePublicKey, obj: Any, sig_hex: str) -> bool:
    try:
        pk.verify(bytes.fromhex(sig_hex), canonical_bytes(obj), ec.ECDSA(hashes.SHA256()))
        return True
    except Exception:
        return False


def pubkey_hex(pk: ec.EllipticCurvePublicKey) -> str:
    return pk.public_bytes(Encoding.X962, PublicFormat.UncompressedPoint).hex()


class ThresholdPaillierRef:
    """Dealer-based threshold Paillier reference implementation for functional tests."""

    def __init__(self, n_clients: int, threshold: int, seed: int) -> None:
        if not (1 <= threshold <= n_clients):
            raise ValueError("invalid threshold")
        self.n_clients = n_clients
        self.threshold = threshold
        self.p = TEST_SAFE_P
        self.q = TEST_SAFE_Q
        self.p1 = (self.p - 1) // 2
        self.q1 = (self.q - 1) // 2
        self.n = self.p * self.q
        self.n2 = self.n * self.n
        self.m = self.p1 * self.q1
        self.nm = self.n * self.m
        self.delta = math.factorial(n_clients)
        # d == 0 mod m and d == 1 mod n
        d = (self.m * pow(self.m, -1, self.n)) % self.nm
        rng = random.Random(seed ^ 0xA5A5_5A5A)
        coeff = [d] + [rng.randrange(0, self.nm) for _ in range(threshold - 1)]
        self.shares: Dict[int, int] = {}
        for i in range(1, n_clients + 1):
            self.shares[i] = sum(coeff[k] * pow(i, k, self.nm) for k in range(threshold)) % self.nm

    def encode(self, x: int) -> int:
        return x % self.n

    def decode(self, x: int) -> int:
        return x - self.n if x > self.n // 2 else x

    def encrypt(self, m: int) -> int:
        m = self.encode(m)
        while True:
            r = secrets.randbelow(self.n - 1) + 1
            if math.gcd(r, self.n) == 1:
                break
        return (pow(1 + self.n, m, self.n2) * pow(r, self.n, self.n2)) % self.n2

    def add(self, ciphertexts: Sequence[int]) -> int:
        out = 1
        for c in ciphertexts:
            out = (out * c) % self.n2
        return out

    def partial_decrypt(self, client_id: int, c: int) -> int:
        return pow(c, 2 * self.delta * self.shares[client_id], self.n2)

    @staticmethod
    def _lagrange(indices: Sequence[int], i: int, delta: int) -> int:
        num = delta
        den = 1
        for j in indices:
            if j == i:
                continue
            num *= -j
            den *= i - j
        if num % den != 0:
            raise ArithmeticError("non-integral threshold Lagrange coefficient")
        return num // den

    def combine(self, partials: Mapping[int, int]) -> int:
        ids = list(partials.keys())
        if len(ids) < self.threshold:
            raise ValueError("threshold unreached")
        ids = ids[: self.threshold]
        c_prime = 1
        for i in ids:
            base = int(partials[i])
            exp = 2 * self._lagrange(ids, i, self.delta)
            if exp < 0:
                base = pow(base, -1, self.n2)
                exp = -exp
            c_prime = (c_prime * pow(base, exp, self.n2)) % self.n2
        L = (c_prime - 1) // self.n
        value = (L * pow(4 * self.delta * self.delta, -1, self.n)) % self.n
        return self.decode(value)


class PedersenVector:
    def __init__(self, dimension: int) -> None:
        # TEST_SAFE_P is itself a safe prime; use its order-q quadratic-residue subgroup.
        self.P = TEST_SAFE_P
        self.q = (self.P - 1) // 2
        self.dimension = dimension
        self.generators = [self._generator(f"g:{j}") for j in range(dimension)]
        self.h = self._generator("h")

    def _generator(self, label: str) -> int:
        x = int.from_bytes(hashlib.sha256(label.encode()).digest(), "big") % self.P
        g = pow(max(2, x), 2, self.P)
        if g in (0, 1):
            g = 4
        return g

    def commit(self, vec: Sequence[int], rho: int) -> int:
        if len(vec) != self.dimension:
            raise ValueError("dimension mismatch")
        out = pow(self.h, rho % self.q, self.P)
        for g, x in zip(self.generators, vec):
            out = (out * pow(g, x % self.q, self.P)) % self.P
        return out

    def aggregate(self, commitments: Iterable[int]) -> int:
        out = 1
        for c in commitments:
            out = (out * int(c)) % self.P
        return out


@dataclass
class Fixture:
    seed: int
    n_clients: int
    threshold: int
    dimension: int
    paillier: ThresholdPaillierRef
    pedersen: PedersenVector
    client_sks: Dict[int, ec.EllipticCurvePrivateKey]
    client_pks: Dict[int, ec.EllipticCurvePublicKey]
    kgc_sk: ec.EllipticCurvePrivateKey
    kgc_pk: ec.EllipticCurvePublicKey
    updates: Dict[int, List[int]]
    masks: Dict[int, List[int]]
    rhos: Dict[int, int]
    upmsgs: Dict[int, Dict[str, Any]]
    actual_active: List[int]
    actual_dropout: List[int]
    compensation_cipher: List[int]
    compensation_commitment: int
    model_hash0: str
    audit_root0: str
    sys_para_hash: str
    u_root: str
    alpha: str
    root_up: str
    root_d: str


def build_fixture(seed: int = 20260714, dimension: int = 32) -> Fixture:
    started = time.perf_counter()
    n_clients, threshold = 5, 3
    rng = random.Random(seed)
    paillier = ThresholdPaillierRef(n_clients, threshold, seed)
    pedersen = PedersenVector(dimension)
    client_sks = {i: ec.generate_private_key(ec.SECP256R1()) for i in range(1, n_clients + 1)}
    client_pks = {i: sk.public_key() for i, sk in client_sks.items()}
    kgc_sk = ec.generate_private_key(ec.SECP256R1())
    kgc_pk = kgc_sk.public_key()

    updates = {i: [rng.randint(-20, 20) for _ in range(dimension)] for i in range(1, n_clients + 1)}
    masks: Dict[int, List[int]] = {i: [0] * dimension for i in range(1, n_clients + 1)}
    for j in range(dimension):
        vals = [rng.randint(-6, 6) for _ in range(n_clients - 1)]
        vals.append(-sum(vals))
        order = list(range(1, n_clients + 1))
        rng.shuffle(order)
        for cid, value in zip(order, vals):
            masks[cid][j] = value
    rho_vals = [rng.randint(-1000, 1000) for _ in range(n_clients - 1)]
    rho_vals.append(-sum(rho_vals))
    order = list(range(1, n_clients + 1))
    rng.shuffle(order)
    rhos = {cid: value for cid, value in zip(order, rho_vals)}

    model_hash0 = sha256_hex({"model": "tiny_cnn", "seed": seed, "purpose": "protocol_extension"})
    u_root = merkle_root([str(i).encode() for i in range(1, n_clients + 1)], b"EMPTY_USERS")
    sys_para_hash = sha256_hex({
        "nClients": n_clients,
        "threshold": threshold,
        "dimension": dimension,
        "paillierN": int_hex(paillier.n),
        "kgcPk": pubkey_hex(kgc_pk),
    })
    audit_root0 = sha256_hex({"sysParaHash": sys_para_hash, "uRoot": u_root, "modelHash0": model_hash0})
    alpha = sha256_hex({"round": 1, "modelHash": model_hash0, "uRoot": u_root})

    actual_active = [1, 2, 3, 4]
    actual_dropout = [5]
    upmsgs: Dict[int, Dict[str, Any]] = {}
    for cid in actual_active:
        masked = [x + m for x, m in zip(updates[cid], masks[cid])]
        ciphertexts = [paillier.encrypt(x) for x in masked]
        enc_hash = sha256_hex([int_hex(c) for c in ciphertexts])
        commitment = pedersen.commit(masked, rhos[cid])
        receipt_body = {
            "r": 1,
            "i": cid,
            "alpha": alpha,
            "encHash": enc_hash,
            "Com": int_hex(commitment),
        }
        receipt = {**receipt_body, "sigUp": sign_obj(client_sks[cid], receipt_body)}
        upmsgs[cid] = {
            "receipt": receipt,
            "ciphertexts": [int_hex(c) for c in ciphertexts],
        }

    drop_mask = [sum(masks[cid][j] for cid in actual_dropout) for j in range(dimension)]
    drop_rho = sum(rhos[cid] for cid in actual_dropout)
    compensation_cipher = [paillier.encrypt(x) for x in drop_mask]
    compensation_commitment = pedersen.commit(drop_mask, drop_rho)

    root_up = merkle_root(
        [canonical_bytes(upmsgs[cid]["receipt"]) for cid in sorted(actual_active)],
        b"EMPTY_UPLOADS",
    )
    root_d = merkle_root([str(i).encode() for i in actual_dropout], b"EMPTY_DROPOUT")
    _ = time.perf_counter() - started
    return Fixture(
        seed=seed,
        n_clients=n_clients,
        threshold=threshold,
        dimension=dimension,
        paillier=paillier,
        pedersen=pedersen,
        client_sks=client_sks,
        client_pks=client_pks,
        kgc_sk=kgc_sk,
        kgc_pk=kgc_pk,
        updates=updates,
        masks=masks,
        rhos=rhos,
        upmsgs=upmsgs,
        actual_active=actual_active,
        actual_dropout=actual_dropout,
        compensation_cipher=compensation_cipher,
        compensation_commitment=compensation_commitment,
        model_hash0=model_hash0,
        audit_root0=audit_root0,
        sys_para_hash=sys_para_hash,
        u_root=u_root,
        alpha=alpha,
        root_up=root_up,
        root_d=root_d,
    )


def verify_upmsg(fx: Fixture, cid: int, msg: Mapping[str, Any]) -> bool:
    try:
        receipt = dict(msg["receipt"])
        sig = receipt.pop("sigUp")
        ciphertexts = [int(x, 16) for x in msg["ciphertexts"]]
        return (
            receipt["r"] == 1
            and receipt["i"] == cid
            and receipt["alpha"] == fx.alpha
            and receipt["encHash"] == sha256_hex([int_hex(c) for c in ciphertexts])
            and verify_obj(fx.client_pks[cid], receipt, sig)
        )
    except Exception:
        return False


def aggregate_for_set(fx: Fixture, active: Sequence[int]) -> Tuple[List[int], int]:
    ciphers: List[int] = []
    for j in range(fx.dimension):
        factors = [int(fx.upmsgs[cid]["ciphertexts"][j], 16) for cid in active]
        factors.append(fx.compensation_cipher[j])
        ciphers.append(fx.paillier.add(factors))
    raw_coms = [int(fx.upmsgs[cid]["receipt"]["Com"], 16) for cid in active]
    com_agg = fx.pedersen.aggregate(raw_coms + [fx.compensation_commitment])
    return ciphers, com_agg


def share_message(fx: Fixture, cid: int, agg_cipher: Sequence[int], wrong: bool = False) -> Dict[str, Any]:
    values = [fx.paillier.partial_decrypt(cid, c) for c in agg_cipher]
    if wrong:
        values[0] = (values[0] * 7) % fx.paillier.n2
    body = {
        "r": 1,
        "i": cid,
        "alpha": fx.alpha,
        "cAggHash": sha256_hex([int_hex(c) for c in agg_cipher]),
        "shareHash": sha256_hex([int_hex(v) for v in values]),
        "values": [int_hex(v) for v in values],
    }
    return {**body, "sigShare": sign_obj(fx.client_sks[cid], body)}


def verify_share(fx: Fixture, msg: Mapping[str, Any], agg_cipher: Sequence[int]) -> bool:
    try:
        body = dict(msg)
        sig = body.pop("sigShare")
        cid = int(body["i"])
        vals = [int(v, 16) for v in body["values"]]
        return (
            body["r"] == 1
            and body["alpha"] == fx.alpha
            and body["cAggHash"] == sha256_hex([int_hex(c) for c in agg_cipher])
            and body["shareHash"] == sha256_hex([int_hex(v) for v in vals])
            and verify_obj(fx.client_pks[cid], body, sig)
        )
    except Exception:
        return False


def combine_vector(fx: Fixture, share_msgs: Sequence[Mapping[str, Any]]) -> List[int]:
    selected = list(share_msgs)[: fx.threshold]
    out: List[int] = []
    for j in range(fx.dimension):
        partials = {int(m["i"]): int(m["values"][j], 16) for m in selected}
        out.append(fx.paillier.combine(partials))
    return out


def final_action(fx: Fixture, aggregate: Sequence[int], com_agg: int) -> Dict[str, Any]:
    model_next = sha256_hex({"modelPrev": fx.model_hash0, "aggregate": list(aggregate)})
    com_hash = sha256_hex(int_hex(com_agg))
    audit_root = sha256_hex({
        "prev": fx.audit_root0,
        "r": 1,
        "alpha": fx.alpha,
        "rootUp": fx.root_up,
        "comAggHash": com_hash,
        "modelPrev": fx.model_hash0,
        "modelNext": model_next,
    })
    return {
        "type": "final",
        "round": 1,
        "alpha": fx.alpha,
        "rootUp": fx.root_up,
        "comAggHash": com_hash,
        "modelHashPrev": fx.model_hash0,
        "modelHashNext": model_next,
        "prevAuditRoot": fx.audit_root0,
        "auditRoot": audit_root,
    }


def fault_action(
    fx: Fixture,
    fault_type: str,
    stage: str,
    resolution: str,
    evidence: Mapping[str, Any],
    attempt: int = 1,
) -> Dict[str, Any]:
    return {
        "type": "fault",
        "round": 1,
        "attempt": attempt,
        "alpha": fx.alpha,
        "faultType": fault_type,
        "faultTypeCode": FAULT_TYPES[fault_type],
        "failureStage": stage,
        "failureStageCode": FAULT_STAGES[stage],
        "resolution": resolution,
        "resolutionCode": RESOLUTIONS[resolution],
        "evidenceHash": sha256_hex(evidence),
        "evidence": dict(evidence),
    }


def init_plan(fx: Fixture) -> Dict[str, Any]:
    return {
        "sysParaHash": fx.sys_para_hash,
        "uRoot": fx.u_root,
        "modelHash0": fx.model_hash0,
        "auditRoot0": fx.audit_root0,
    }


def run_scenario(scenario: str, output_dir: Path, seed: int = 20260714, dimension: int = 32) -> Dict[str, Any]:
    if scenario not in PROTOCOL_SCENARIOS:
        raise ValueError(f"unsupported protocol scenario: {scenario}")
    output_dir.mkdir(parents=True, exist_ok=True)
    t0 = time.perf_counter()
    fx = build_fixture(seed=seed, dimension=dimension)
    events: List[Dict[str, Any]] = []
    comm_rows: List[Dict[str, Any]] = []
    runtime_rows: List[Dict[str, Any]] = []
    chain_actions: List[Dict[str, Any]] = []

    # KGC has clients 1-4; C5 is the genuine dropout.  CS initially misses C2.
    kgc_active = list(fx.actual_active)
    cs_initial = [1, 3, 4]
    kgc_dropout = list(fx.actual_dropout)
    cs_dropout = [2, 5]
    root_d_kgc = fx.root_d
    root_d_cs = merkle_root([str(i).encode() for i in cs_dropout], b"EMPTY_DROPOUT")
    mismatch = root_d_cs != root_d_kgc
    events.append({
        "event": "dropout_root_compare",
        "rootD_cs": root_d_cs,
        "rootD_kgc": root_d_kgc,
        "mismatch": mismatch,
        "bitmap_cs": bitmap(cs_initial, fx.n_clients),
        "bitmap_kgc": bitmap(kgc_active, fx.n_clients),
    })

    aggregate: Optional[List[int]] = None
    com_agg: Optional[int] = None
    detected = True
    accepted = False
    detection_stage = ""
    reason = ""
    resolution = ""
    combine_executed = False
    final_generated = False
    fault_generated = True
    valid_share_count: Optional[int] = None
    local_training_reexecuted = False
    paillier_reencrypted = False
    alpha_unchanged = True

    if scenario.startswith("dropout_reconciliation") or scenario in {"ignore_kgc_dropout_set", "tamper_coordination_response"}:
        coord_req_body = {
            "r": 1,
            "alpha": fx.alpha,
            "bitmapUpCS": bitmap(cs_initial, fx.n_clients),
            "rootDCS": root_d_cs,
        }
        # Experimental CS key is used only to authenticate the request.
        cs_sk = ec.generate_private_key(ec.SECP256R1())
        cs_pk = cs_sk.public_key()
        coord_req = {**coord_req_body, "sigCS": sign_obj(cs_sk, coord_req_body)}
        comm_rows.append({"payload_type": "CoordReq", "messages": 1, "bytes": len(canonical_bytes(coord_req))})
        events.append({"event": "coord_request", "valid": verify_obj(cs_pk, coord_req_body, coord_req["sigCS"])})

        missing = sorted(set(kgc_active) - set(cs_initial))
        response_body = {
            "r": 1,
            "alpha": fx.alpha,
            "bitmapUpKGC": bitmap(kgc_active, fx.n_clients),
            "rootDKGC": root_d_kgc,
            "missingUpMsgIds": missing,
            "missingUpMsgs": {str(i): fx.upmsgs[i] for i in missing},
            "compensationHash": sha256_hex([int_hex(c) for c in fx.compensation_cipher]),
        }
        response = {**response_body, "sigKGC": sign_obj(fx.kgc_sk, response_body)}

        if scenario == "tamper_coordination_response":
            response["bitmapUpKGC"] = "11111"  # modify after KGC signed it

        response_valid = verify_obj(
            fx.kgc_pk,
            {k: v for k, v in response.items() if k != "sigKGC"},
            response["sigKGC"],
        )
        comm_rows.append({"payload_type": "CoordResp", "messages": 1, "bytes": len(canonical_bytes(response))})
        events.append({"event": "coord_response_verify", "valid": response_valid, "missing_ids": missing})

        if scenario == "dropout_reconciliation_success":
            recovered_msgs = response_body["missingUpMsgs"]
            upmsg_ok = all(verify_upmsg(fx, int(cid), msg) for cid, msg in recovered_msgs.items())
            if not (mismatch and response_valid and upmsg_ok):
                raise RuntimeError("reconciliation-success fixture unexpectedly failed")
            active = kgc_active
            cagg, com_agg = aggregate_for_set(fx, active)
            shares = [share_message(fx, cid, cagg) for cid in active]
            valid = [m for m in shares if verify_share(fx, m, cagg)]
            valid_share_count = len(valid)
            aggregate = combine_vector(fx, valid)
            combine_executed = True
            open_ok = fx.pedersen.commit(aggregate, 0) == com_agg
            if not open_ok:
                raise RuntimeError("reconciled aggregate failed commitment check")
            evidence = {
                "rootDCS": root_d_cs,
                "rootDKGC": root_d_kgc,
                "bitmapCS": bitmap(cs_initial, fx.n_clients),
                "bitmapKGC": bitmap(kgc_active, fx.n_clients),
                "missingUpMsgHashes": {str(i): sha256_hex(fx.upmsgs[i]) for i in missing},
                "result": "recovered",
            }
            chain_actions.append(fault_action(fx, "SET_VIEW_MISMATCH", "DROPOUT_COMPENSATION", "RECOVERED", evidence))
            chain_actions.append(final_action(fx, aggregate, com_agg))
            accepted = True
            final_generated = True
            detection_stage = "dropout_set_reconciliation"
            resolution = "RECOVERED"
            reason = "CS detected root mismatch, obtained KGC-saved bitmap and original UpMsg, then reaggregated without retraining"

        elif scenario == "dropout_reconciliation_failed":
            # Coordination response is authenticated, but the large missing UpMsg is unavailable.
            response_body["missingUpMsgs"] = {}
            evidence = {
                "rootDCS": root_d_cs,
                "rootDKGC": root_d_kgc,
                "missingIds": missing,
                "missingUpMsgAvailable": False,
                "result": "aborted",
            }
            chain_actions.append(fault_action(fx, "RECONCILIATION_FAILED", "COORDINATION", "ABORTED", evidence))
            detection_stage = "dropout_set_reconciliation"
            resolution = "ABORTED"
            reason = "KGC set was authoritative but CS could not obtain every required original UpMsg; Combine was not entered"

        elif scenario == "ignore_kgc_dropout_set":
            cagg, com_agg = aggregate_for_set(fx, cs_initial)
            shares = [share_message(fx, cid, cagg) for cid in cs_initial]
            valid_share_count = len(shares)
            aggregate = combine_vector(fx, shares)
            combine_executed = True
            open_ok = fx.pedersen.commit(aggregate, 0) == com_agg
            evidence = {
                "rootDCS": root_d_cs,
                "rootDKGC": root_d_kgc,
                "coordinationIgnored": True,
                "openCheck": open_ok,
                "csActive": cs_initial,
                "kgcActive": kgc_active,
            }
            chain_actions.append(fault_action(fx, "DROPOUT_SET_ATTACK", "DROPOUT_COMPENSATION", "ATTACK_CONFIRMED", evidence))
            detection_stage = "kgc_final_gate"
            resolution = "ATTACK_CONFIRMED"
            reason = "CS ignored the KGC-authoritative set; the residual mask/randomness broke the final commitment relation"
            if open_ok:
                raise RuntimeError("ignored dropout-set attack was not detected")

        elif scenario == "tamper_coordination_response":
            evidence = {
                "rootDCS": root_d_cs,
                "rootDKGC": root_d_kgc,
                "coordResponseSignatureValid": response_valid,
                "tamperedField": "bitmapUpKGC",
            }
            chain_actions.append(fault_action(fx, "COORDINATION_RESPONSE_TAMPER", "COORDINATION", "REJECTED", evidence))
            detection_stage = "coordination_response_verify"
            resolution = "REJECTED"
            reason = "CS rejected a coordination response whose KGC-signed bitmap was modified in transit"
            if response_valid:
                raise RuntimeError("tampered coordination response unexpectedly verified")

    else:
        # Share-stage scenarios start after a correct KGC-authoritative aggregate exists.
        cagg, com_agg = aggregate_for_set(fx, kgc_active)
        shares = [share_message(fx, cid, cagg) for cid in kgc_active]

        if scenario == "tampered_decryption_share":
            tampered = json.loads(json.dumps(shares[0]))
            tampered["values"][0] = int_hex((int(tampered["values"][0], 16) * 11) % fx.paillier.n2)
            received = [tampered] + shares[1:]
            valid = [m for m in received if verify_share(fx, m, cagg)]
            valid_share_count = len(valid)
            events.append({"event": "share_signature_verify", "received": len(received), "valid": len(valid)})
            if len(valid) < fx.threshold:
                raise RuntimeError("tampered share scenario should remain above threshold")
            aggregate = combine_vector(fx, valid)
            combine_executed = True
            open_ok = fx.pedersen.commit(aggregate, 0) == com_agg
            if not open_ok:
                raise RuntimeError("recovery after rejecting tampered share failed")
            evidence = {
                "invalidClient": int(tampered["i"]),
                "shareSignatureValid": False,
                "validShareCount": len(valid),
                "threshold": fx.threshold,
                "openCheck": open_ok,
            }
            chain_actions.append(fault_action(fx, "INVALID_DECRYPTION_SHARE", "SHARE_VERIFY", "RECOVERED", evidence))
            chain_actions.append(final_action(fx, aggregate, com_agg))
            accepted = True
            final_generated = True
            detection_stage = "share_signature_verify"
            resolution = "RECOVERED"
            reason = "A share modified after signing was rejected; the remaining valid shares still met the threshold"

        elif scenario == "wrong_signed_decryption_share":
            wrong = share_message(fx, 1, cagg, wrong=True)
            received = [wrong] + shares[1:]
            valid = [m for m in received if verify_share(fx, m, cagg)]
            valid_share_count = len(valid)
            # The current main scheme has signatures but no proof of algebraic share correctness.
            # Select the first threshold shares, including the wrong-but-validly-signed one.
            aggregate = combine_vector(fx, valid)
            combine_executed = True
            open_ok = fx.pedersen.commit(aggregate, 0) == com_agg
            evidence = {
                "wrongSignedShareClient": 1,
                "signatureValid": True,
                "individualAlgebraicProofAvailable": False,
                "openCheck": open_ok,
                "threshold": fx.threshold,
            }
            chain_actions.append(fault_action(
                fx,
                "DECRYPTION_RECOVERY_INCONSISTENCY",
                "AGGREGATE_OPEN_CHECK",
                "REJECTED",
                evidence,
            ))
            detection_stage = "aggregate_open_check"
            resolution = "REJECTED"
            reason = "A wrong but validly signed share was not individually attributable; the post-Combine Pedersen check rejected the recovered aggregate"
            if open_ok:
                raise RuntimeError("wrong signed share unexpectedly passed commitment check")

        elif scenario == "threshold_unreached":
            received = shares[: fx.threshold - 1]
            valid = [m for m in received if verify_share(fx, m, cagg)]
            valid_share_count = len(valid)
            combine_executed = False
            evidence = {
                "validShareCount": len(valid),
                "threshold": fx.threshold,
                "combineExecuted": False,
                "missingShareClients": [3, 4],
            }
            chain_actions.append(fault_action(fx, "THRESHOLD_UNREACHED", "SHARE_COLLECTION", "ABORTED", evidence))
            detection_stage = "share_collection"
            resolution = "ABORTED"
            reason = "The number of valid decryption shares was below t; Combine, model update, and FinalTx were skipped"

    elapsed = time.perf_counter() - t0
    runtime_rows.append({"round": 1, "stage": "protocol_extension_total", "seconds": elapsed})
    for cid in fx.actual_active:
        comm_rows.append({"payload_type": "UpMsg", "messages": 1, "bytes": len(canonical_bytes(fx.upmsgs[cid]))})

    expected_final_count = sum(1 for a in chain_actions if a["type"] == "final")
    expected_fault_count = sum(1 for a in chain_actions if a["type"] == "fault")
    result = {
        "scenario": scenario,
        "execution_mode": "protocol_extension_crypto",
        "expected_stage": detection_stage,
        "attack_round": 1,
        "target_client": 2 if "dropout" in scenario or "coordination" in scenario else 1,
        "attack_executed": True,
        "detected": detected,
        "accepted": accepted,
        "detection_round": 1,
        "detection_stage": detection_stage,
        "reason": reason,
        "rounds_completed": 1 if accepted else 0,
        "model_dimension": fx.dimension,
        "paillier_bits": fx.paillier.n.bit_length(),
        "threshold": fx.threshold,
        "valid_share_count": valid_share_count if valid_share_count is not None else "",
        "combine_executed": combine_executed,
        "faulttx_expected": fault_generated,
        "finaltx_expected": final_generated,
        "fault_resolution": resolution,
        "local_training_reexecuted": local_training_reexecuted,
        "paillier_reencrypted": paillier_reencrypted,
        "alpha_unchanged": alpha_unchanged,
    }

    chain_plan = {
        "scenario": scenario,
        "init": init_plan(fx),
        "actions": chain_actions,
        "expected": {
            "faultTxCount": expected_fault_count,
            "finalTxCount": expected_final_count,
            "faultDoesNotAdvanceAuditRoot": True,
        },
    }
    trace = {
        "fixture": {
            "seed": fx.seed,
            "nClients": fx.n_clients,
            "threshold": fx.threshold,
            "dimension": fx.dimension,
            "paillierBits": fx.paillier.n.bit_length(),
            "actualActive": fx.actual_active,
            "actualDropout": fx.actual_dropout,
            "alpha": fx.alpha,
            "rootUp": fx.root_up,
            "rootD": fx.root_d,
        },
        "events": events,
        "result": result,
    }

    (output_dir / "run_trace.json").write_text(json.dumps(trace, ensure_ascii=False, indent=2), encoding="utf-8")
    (output_dir / "chain_plan.json").write_text(json.dumps(chain_plan, ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv(output_dir / "attack_result.csv", [result])
    write_csv(output_dir / "verify_result.csv", [{
        "accepted": accepted,
        "detected": detected,
        "detection_stage": detection_stage,
        "faulttx_expected": expected_fault_count,
        "finaltx_expected": expected_final_count,
    }])
    write_csv(output_dir / "attack_events.csv", events)
    write_csv(output_dir / "runtime_cost.csv", runtime_rows)
    write_csv(output_dir / "communication_cost.csv", comm_rows)
    write_csv(output_dir / "crypto_cost.csv", [
        {"round": 1, "metric": "model_dimension", "value": fx.dimension},
        {"round": 1, "metric": "paillier_bits", "value": fx.paillier.n.bit_length()},
        {"round": 1, "metric": "threshold", "value": fx.threshold},
        {"round": 1, "metric": "valid_share_count", "value": valid_share_count if valid_share_count is not None else ""},
        {"round": 1, "metric": "combine_executed", "value": int(combine_executed)},
    ])
    print(json.dumps(result, ensure_ascii=False))
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", required=True, choices=PROTOCOL_SCENARIOS)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--seed", type=int, default=20260714)
    ap.add_argument("--dimension", type=int, default=32)
    args = ap.parse_args()
    run_scenario(args.scenario, Path(args.output_dir), seed=args.seed, dimension=args.dimension)


if __name__ == "__main__":
    main()
