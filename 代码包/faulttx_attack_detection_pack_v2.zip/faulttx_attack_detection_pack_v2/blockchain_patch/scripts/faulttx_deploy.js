const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

function statePath() {
  return process.env.FAULT_BOARD_STATE || path.join(process.cwd(), "outputs", "faulttx_contract_state.json");
}

async function waitDeployment(contract) {
  if (typeof contract.waitForDeployment === "function") {
    await contract.waitForDeployment();
    return await contract.getAddress();
  }
  await contract.deployed();
  return contract.address;
}

async function main() {
  const [kgc] = await hre.ethers.getSigners();
  const Factory = await hre.ethers.getContractFactory("AuditBoardFaultTx");
  const contract = await Factory.deploy(kgc.address);
  const address = await waitDeployment(contract);
  const network = await hre.ethers.provider.getNetwork();
  const out = {
    ok: true,
    address,
    kgc: kgc.address,
    chainId: network.chainId.toString(),
    stateFile: statePath(),
  };
  fs.mkdirSync(path.dirname(statePath()), { recursive: true });
  fs.writeFileSync(statePath(), JSON.stringify(out, null, 2));
  console.log(JSON.stringify(out));
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
