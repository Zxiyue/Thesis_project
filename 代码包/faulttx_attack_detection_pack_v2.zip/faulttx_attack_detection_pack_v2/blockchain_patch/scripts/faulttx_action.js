const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

function req(name, fallback = undefined) {
  const v = process.env[name];
  if ((v === undefined || v === "") && fallback === undefined) {
    throw new Error(`missing env ${name}`);
  }
  return (v === undefined || v === "") ? fallback : v;
}

function statePath() {
  return req("FAULT_BOARD_STATE", path.join(process.cwd(), "outputs", "faulttx_contract_state.json"));
}

function bytes32(name, fallback = "0x" + "00".repeat(32)) {
  const value = req(name, fallback);
  if (!/^0x[0-9a-fA-F]{64}$/.test(value)) {
    throw new Error(`${name} must be bytes32 hex, got ${value}`);
  }
  return value;
}

async function contractAddress() {
  const data = JSON.parse(fs.readFileSync(statePath(), "utf8"));
  return data.address;
}

async function receiptInfo(tx, extra = {}) {
  const receipt = await tx.wait();
  return {
    ok: true,
    txHash: receipt.hash || receipt.transactionHash,
    gasUsed: receipt.gasUsed.toString(),
    blockNumber: Number(receipt.blockNumber),
    ...extra,
  };
}

async function main() {
  const action = req("FAULT_ACTION");
  const signers = await hre.ethers.getSigners();
  const address = await contractAddress();
  const kgc = signers[0];
  const contract = await hre.ethers.getContractAt("AuditBoardFaultTx", address, kgc);

  if (action === "init") {
    const tx = await contract.recordInit(
      bytes32("SYS_PARA_HASH"), bytes32("U_ROOT"),
      bytes32("MODEL_HASH0"), bytes32("AUDIT_ROOT0")
    );
    console.log(JSON.stringify(await receiptInfo(tx, { action })));
    return;
  }

  if (action === "final") {
    const tx = await contract.recordFinal(
      req("FINAL_ROUND"), bytes32("FINAL_ALPHA"),
      bytes32("FINAL_ROOT_UP"), bytes32("FINAL_COM_AGG_HASH"),
      bytes32("FINAL_MODEL_PREV"), bytes32("FINAL_MODEL_NEXT"),
      bytes32("FINAL_PREV_AUDIT_ROOT"), bytes32("FINAL_AUDIT_ROOT")
    );
    console.log(JSON.stringify(await receiptInfo(tx, { action })));
    return;
  }

  if (action === "fault") {
    const tx = await contract.recordFault(
      req("FAULT_ROUND"), Number(req("FAULT_ATTEMPT", "1")),
      bytes32("FAULT_ALPHA"), Number(req("FAULT_TYPE")),
      Number(req("FAULT_STAGE")), Number(req("FAULT_RESOLUTION")),
      bytes32("FAULT_EVIDENCE_HASH"), bytes32("FAULT_ANCHOR_AUDIT_ROOT")
    );
    const info = await receiptInfo(tx, { action });
    console.log(JSON.stringify(info));
    return;
  }

  if (action === "status") {
    const out = {
      ok: true,
      action,
      address,
      kgc: await contract.kgc(),
      initialized: await contract.initialized(),
      latestFinalRound: (await contract.latestFinalRound()).toString(),
      currentModelHash: await contract.currentModelHash(),
      latestAuditRoot: await contract.latestAuditRoot(),
      faultCount: (await contract.faultCount()).toString(),
    };
    console.log(JSON.stringify(out));
    return;
  }

  if (action === "unauthorized-fault") {
    const attacker = signers[1];
    const bad = contract.connect(attacker);
    try {
      const tx = await bad.recordFault(
        1, 999, bytes32("FAULT_ALPHA"), 1, 1, 4,
        bytes32("FAULT_EVIDENCE_HASH"), bytes32("FAULT_ANCHOR_AUDIT_ROOT")
      );
      await tx.wait();
      console.log(JSON.stringify({ ok: false, action, rejected: false }));
      process.exitCode = 2;
    } catch (err) {
      console.log(JSON.stringify({ ok: true, action, rejected: true, reason: String(err.message || err) }));
    }
    return;
  }

  throw new Error(`unknown FAULT_ACTION=${action}`);
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
