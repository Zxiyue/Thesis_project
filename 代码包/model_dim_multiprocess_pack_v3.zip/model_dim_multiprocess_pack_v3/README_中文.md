# 模型维度对比实验代码包 v3

本包用于重新设计后的模型维度对比实验。实验分为两组：

1. **真实模型组**：`logistic_regression`、`mlp`、`tiny_cnn`、`small_cnn`、`larger_cnn/cnn`。
2. **合成维度组**：`synthetic_1000`、`synthetic_5000`、`synthetic_10000`、`synthetic_20000`、`synthetic_50000`、`synthetic_100000`。

固定实验口径：

```text
clients = 10
threshold = 6
rounds = 10
dataset = MNIST-IID
Paillier = 512-bit
slot_bits = 40
blockchain = on
mode = multiprocess HTTP
client_mode = individual
dropout = 0
```

## 重要说明

- synthetic 是合成维度实验，不用于准确率比较。
- synthetic 通过“基础小模型 + padding 参数向量”的方式让协议看到指定维度 d，用于单独测试 d 对加密、承诺、通信和运行时间的影响。
- 真实模型组用于说明不同真实模型结构下系统仍可完成公开审计。
- 合成维度组用于更清晰地观察链下开销随 d 的增长趋势。
- 链上仍只写固定格式的 InitTx 和 FinalTx，因此预期 FinalTx gas 与模型维度弱相关或基本稳定。

## 脚本

```text
scripts/probe_model_dims.sh                 # 检测并打印模型维度
scripts/run_model_dim_smoke_1r.sh           # synthetic_100000 1轮 smoke
scripts/run_model_dim_real_models.sh        # 只跑真实模型组
scripts/run_model_dim_synthetic.sh          # 只跑 synthetic 组
scripts/run_model_dim_multiprocess_full.sh  # 一次跑真实模型组 + synthetic 组
scripts/check_status.sh                     # 查看结果与端口状态
```

## 推荐运行顺序

```bash
cd /root
unzip -o model_dim_multiprocess_pack_v3.zip
cd /root/model_dim_multiprocess_pack_v3
bash scripts/probe_model_dims.sh
bash scripts/run_model_dim_smoke_1r.sh
```

smoke 通过后，推荐分组跑：

```bash
tmux new -s model_dim_real
cd /root/model_dim_multiprocess_pack_v3
bash scripts/run_model_dim_real_models.sh
```

真实模型组完成后：

```bash
tmux new -s model_dim_syn
cd /root/model_dim_multiprocess_pack_v3
bash scripts/run_model_dim_synthetic.sh
```

也可以一次性跑完整 11 个 case：

```bash
tmux new -s model_dim_full
cd /root/model_dim_multiprocess_pack_v3
bash scripts/run_model_dim_multiprocess_full.sh
```

## 输出结果

完整运行默认结果包：

```text
/root/model_dim_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_v3_results.zip
```

分组运行结果包：

```text
/root/model_dim_real_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_v3_results.zip
/root/model_dim_synthetic_multiprocess_mnist_iid_c10_t6_p512_s40_10r_chain_v3_results.zip
```


## v3 修复说明

修复 `patch_model_dim_support.py` 中 `re.sub()` 替换块包含 `\d` 时被解释为正则替换转义字符的问题。该错误会导致 `probe_model_dims.sh` 报 `re.error: bad escape \d`。v3 使用 `lambda` 替换方式，避免 PATCH_BLOCK 中的反斜杠被二次解释。
