# fpa5 服务器运行说明

本压缩包是服务器运行版，已排除 node_modules、artifacts、cache、outputs、data、__pycache__。

## 1. 解压

```bash
cd /mnt
unzip fpa5_server_ready_fixed.zip
cd /mnt/fpa5
```

如果解压后目录名不是 fpa5，请执行：

```bash
mv /mnt/fpa5_server_ready /mnt/fpa5
cd /mnt/fpa5
```

## 2. 安装依赖

```bash
apt update
apt install -y git unzip zip curl wget build-essential tmux python3 python3-venv python3-pip
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs
npm install
```

## 3. 准备数据集

```bash
mkdir -p /mnt/fpa5/data
cp -r /public/torchvision_datasets/MNIST /mnt/fpa5/data/
cp -r /public/torchvision_datasets/FashionMNIST /mnt/fpa5/data/
```

## 4. 三个 tmux 窗口运行

窗口1：

```bash
cd /mnt/fpa5
source .venv/bin/activate
npx hardhat node
```

窗口2：

```bash
cd /mnt/fpa5
source .venv/bin/activate
npx hardhat compile
npx hardhat run scripts/deploy.js --network localhost
python scripts/start_all_entities.py --config configs/mnist_iid_50r_main.yaml --clients 5
```

窗口3：

```bash
cd /mnt/fpa5
source .venv/bin/activate
python scripts/start_experiment.py --config configs/mnist_iid_50r_main.yaml
python scripts/collect_results.py --config configs/mnist_iid_50r_main.yaml
python scripts/stop_all_entities.py --config configs/mnist_iid_50r_main.yaml
zip -r /mnt/mnist_iid_50r_main_results.zip outputs/mnist_iid_50r_main
```

正式跑 50 轮前，建议先把配置中的 `rounds: 50` 改为 `rounds: 5` 做 smoke test。
