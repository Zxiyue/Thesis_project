# fpa5 实验结果绘图与汇总代码

## 1. 用途

该代码用于读取 fpa5 实验输出压缩包，并自动生成：

- 训练收敛图：accuracy / loss 曲线；
- 最终性能图：第 50 轮 accuracy / loss 柱状图；
- 掉线与有效客户端图；
- 通信开销图：按消息类型分解；
- 运行时间图：Paillier、Pedersen、本地训练、总墙钟等；
- 区块链开销图：FinalTx gas、链上延迟；
- 掉线补偿图：compensation encryptions；
- 汇总表：experiment_summary.csv、runtime_stage_summary.csv、communication_summary_combined.csv 等；
- 数据一致性检查：data_integrity_warnings.txt。

## 2. 目录准备

把四个结果压缩包放到同一个目录，例如：

```text
results_zips/
├─ mnist_iid_50r_main_results.zip
├─ mnist_noniid_50r_main_results.zip
├─ fashion_mnist_iid_50r_main_results.zip
└─ fashion_mnist_noniid_50r_main_results.zip
```

## 3. 安装依赖

```bash
pip install pandas matplotlib numpy openpyxl
```

## 4. 运行

```bash
python plot_experiment_results.py --input results_zips --output analysis_outputs --clean
```

运行后会生成：

```text
analysis_outputs/
├─ figures/
│  ├─ 01_accuracy_curves.png
│  ├─ 02_loss_curves.png
│  ├─ 03_final_accuracy_bar.png
│  ├─ ...
│  └─ 14_compensation_encryptions.png
└─ tables/
   ├─ experiment_summary.csv
   ├─ communication_summary_combined.csv
   ├─ runtime_stage_summary.csv
   ├─ blockchain_summary.csv
   ├─ crypto_summary.csv
   └─ data_integrity_warnings.txt
```

## 5. 注意事项

当前这批数据里，脚本会检查不同实验的 `metrics_round.csv` 是否完全相同。  
如果发现 MNIST 和 Fashion-MNIST 的曲线完全一致，需要先核查数据加载器和配置文件是否真正加载了 Fashion-MNIST，而不是仍然加载 MNIST。
