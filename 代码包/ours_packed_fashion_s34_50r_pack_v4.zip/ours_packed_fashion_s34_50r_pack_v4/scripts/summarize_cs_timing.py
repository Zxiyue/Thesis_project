from __future__ import annotations
import csv, sys
from collections import defaultdict
from pathlib import Path
if len(sys.argv)!=2:
    raise SystemExit('Usage: summarize_cs_timing.py <output_dir>')
out=Path(sys.argv[1]); runtime=out/'runtime_cost.csv'
if not runtime.exists():
    raise SystemExit(f'{runtime} not found')
stages=['cs_decrypt_combine','cs_unpack_vector','cs_decode_aggregate','cs_model_update']
by_stage=defaultdict(list); by_round=defaultdict(dict)
with runtime.open(newline='', encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        stage=row.get('stage') or row.get('name') or row.get('metric')
        if stage not in stages: continue
        sec=float(row.get('seconds') or row.get('time') or row.get('value') or 0.0)
        r=int(float(row.get('round') or row.get('r') or 0))
        by_stage[stage].append(sec); by_round[r][stage]=sec

def stats(vals):
    if not vals: return (0,0,0,0,0)
    vals=sorted(vals); total=sum(vals); avg=total/len(vals); mid=len(vals)//2
    med=vals[mid] if len(vals)%2 else (vals[mid-1]+vals[mid])/2
    return total,avg,med,vals[0],vals[-1]
summary=out/'cs_timing_summary.csv'
with summary.open('w', newline='', encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['stage','count','total_seconds','avg_seconds','median_seconds','min_seconds','max_seconds'])
    for s in stages:
        total,avg,med,mn,mx=stats(by_stage.get(s,[])); w.writerow([s,len(by_stage.get(s,[])),f'{total:.6f}',f'{avg:.6f}',f'{med:.6f}',f'{mn:.6f}',f'{mx:.6f}'])
roundp=out/'cs_timing_by_round.csv'
with roundp.open('w', newline='', encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['round']+stages)
    for r in sorted(by_round): w.writerow([r]+[f'{by_round[r].get(s,0.0):.6f}' for s in stages])
print('stage,count,total_seconds,avg_seconds,median_seconds,min_seconds,max_seconds')
for s in stages:
    total,avg,med,mn,mx=stats(by_stage.get(s,[])); print(f'{s},{len(by_stage.get(s,[]))},{total:.6f},{avg:.6f},{med:.6f},{mn:.6f},{mx:.6f}')
print('[OK] wrote', summary)
print('[OK] wrote', roundp)
