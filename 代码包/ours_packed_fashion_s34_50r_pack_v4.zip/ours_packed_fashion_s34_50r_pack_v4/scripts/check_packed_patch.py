from pathlib import Path
ROOT=Path('/root/fpa5')
checks=[]
entities=(ROOT/'fl_audit/protocol/entities.py').read_text(encoding='utf-8')
cs=(ROOT/'scripts/run_cs_server.py').read_text(encoding='utf-8')
kgc=(ROOT/'scripts/run_kgc_server.py').read_text(encoding='utf-8')
checks.append(('packing module import', 'packing as cipher_packing' in entities))
checks.append(('client_paillier_pack', 'client_paillier_pack' in entities))
checks.append(('packed make_compensation cfg', 'def make_compensation(self, r: int, D: List[int], paillier_pub, ped_params, cfg:' in entities))
checks.append(('packed recover cfg/dim/timer', 'cfg: Dict[str, Any] | None = None, dim: int | None = None, timer=None' in entities))
checks.append(('kgc passes cfg', 'make_compensation(r, D_r, self.pkey.public, self.ped_params, cfg=self.cfg)' in kgc))
checks.append(('cs passes cfg/dim/timer', 'cfg=self.cfg' in cs and 'dim=int(get_vector(self.model).numel())' in cs and 'timer=self.timer' in cs))
checks.append(('cs_decrypt_combine', 'cs_decrypt_combine' in entities))
checks.append(('cs_unpack_vector', 'cs_unpack_vector' in entities))
checks.append(('cs_decode_aggregate', 'cs_decode_aggregate' in cs))
checks.append(('cs_model_update', 'cs_model_update' in cs))
ok=True
for name, passed in checks:
    print(f'{name:35s}: {"OK" if passed else "FAIL"}')
    ok=ok and passed
print('PACKED_FASHION_PATCH_READY =', ok)
raise SystemExit(0 if ok else 1)
