from pathlib import Path
import csv, json
ROOT=Path('/root/fpa5')
NAMES=['ours_packed_fashion_mnist_iid_50r_p2048_s34_final','ours_packed_fashion_mnist_noniid_50r_p2048_s34_final']
def read_csv(p):
    if not p.exists(): return []
    return list(csv.DictReader(open(p, newline='', encoding='utf-8-sig')))
def f(x):
    try: return float(x)
    except Exception: return 0.0
def sum_stage(rt, st): return sum(f(r.get('seconds',0)) for r in rt if r.get('stage')==st)
def avg_stage(rt, st):
    vals=[f(r.get('seconds',0)) for r in rt if r.get('stage')==st]
    return sum(vals)/len(vals) if vals else 0.0
def best(metrics):
    if not metrics: return ('','')
    b=max(metrics, key=lambda r:f(r.get('test_accuracy',0)))
    return b.get('test_accuracy',''), b.get('round','')
def trace_meta(d):
    p=d/'run_trace.json'; out={'packing_slot_bits':'','packing_slots_per_cipher':'','packing_cipher_count':''}
    if not p.exists(): return out
    obj=json.load(open(p, encoding='utf-8'))
    for rd in obj.get('rounds',[]):
        for cs in rd.get('clientStats',[]):
            if cs.get('packing_enabled'):
                out['packing_slot_bits']=cs.get('packing_slot_bits')
                out['packing_slots_per_cipher']=cs.get('packing_slots_per_cipher')
                out['packing_cipher_count']=cs.get('packing_cipher_count')
                return out
    return out
rows=[]
for name in NAMES:
    d=ROOT/'outputs'/name
    if not d.exists(): continue
    metrics=read_csv(d/'metrics_round.csv'); rt=read_csv(d/'runtime_cost.csv'); comm=read_csv(d/'communication_summary_by_type.csv'); verify=read_csv(d/'verify_result.csv')
    final=metrics[-1] if metrics else {}; best_acc,best_round=best(metrics); meta=trace_meta(d)
    rows.append({
        'name':name,
        'accepted': verify[-1].get('accepted','') if verify else '',
        'rounds': verify[-1].get('rounds','') if verify else '',
        'final_acc': final.get('test_accuracy',''), 'best_acc':best_acc, 'best_round':best_round, 'final_loss':final.get('test_loss',''),
        **meta,
        'total_comm_MB': sum(f(r.get('total_bytes',r.get('bytes',0))) for r in comm)/1024/1024,
        'total_wall_s': sum_stage(rt,'start_experiment_total_wall'),
        'client_upload_parallel_wall_avg_s': avg_stage(rt,'client_upload_parallel_wall'),
        'client_paillier_encrypt_sum_s': sum_stage(rt,'client_paillier_encrypt'),
        'client_paillier_pack_sum_s': sum_stage(rt,'client_paillier_pack'),
        'client_pedersen_commit_sum_s': sum_stage(rt,'client_pedersen_commit'),
        'client_local_train_sum_s': sum_stage(rt,'client_local_train'),
        'cs_decrypt_combine_avg_s': avg_stage(rt,'cs_decrypt_combine'),
        'cs_unpack_vector_avg_s': avg_stage(rt,'cs_unpack_vector'),
        'cs_decode_aggregate_avg_s': avg_stage(rt,'cs_decode_aggregate'),
        'cs_model_update_avg_s': avg_stage(rt,'cs_model_update'),
    })
if not rows:
    print('No outputs found.'); raise SystemExit
headers=list(rows[0].keys()); print(','.join(headers))
for r in rows: print(','.join(str(r.get(h,'')) for h in headers))
