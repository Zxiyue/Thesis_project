#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}
PACK_ROOT="/root/ours_packed_fashion_s34_50r_pack_v4"

check_hardhat(){
  curl -s -X POST http://127.0.0.1:8545 -H "Content-Type: application/json" --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' | grep -q '"result"'
}
cleanup_processes(){
  local cfg="$1"
  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  pkill -f "run_kgc_server.py" || true
  pkill -f "run_cs_server.py" || true
  pkill -f "run_client_server.py" || true
  pkill -f "start_experiment.py" || true
  sleep 3
}
ensure_patches_and_configs(){
  echo "[STEP] Reset core files to pristine Ours-basic base"
  python3 "${PACK_ROOT}/patch/reset_to_pristine_base.py" || exit 1
  echo "[STEP] Apply Ours-packed patch"
  python3 "${PACK_ROOT}/patch/apply_ours_packed_patch.py" || exit 1
  echo "[STEP] Integrate CS timing for packed mode"
  python3 "${PACK_ROOT}/patch/apply_integrated_cs_timing_for_packed.py" || exit 1
  echo "[STEP] Check packed/timing patch"
  python3 "${PACK_ROOT}/scripts/check_packed_patch.py" || exit 1
  echo "[STEP] Generate Fashion-MNIST packed configs"
  python3 "${PACK_ROOT}/config_tools/make_ours_packed_fashion_s34_50r_configs.py" || exit 1
}
run_one(){
  local ds="$1"; local name=""; local cfg=""; local rounds=50
  case "$ds" in
    fashion_iid) name="ours_packed_fashion_mnist_iid_50r_p2048_s34_final";;
    fashion_noniid) name="ours_packed_fashion_mnist_noniid_50r_p2048_s34_final";;
    *) echo "[ERROR] Unknown dataset key: $ds"; exit 1;;
  esac
  cfg="configs/${name}.yaml"
  echo; echo "================================================================"; echo "[RUN] ${name}"; echo "[CFG] ${cfg}"; echo "[OUTDIR] outputs/${name}"; echo "================================================================"
  python3 - <<PY
import yaml
from pathlib import Path
cfg=yaml.safe_load(Path('/root/fpa5/${cfg}').read_text())
assert cfg['dataset']['name']=='FashionMNIST', cfg['dataset']
assert int(cfg['federated']['rounds'])==50, cfg['federated']
assert int(cfg['crypto']['paillier_bits'])==2048, cfg['crypto']
p=cfg['crypto'].get('packing',{})
assert p.get('enabled') is True and int(p.get('slot_bits'))==34, p
print('[OK] config checked:', cfg['output_dir'])
PY
  if ! check_hardhat; then
    echo "[ERROR] Hardhat RPC not reachable at http://127.0.0.1:8545"
    exit 1
  fi
  cleanup_processes "$cfg"
  rm -rf "outputs/${name}"
  echo "[INFO] Deploying audit board contract..."
  npx hardhat run scripts/deploy.js --network localhost || { echo "[ERROR] deploy failed"; exit 1; }
  echo "[INFO] Starting KGC/CS/clients..."
  python3 scripts/start_all_entities.py --config "$cfg" --clients 5 || { echo "[ERROR] start_all_entities failed"; exit 1; }
  echo "[INFO] Starting experiment..."
  python3 scripts/start_experiment.py --config "$cfg" || echo "[WARN] start_experiment returned non-zero; continue polling."
  local done_flag=0; local max_poll="${MAX_POLL:-720}"
  for i in $(seq 1 "$max_poll"); do
    echo; echo "---- $(date) ${name} status ${i}/${max_poll} ----"
    tail -n 8 "outputs/${name}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
    cat "outputs/${name}/verify_result.csv" 2>/dev/null || echo "verify not ready"
    if [ -f "outputs/${name}/verify_result.csv" ] && grep -q "True,${rounds}" "outputs/${name}/verify_result.csv"; then
      done_flag=1; echo "[INFO] ${name} accepted=True rounds=${rounds}"; break
    fi
    sleep 30
  done
  echo "[INFO] Collecting results..."; python3 scripts/collect_results.py --config "$cfg" || true
  echo "[INFO] Summarize CS timing..."; python3 "${PACK_ROOT}/scripts/summarize_cs_timing.py" "outputs/${name}" | tee "/root/cs_timing_summary_${name}.csv" || true
  echo "[INFO] Stopping entities..."; cleanup_processes "$cfg"
  if [ "$done_flag" -ne 1 ]; then
    echo "[ERROR] ${name} did not finish correctly. Keeping partial outputs."
    zip -qr "/root/${name}_partial_results.zip" "outputs/${name}" "/root/cs_timing_summary_${name}.csv" 2>/dev/null || true
    exit 1
  fi
  cd /root/fpa5
  zip -qr "/root/${name}_results.zip" "outputs/${name}" "/root/cs_timing_summary_${name}.csv" 2>/dev/null || true
  echo "[INFO] Result zip: /root/${name}_results.zip"
}
ensure_patches_and_configs
DATASETS="${DATASETS:-fashion_iid fashion_noniid}"
for ds in ${DATASETS}; do run_one "$ds"; done
cd /root/fpa5
COMBINED="/root/ours_packed_fashion_s34_50r_results.zip"
rm -f "$COMBINED"
zip_args=()
for ds in ${DATASETS}; do
  case "$ds" in
    fashion_iid) zip_args+=("outputs/ours_packed_fashion_mnist_iid_50r_p2048_s34_final" "/root/cs_timing_summary_ours_packed_fashion_mnist_iid_50r_p2048_s34_final.csv");;
    fashion_noniid) zip_args+=("outputs/ours_packed_fashion_mnist_noniid_50r_p2048_s34_final" "/root/cs_timing_summary_ours_packed_fashion_mnist_noniid_50r_p2048_s34_final.csv");;
  esac
done
zip -qr "$COMBINED" "${zip_args[@]}" 2>/dev/null || true
echo "[DONE] Combined result zip: $COMBINED"
