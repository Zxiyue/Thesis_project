#!/usr/bin/env bash
set -uo pipefail
cd /root/fpa5
for name in \
  ours_packed_fashion_mnist_iid_50r_p2048_s34_final \
  ours_packed_fashion_mnist_noniid_50r_p2048_s34_final; do
  echo; echo "================ ${name} ================"
  if [ ! -d "outputs/${name}" ]; then echo "not created"; continue; fi
  echo "--- metrics tail ---"; tail -n 12 "outputs/${name}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
  echo "--- verify ---"; cat "outputs/${name}/verify_result.csv" 2>/dev/null || echo "verify not ready"
  echo "--- cs timing tail ---"; grep -E "cs_decrypt_combine|cs_unpack_vector|cs_decode_aggregate|cs_model_update" "outputs/${name}/runtime_cost.csv" 2>/dev/null | tail -n 20 || echo "CS timing not ready"
  echo "--- communication summary ---"; cat "outputs/${name}/communication_summary_by_type.csv" 2>/dev/null || echo "communication not ready"
done
ls -lh /root/ours_packed_fashion*_results.zip /root/ours_packed_fashion_s34_50r_results.zip 2>/dev/null || true
