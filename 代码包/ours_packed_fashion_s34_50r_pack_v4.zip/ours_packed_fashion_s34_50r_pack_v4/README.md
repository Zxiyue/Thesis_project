# Ours-packed Fashion-MNIST 2048-bit slot_bits=34 50-round experiments v4

v4 packages the Fashion-MNIST IID and Non-IID 50-round Ours-packed execution scripts, configs, packed Paillier patch, and CS timing summary tools.

Run:

```bash
cd /root
unzip -o ours_packed_fashion_s34_50r_pack_v4.zip
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
DATASETS="fashion_iid fashion_noniid" stdbuf -oL -eL \
  /root/ours_packed_fashion_s34_50r_pack_v4/scripts/run_ours_packed_fashion_s34_50r.sh \
  | tee /root/packed50_fashion_iid_noniid_v3.log
```

Status:

```bash
/root/ours_packed_fashion_s34_50r_pack_v4/scripts/check_ours_packed_fashion_s34_50r_status.sh
```

Combined output:

```text
/root/ours_packed_fashion_s34_50r_results.zip
```

## 中文快速命令

```bash
cd /root
unzip -o ours_packed_fashion_s34_50r_pack_v4.zip
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
DATASETS="fashion_iid fashion_noniid" stdbuf -oL -eL \
  /root/ours_packed_fashion_s34_50r_pack_v4/scripts/run_ours_packed_fashion_s34_50r.sh \
  | tee /root/packed50_fashion_iid_noniid_v4.log
```

若只跑一组，可设置：`DATASETS="fashion_iid"` 或 `DATASETS="fashion_noniid"`。
