from __future__ import annotations
import re
from pathlib import Path
import shutil

ROOT = Path('/root/fpa5')

def backup(path: Path) -> None:
    bak = path.with_suffix(path.suffix + '.before_integrated_cs_timing_packed_v3')
    if path.exists() and not bak.exists():
        shutil.copy2(path, bak)


def patch_entities() -> None:
    path = ROOT / 'fl_audit/protocol/entities.py'
    backup(path)
    s = path.read_text(encoding='utf-8')

    new_recover = '''    def recover_lambda_and_decrypt(self, share_msgs: List[Dict[str, Any]], client_pubkeys: Dict[int, str], field_prime: int, threshold: int, paillier_keypair, cagg: List[int], r: int, alpha: str, cfg: Dict[str, Any] | None = None, dim: int | None = None, timer=None):
        t_dec_start = time.perf_counter()
        shares = []
        for sm in share_msgs:
            msg = sm["ShareMsg"]
            cid = int(msg["j"])
            if verify_obj(client_pubkeys[cid], sm["sigShare"], msg):
                shares.append((cid, int(msg["share"])))
            if len(shares) >= threshold:
                break
        if len(shares) < threshold:
            raise RuntimeError("not enough valid shares")
        lam = reconstruct(shares, field_prime)
        # The CS only needs the public key and threshold-recovered lambda.
        # If a full keypair is passed by the legacy single-process runner, keep
        # compatibility. In distributed mode, mu is recomputed from public data
        # and recovered lambda, so KGC does not disclose the Paillier private key.
        pub = getattr(paillier_keypair, "public", paillier_keypair)
        if hasattr(paillier_keypair, "private"):
            mu = paillier_keypair.private.mu
        else:
            mu = pow(paillier.L(pow(pub.g, lam, pub.n2), pub.n), -1, pub.n)
        priv = paillier.PaillierPrivateKey(lam=lam, mu=mu)
        plain = [paillier.decrypt(pub, priv, int(c)) for c in cagg]
        if timer is not None:
            timer.add(
                r,
                "cs_decrypt_combine",
                time.perf_counter() - t_dec_start,
                detail="verify decryption shares, reconstruct threshold secret, and decrypt aggregate Paillier ciphertexts",
                cid="CS",
            )

        t_unpack_start = time.perf_counter()
        cfg = cfg or {}
        packing_cfg = cfg.get("crypto", {}).get("packing", {}) or {}
        if bool(packing_cfg.get("enabled", False)):
            if dim is None:
                raise ValueError("dim is required when Paillier packing is enabled")
            slot_bits = int(packing_cfg.get("slot_bits", 40))
            q = int(cfg.get("encoding", {}).get("q", 1000000007))
            slots = cipher_packing.slots_per_cipher(pub, slot_bits)
            xagg = cipher_packing.unpack_vector_mod_q(plain, int(dim), q, slot_bits, slots)
        else:
            xagg = np.array(plain, dtype=np.int64)
        if timer is not None:
            timer.add(
                r,
                "cs_unpack_vector",
                time.perf_counter() - t_unpack_start,
                detail="unpack packed Paillier plaintexts into aggregate vector, or convert plaintext coordinates in basic mode",
                cid="CS",
            )
        return xagg, shares
'''

    pattern = (r'    def recover_lambda_and_decrypt\(self, share_msgs: List\[Dict\[str, Any\]\], client_pubkeys: Dict\[int, str\], field_prime: int, threshold: int, paillier_keypair, cagg: List\[int\], r: int, alpha: str, cfg: Dict\[str, Any\] \| None = None, dim: int \| None = None(?:, timer=None)?\):\n'
               r'.*?        return xagg, shares\n')
    s2, n = re.subn(pattern, new_recover, s, flags=re.S)
    if n != 1:
        raise RuntimeError(f'failed to replace packed recover_lambda_and_decrypt in {path}; replacements={n}')

    # Defensive guard: make_compensation must never reference a CS timer.
    m_start = s2.find('    def make_compensation(')
    m_end = s2.find('    def recover_lambda_and_decrypt(', m_start)
    if m_start >= 0 and m_end > m_start:
        mc = s2[m_start:m_end]
        if 'timer is not None' in mc or 'cs_decrypt_combine' in mc or 'cs_unpack_vector' in mc:
            raise RuntimeError('timer code leaked into make_compensation; reset and patch again')

    path.write_text(s2, encoding='utf-8')
    print('[OK] replaced packed recover_lambda_and_decrypt with integrated CS timing')


def patch_cs_server() -> None:
    path = ROOT / 'scripts/run_cs_server.py'
    backup(path)
    s = path.read_text(encoding='utf-8')
    call_pos = s.find('recover_lambda_and_decrypt')
    if call_pos < 0:
        raise RuntimeError('recover_lambda_and_decrypt call not found in run_cs_server.py')
    snippet = s[call_pos:call_pos+1600]
    if 'timer=self.timer' not in snippet:
        target = '                dim=int(get_vector(self.model).numel()),\n'
        if target in s:
            s = s.replace(target, target + '                timer=self.timer,\n', 1)
        else:
            old = '''                cagg,
                r,
                alpha,
            )
'''
            new = '''                cagg,
                r,
                alpha,
                cfg=self.cfg,
                dim=int(get_vector(self.model).numel()),
                timer=self.timer,
            )
'''
            if old not in s:
                raise RuntimeError('failed to patch recover call timer in run_cs_server.py')
            s = s.replace(old, new, 1)

    if 'cs_decode_aggregate' not in s or 'cs_model_update' not in s:
        old_update = '''            update = torch.tensor(dequantize(xagg, int(self.cfg["encoding"]["scale"])), dtype=torch.float64)
            W_next_vec = W_r_vec + float(self.cfg["federated"].get("server_lr", 1.0)) * update
            set_vector(self.model, W_next_vec)
            model_hash_next = model_hash(self.model)
'''
        new_update = '''            t_decode = time.perf_counter()
            update = torch.tensor(dequantize(xagg, int(self.cfg["encoding"]["scale"])), dtype=torch.float64)
            self.timer.add(
                r,
                "cs_decode_aggregate",
                time.perf_counter() - t_decode,
                detail="fixed-point dequantization of aggregate update and tensor conversion",
                cid="CS",
            )

            t_update = time.perf_counter()
            W_next_vec = W_r_vec + float(self.cfg["federated"].get("server_lr", 1.0)) * update
            set_vector(self.model, W_next_vec)
            model_hash_next = model_hash(self.model)
            self.timer.add(
                r,
                "cs_model_update",
                time.perf_counter() - t_update,
                detail="apply aggregate update, set model vector, and compute next model hash",
                cid="CS",
            )
'''
        if old_update not in s:
            raise RuntimeError('failed to locate decode/model update block in run_cs_server.py')
        s = s.replace(old_update, new_update, 1)
    path.write_text(s, encoding='utf-8')
    print('[OK] integrated run_cs_server CS timing')


def check() -> None:
    ent = (ROOT / 'fl_audit/protocol/entities.py').read_text(encoding='utf-8')
    cs = (ROOT / 'scripts/run_cs_server.py').read_text(encoding='utf-8')
    m_start = ent.find('    def make_compensation(')
    m_end = ent.find('    def recover_lambda_and_decrypt(', m_start)
    mc = ent[m_start:m_end] if m_start >= 0 and m_end > m_start else ''
    checks = [
        ('recover has timer arg', 'dim: int | None = None, timer=None' in ent),
        ('cs_decrypt_combine in recover', 'cs_decrypt_combine' in ent),
        ('cs_unpack_vector in recover', 'cs_unpack_vector' in ent),
        ('no timer in make_compensation', 'timer is not None' not in mc and 'cs_decrypt_combine' not in mc and 'cs_unpack_vector' not in mc),
        ('run_cs_server passes timer', 'timer=self.timer' in cs[cs.find('recover_lambda_and_decrypt'):cs.find('recover_lambda_and_decrypt')+1600]),
        ('cs_decode_aggregate', 'cs_decode_aggregate' in cs),
        ('cs_model_update', 'cs_model_update' in cs),
    ]
    ok = True
    for name, passed in checks:
        print(f'{name:34s}: {"OK" if passed else "FAIL"}')
        ok = ok and passed
    print('PACKED_CS_TIMING_READY =', ok)
    if not ok:
        raise SystemExit(1)


if __name__ == '__main__':
    patch_entities()
    patch_cs_server()
    check()
