from __future__ import annotations
from pathlib import Path
import shutil

ROOT = Path('/root/fpa5')
PACK_ROOT = Path(__file__).resolve().parents[1]
FILES = [
    ('fl_audit/protocol/entities.py', 'pristine_base/fl_audit/protocol/entities.py'),
    ('scripts/run_cs_server.py', 'pristine_base/scripts/run_cs_server.py'),
    ('scripts/run_kgc_server.py', 'pristine_base/scripts/run_kgc_server.py'),
]

def backup(path: Path) -> None:
    bak = path.with_suffix(path.suffix + '.before_fashion_packed_v2')
    if path.exists() and not bak.exists():
        shutil.copy2(path, bak)

if not ROOT.exists():
    raise SystemExit('/root/fpa5 does not exist')
for rel, src_rel in FILES:
    dst = ROOT / rel
    src = PACK_ROOT / src_rel
    if not src.exists():
        raise SystemExit(f'missing pristine file: {src}')
    backup(dst)
    shutil.copy2(src, dst)
    print(f'[OK] reset {rel} to packaged pristine Ours-basic base')
