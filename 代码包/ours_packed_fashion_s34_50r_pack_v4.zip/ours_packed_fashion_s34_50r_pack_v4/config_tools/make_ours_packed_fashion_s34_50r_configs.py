from __future__ import annotations
from pathlib import Path
import copy, yaml

ROOT = Path('/root/fpa5')
CONFIG_DIR = ROOT / 'configs'
DATASETS = {
    'fashion_iid': {
        'candidates': ['fashion_mnist_iid_50r_lr020_main.yaml','fashion_mnist_iid_50r_main.yaml','mnist_iid_50r_main.yaml'],
        'out_name': 'ours_packed_fashion_mnist_iid_50r_p2048_s34_final.yaml',
        'output_dir': 'outputs/ours_packed_fashion_mnist_iid_50r_p2048_s34_final',
        'iid': True,
    },
    'fashion_noniid': {
        'candidates': ['fashion_mnist_noniid_50r_lr020_main.yaml','fashion_mnist_noniid_50r_main.yaml','mnist_noniid_50r_main.yaml'],
        'out_name': 'ours_packed_fashion_mnist_noniid_50r_p2048_s34_final.yaml',
        'output_dir': 'outputs/ours_packed_fashion_mnist_noniid_50r_p2048_s34_final',
        'iid': False,
    },
}

def find_base(cands):
    for n in cands:
        p=CONFIG_DIR/n
        if p.exists(): return p
    raise FileNotFoundError('base config not found: '+', '.join(cands))

def make_one(key):
    m=DATASETS[key]
    base=find_base(m['candidates'])
    cfg=copy.deepcopy(yaml.safe_load(base.read_text(encoding='utf-8')))
    cfg['output_dir']=m['output_dir']
    cfg.setdefault('dataset', {})
    cfg['dataset']['name']='FashionMNIST'
    cfg['dataset']['iid']=bool(m['iid'])
    cfg['dataset']['partition']='iid' if m['iid'] else 'non_iid'
    cfg['dataset']['download']=True
    cfg['dataset'].setdefault('data_dir','/root/fpa5/data')
    cfg['dataset']['shards_per_client']=2
    cfg.setdefault('model', {})
    cfg['model']['name']='tiny_cnn'
    cfg.setdefault('federated', {})
    cfg['federated']['clients']=5
    cfg['federated']['rounds']=50
    cfg['federated']['threshold']=3
    cfg['federated']['local_epochs']=1
    cfg['federated']['batch_size']=64
    cfg['federated']['local_lr']=0.20
    cfg['federated']['server_lr']=1.0
    cfg['federated'].setdefault('dropout', {10:[2],25:[4]})
    if not cfg['federated'].get('dropout'):
        cfg['federated']['dropout']={10:[2],25:[4]}
    cfg.setdefault('encoding', {})
    cfg['encoding']['scale']=10000
    cfg['encoding']['q']=1000000007
    cfg.setdefault('crypto', {})
    cfg['crypto']['paillier_bits']=2048
    cfg['crypto']['pedersen_prime_bits']=521
    cfg['crypto']['pedersen_window']=0
    cfg['crypto']['packing']={
        'enabled': True,
        'scheme':'mod_q_residue',
        'slot_bits':34,
        'pack_size': None,
        'guard_bits':1,
        'allow_unsafe': False,
    }
    cfg.setdefault('runtime', {})
    cfg['runtime']['device']=cfg['runtime'].get('device','cpu')
    cfg['runtime']['parallel_clients']=True
    cfg['runtime']['max_client_workers']=5
    cfg['runtime']['num_workers']=0
    cfg['runtime']['pin_memory']=False
    cfg['runtime']['test_batch_size']=256
    cfg.setdefault('distributed', {})
    cfg['distributed']['enabled']=True
    cfg['distributed']['client_mode']='individual'
    cfg['distributed']['host']='127.0.0.1'
    cfg['distributed']['kgc_port']=9200
    cfg['distributed']['cs_port']=9300
    cfg['distributed']['client_base_port']=9400
    cfg.setdefault('communication', {})
    cfg['communication']['enabled']=True
    cfg['communication']['mode']='http'
    cfg['communication']['record_actual_time']=True
    cfg['communication']['timeout_seconds']=7200
    cfg.setdefault('blockchain', {})
    cfg['blockchain']['enabled']=True
    cfg['blockchain']['rpc_url']='http://127.0.0.1:8545'
    cfg['blockchain']['contract_json']='outputs/contract.json'
    cfg.setdefault('logging', {})
    cfg['logging']['verbose']=True
    cfg['logging']['save_trace']=True
    out=CONFIG_DIR/m['out_name']
    out.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding='utf-8')
    print('wrote', out)
    print('  base:', base.name)
    print('  output_dir:', m['output_dir'])
    print('  dataset: FashionMNIST iid=', m['iid'])
    print('  paillier_bits=2048 packing.enabled=True slot_bits=34 pack_size=auto')

def main():
    for k in ['fashion_iid','fashion_noniid']: make_one(k)
if __name__=='__main__': main()
