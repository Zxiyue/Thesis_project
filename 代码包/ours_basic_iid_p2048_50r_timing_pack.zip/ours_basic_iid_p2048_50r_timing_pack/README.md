# Ours-basic MNIST-IID 50r Paillier-2048 Timing Pack

本包用于运行：

```text
Ours-basic MNIST-IID 50r Paillier-2048 with CS timing
```

注意：这不是优化后的 Ours-packed，而是未打包 Ours-basic 2048-bit 对照组。它用于和已经完成的 Ours-packed MNIST-IID 50r 2048-bit `slot_bits=34, pack_size=auto` 直接比较，从而证明 packing 优化带来的时间、通信和 CS 解密组合开销下降。

## 使用步骤

上传并解压到 `/root`：

```bash
cd /root
unzip -o ours_basic_iid_p2048_50r_timing_pack.zip
```

确保 Hardhat 在另一个前台会话中运行：

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
npx hardhat node | tee /root/hardhat.log
```

在实验会话中前台运行：

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

stdbuf -oL -eL /root/ours_basic_iid_p2048_50r_timing_pack/scripts/run_ours_basic_iid_p2048_50r_timing.sh \
  | tee /root/ours_basic_mnist_iid_p2048_50r_timing_front.log
```

另开窗口查看状态：

```bash
/root/ours_basic_iid_p2048_50r_timing_pack/scripts/check_ours_basic_iid_p2048_status.sh
```

完成后结果包：

```text
/root/ours_basic_mnist_iid_50r_p2048_with_cs_timing_results.zip
```

预计耗时：18–22 小时，建议放夜间运行。
