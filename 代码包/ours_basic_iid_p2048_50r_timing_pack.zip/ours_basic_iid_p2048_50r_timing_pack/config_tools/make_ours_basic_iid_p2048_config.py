#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import yaml

ROOT = Path('/root/fpa5')
TARGET = ROOT / 'configs/ours_basic_mnist_iid_50r_lr020_p2048_final.yaml'
OUTDIR = 'outputs/ours_basic_mnist_iid_50r_lr020_p2048_final'
BASE_CANDIDATES = [
    ROOT / 'configs/ours_basic_mnist_iid_50r_lr020_p2048_final.yaml',
    ROOT / 'configs/mnist_iid_50r_lr020_main.yaml',
    ROOT / 'configs/mnist_iid_50r_main.yaml',
    ROOT / 'configs/ours_basic_mnist_iid_50r_lr020_p1024_final.yaml',
    ROOT / 'configs/mnist_iid_distributed.yaml',
]

def deep_set(d: dict, path: list[str], value):
    cur = d
    for k in path[:-1]:
        nxt = cur.get(k)
        if not isinstance(nxt, dict):
            nxt = {}
            cur[k] = nxt
        cur = nxt
    cur[path[-1]] = value

def main() -> None:
    src = next((p for p in BASE_CANDIDATES if p.exists()), None)
    if src is None:
        raise FileNotFoundError('No base config found under /root/fpa5/configs')
    cfg = yaml.safe_load(src.read_text()) or {}

    cfg['output_dir'] = OUTDIR
    deep_set(cfg, ['federated', 'rounds'], 50)
    deep_set(cfg, ['federated', 'local_lr'], 0.20)
    deep_set(cfg, ['federated', 'server_lr'], 1.0)
    deep_set(cfg, ['crypto', 'paillier_bits'], 2048)

    # This experiment is Ours-basic, not Ours-packed. Disable packing explicitly.
    deep_set(cfg, ['crypto', 'packing', 'enabled'], False)
    deep_set(cfg, ['crypto', 'packing', 'slot_bits'], None)
    deep_set(cfg, ['crypto', 'packing', 'pack_size'], None)

    # Real distributed HTTP route.
    deep_set(cfg, ['runtime', 'parallel_clients'], True)
    deep_set(cfg, ['runtime', 'max_client_workers'], 5)
    deep_set(cfg, ['distributed', 'enabled'], True)
    deep_set(cfg, ['distributed', 'client_mode'], 'individual')
    deep_set(cfg, ['communication', 'enabled'], True)
    deep_set(cfg, ['communication', 'mode'], 'http')
    deep_set(cfg, ['communication', 'timeout_seconds'], 7200)

    TARGET.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True))
    print(f'[OK] wrote {TARGET}')
    print(f'  base: {src}')
    print(f'  output_dir: {OUTDIR}')
    print('  rounds: 50')
    print('  paillier_bits: 2048')
    print('  packing.enabled: false')

if __name__ == '__main__':
    main()
