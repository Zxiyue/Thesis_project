#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:${PYTHONPATH:-}

PKG=/root/ours_basic_iid_p2048_50r_timing_pack
CFG="configs/ours_basic_mnist_iid_50r_lr020_p2048_final.yaml"
NAME="ours_basic_mnist_iid_50r_lr020_p2048_final"
OUTDIR="outputs/${NAME}"
ROUNDS=50
LOG="/root/ours_basic_mnist_iid_p2048_50r_timing.log"

check_hardhat() {
  curl -s -X POST http://127.0.0.1:8545 \
    -H "Content-Type: application/json" \
    --data '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' | grep -q '"result"'
}

stop_entities() {
  python3 scripts/stop_all_entities.py --config "${CFG}" || true
  pkill -f "run_kgc_server.py" || true
  pkill -f "run_cs_server.py" || true
  pkill -f "run_client_server.py" || true
  pkill -f "start_experiment.py" || true
  sleep 3
}

{
  echo "================================================================"
  echo "[RUN] Ours-basic MNIST-IID 50r Paillier-2048 with CS timing"
  echo "[NOTE] This is the un-packed Ours-basic baseline, used to compare against Ours-packed."
  echo "[CFG] ${CFG}"
  echo "[OUTDIR] ${OUTDIR}"
  echo "================================================================"

  echo "[STEP] Generate/normalize config"
  python3 "${PKG}/config_tools/make_ours_basic_iid_p2048_config.py" || exit 1

  echo "[STEP] Preflight"
  python3 "${PKG}/scripts/preflight_ours_basic_iid_p2048.py" || exit 1

  if ! check_hardhat; then
    echo "[ERROR] Hardhat is not reachable at http://127.0.0.1:8545"
    echo "Start it in another foreground tmux/session:"
    echo "  cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && npx hardhat node | tee /root/hardhat.log"
    exit 1
  fi
  echo "[OK] Hardhat reachable"

  echo "[STEP] Stop previous entities"
  stop_entities

  if [ -d "${OUTDIR}" ]; then
    BACKUP="${OUTDIR}_backup_$(date +%Y%m%d_%H%M%S)"
    echo "[WARN] ${OUTDIR} exists. Moving to ${BACKUP}"
    mv "${OUTDIR}" "${BACKUP}"
  fi

  echo "[STEP] Deploy audit board contract"
  npx hardhat run scripts/deploy.js --network localhost || exit 1

  echo "[STEP] Start KGC/CS/clients"
  python3 scripts/start_all_entities.py --config "${CFG}" --clients 5 || exit 1

  START_TS=$(date +%s)
  echo "[STEP] Start experiment"
  python3 scripts/start_experiment.py --config "${CFG}" || echo "[WARN] start_experiment returned non-zero; continue polling."

  DONE=0
  MAX_POLL=${MAX_POLL:-2400}  # 2400*60s = 40h
  for i in $(seq 1 "${MAX_POLL}"); do
    echo
    echo "---- $(date '+%F %T') ${NAME} status ${i}/${MAX_POLL} ----"
    tail -n 8 "${OUTDIR}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
    cat "${OUTDIR}/verify_result.csv" 2>/dev/null || echo "verify not ready"

    if [ -f "${OUTDIR}/verify_result.csv" ] && grep -q "True,${ROUNDS}" "${OUTDIR}/verify_result.csv"; then
      DONE=1
      echo "[OK] ${NAME} accepted=True rounds=${ROUNDS}"
      break
    fi
    sleep 60
  done

  echo "[STEP] Collect results"
  python3 scripts/collect_results.py --config "${CFG}" || true

  echo "[STEP] Stop entities"
  stop_entities

  END_TS=$(date +%s)
  echo "[INFO] elapsed_seconds=$((END_TS-START_TS))"

  if [ "${DONE}" -ne 1 ]; then
    echo "[ERROR] experiment did not finish correctly"
    zip -qr "/root/${NAME}_partial_results.zip" "${OUTDIR}" "${LOG}" 2>/dev/null || true
    exit 1
  fi

  echo "[STEP] Summarize CS timing"
  if [ -f /root/cs_timing_patch_pack/scripts/summarize_cs_timing.py ]; then
    python3 /root/cs_timing_patch_pack/scripts/summarize_cs_timing.py "${OUTDIR}" \
      | tee /root/cs_timing_summary_ours_basic_mnist_iid_p2048.csv || true
  else
    echo "[WARN] summarize_cs_timing.py not found; skip CS timing summary"
  fi

  echo "[STEP] Zip final results"
  cd /root/fpa5
  zip -qr /root/ours_basic_mnist_iid_50r_p2048_with_cs_timing_results.zip \
    "${OUTDIR}" \
    /root/cs_timing_summary_ours_basic_mnist_iid_p2048.csv \
    "${LOG}" 2>/dev/null || \
  zip -qr /root/ours_basic_mnist_iid_50r_p2048_with_cs_timing_results.zip "${OUTDIR}"

  ls -lh /root/ours_basic_mnist_iid_50r_p2048_with_cs_timing_results.zip
  echo "[DONE] /root/ours_basic_mnist_iid_50r_p2048_with_cs_timing_results.zip"
} 2>&1 | tee "${LOG}"
