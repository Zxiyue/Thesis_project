#!/usr/bin/env bash
set -uo pipefail
cd /root/fpa5
D=outputs/ours_basic_mnist_iid_50r_lr020_p2048_final

echo "================ ${D} ================"
ls -lah "$D" 2>/dev/null || { echo "not created"; exit 0; }

echo "--- metrics tail ---"
tail -n 12 "$D/metrics_round.csv" 2>/dev/null || true

echo "--- verify ---"
cat "$D/verify_result.csv" 2>/dev/null || true

echo "--- runtime stage sum ---"
python3 - <<'PY' 2>/dev/null || true
import pandas as pd
p='outputs/ours_basic_mnist_iid_50r_lr020_p2048_final/runtime_cost.csv'
df=pd.read_csv(p)
print(df.groupby('stage')['seconds'].sum().sort_values(ascending=False).head(20).to_string())
PY

echo "--- cs timing summary if fields exist ---"
python3 - <<'PY' 2>/dev/null || true
import pandas as pd
p='outputs/ours_basic_mnist_iid_50r_lr020_p2048_final/runtime_cost.csv'
df=pd.read_csv(p)
for s in ['cs_decrypt_combine','cs_unpack_vector','cs_decode_aggregate','cs_model_update']:
    sub=df[df.stage==s]
    if len(sub):
        print(f'{s}: total={sub.seconds.sum():.6f}s avg_per_round={sub.seconds.mean():.6f}s count={len(sub)}')
PY

echo "--- communication summary ---"
python3 - <<'PY' 2>/dev/null || true
import pandas as pd
p='outputs/ours_basic_mnist_iid_50r_lr020_p2048_final/communication_summary_by_type.csv'
df=pd.read_csv(p)
print('total_MB=', float(df['total_MB'].sum()))
print(df[['payload_type','count','total_MB']].sort_values('total_MB', ascending=False).head(10).to_string(index=False))
PY

echo "--- result zip ---"
ls -lh /root/ours_basic_mnist_iid_50r_p2048_with_cs_timing_results.zip 2>/dev/null || true
