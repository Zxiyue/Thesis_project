#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import sys, yaml
ROOT = Path('/root/fpa5')
CFG = ROOT / 'configs/ours_basic_mnist_iid_50r_lr020_p2048_final.yaml'

def fail(msg: str):
    print('[FAIL]', msg)
    sys.exit(1)

def ok(msg: str):
    print('[OK]', msg)

def main() -> None:
    if not CFG.exists():
        fail(f'config missing: {CFG}')
    cfg = yaml.safe_load(CFG.read_text()) or {}
    if cfg.get('output_dir') != 'outputs/ours_basic_mnist_iid_50r_lr020_p2048_final':
        fail('unexpected output_dir')
    if int(cfg.get('federated', {}).get('rounds', -1)) != 50:
        fail('rounds is not 50')
    if int(cfg.get('crypto', {}).get('paillier_bits', -1)) != 2048:
        fail('paillier_bits is not 2048')
    packing = cfg.get('crypto', {}).get('packing', {}) or {}
    if bool(packing.get('enabled', False)):
        fail('packing.enabled is true; this must be Ours-basic with packing disabled')
    ok('config is Ours-basic MNIST-IID 50r Paillier-2048 with packing disabled')

    cs = ROOT / 'scripts/run_cs_server.py'
    if not cs.exists():
        fail('scripts/run_cs_server.py not found')
    text = cs.read_text()
    fields = ['cs_decrypt_combine', 'cs_unpack_vector', 'cs_decode_aggregate', 'cs_model_update']
    missing = [f for f in fields if f not in text]
    if missing:
        fail('CS timing patch missing fields: ' + ', '.join(missing))
    ok('CS timing patch fields found')

if __name__ == '__main__':
    main()
