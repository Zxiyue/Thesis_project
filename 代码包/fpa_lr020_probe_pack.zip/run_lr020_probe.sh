#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

CONFIGS=(
  "configs/fashion_mnist_noniid_50r_lr020_nodrop.yaml"
  "configs/fashion_mnist_noniid_50r_lr020_dropout.yaml"
)
NAMES=(
  "fashion_mnist_noniid_50r_lr020_nodrop"
  "fashion_mnist_noniid_50r_lr020_dropout"
)

run_one() {
  local cfg="$1"
  local name="$2"
  echo "================================================================"
  echo "Running ${name}"
  echo "Config: ${cfg}"
  echo "Fashion-MNIST Non-IID, local_lr=0.20, server_lr=1.0, 50 rounds"
  echo "================================================================"

  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  pkill -f "run_kgc_server.py" || true
  pkill -f "run_cs_server.py" || true
  pkill -f "run_client_server.py" || true
  pkill -f "start_experiment.py" || true
  sleep 3

  rm -rf "outputs/${name}"

  echo "[INFO] Deploying audit board contract..."
  npx hardhat run scripts/deploy.js --network localhost || { echo "[ERROR] deploy failed. Is Hardhat node running?"; exit 1; }

  echo "[INFO] Starting KGC/CS/clients..."
  python3 scripts/start_all_entities.py --config "${cfg}" --clients 5 || { echo "[ERROR] start_all_entities failed"; exit 1; }

  echo "[INFO] Starting experiment..."
  python3 scripts/start_experiment.py --config "${cfg}" || echo "[WARN] start_experiment returned non-zero; continue polling."

  local done_flag=0
  for i in $(seq 1 360); do
    if [ -f "outputs/${name}/verify_result.csv" ] && grep -q "True,50" "outputs/${name}/verify_result.csv"; then
      done_flag=1
      echo "[INFO] ${name} accepted=True rounds=50"
      break
    fi
    echo "---- $(date) ${name} status ----"
    tail -n 5 "outputs/${name}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
    cat "outputs/${name}/verify_result.csv" 2>/dev/null || echo "verify not ready"
    sleep 30
  done

  if [ "${done_flag}" -ne 1 ]; then
    echo "[ERROR] ${name} did not finish within polling window."
    python3 scripts/stop_all_entities.py --config "${cfg}" || true
    exit 1
  fi

  python3 scripts/collect_results.py --config "${cfg}" || true
  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  zip -r "/root/${name}_results.zip" "outputs/${name}"
  echo "[INFO] Result zip: /root/${name}_results.zip"
}

for idx in "${!CONFIGS[@]}"; do
  run_one "${CONFIGS[$idx]}" "${NAMES[$idx]}"
done

cd /root
zip -r /root/fashion_mnist_noniid_lr020_probe_results.zip \
  /root/fashion_mnist_noniid_50r_lr020_nodrop_results.zip \
  /root/fashion_mnist_noniid_50r_lr020_dropout_results.zip

echo "Probe experiments finished: /root/fashion_mnist_noniid_lr020_probe_results.zip"
