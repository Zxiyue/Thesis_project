# CIFAR-10 与学习率敏感性实验补丁说明

本补丁用于在现有 `/root/fpa5` 项目中增加：

1. CIFAR-10-IID 50 轮主实验；
2. CIFAR-10-Non-IID 50 轮主实验；
3. `server_lr` 敏感性实验，10 组，30 轮，不设置掉线；
4. `local_lr` 敏感性实验，6 组，30 轮，不设置掉线。

## 1. 文件作用

补丁会覆盖或新增以下文件：

```text
fl_audit/data.py                         # 增加 CIFAR10 数据集加载
fl_audit/model.py                        # 增加 tiny_cnn_cifar10 / small_cnn_cifar10
scripts/check_dataset_loader.py          # 支持检查 CIFAR10 和敏感性配置
scripts/check_model_dims.py              # 检查模型参数维度
scripts/generate_cifar10_sensitivity_configs.py
configs/cifar10_iid_50r_main.yaml
configs/cifar10_noniid_50r_main.yaml
configs/sensitivity_server_lr_*.yaml
configs/sensitivity_local_lr_*.yaml
run_cifar10_main.sh
run_server_lr_sensitivity.sh
run_local_lr_sensitivity.sh
run_all_cifar10_sensitivity.sh
```

## 2. 实验设置

### CIFAR-10 主实验

```text
CIFAR-10-IID: 50 rounds
CIFAR-10-Non-IID: 50 rounds
model: tiny_cnn_cifar10
local_lr: 0.05
server_lr: 1.0
dropout: 第10轮 C2，第25轮 C4
```

`tiny_cnn_cifar10` 参数维度约为 8786，比 MNIST/Fashion-MNIST 的 `tiny_cnn` 6794 略大，能控制 Paillier 和 Pedersen 开销。

### server_lr 敏感性实验

```text
dataset: FashionMNIST-Non-IID
rounds: 30
local_lr: 0.05
server_lr: 0.2, 0.4, ..., 2.0
dropout: {}
```

### local_lr 敏感性实验

```text
dataset: FashionMNIST-Non-IID
rounds: 30
server_lr: 1.0
local_lr: 0.01, 0.03, 0.05, 0.07, 0.09, 0.10
dropout: {}
```

注意：敏感性实验没有掉线设置，配置中统一为：

```yaml
dropout: {}
```

## 3. 在服务器上应用补丁

将 `fpa_cifar10_sensitivity_pack.zip` 上传到服务器 `/root/fpa5`，然后执行：

```bash
cd /root/fpa5
unzip -o /root/fpa5/fpa_cifar10_sensitivity_pack.zip -d /root/fpa5
chmod +x run_*.sh
```

如果上传到了 `/root`，则执行：

```bash
cd /root/fpa5
unzip -o /root/fpa_cifar10_sensitivity_pack.zip -d /root/fpa5
chmod +x run_*.sh
```

## 4. 准备数据集

```bash
cd /root/fpa5
mkdir -p /root/fpa5/data
cp -rn /public/torchvision_datasets/MNIST /root/fpa5/data/ 2>/dev/null || true
cp -rn /public/torchvision_datasets/FashionMNIST /root/fpa5/data/ 2>/dev/null || true
cp -rn /public/torchvision_datasets/CIFAR10 /root/fpa5/data/ 2>/dev/null || true
cp -rn /public/torchvision_datasets/cifar-10-batches-py /root/fpa5/data/ 2>/dev/null || true
find /root/fpa5/data -maxdepth 2 -type d | sort | head -n 30
```

若公共目录没有 CIFAR-10，可临时把两个 CIFAR 配置中的 `download: false` 改为 `download: true`，但这依赖服务器能访问 torchvision 数据源。

## 5. 运行前检查

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

python3 scripts/check_model_dims.py
python3 scripts/check_dataset_loader.py --configs \
  configs/cifar10_iid_50r_main.yaml \
  configs/cifar10_noniid_50r_main.yaml \
  configs/sensitivity_server_lr_1_0.yaml \
  configs/sensitivity_local_lr_0_05.yaml
```

需要看到 CIFAR 配置实际加载为 `CIFAR10`，Fashion 敏感性配置实际加载为 `FashionMNIST`。

## 6. 启动 Hardhat

```bash
tmux new -d -s hardhat "cd /root/fpa5 && source .venv/bin/activate && export PYTHONPATH=/root/fpa5:\$PYTHONPATH && npx hardhat node > /root/hardhat.log 2>&1"
sleep 5
tail -n 20 /root/hardhat.log
```

## 7. 运行实验

只跑 CIFAR-10 主实验：

```bash
tmux new -s cifar10
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_cifar10_main.sh
```

只跑 server_lr 敏感性实验：

```bash
tmux new -s serverlr
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_server_lr_sensitivity.sh
```

只跑 local_lr 敏感性实验：

```bash
tmux new -s locallr
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_local_lr_sensitivity.sh
```

全部依次运行：

```bash
tmux new -s cifar_sens
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_all_cifar10_sensitivity.sh
```

## 8. 结果包

运行完成后，结果会放在：

```text
/root/cifar10_main_results.zip
/root/server_lr_sensitivity_results.zip
/root/local_lr_sensitivity_results.zip
/root/cifar10_and_sensitivity_all_results.zip
```

下载结果包后再释放服务器。
