from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fl_audit.model import get_vector, make_model

for name in ["tiny_cnn", "small_cnn", "tiny_cnn_cifar10", "small_cnn_cifar10"]:
    m = make_model(name)
    print(f"{name}: dim={get_vector(m).numel()}")
