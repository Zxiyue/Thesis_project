from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs"
CONFIG_DIR.mkdir(exist_ok=True)

COMMON_TAIL = """
encoding:
  scale: 10000
  q: 1000000007

crypto:
  paillier_bits: 512
  pedersen_prime_bits: 521
  pedersen_window: 0

blockchain:
  enabled: true
  rpc_url: http://127.0.0.1:8545
  contract_json: outputs/contract.json

communication:
  enabled: true
  mode: http
  record_actual_time: true
  timeout_seconds: 1800

distributed:
  enabled: true
  client_mode: individual
  host: 127.0.0.1
  kgc_port: 9200
  cs_port: 9300
  client_base_port: 9400

logging:
  verbose: true
  save_trace: true

runtime:
  device: cpu
  parallel_clients: true
  max_client_workers: 5
  num_workers: 0
  pin_memory: false
  test_batch_size: 256
""".lstrip()


def write(path: str, text: str) -> None:
    p = CONFIG_DIR / path
    p.write_text(text.strip() + "\n", encoding="utf-8")
    print(f"written {p}")


def cifar_config(name: str, iid: bool) -> str:
    return f"""
seed: 20260627
output_dir: outputs/{name}

dataset:
  name: CIFAR10
  data_dir: /root/fpa5/data
  iid: {str(iid).lower()}
  shards_per_client: 2
  download: false

federated:
  clients: 5
  rounds: 50
  threshold: 3
  local_epochs: 1
  batch_size: 64
  local_lr: 0.05
  server_lr: 1.0
  dropout:
    10: [2]
    25: [4]

model:
  name: tiny_cnn_cifar10

{COMMON_TAIL}
"""


def sensitivity_config(name: str, server_lr: str, local_lr: str) -> str:
    return f"""
seed: 20260627
output_dir: outputs/{name}

dataset:
  name: FashionMNIST
  data_dir: /root/fpa5/data
  iid: false
  shards_per_client: 2
  download: false

federated:
  clients: 5
  rounds: 30
  threshold: 3
  local_epochs: 1
  batch_size: 64
  local_lr: {local_lr}
  server_lr: {server_lr}
  dropout: {{}}

model:
  name: tiny_cnn

{COMMON_TAIL}
"""


def main() -> None:
    write("cifar10_iid_50r_main.yaml", cifar_config("cifar10_iid_50r_main", iid=True))
    write("cifar10_noniid_50r_main.yaml", cifar_config("cifar10_noniid_50r_main", iid=False))

    for v in ["0.2", "0.4", "0.6", "0.8", "1.0", "1.2", "1.4", "1.6", "1.8", "2.0"]:
        tag = v.replace(".", "_")
        write(
            f"sensitivity_server_lr_{tag}.yaml",
            sensitivity_config(f"sensitivity_server_lr_{tag}", server_lr=v, local_lr="0.05"),
        )

    for v in ["0.01", "0.03", "0.05", "0.07", "0.09", "0.10"]:
        tag = v.replace(".", "_")
        write(
            f"sensitivity_local_lr_{tag}.yaml",
            sensitivity_config(f"sensitivity_local_lr_{tag}", server_lr="1.0", local_lr=v),
        )


if __name__ == "__main__":
    main()
