#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

./run_cifar10_main.sh
./run_server_lr_sensitivity.sh
./run_local_lr_sensitivity.sh

cd /root
zip -r /root/cifar10_and_sensitivity_all_results.zip \
  /root/cifar10_main_results.zip \
  /root/server_lr_sensitivity_results.zip \
  /root/local_lr_sensitivity_results.zip

echo "All CIFAR-10 and sensitivity experiments finished."
echo "Combined result: /root/cifar10_and_sensitivity_all_results.zip"
