#!/usr/bin/env bash
set -euo pipefail
FPA5_DIR="${FPA5_DIR:-/root/fpa5}"
echo "==== PriVeriFL-A 50r running processes ===="
ps -eo pid,etime,pcpu,pmem,cmd | grep -E 'run_priverifl_a_mnist_50r|run_repro_baseline.py|baseline_repro_priverifl_a_mnist' | grep -v grep || true
echo
echo "==== Output progress ===="
for name in iid noniid; do
  d="$FPA5_DIR/outputs/baseline_repro_priverifl_a_mnist_${name}_50r_p2048_lr020"
  echo "---- $name ----"
  if [[ -f "$d/metrics_round.csv" ]]; then
    rows=$(($(wc -l < "$d/metrics_round.csv")-1))
    echo "metrics rows: $rows (contains round 0, target 51 rows incl. header)"
    tail -n 3 "$d/metrics_round.csv" || true
  else
    echo "metrics not found: $d/metrics_round.csv"
  fi
  if [[ -f "$d/verify_result.csv" ]]; then
    echo "verify:"; cat "$d/verify_result.csv"
  fi
  if [[ -f "/root/priverifl_a_mnist_${name}_50r_p2048_lr020.log" ]]; then
    echo "last log lines:"; tail -n 5 "/root/priverifl_a_mnist_${name}_50r_p2048_lr020.log"
  fi
  echo
done
