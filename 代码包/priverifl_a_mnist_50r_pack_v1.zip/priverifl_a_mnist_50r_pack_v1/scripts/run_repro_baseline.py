from __future__ import annotations

import argparse

from fl_audit.baselines.common import load_yaml
from fl_audit.baselines.priverifl_a_repro import run_priverifl_a_repro


def main() -> None:
    ap = argparse.ArgumentParser(description="Run PriVeriFL-A paper-faithful reproduction baseline")
    ap.add_argument("--config", required=True, help="YAML config path")
    args = ap.parse_args()
    cfg = load_yaml(args.config)
    scheme = str(((cfg.get("baseline", {}) or {}).get("scheme", ""))).lower()
    if scheme not in {"priverifl_a_repro", "priverifl-a-repro", "priverifl_a", "priverifl-a"}:
        raise SystemExit(f"Unsupported baseline.scheme={scheme!r}; this pack only runs PriVeriFL-A reproduction")
    res = run_priverifl_a_repro(cfg)
    print(res)


if __name__ == "__main__":
    main()
