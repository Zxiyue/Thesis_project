#!/usr/bin/env bash
set -euo pipefail
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FPA5_DIR="${FPA5_DIR:-/root/fpa5}"
bash "$PACK_DIR/install_priverifl_a_mnist_50r.sh"
cd "$FPA5_DIR"
if [[ -f .venv/bin/activate ]]; then source .venv/bin/activate; fi
export PYTHONPATH="$FPA5_DIR:${PYTHONPATH:-}"
DATASETS="${DATASETS:-iid noniid}"
CLEAN_OUTPUT="${CLEAN_OUTPUT:-1}"
run_one() {
  local name="$1"
  local cfg="configs/baseline_repro_priverifl_a_mnist_${name}_50r_p2048_lr020.yaml"
  local out="outputs/baseline_repro_priverifl_a_mnist_${name}_50r_p2048_lr020"
  local log="/root/priverifl_a_mnist_${name}_50r_p2048_lr020.log"
  if [[ "$CLEAN_OUTPUT" == "1" ]]; then rm -rf "$out"; fi
  echo "[RUN] PriVeriFL-A MNIST-${name} 50r p2048 lr020 -> $out"
  stdbuf -oL -eL python3 scripts/run_repro_baseline.py --config "$cfg" 2>&1 | tee "$log"
  echo "[DONE] $name"
}
for ds in $DATASETS; do run_one "$ds"; done
bash "$FPA5_DIR/tools/zip_priverifl_a_mnist_50r_results.sh"
