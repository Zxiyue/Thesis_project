# PriVeriFL-A MNIST-IID / Non-IID 50轮执行包

用途：在已有 `/root/fpa5` 环境中补跑 PriVeriFL-A reproduction baseline 的 MNIST-IID 与 MNIST-Non-IID 2048-bit Paillier 50轮实验。

本包是本地 reproduction baseline，不需要 Hardhat，不是 KGC/CS/Clients 独立 HTTP 服务版。它用于论文主表中的真实 baseline 对比：训练数据为真实 MNIST，模型为 tiny_cnn，客户端数为 5，轮次为 50，local_lr=0.20，server_lr=1.0，Paillier=2048-bit。

## 快速运行

```bash
cd /root
unzip -o priverifl_a_mnist_50r_pack_v1.zip
cd /root/priverifl_a_mnist_50r_pack_v1

# 可选：先 smoke 2轮
stdbuf -oL -eL bash scripts/run_priverifl_a_mnist_smoke_2r.sh | tee /root/priverifl_a_mnist_smoke_2r_pack_v1.log

# 正式跑 IID + Non-IID 50轮
stdbuf -oL -eL bash scripts/run_priverifl_a_mnist_50r.sh | tee /root/priverifl_a_mnist_50r_pack_v1.log
```

只跑其中一个数据划分：

```bash
DATASETS="iid" bash scripts/run_priverifl_a_mnist_50r.sh
DATASETS="noniid" bash scripts/run_priverifl_a_mnist_50r.sh
```

查看进度：

```bash
bash scripts/check_priverifl_a_mnist_50r_status.sh
```

汇总结果：

```bash
cd /root/fpa5
python3 tools/analyze_priverifl_a_mnist_50r_results.py /root/fpa5/outputs | tee /root/priverifl_a_mnist_p2048_50r_summary.csv
```

打包结果：

```bash
bash /root/fpa5/tools/zip_priverifl_a_mnist_50r_results.sh
```

最终结果包：

```text
/root/priverifl_a_mnist_p2048_50r_results.zip
```

## 输出目录

```text
/root/fpa5/outputs/baseline_repro_priverifl_a_mnist_iid_50r_p2048_lr020
/root/fpa5/outputs/baseline_repro_priverifl_a_mnist_noniid_50r_p2048_lr020
```

每个目录包括：

- `metrics_round.csv`：每轮准确率、loss、有效客户端数。
- `runtime_cost.csv`：训练、Paillier packed encryption、AES、homomorphic hash、聚合、解密验证等分阶段时间。
- `communication_cost.csv` / `communication_summary_by_type.csv`：估算通信开销。
- `crypto_cost.csv`：Paillier bits、slot_bits、pack_size、加密数等。
- `verify_result.csv`：accepted、rounds、latestAuditRoot。
- `run_trace.json`：完整运行配置与轮次轨迹。

## 运行建议

50轮比 2轮 smoke 明显更久，建议在 `tmux` 中运行：

```bash
tmux new -s priverifl50
cd /root/priverifl_a_mnist_50r_pack_v1
stdbuf -oL -eL bash scripts/run_priverifl_a_mnist_50r.sh | tee /root/priverifl_a_mnist_50r_pack_v1.log
```

断开后重新进入：

```bash
tmux attach -t priverifl50
```
