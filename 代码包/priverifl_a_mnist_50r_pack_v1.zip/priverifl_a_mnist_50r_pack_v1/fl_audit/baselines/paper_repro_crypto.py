from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import random
from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Dict, Iterable, List, Sequence, Tuple

import numpy as np

from fl_audit.crypto import paillier
from fl_audit.crypto.number import invmod
from fl_audit.utils.codec import bytes32_hex, canonical_bytes

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except Exception:  # pragma: no cover
    AESGCM = None


# ---------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------

def b64e(x: bytes) -> str:
    return base64.b64encode(x).decode("ascii")


def b64d(x: str) -> bytes:
    return base64.b64decode(x.encode("ascii"))


def mod_pow_signed(base: int, exp: int, mod: int) -> int:
    exp = int(exp)
    if exp >= 0:
        return pow(int(base), exp, int(mod))
    return pow(invmod(int(base) % int(mod), int(mod)), -exp, int(mod))


# ---------------------------------------------------------------------------
# PriVeriFL-A: decimal sensitivity segmentation + BatchCrypt-style packing
# ---------------------------------------------------------------------------

def quantize_decimal(vec: np.ndarray, decimal_scale: int) -> np.ndarray:
    return np.rint(vec.astype(np.float64) * int(decimal_scale)).astype(object)


def split_decimal_sensitive(x_scaled: np.ndarray, *, decimal_digits: int = 8, sensitive_digits: int = 2) -> Tuple[np.ndarray, np.ndarray]:
    """Split paper-style decimal sensitive digits.

    PriVeriFL-A first multiplies model parameters by 10^8, then extracts the
    first t decimal places as A and sets those extracted places to 0 in B.  For
    t=2 and decimal_digits=8, x=0.07327445 is represented as 7327445 and split
    as A=7000000, B=327445.  Negative values are truncated toward zero so that
    -0.06269688 becomes A=-6000000 and B=-269688.
    """
    base = 10 ** (int(decimal_digits) - int(sensitive_digits))
    a_vals: List[int] = []
    b_vals: List[int] = []
    for v in x_scaled.reshape(-1).tolist():
        iv = int(v)
        q_abs = abs(iv) // base
        q = q_abs if iv >= 0 else -q_abs
        a = q * base
        b = iv - a
        a_vals.append(int(a))
        b_vals.append(int(b))
    return np.array(a_vals, dtype=object), np.array(b_vals, dtype=object)


def merge_decimal_segments(a_sum: np.ndarray, b_sum: np.ndarray) -> np.ndarray:
    return np.array([int(a) + int(b) for a, b in zip(a_sum.reshape(-1).tolist(), b_sum.reshape(-1).tolist())], dtype=object)


def signed_to_twos(v: int, bits: int) -> int:
    bits = int(bits)
    lo, hi = -(1 << (bits - 1)), (1 << (bits - 1)) - 1
    iv = int(v)
    if iv < lo or iv > hi:
        raise OverflowError(f"value {iv} does not fit in signed {bits}-bit payload")
    return iv if iv >= 0 else (1 << bits) + iv


def twos_to_signed(v: int, bits: int) -> int:
    bits = int(bits)
    iv = int(v) & ((1 << bits) - 1)
    if iv >= (1 << (bits - 1)):
        return iv - (1 << bits)
    return iv


def choose_signed_payload_and_slot_bits(values_bound: int, total_weight: int, *, min_payload_bits: int = 34, payload_guard_bits: int = 2, padding_guard_bits: int = 2) -> Tuple[int, int]:
    """Choose BatchCrypt-style payload and slot widths.

    Each slot is [padding | two's-complement payload].  The payload must hold
    the final weighted signed sum; the padding absorbs carries created by adding
    or scalar-multiplying two's-complement encoded negative payloads, preventing
    them from spilling into the next packed slot.
    """
    bound = max(1, int(values_bound)) * max(1, int(total_weight))
    payload_bits = max(int(min_payload_bits), int(math.ceil(math.log2(bound + 1))) + 1 + int(payload_guard_bits))
    padding_bits = int(math.ceil(math.log2(max(2, int(total_weight) + 1)))) + int(padding_guard_bits)
    slot_bits = payload_bits + padding_bits
    return int(payload_bits), int(slot_bits)


def choose_signed_slot_bits(values_bound: int, total_weight: int, min_slot_bits: int = 34, extra_guard_bits: int = 2) -> int:
    # Backward-compatible wrapper.  Returns a safe full slot width.
    _payload, slot = choose_signed_payload_and_slot_bits(values_bound, total_weight, min_payload_bits=min_slot_bits, payload_guard_bits=extra_guard_bits)
    return slot


def choose_pack_size(n_bits: int, slot_bits: int, requested_pack_size: int | str = "auto") -> int:
    cap = max(1, (int(n_bits) - 2) // int(slot_bits))
    if str(requested_pack_size).lower() == "auto":
        return cap
    return max(1, min(int(requested_pack_size), cap))


def pack_signed_slots(values: Sequence[int], payload_bits: int, slot_bits: int) -> int:
    if int(payload_bits) >= int(slot_bits):
        raise ValueError("payload_bits must be smaller than slot_bits so padding can absorb carries")
    out = 0
    shift = 0
    payload_mask = (1 << int(payload_bits)) - 1
    for v in values:
        enc = signed_to_twos(int(v), int(payload_bits)) & payload_mask
        out |= enc << shift
        shift += int(slot_bits)
    return int(out)


def unpack_signed_slots(packed: int, count: int, payload_bits: int, slot_bits: int) -> List[int]:
    payload_mask = (1 << int(payload_bits)) - 1
    cur = int(packed)
    out: List[int] = []
    for _ in range(int(count)):
        out.append(twos_to_signed(cur & payload_mask, int(payload_bits)))
        cur >>= int(slot_bits)
    return out


def pack_vector_signed(values: Sequence[int], payload_bits: int, slot_bits: int, pack_size: int) -> List[int]:
    vals = [int(v) for v in values]
    return [pack_signed_slots(vals[i:i + int(pack_size)], int(payload_bits), int(slot_bits)) for i in range(0, len(vals), int(pack_size))]


def unpack_vector_signed(packed_values: Sequence[int], total_count: int, payload_bits: int, slot_bits: int, pack_size: int) -> List[int]:
    out: List[int] = []
    remaining = int(total_count)
    for p in packed_values:
        c = min(int(pack_size), remaining)
        out.extend(unpack_signed_slots(int(p), c, int(payload_bits), int(slot_bits)))
        remaining -= c
        if remaining <= 0:
            break
    if len(out) != int(total_count):
        raise ValueError("unpacked vector length mismatch")
    return out


def encrypt_packed_signed_vector(pub: paillier.PaillierPublicKey, values: Sequence[int], payload_bits: int, slot_bits: int, pack_size: int) -> List[int]:
    return [paillier.encrypt(pub, m) for m in pack_vector_signed(values, payload_bits, slot_bits, pack_size)]


def aggregate_weighted_packed_ciphertexts(pub: paillier.PaillierPublicKey, encrypted_vectors: List[List[int]], weights: Sequence[int]) -> List[int]:
    if not encrypted_vectors:
        return []
    width = len(encrypted_vectors[0])
    out: List[int] = []
    for j in range(width):
        acc = 1
        for vec, w in zip(encrypted_vectors, weights):
            # PHE.Mul(c, w) followed by PHE.Add.
            acc = (acc * pow(int(vec[j]), int(w), pub.n2)) % pub.n2
        out.append(acc)
    return out


def decrypt_packed_signed_vector(pub: paillier.PaillierPublicKey, priv: paillier.PaillierPrivateKey, c_vec: Sequence[int], total_count: int, payload_bits: int, slot_bits: int, pack_size: int) -> np.ndarray:
    packed_plain = [paillier.decrypt(pub, priv, int(c)) for c in c_vec]
    vals = unpack_vector_signed(packed_plain, total_count=total_count, payload_bits=payload_bits, slot_bits=slot_bits, pack_size=pack_size)
    return np.array(vals, dtype=object)


@dataclass
class SymmetricCiphertext:
    nonce: str
    ciphertext: str
    aad_hash: str
    bytes_len: int

    def to_dict(self) -> Dict[str, Any]:
        return {"nonce": self.nonce, "ciphertext": self.ciphertext, "aad_hash": self.aad_hash, "bytes_len": self.bytes_len}


def aesgcm_encrypt_json(key: bytes, obj: Any, aad: Any) -> SymmetricCiphertext:
    if AESGCM is None:
        raise RuntimeError("cryptography is required for AES-GCM symmetric encryption")
    nonce = os.urandom(12)
    aad_b = canonical_bytes(aad)
    plain = canonical_bytes(obj)
    ct = AESGCM(key).encrypt(nonce, plain, aad_b)
    return SymmetricCiphertext(nonce=b64e(nonce), ciphertext=b64e(ct), aad_hash=bytes32_hex(aad), bytes_len=len(plain) + len(ct) + len(nonce))


def aesgcm_decrypt_json(key: bytes, ct: SymmetricCiphertext | Dict[str, Any], aad: Any) -> Any:
    if AESGCM is None:
        raise RuntimeError("cryptography is required for AES-GCM symmetric decryption")
    if isinstance(ct, dict):
        ct = SymmetricCiphertext(nonce=ct["nonce"], ciphertext=ct["ciphertext"], aad_hash=ct.get("aad_hash", ""), bytes_len=int(ct.get("bytes_len", 0)))
    plain = AESGCM(key).decrypt(b64d(ct.nonce), b64d(ct.ciphertext), canonical_bytes(aad))
    return json.loads(plain.decode("utf-8"))


class VectorHomomorphicHash:
    """PriVeriFL-A-style multiplicative homomorphic hash.

    H(x)=g^{sum_j a_j x_j mod q} mod p, so H(sum_i n_i x_i)=prod_i H(x_i)^{n_i}.
    It is an efficient exponent-compressed implementation of the vector HH API
    H.Hash/H.Eval used in the paper.
    """

    def __init__(self, dim: int, seed: int, prime_bits: int = 127):
        if int(prime_bits) <= 127:
            self.p = (1 << 127) - 1
        else:
            from fl_audit.crypto.number import gen_prime
            self.p = gen_prime(int(prime_bits))
        self.q = self.p - 1
        self.g = 3
        rng = random.Random(int(seed) + 24019)
        self.coeffs = np.array([rng.randrange(1, self.q) for _ in range(int(dim))], dtype=object)

    def exponent(self, x: np.ndarray) -> int:
        total = 0
        for a, v in zip(self.coeffs.tolist(), x.reshape(-1).tolist()):
            total = (total + int(a) * int(v)) % self.q
        return int(total)

    def digest(self, x: np.ndarray) -> int:
        return pow(self.g, self.exponent(x), self.p)

    def eval_weighted(self, digests: Sequence[int], weights: Sequence[int]) -> int:
        out = 1
        for h, w in zip(digests, weights):
            out = (out * pow(int(h), int(w), self.p)) % self.p
        return int(out)

    def verify_weighted_sum(self, x_sum: np.ndarray, digests: Sequence[int], weights: Sequence[int]) -> bool:
        return self.digest(x_sum) == self.eval_weighted(digests, weights)

    def public_params(self) -> Dict[str, str]:
        return {"p": str(self.p), "q": str(self.q), "g": str(self.g), "coeffHash": bytes32_hex([int(v) for v in self.coeffs.tolist()])}


# ---------------------------------------------------------------------------
# RTP-FL: product-matrix MBR regenerating code + paper-style decryption
# ---------------------------------------------------------------------------

def frac_matrix_inverse(A: List[List[int | Fraction]]) -> List[List[Fraction]]:
    n = len(A)
    M = [[Fraction(A[i][j]) for j in range(n)] + [Fraction(1 if i == j else 0) for j in range(n)] for i in range(n)]
    for col in range(n):
        pivot = None
        for row in range(col, n):
            if M[row][col] != 0:
                pivot = row
                break
        if pivot is None:
            raise ValueError("matrix is singular")
        if pivot != col:
            M[col], M[pivot] = M[pivot], M[col]
        div = M[col][col]
        M[col] = [x / div for x in M[col]]
        for row in range(n):
            if row == col:
                continue
            factor = M[row][col]
            if factor:
                M[row] = [a - factor * b for a, b in zip(M[row], M[col])]
    return [row[n:] for row in M]


def frac_mat_vec_mul(A: List[List[int | Fraction]], x: List[int | Fraction]) -> List[Fraction]:
    return [sum(Fraction(a) * Fraction(b) for a, b in zip(row, x)) for row in A]


def frac_lcm_denominators(M: List[List[Fraction]]) -> int:
    d = 1
    for row in M:
        for v in row:
            d = abs(d * v.denominator) // math.gcd(d, v.denominator)
    return int(d)


def vector_to_mbr_matrix(message: Sequence[int], k: int, d: int) -> List[List[int]]:
    """Map B=kd-k(k-1)/2 message symbols to product-matrix MBR matrix.

    M = [[S, T], [T^T, 0]], where S is k×k symmetric and T is k×(d-k).
    """
    k, d = int(k), int(d)
    vals = [int(v) for v in message]
    B = k * d - k * (k - 1) // 2
    if len(vals) != B:
        raise ValueError(f"message length {len(vals)} != B={B}")
    M = [[0 for _ in range(d)] for __ in range(d)]
    idx = 0
    for i in range(k):
        for j in range(i, k):
            M[i][j] = vals[idx]
            M[j][i] = vals[idx]
            idx += 1
    for i in range(k):
        for j in range(k, d):
            M[i][j] = vals[idx]
            M[j][i] = vals[idx]
            idx += 1
    return M


def mbr_matrix_to_vector(M: List[List[int | Fraction]], k: int, d: int) -> List[Fraction]:
    out: List[Fraction] = []
    for i in range(int(k)):
        for j in range(i, int(k)):
            out.append(Fraction(M[i][j]))
    for i in range(int(k)):
        for j in range(int(k), int(d)):
            out.append(Fraction(M[i][j]))
    return out


def make_psi(N: int, d: int) -> List[List[int]]:
    rows: List[List[int]] = []
    for i in range(1, int(N) + 1):
        rows.append([i ** j for j in range(int(d))])
    return rows


def encode_mbr_nodes(message: Sequence[int], N: int, k: int, d: int) -> Dict[int, List[int]]:
    M = vector_to_mbr_matrix(message, k, d)
    psi = make_psi(N, d)
    shares: Dict[int, List[int]] = {}
    for idx, row in enumerate(psi, start=1):
        shares[idx] = [sum(row[a] * M[a][b] for a in range(int(d))) for b in range(int(d))]
    return shares


def build_mbr_generator(N: int, k: int, d: int) -> List[List[int]]:
    B = int(k) * int(d) - int(k) * (int(k) - 1) // 2
    rows = [[0 for _ in range(int(N) * int(d))] for __ in range(B)]
    for m_idx in range(B):
        basis = [0] * B
        basis[m_idx] = 1
        shares = encode_mbr_nodes(basis, N, k, d)
        flat: List[int] = []
        for cid in range(1, int(N) + 1):
            flat.extend(shares[cid])
        for col, val in enumerate(flat):
            rows[m_idx][col] = int(val)
    return rows


def rank_fraction(A: List[List[int | Fraction]]) -> int:
    M = [[Fraction(x) for x in row] for row in A]
    if not M:
        return 0
    m, n = len(M), len(M[0])
    r = 0
    for c in range(n):
        pivot = None
        for i in range(r, m):
            if M[i][c] != 0:
                pivot = i
                break
        if pivot is None:
            continue
        M[r], M[pivot] = M[pivot], M[r]
        div = M[r][c]
        M[r] = [x / div for x in M[r]]
        for i in range(m):
            if i != r and M[i][c] != 0:
                factor = M[i][c]
                M[i] = [a - factor * b for a, b in zip(M[i], M[r])]
        r += 1
        if r == m:
            break
    return r


def select_independent_columns(G: List[List[int]], t: int) -> List[int]:
    selected: List[int] = []
    current: List[List[int]] = [[] for _ in range(t)]
    for col in range(len(G[0])):
        trial = [row + [G[i][col]] for i, row in enumerate(current)]
        if rank_fraction(trial) > rank_fraction(current):
            selected.append(col)
            current = trial
            if len(selected) == t:
                return selected
    raise ValueError("could not find enough independent columns")


def right_inverse_delta(G: List[List[int]], N: int, d: int) -> Tuple[List[List[int]], int, List[int]]:
    """Return integer R_delta with G*R_delta = Delta*I_t.

    R_delta has shape (N*d) × t.  Client i receives its d × t row block.
    """
    t = len(G)
    cols = select_independent_columns(G, t)
    A = [[G[i][c] for c in cols] for i in range(t)]
    A_inv = frac_matrix_inverse(A)
    Delta = frac_lcm_denominators(A_inv)
    R = [[0 for _ in range(t)] for __ in range(int(N) * int(d))]
    for local_row, col in enumerate(cols):
        for j in range(t):
            R[col][j] = int(A_inv[local_row][j] * Delta)
    return R, int(Delta), cols


@dataclass
class RTPFLCodeState:
    N: int
    k: int
    d: int
    t: int
    private_exp: int
    message: List[int]
    shares: Dict[int, List[int]]
    psi: List[List[int]]
    G: List[List[int]]
    R_delta: List[List[int]]
    Delta: int
    independent_columns: List[int]

    @classmethod
    def deal(cls, private_exp: int, N: int, k: int, d: int, seed: int = 0, random_bits: int = 96) -> "RTPFLCodeState":
        N, k, d = int(N), int(k), int(d)
        if d < k:
            raise ValueError("RTP-FL requires d >= k")
        if N < d:
            raise ValueError("RTP-FL requires N >= d")
        t = k * d - k * (k - 1) // 2
        rng = random.Random(int(seed) + 78233)
        # Sum of coefficients equals private_exp, following Algorithm 1 text.
        msg = [rng.getrandbits(int(random_bits)) for _ in range(t - 1)]
        msg.append(int(private_exp) - sum(msg))
        shares = encode_mbr_nodes(msg, N, k, d)
        G = build_mbr_generator(N, k, d)
        R_delta, Delta, cols = right_inverse_delta(G, N, d)
        return cls(N=N, k=k, d=d, t=t, private_exp=int(private_exp), message=msg, shares=shares, psi=make_psi(N, d), G=G, R_delta=R_delta, Delta=Delta, independent_columns=cols)

    def R_block(self, cid: int) -> List[List[int]]:
        start = (int(cid) - 1) * self.d
        return self.R_delta[start:start + self.d]

    def repair_share(self, failed_cid: int, helpers: Sequence[int]) -> Tuple[List[int], List[Dict[str, Any]]]:
        helpers = list(helpers)[: self.d]
        if len(helpers) < self.d:
            raise ValueError(f"need d={self.d} helpers to repair a failed share")
        psi_f = self.psi[int(failed_cid) - 1]
        # Each helper sends beta=1 symbol: c_h · psi_f.
        symbols: List[Dict[str, Any]] = []
        for h in helpers:
            sym = sum(int(a) * int(b) for a, b in zip(self.shares[int(h)], psi_f))
            symbols.append({"helper": int(h), "failed": int(failed_cid), "symbol": int(sym)})
        Psi_D = [self.psi[int(h) - 1] for h in helpers]
        inv = frac_matrix_inverse(Psi_D)
        z = frac_mat_vec_mul(inv, [s["symbol"] for s in symbols])  # z = M * psi_f
        repaired = [int(v) if v.denominator == 1 else int(v) for v in z]
        return repaired, symbols

    def reconstruct_message_from_nodes(self, node_ids: Sequence[int]) -> List[Fraction]:
        node_ids = list(node_ids)[: self.k]
        if len(node_ids) < self.k:
            raise ValueError("not enough nodes for reconstruction")
        rows: List[List[int]] = []
        vals: List[int] = []
        for cid in node_ids:
            start = (int(cid) - 1) * self.d
            for j in range(self.d):
                rows.append([self.G[m][start + j] for m in range(self.t)])
                vals.append(self.shares[int(cid)][j])
        # Select t independent equations.
        selected: List[int] = []
        cur: List[List[int]] = []
        for idx, row in enumerate(rows):
            if rank_fraction(cur + [row]) > rank_fraction(cur):
                selected.append(idx)
                cur.append(row)
                if len(selected) == self.t:
                    break
        if len(selected) < self.t:
            raise ValueError("selected nodes cannot reconstruct message")
        A = [rows[i] for i in selected]
        b = [vals[i] for i in selected]
        A_inv = frac_matrix_inverse(A)
        return frac_mat_vec_mul(A_inv, b)


def paillier_theta_for_exponent(pub: paillier.PaillierPublicKey, exp: int) -> int:
    return paillier.L(pow(pub.g, int(exp), pub.n2), pub.n) % pub.n


def decrypt_with_private_exponent(pub: paillier.PaillierPublicKey, private_exp: int, c: int) -> int:
    theta = paillier_theta_for_exponent(pub, private_exp)
    x = (paillier.L(pow(int(c), int(private_exp), pub.n2), pub.n) * invmod(theta, pub.n)) % pub.n
    return paillier.decode_signed(x, pub.n)


def rtpfl_partial_decrypt_cipher(pub: paillier.PaillierPublicKey, state: RTPFLCodeState, share_map: Dict[int, List[int]], c: int) -> int:
    # Algorithm-1-like vector partial decryptions: ci = c^{s_i R_i}; then Hadamard product.
    kappa = [1 for _ in range(state.t)]
    for cid in range(1, state.N + 1):
        s_i = share_map[int(cid)]
        R_i = state.R_block(int(cid))
        for col in range(state.t):
            exp = sum(int(s_i[row]) * int(R_i[row][col]) for row in range(state.d))
            kappa[col] = (kappa[col] * mod_pow_signed(c, exp, pub.n2)) % pub.n2
    c_priv_delta = 1
    for v in kappa:
        c_priv_delta = (c_priv_delta * v) % pub.n2
    theta_delta = paillier_theta_for_exponent(pub, state.private_exp * state.Delta)
    x = (paillier.L(c_priv_delta, pub.n) * invmod(theta_delta, pub.n)) % pub.n
    return paillier.decode_signed(x, pub.n)
