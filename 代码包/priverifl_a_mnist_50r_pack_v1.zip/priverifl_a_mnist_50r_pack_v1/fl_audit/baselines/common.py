from __future__ import annotations

import json
import random
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
import yaml

from fl_audit.crypto.signature import generate_keypair
from fl_audit.data import make_loaders
from fl_audit.model import get_vector, set_vector
from fl_audit.trainer import train_local
from fl_audit.utils.codec import canonical_bytes


def set_seed(seed: int) -> None:
    random.seed(int(seed))
    np.random.seed(int(seed))
    torch.manual_seed(int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(seed))


def load_yaml(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def save_csv(rows: List[Dict[str, Any]], path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")


def save_json(obj: Any, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, default=str)


def estimate_json_bytes(obj: Any) -> int:
    return len(canonical_bytes(obj))


@dataclass
class Runtime:
    rows: List[Dict[str, Any]] = field(default_factory=list)

    @contextmanager
    def record(self, round_id: int, stage: str, detail: str = "", cid: int | str = ""):
        t0 = time.perf_counter()
        try:
            yield
        finally:
            self.rows.append({
                "round": int(round_id),
                "stage": str(stage),
                "detail": str(detail),
                "cid": cid,
                "seconds": float(time.perf_counter() - t0),
            })

    def add(self, round_id: int, stage: str, seconds: float, detail: str = "", cid: int | str = ""):
        self.rows.append({
            "round": int(round_id),
            "stage": str(stage),
            "detail": str(detail),
            "cid": cid,
            "seconds": float(seconds),
        })


@dataclass
class CommRecorder:
    rows: List[Dict[str, Any]] = field(default_factory=list)

    def add(self, round_id: int, sender: str, receiver: str, payload_type: str, payload: Any, *, note: str = "") -> int:
        b = estimate_json_bytes(payload)
        self.rows.append({
            "round": int(round_id),
            "sender": str(sender),
            "receiver": str(receiver),
            "payload_type": str(payload_type),
            "bytes": int(b),
            "actual_seconds": 0.0,
            "process_seconds": 0.0,
            "includes_processing": False,
            "note": note,
        })
        return b

    def summary_by_type(self) -> List[Dict[str, Any]]:
        if not self.rows:
            return []
        df = pd.DataFrame(self.rows)
        g = df.groupby("payload_type", as_index=False).agg(count=("bytes", "count"), total_bytes=("bytes", "sum"))
        g["total_actual_seconds"] = 0.0
        g["total_process_seconds"] = 0.0
        g["network_transfer_count"] = g["count"]
        g["processing_request_count"] = 0
        g["total_MB"] = g["total_bytes"] / (1024 * 1024)
        return g.to_dict(orient="records")


def active_clients_for_round(cfg: dict, r: int) -> Tuple[List[int], List[int]]:
    clients = int(cfg["federated"]["clients"])
    all_ids = list(range(1, clients + 1))
    dropout_cfg = cfg["federated"].get("dropout", {}) or {}
    dropped = dropout_cfg.get(r, dropout_cfg.get(str(r), [])) or []
    dropped = sorted({int(x) for x in dropped})
    active = [cid for cid in all_ids if cid not in set(dropped)]
    return active, dropped


def make_client_keypairs(clients: int) -> Dict[int, Any]:
    return {cid: generate_keypair() for cid in range(1, int(clients) + 1)}


def get_device(cfg: dict) -> str:
    device = str((cfg.get("runtime", {}) or {}).get("device", "cpu"))
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    if device.startswith("cuda") and not torch.cuda.is_available():
        device = "cpu"
    return device


def train_raw_delta(global_model, loader, cfg: dict, timer: Runtime, r: int, cid: int, device: str) -> Tuple[np.ndarray, float, int]:
    epochs = int(cfg["federated"].get("local_epochs", 1))
    lr = float(cfg["federated"].get("local_lr", 0.05))
    with timer.record(r, "client_local_train", "real local SGD on real dataset", cid=cid):
        local_model, local_loss = train_local(global_model, loader, epochs, lr, device=device)
    with timer.record(r, "client_model_delta", "raw local model delta", cid=cid):
        delta = (get_vector(local_model) - get_vector(global_model)).numpy().astype(np.float64)
    return delta, float(local_loss), int(len(loader.dataset))


def apply_integer_average_update(model, weighted_integer_sum: np.ndarray, total_weight: int, scale: int, server_lr: float) -> None:
    delta = torch.from_numpy(weighted_integer_sum.astype(np.float64) / (float(scale) * float(max(total_weight, 1)))).double()
    new_vec = get_vector(model) + float(server_lr) * delta
    set_vector(model, new_vec)


def apply_integer_update(model, integer_update: np.ndarray, scale: int, server_lr: float) -> None:
    delta = torch.from_numpy(integer_update.astype(np.float64) / float(scale)).double()
    new_vec = get_vector(model) + float(server_lr) * delta
    set_vector(model, new_vec)


def write_common_outputs(out_dir: str | Path, *, cfg: dict, scheme_name: str, accepted: bool, rounds_done: int, latest_root: str, metrics_rows: list, runtime: Runtime, comm: CommRecorder, crypto_rows: list, trace: dict, blockchain_rows: list | None = None, baseline_rows: list | None = None) -> None:
    out = ensure_dir(out_dir)
    save_csv(metrics_rows, out / "metrics_round.csv")
    save_csv(runtime.rows, out / "runtime_cost.csv")
    save_csv(crypto_rows, out / "crypto_cost.csv")
    save_csv(blockchain_rows or [], out / "blockchain_cost.csv")
    save_csv(baseline_rows or [], out / "baseline_cost.csv")
    save_csv(comm.rows, out / "communication_cost.csv")
    save_csv(comm.rows, out / "communication_network_only.csv")
    save_csv([], out / "communication_processing_requests.csv")
    save_csv(comm.summary_by_type(), out / "communication_summary_by_type.csv")
    save_csv([{"accepted": bool(accepted), "rounds": int(rounds_done), "latestAuditRoot": latest_root}], out / "verify_result.csv")
    trace = dict(trace)
    trace.setdefault("scheme", scheme_name)
    trace.setdefault("config", cfg)
    save_json(trace, out / "run_trace.json")
