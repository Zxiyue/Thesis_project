from __future__ import annotations

import os
import time
from typing import Any, Dict, List

import numpy as np
import torch

from fl_audit.baselines.common import (
    CommRecorder,
    Runtime,
    active_clients_for_round,
    apply_integer_average_update,
    get_device,
    make_client_keypairs,
    set_seed,
    train_raw_delta,
    write_common_outputs,
)
from fl_audit.baselines.paper_repro_crypto import (
    VectorHomomorphicHash,
    aesgcm_decrypt_json,
    aesgcm_encrypt_json,
    aggregate_weighted_packed_ciphertexts,
    choose_pack_size,
    choose_signed_payload_and_slot_bits,
    decrypt_packed_signed_vector,
    encrypt_packed_signed_vector,
    merge_decimal_segments,
    quantize_decimal,
    split_decimal_sensitive,
)
from fl_audit.crypto import paillier
from fl_audit.crypto.signature import sign_obj, verify_obj
from fl_audit.data import make_loaders
from fl_audit.model import evaluate, get_vector, make_model, model_hash
from fl_audit.utils.codec import bytes32_hex


def _cfg_get(cfg: Dict[str, Any], *path: str, default: Any = None) -> Any:
    cur: Any = cfg
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return default
        cur = cur[key]
    return cur


def _int_list(x: np.ndarray) -> List[int]:
    return [int(v) for v in x.reshape(-1).tolist()]


def run_priverifl_a_repro(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Paper-faithful PriVeriFL-A reproduction baseline.

    Compared with the old style baseline, this runner follows Algorithm 1 of
    PriVeriFL-A more closely:
      * m_i is quantized as m_i * 10^8;
      * A_i stores the first t sensitive decimal digits and B_i keeps the rest;
      * A_i is encoded with BatchCrypt-style signed packing and Paillier;
      * B_i is protected by AES-GCM symmetric encryption;
      * the aggregator weights ciphertexts by n_i and aggregates them;
      * simulated participants decrypt {V_j}, decode A, combine with M_B,
        and verify H.Hash(M') = H.Eval(h_i, n_i);
      * signatures are generated separately for h_i and n_i.
    """
    seed = int(cfg.get("seed", 42))
    set_seed(seed)
    out_dir = cfg.get("output_dir", "outputs/baseline_repro_priverifl_a")
    device = get_device(cfg)

    timer = Runtime()
    comm = CommRecorder()
    metrics_rows: List[Dict[str, Any]] = []
    crypto_rows: List[Dict[str, Any]] = []
    baseline_rows: List[Dict[str, Any]] = []
    trace: Dict[str, Any] = {"scheme": "baseline_repro_priverifl_a", "rounds": []}

    model = make_model(cfg["model"]["name"])
    train_loaders, test_loader, _parts = make_loaders(cfg)
    clients = int(cfg["federated"]["clients"])
    dim = int(get_vector(model).numel())

    decimal_digits = int(_cfg_get(cfg, "baseline", "priverifl_a", "decimal_digits", default=8))
    sensitive_digits = int(_cfg_get(cfg, "baseline", "priverifl_a", "sensitive_digits", default=2))
    decimal_scale = int(_cfg_get(cfg, "baseline", "priverifl_a", "decimal_scale", default=10 ** decimal_digits))
    requested_pack_size = _cfg_get(cfg, "baseline", "priverifl_a", "pack_size", default="auto")
    min_slot_bits = int(_cfg_get(cfg, "baseline", "priverifl_a", "min_slot_bits", default=34))
    slot_guard_bits = int(_cfg_get(cfg, "baseline", "priverifl_a", "slot_guard_bits", default=2))
    padding_guard_bits = int(_cfg_get(cfg, "baseline", "priverifl_a", "padding_guard_bits", default=2))
    paillier_bits = int(_cfg_get(cfg, "crypto", "paillier_bits", default=2048))

    with timer.record(0, "priverifl_a_paillier_keygen", "shared Paillier key generation"):
        pkey = paillier.keygen(paillier_bits)

    total_train_samples = sum(len(loader.dataset) for loader in train_loaders.values())
    # A conservative slot bound for weighted sums of sensitive decimal segment.
    # It can be overridden by baseline.priverifl_a.slot_bits.
    payload_bits_cfg = _cfg_get(cfg, "baseline", "priverifl_a", "payload_bits", default=None)
    slot_bits_cfg = _cfg_get(cfg, "baseline", "priverifl_a", "slot_bits", default=None)
    if payload_bits_cfg is None or slot_bits_cfg is None:
        rough_value_bound = max(1, decimal_scale)
        payload_bits, slot_bits = choose_signed_payload_and_slot_bits(
            rough_value_bound,
            total_train_samples,
            min_payload_bits=min_slot_bits,
            payload_guard_bits=slot_guard_bits,
            padding_guard_bits=padding_guard_bits,
        )
    else:
        payload_bits = int(payload_bits_cfg)
        slot_bits = int(slot_bits_cfg)
    pack_size = choose_pack_size(pkey.public.n.bit_length(), slot_bits, requested_pack_size)

    hh = VectorHomomorphicHash(dim=dim, seed=seed, prime_bits=int(_cfg_get(cfg, "baseline", "priverifl_a", "hh_prime_bits", default=127)))
    se_key = os.urandom(32)
    client_keys = make_client_keypairs(clients)

    init_model_hash = model_hash(model)
    init_public = {
        "scheme": "PriVeriFL-A-reproduction",
        "modelHash": init_model_hash,
        "dim": dim,
        "decimalScale": decimal_scale,
        "decimalDigits": decimal_digits,
        "sensitiveDigits": sensitive_digits,
        "paillier_n_bits": pkey.public.n.bit_length(),
        "payloadBits": payload_bits,
        "slotBits": slot_bits,
        "packSize": pack_size,
        "HH": hh.public_params(),
    }
    for cid in range(1, clients + 1):
        comm.add(0, "CA/Aggregator", f"C{cid}", "InitModel", init_public)

    loss0, acc0 = evaluate(model, test_loader, device=device)
    metrics_rows.append({"round": 0, "test_loss": loss0, "test_accuracy": acc0, "effective_clients": 0, "dropout_clients": 0})

    accepted = True
    latest_root = bytes32_hex({"scheme": "baseline_repro_priverifl_a", "modelHash": init_model_hash})
    rounds_done = 0
    exp_t0 = time.perf_counter()

    for r in range(1, int(cfg["federated"]["rounds"]) + 1):
        r_t0 = time.perf_counter()
        active, dropped = active_clients_for_round(cfg, r)
        model_hash_r = model_hash(model)
        cA_vectors: List[List[int]] = []
        B_plain_list: List[np.ndarray] = []
        weights: List[int] = []
        h_list: List[int] = []
        sig_hash_ok = True
        sig_size_ok = True
        se_ok = True
        local_losses: List[float] = []
        upload_receipts: List[Dict[str, Any]] = []

        for cid in active:
            delta, local_loss, n_i = train_raw_delta(model, train_loaders[cid], cfg, timer, r, cid, device)
            local_losses.append(local_loss)
            weights.append(n_i)
            with timer.record(r, "client_decimal_quantize", "m_i <- m_i * 10^8", cid=cid):
                x = quantize_decimal(delta, decimal_scale)
            with timer.record(r, "client_priverifl_decimal_split", "A_i,B_i <- split(m_i) by sensitive decimal digits", cid=cid):
                A_i, B_i = split_decimal_sensitive(x, decimal_digits=decimal_digits, sensitive_digits=sensitive_digits)
            with timer.record(r, "client_priverifl_batchcrypt_paillier_encrypt", "encode, pack and PHE.Enc(A_i)", cid=cid):
                cA_i = encrypt_packed_signed_vector(pkey.public, _int_list(A_i), payload_bits=payload_bits, slot_bits=slot_bits, pack_size=pack_size)
            aad = {"scheme": "PriVeriFL-A", "r": r, "cid": cid, "modelHash": model_hash_r, "part": "B"}
            with timer.record(r, "client_priverifl_symmetric_encrypt", "SE.Enc(k,B_i)", cid=cid):
                B_ct = aesgcm_encrypt_json(se_key, _int_list(B_i), aad=aad)
            with timer.record(r, "client_priverifl_homomorphic_hash", "h_i <- H.Hash(m_i*10^8)", cid=cid):
                h_i = hh.digest(x)
            hash_msg = {"scheme": "PriVeriFL-A", "r": r, "cid": cid, "modelHash": model_hash_r, "h_i": str(h_i)}
            size_msg = {"scheme": "PriVeriFL-A", "r": r, "cid": cid, "modelHash": model_hash_r, "n_i": int(n_i)}
            sig_h = sign_obj(client_keys[cid].private_key, hash_msg)
            sig_n = sign_obj(client_keys[cid].private_key, size_msg)
            if not verify_obj(client_keys[cid].public_pem, sig_h, hash_msg):
                sig_hash_ok = False
            if not verify_obj(client_keys[cid].public_pem, sig_n, size_msg):
                sig_size_ok = False

            upload = {
                "Vhat_i": [str(v) for v in cA_i],
                "Bhat_i": B_ct.to_dict(),
                "h_i": str(h_i),
                "sigma_i": sig_h,
                "n_i": int(n_i),
                "xi_i": sig_n,
                "hashMsg": hash_msg,
                "sizeMsg": size_msg,
            }
            comm.add(r, f"C{cid}", "Aggregator", "UpMsg", upload)

            with timer.record(r, "aggregator_symmetric_decrypt", "SE.Dec(k,B_i)", cid=cid):
                try:
                    B_dec = np.array([int(v) for v in aesgcm_decrypt_json(se_key, B_ct, aad=aad)], dtype=object)
                except Exception:
                    se_ok = False
                    B_dec = np.zeros(dim, dtype=object)
            cA_vectors.append(cA_i)
            B_plain_list.append(B_dec)
            h_list.append(h_i)
            upload_receipts.append({"cid": cid, "hashMsg": hash_msg, "sizeMsg": size_msg, "cAHash": bytes32_hex(cA_i), "BHash": bytes32_hex(B_ct.to_dict())})

        with timer.record(r, "aggregator_weighted_phe_aggregate", "V_j <- product_i PHE.Mul(vhat_ij,n_i)"):
            VAgg = aggregate_weighted_packed_ciphertexts(pkey.public, cA_vectors, weights)
        with timer.record(r, "aggregator_weighted_B_aggregate", "M_B <- sum_i B_i*n_i"):
            MB = np.zeros(dim, dtype=object)
            for B_i, n_i in zip(B_plain_list, weights):
                MB += B_i * int(n_i)
        agg_msg = {
            "scheme": "PriVeriFL-A-reproduction",
            "r": r,
            "Z": active,
            "n": int(sum(weights)),
            "h": [str(v) for v in h_list],
            "n_i": weights,
            "MBHash": bytes32_hex(_int_list(MB)),
            "VAggHash": bytes32_hex(VAgg),
            "VAgg": [str(v) for v in VAgg],
        }
        for cid in active:
            comm.add(r, "Aggregator", f"C{cid}", "AggMsg", agg_msg)

        # Simulate participant-side Decrypt&Verify exactly once; all honest clients get same result.
        with timer.record(r, "participant_phe_decrypt_decode", "MA <- decode({PHE.Dec(sPHE,V_j)})"):
            MA = decrypt_packed_signed_vector(pkey.public, pkey.private, VAgg, total_count=dim, payload_bits=payload_bits, slot_bits=slot_bits, pack_size=pack_size)
        with timer.record(r, "participant_combine_model", "M <- combine(MA,MB)"):
            M_weighted = merge_decimal_segments(MA, MB)
        with timer.record(r, "participant_verify_homomorphic_hash", "H.Hash(M') == H.Eval(h_i,n_i)"):
            hh_ok = hh.verify_weighted_sum(M_weighted, h_list, weights)
        accepted = bool(accepted and sig_hash_ok and sig_size_ok and se_ok and hh_ok)

        if accepted:
            with timer.record(r, "participant_update_global_model", "global M <- M/n"):
                apply_integer_average_update(model, M_weighted.astype(object), total_weight=sum(weights), scale=decimal_scale, server_lr=float(cfg["federated"].get("server_lr", 1.0)))
        with timer.record(r, "server_evaluate", "test evaluation"):
            test_loss, test_acc = evaluate(model, test_loader, device=device)

        model_hash_next = model_hash(model)
        latest_root = bytes32_hex({
            "prev": latest_root,
            "r": r,
            "modelHashR": model_hash_r,
            "modelHashNext": model_hash_next,
            "VAggHash": bytes32_hex(VAgg),
            "MBHash": bytes32_hex(_int_list(MB)),
            "hhOk": hh_ok,
        })
        rounds_done = r
        metrics_rows.append({"round": r, "test_loss": test_loss, "test_accuracy": test_acc, "effective_clients": len(active), "dropout_clients": len(dropped)})
        crypto_rows.extend([
            {"round": r, "metric": "model_dimension", "value": dim},
            {"round": r, "metric": "decimal_scale", "value": decimal_scale},
            {"round": r, "metric": "sensitive_decimal_digits", "value": sensitive_digits},
            {"round": r, "metric": "payload_bits", "value": payload_bits},
            {"round": r, "metric": "slot_bits", "value": slot_bits},
            {"round": r, "metric": "actual_pack_size", "value": pack_size},
            {"round": r, "metric": "paillier_encryptions", "value": len(active) * (len(cA_vectors[0]) if cA_vectors else 0)},
            {"round": r, "metric": "paillier_ciphertexts_after_packing", "value": len(cA_vectors[0]) if cA_vectors else 0},
            {"round": r, "metric": "paillier_decryptions_by_participant", "value": len(VAgg)},
            {"round": r, "metric": "aes_gcm_encryptions", "value": len(active)},
            {"round": r, "metric": "aes_gcm_decryptions", "value": len(active)},
            {"round": r, "metric": "homomorphic_hash_client_ops", "value": len(active)},
            {"round": r, "metric": "homomorphic_hash_verify_ops", "value": 1},
            {"round": r, "metric": "signature_hash_sigma", "value": len(active)},
            {"round": r, "metric": "signature_size_xi", "value": len(active)},
        ])
        baseline_rows.append({
            "round": r,
            "scheme": "PriVeriFL-A-reproduction",
            "signature_hash_ok": bool(sig_hash_ok),
            "signature_size_ok": bool(sig_size_ok),
            "symmetric_decrypt_ok": bool(se_ok),
            "homomorphic_hash_ok": bool(hh_ok),
            "accepted_so_far": bool(accepted),
            "effective_clients": len(active),
            "dropout_clients": len(dropped),
            "total_weight_n": int(sum(weights)),
            "round_wall_seconds": float(time.perf_counter() - r_t0),
        })
        trace["rounds"].append({"round": r, "active": active, "dropped": dropped, "hh_ok": hh_ok, "accepted": accepted, "test_accuracy": test_acc, "test_loss": test_loss})
        if not accepted:
            break

    timer.add(0, "experiment_wall", time.perf_counter() - exp_t0, detail="total PriVeriFL-A reproduction wall-clock time")
    write_common_outputs(
        out_dir,
        cfg=cfg,
        scheme_name="baseline_repro_priverifl_a",
        accepted=accepted,
        rounds_done=rounds_done,
        latest_root=latest_root,
        metrics_rows=metrics_rows,
        runtime=timer,
        comm=comm,
        crypto_rows=crypto_rows,
        trace=trace,
        blockchain_rows=[{"round": "N/A", "tx_type": "N/A", "gas_used": 0, "latency_sec": 0.0, "note": "PriVeriFL-A has no blockchain audit board"}],
        baseline_rows=baseline_rows,
    )
    return {"accepted": bool(accepted), "rounds": rounds_done, "output_dir": str(out_dir), "latestRoot": latest_root, "payload_bits": payload_bits, "slot_bits": slot_bits, "pack_size": pack_size}
