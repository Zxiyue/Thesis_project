#!/usr/bin/env bash
set -euo pipefail
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FPA5_DIR="${FPA5_DIR:-/root/fpa5}"
if [[ ! -d "$FPA5_DIR" ]]; then
  echo "[ERROR] FPA5_DIR not found: $FPA5_DIR" >&2
  echo "请先确认已有 /root/fpa5 环境，或用 FPA5_DIR=/path/to/fpa5 指定。" >&2
  exit 1
fi
mkdir -p "$FPA5_DIR/configs" "$FPA5_DIR/fl_audit/baselines" "$FPA5_DIR/scripts" "$FPA5_DIR/tools"
cp -f "$PACK_DIR"/configs/*.yaml "$FPA5_DIR/configs/"
cp -f "$PACK_DIR"/fl_audit/baselines/*.py "$FPA5_DIR/fl_audit/baselines/"
cp -f "$PACK_DIR"/scripts/run_repro_baseline.py "$FPA5_DIR/scripts/run_repro_baseline.py"
cp -f "$PACK_DIR"/tools/analyze_priverifl_a_mnist_50r_results.py "$FPA5_DIR/tools/analyze_priverifl_a_mnist_50r_results.py"
cp -f "$PACK_DIR"/tools/zip_priverifl_a_mnist_50r_results.sh "$FPA5_DIR/tools/zip_priverifl_a_mnist_50r_results.sh"
chmod +x "$FPA5_DIR/tools/zip_priverifl_a_mnist_50r_results.sh"
echo "[OK] PriVeriFL-A MNIST 50r patch/configs installed into $FPA5_DIR"
