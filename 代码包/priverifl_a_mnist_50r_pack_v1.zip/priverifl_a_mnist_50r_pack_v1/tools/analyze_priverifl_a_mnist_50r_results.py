from __future__ import annotations
import csv
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/root/fpa5/outputs')
PATTERNS = [
    'baseline_repro_priverifl_a_mnist_iid_50r_p2048_lr020',
    'baseline_repro_priverifl_a_mnist_noniid_50r_p2048_lr020',
]

def read_csv(path: Path):
    if not path.exists():
        return []
    with path.open(newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def f(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default

rows = []
for name in PATTERNS:
    d = ROOT / name
    metrics = read_csv(d / 'metrics_round.csv')
    verify = read_csv(d / 'verify_result.csv')
    runtime = read_csv(d / 'runtime_cost.csv')
    comm_detail = read_csv(d / 'communication_cost.csv')
    crypto = read_csv(d / 'crypto_cost.csv')
    if not d.exists():
        rows.append({'output_dir': str(d), 'accepted': 'MISSING'})
        continue
    final = metrics[-1] if metrics else {}
    best_acc = max([f(r.get('test_accuracy')) for r in metrics], default=0.0)
    exp_wall = sum(f(r.get('seconds')) for r in runtime if r.get('stage') == 'experiment_wall')
    enc = sum(f(r.get('seconds')) for r in runtime if r.get('stage') == 'client_priverifl_batchcrypt_paillier_encrypt')
    dec = sum(f(r.get('seconds')) for r in runtime if r.get('stage') == 'participant_phe_decrypt_decode')
    hh = sum(f(r.get('seconds')) for r in runtime if 'homomorphic_hash' in r.get('stage',''))
    train = sum(f(r.get('seconds')) for r in runtime if r.get('stage') == 'client_local_train')
    comm_bytes = sum(f(r.get('bytes')) for r in comm_detail)
    pack_size = ''
    slot_bits = ''
    for r in crypto:
        if r.get('metric') == 'actual_pack_size': pack_size = r.get('value')
        if r.get('metric') == 'slot_bits': slot_bits = r.get('value')
    rows.append({
        'output_dir': str(d),
        'accepted': verify[-1].get('accepted','') if verify else '',
        'rounds': verify[-1].get('rounds','') if verify else final.get('round',''),
        'final_acc': final.get('test_accuracy',''),
        'best_acc': f'{best_acc:.6f}',
        'total_comm_MB': f'{comm_bytes/1024/1024:.3f}',
        'experiment_wall_s': f'{exp_wall:.3f}',
        'paillier_encrypt_s': f'{enc:.3f}',
        'phe_decrypt_decode_s': f'{dec:.3f}',
        'local_train_s': f'{train:.3f}',
        'homomorphic_hash_s': f'{hh:.3f}',
        'pack_size': pack_size,
        'slot_bits': slot_bits,
    })

fields = ['output_dir','accepted','rounds','final_acc','best_acc','total_comm_MB','experiment_wall_s','paillier_encrypt_s','phe_decrypt_decode_s','local_train_s','homomorphic_hash_s','pack_size','slot_bits']
w = csv.DictWriter(sys.stdout, fieldnames=fields, extrasaction='ignore')
w.writeheader()
w.writerows(rows)
