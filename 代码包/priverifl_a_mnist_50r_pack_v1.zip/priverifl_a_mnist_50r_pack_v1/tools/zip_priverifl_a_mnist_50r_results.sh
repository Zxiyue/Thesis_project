#!/usr/bin/env bash
set -euo pipefail
cd /root
zip -qr priverifl_a_mnist_p2048_50r_results.zip \
  fpa5/outputs/baseline_repro_priverifl_a_mnist_iid_50r_p2048_lr020 \
  fpa5/outputs/baseline_repro_priverifl_a_mnist_noniid_50r_p2048_lr020 \
  priverifl_a_mnist_iid_50r_p2048_lr020.log \
  priverifl_a_mnist_noniid_50r_p2048_lr020.log 2>/dev/null || true
ls -lh /root/priverifl_a_mnist_p2048_50r_results.zip
