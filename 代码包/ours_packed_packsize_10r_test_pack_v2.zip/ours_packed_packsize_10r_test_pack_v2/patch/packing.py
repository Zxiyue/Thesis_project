from __future__ import annotations

import math
from typing import Iterable, List, Any
import numpy as np


def enabled_from_config(cfg: dict) -> bool:
    return bool(((cfg.get("crypto", {}) or {}).get("packing", {}) or {}).get("enabled", False))


def packing_config(cfg: dict) -> dict:
    return ((cfg.get("crypto", {}) or {}).get("packing", {}) or {})


def slot_bits_from_config(cfg: dict, default: int = 40) -> int:
    return int(packing_config(cfg).get("slot_bits", default))


def _normalize_pack_size(pack_size: Any) -> int | None:
    """Return None for auto, otherwise a positive integer pack_size."""
    if pack_size is None:
        return None
    if isinstance(pack_size, str):
        s = pack_size.strip().lower()
        if s in ("", "none", "null", "auto"):
            return None
        return int(s)
    return int(pack_size)


def auto_slots_per_cipher(pub, slot_bits: int) -> int:
    return max(1, (int(pub.n).bit_length() - 2) // int(slot_bits))


def slots_per_cipher(pub, slot_bits: int, pack_size: Any = None) -> int:
    auto_slots = auto_slots_per_cipher(pub, slot_bits)
    p = _normalize_pack_size(pack_size)
    if p is None:
        return auto_slots
    if p < 1:
        raise ValueError(f"pack_size must be positive or auto, got {pack_size!r}")
    if p > auto_slots:
        raise ValueError(
            f"pack_size={p} exceeds safe auto slots={auto_slots} for slot_bits={slot_bits}"
        )
    return p


def packed_cipher_count(dim: int, pub, slot_bits: int, pack_size: Any = None) -> int:
    s = slots_per_cipher(pub, slot_bits, pack_size)
    return int(math.ceil(int(dim) / float(s)))


def minimum_safe_slot_bits(q: int, max_terms: int, guard_bits: int = 1) -> int:
    return int(math.ceil(math.log2(max(2, int(q) * int(max_terms)))) + int(guard_bits))


def pack_vector_mod_q(vec: Iterable[int], q: int, slot_bits: int, slots: int) -> List[int]:
    q = int(q)
    slot_bits = int(slot_bits)
    slots = int(slots)
    base = 1 << slot_bits
    if q >= base:
        raise ValueError(f"q={q} must be smaller than slot base 2^{slot_bits}")
    arr = [int(v) % q for v in list(vec)]
    out: List[int] = []
    for start in range(0, len(arr), slots):
        acc = 0
        chunk = arr[start:start + slots]
        for j, val in enumerate(chunk):
            if val < 0 or val >= base:
                raise ValueError(f"slot value {val} does not fit in {slot_bits} bits")
            acc |= int(val) << (slot_bits * j)
        out.append(acc)
    return out


def unpack_vector_mod_q(packed_values: Iterable[int], dim: int, q: int, slot_bits: int, slots: int) -> np.ndarray:
    q = int(q)
    slot_bits = int(slot_bits)
    slots = int(slots)
    mask = (1 << slot_bits) - 1
    out: List[int] = []
    for packed in packed_values:
        x = int(packed)
        for j in range(slots):
            if len(out) >= int(dim):
                break
            residue = (x >> (slot_bits * j)) & mask
            v = int(residue % q)
            if v > q // 2:
                v -= q
            out.append(v)
    if len(out) != int(dim):
        raise ValueError(f"unpacked {len(out)} values, expected {dim}")
    return np.array(out, dtype=np.int64)
