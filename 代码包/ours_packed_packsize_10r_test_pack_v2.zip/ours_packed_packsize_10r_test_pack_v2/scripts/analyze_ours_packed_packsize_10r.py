from __future__ import annotations
from pathlib import Path
import csv, json, statistics as stats

ROOT = Path('/root/fpa5')
NAMES = [
    'ours_packed_mnist_iid_10r_p2048_s34_pauto',
    'ours_packed_mnist_iid_10r_p2048_s34_p48',
    'ours_packed_mnist_iid_10r_p2048_s34_p32',
    'ours_packed_mnist_iid_10r_p2048_s34_p16',
]


def read_csv(p: Path):
    if not p.exists(): return []
    with p.open(newline='', encoding='utf-8-sig') as f: return list(csv.DictReader(f))

def fnum(v):
    try: return float(v)
    except Exception: return 0.0

def sum_stage(rows, stage):
    return sum(fnum(r.get('seconds',0)) for r in rows if r.get('stage')==stage)

def avg_stage(rows, stage):
    vals=[fnum(r.get('seconds',0)) for r in rows if r.get('stage')==stage]
    return sum(vals)/len(vals) if vals else 0.0

def total_comm_mb(rows):
    total=0.0
    for r in rows: total += fnum(r.get('total_bytes', r.get('bytes',0)))
    return total/1024/1024

def best_acc(metrics):
    if not metrics: return ('','')
    b=max(metrics, key=lambda r:fnum(r.get('test_accuracy',0)))
    return b.get('test_accuracy',''), b.get('round','')

def trace_meta(d: Path):
    out={
        'slot_bits':'','configured_pack_size':'','actual_slots_per_cipher':'',
        'actual_cipher_count':'','logical_coordinates':'','compression_ratio':''
    }
    cfg_path=d/'config.yaml'
    # output directories may not include config.yaml in current project, so infer from name too.
    p=d/'run_trace.json'
    if p.exists():
        try:
            obj=json.load(open(p,encoding='utf-8'))
            for rd in obj.get('rounds',[]):
                for cs in rd.get('clientStats',[]):
                    if cs.get('packing_enabled'):
                        out['slot_bits']=cs.get('packing_slot_bits','')
                        out['actual_slots_per_cipher']=cs.get('packing_slots_per_cipher','')
                        out['actual_cipher_count']=cs.get('packing_cipher_count','')
                        out['compression_ratio']=cs.get('packing_compression_ratio','')
                        out['logical_coordinates']=cs.get('logical_coordinates',6794)
                        return out
        except Exception as e:
            out['trace_error']=repr(e)
    return out

def analyze(name):
    d=ROOT/'outputs'/name
    if not d.exists(): return None
    metrics=read_csv(d/'metrics_round.csv')
    runtime=read_csv(d/'runtime_cost.csv')
    comm=read_csv(d/'communication_summary_by_type.csv')
    verify=read_csv(d/'verify_result.csv')
    final=metrics[-1] if metrics else {}
    best,bround=best_acc(metrics)
    ver=verify[-1] if verify else {}
    meta=trace_meta(d)
    pack_tag=name.split('_')[-1]
    meta['configured_pack_size']='auto' if pack_tag=='pauto' else pack_tag.lstrip('p')
    return {
        'name':name,
        'configured_pack_size':meta.get('configured_pack_size',''),
        'accepted':ver.get('accepted',''),
        'rounds':ver.get('rounds',''),
        'final_acc':final.get('test_accuracy',''),
        'best_acc':best,
        'best_round':bround,
        'slot_bits':meta.get('slot_bits',''),
        'actual_slots_per_cipher':meta.get('actual_slots_per_cipher',''),
        'actual_cipher_count':meta.get('actual_cipher_count',''),
        'compression_ratio':meta.get('compression_ratio',''),
        'total_comm_MB':total_comm_mb(comm),
        'client_upload_parallel_wall_avg_s':avg_stage(runtime,'client_upload_parallel_wall'),
        'client_paillier_encrypt_sum_s':sum_stage(runtime,'client_paillier_encrypt'),
        'client_paillier_encrypt_avg_row_s':avg_stage(runtime,'client_paillier_encrypt'),
        'client_paillier_pack_sum_s':sum_stage(runtime,'client_paillier_pack'),
        'client_pedersen_commit_sum_s':sum_stage(runtime,'client_pedersen_commit'),
        'cs_decrypt_combine_sum_s':sum_stage(runtime,'cs_decrypt_combine'),
        'cs_decrypt_combine_avg_s':avg_stage(runtime,'cs_decrypt_combine'),
        'cs_unpack_vector_sum_s':sum_stage(runtime,'cs_unpack_vector'),
        'cs_decode_aggregate_sum_s':sum_stage(runtime,'cs_decode_aggregate'),
        'cs_model_update_sum_s':sum_stage(runtime,'cs_model_update'),
        'start_experiment_total_wall_s':sum_stage(runtime,'start_experiment_total_wall'),
    }

def main():
    rows=[r for r in (analyze(n) for n in NAMES) if r]
    if not rows:
        print('No outputs found.')
        return
    headers=list(rows[0].keys())
    print(','.join(headers))
    for r in rows:
        print(','.join(str(r.get(h,'')) for h in headers))

if __name__=='__main__': main()
