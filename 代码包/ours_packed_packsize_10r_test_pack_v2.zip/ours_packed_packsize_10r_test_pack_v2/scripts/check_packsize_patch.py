from pathlib import Path
ROOT = Path("/root/fpa5")
entities = (ROOT/"fl_audit/protocol/entities.py").read_text(encoding="utf-8")
packing = (ROOT/"fl_audit/crypto/packing.py").read_text(encoding="utf-8")
checks = [
    ("packing slots_per_cipher has pack_size arg", "def slots_per_cipher(pub, slot_bits: int, pack_size" in packing),
    ("packing packed_cipher_count has pack_size arg", "def packed_cipher_count(dim: int, pub, slot_bits: int, pack_size" in packing),
    ("client encryption passes pack_size", 'slots_per_cipher(paillier_pub, slot_bits, packing_cfg.get("pack_size", None))' in entities),
    ("recover/unpack passes pack_size", 'slots_per_cipher(pub, slot_bits, packing_cfg.get("pack_size", None))' in entities),
    ("compensation count passes pack_size", 'packed_cipher_count(dim, paillier_pub, slot_bits, packing_cfg.get("pack_size", None))' in entities),
]
ok = True
for name, passed in checks:
    print(f"{name:45s}: {'OK' if passed else 'FAIL'}")
    ok = ok and passed
print()
print("PACK_SIZE_PATCH_READY =", ok)
raise SystemExit(0 if ok else 1)
