#!/usr/bin/env bash
set -uo pipefail
cd /root/fpa5
PACK_TAGS="${PACK_TAGS:-pauto p48 p32 p16}"
for tag in ${PACK_TAGS}; do
  name="ours_packed_mnist_iid_10r_p2048_s34_${tag}"
  echo
  echo "================ ${name} ================"
  if [ ! -d "outputs/${name}" ]; then
    echo "not created"
    continue
  fi
  echo "--- metrics tail ---"
  tail -n 8 "outputs/${name}/metrics_round.csv" 2>/dev/null || true
  echo "--- verify ---"
  cat "outputs/${name}/verify_result.csv" 2>/dev/null || true
  echo "--- runtime cs timing tail ---"
  grep -E 'cs_decrypt_combine|cs_unpack_vector|cs_decode_aggregate|cs_model_update|client_paillier_encrypt|client_upload_parallel_wall' "outputs/${name}/runtime_cost.csv" 2>/dev/null | tail -n 20 || true
  echo "--- communication summary ---"
  cat "outputs/${name}/communication_summary_by_type.csv" 2>/dev/null || true
  echo "--- packing trace ---"
  python3 - "outputs/${name}/run_trace.json" <<'PY' 2>/dev/null || true
import json, sys
p=sys.argv[1]
obj=json.load(open(p,encoding='utf-8'))
for rd in obj.get('rounds',[]):
    for cs in rd.get('clientStats',[]):
        if cs.get('packing_enabled'):
            keys=['packing_slot_bits','packing_slots_per_cipher','packing_cipher_count','packing_compression_ratio']
            print({k:cs.get(k) for k in keys})
            raise SystemExit
print('no packing metadata found')
PY
done
