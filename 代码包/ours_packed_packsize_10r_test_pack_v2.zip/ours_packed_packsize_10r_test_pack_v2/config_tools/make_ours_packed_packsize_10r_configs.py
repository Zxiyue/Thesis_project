from __future__ import annotations

from pathlib import Path
import copy
import yaml

ROOT = Path('/root/fpa5')
CONFIG_DIR = ROOT / 'configs'

# Fixed slot_bits=34 because the previous slot_bits sensitivity test selected it
# as the smallest stable conservative slot width. This script varies only pack_size.
PACK_SIZES = [None, 48, 32, 16]
ROUNDS = 10


def load_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding='utf-8'))


def write_yaml(path: Path, cfg: dict) -> None:
    path.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding='utf-8')
    print('wrote', path)


def find_base() -> Path:
    candidates = [
        'ours_packed_mnist_iid_10r_p2048_s34.yaml',
        'ours_packed_mnist_iid_50r_p2048_s34_final.yaml',
        'mnist_iid_50r_lr020_main.yaml',
        'mnist_iid_50r_main.yaml',
    ]
    for name in candidates:
        p = CONFIG_DIR / name
        if p.exists():
            return p
    raise FileNotFoundError('No base config found: ' + ', '.join(candidates))


def tag_for_pack_size(pack_size):
    return 'pauto' if pack_size is None else f'p{int(pack_size)}'


def make_one(pack_size) -> None:
    base_path = find_base()
    cfg = copy.deepcopy(load_yaml(base_path))
    tag = tag_for_pack_size(pack_size)
    name = f'ours_packed_mnist_iid_10r_p2048_s34_{tag}'

    cfg['output_dir'] = f'outputs/{name}'

    cfg.setdefault('dataset', {})
    cfg['dataset']['name'] = 'MNIST'
    cfg['dataset']['iid'] = True
    cfg['dataset'].setdefault('data_dir', '/root/fpa5/data')
    cfg['dataset'].setdefault('download', False)
    cfg['dataset'].setdefault('shards_per_client', 2)

    cfg.setdefault('model', {})
    cfg['model']['name'] = 'tiny_cnn'

    cfg.setdefault('federated', {})
    cfg['federated']['rounds'] = ROUNDS
    cfg['federated']['clients'] = 5
    cfg['federated']['threshold'] = 3
    cfg['federated']['local_lr'] = 0.20
    cfg['federated']['server_lr'] = 1.0
    cfg['federated'].setdefault('local_epochs', 1)
    cfg['federated'].setdefault('batch_size', 64)
    # Pack-size sensitivity should isolate packing overhead, so dropout is disabled.
    cfg['federated']['dropout'] = {}

    cfg.setdefault('encoding', {})
    cfg['encoding'].setdefault('q', 1000000007)
    cfg['encoding'].setdefault('scale', 10000)

    cfg.setdefault('crypto', {})
    cfg['crypto']['paillier_bits'] = 2048
    cfg['crypto'].setdefault('pedersen_prime_bits', 521)
    cfg['crypto'].setdefault('pedersen_window', 0)
    cfg['crypto']['packing'] = {
        'enabled': True,
        'scheme': 'mod_q_residue',
        'slot_bits': 34,
        'pack_size': pack_size,
        'guard_bits': 1,
        'allow_unsafe': False,
    }

    cfg.setdefault('runtime', {})
    cfg['runtime']['device'] = cfg['runtime'].get('device', 'cpu')
    cfg['runtime']['parallel_clients'] = True
    cfg['runtime']['max_client_workers'] = 5
    cfg['runtime'].setdefault('num_workers', 0)
    cfg['runtime'].setdefault('pin_memory', False)
    cfg['runtime'].setdefault('test_batch_size', 256)

    cfg.setdefault('distributed', {})
    cfg['distributed']['enabled'] = True
    cfg['distributed']['client_mode'] = 'individual'
    cfg['distributed'].setdefault('host', '127.0.0.1')
    cfg['distributed'].setdefault('kgc_port', 9200)
    cfg['distributed'].setdefault('cs_port', 9300)
    cfg['distributed'].setdefault('client_base_port', 9400)

    cfg.setdefault('communication', {})
    cfg['communication']['enabled'] = True
    cfg['communication']['mode'] = 'http'
    cfg['communication']['record_actual_time'] = True
    cfg['communication']['timeout_seconds'] = 3600

    cfg.setdefault('blockchain', {})
    cfg['blockchain']['enabled'] = True
    cfg['blockchain'].setdefault('rpc_url', 'http://127.0.0.1:8545')
    cfg['blockchain'].setdefault('contract_json', 'outputs/contract.json')

    cfg.setdefault('logging', {})
    cfg['logging']['save_trace'] = True
    cfg['logging']['verbose'] = True

    cfg['seed'] = cfg.get('seed', 20260627)

    out_path = CONFIG_DIR / f'{name}.yaml'
    write_yaml(out_path, cfg)
    print(f'  base: {base_path.name}')
    print(f'  output_dir: outputs/{name}')
    print(f'  slot_bits: 34')
    print(f'  pack_size: {pack_size if pack_size is not None else "auto"}')


def main() -> None:
    for ps in PACK_SIZES:
        make_one(ps)


if __name__ == '__main__':
    main()
