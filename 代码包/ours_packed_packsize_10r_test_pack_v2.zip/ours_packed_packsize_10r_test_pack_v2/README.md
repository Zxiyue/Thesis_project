# Ours-packed pack_size 10-round sensitivity test v2

This v2 package fixes the previous pack_size test: the earlier run still used auto slots for all pauto/p48/p32/p16 groups. In v2, `crypto.packing.pack_size` is passed to the packing layer, so the actual ciphertext counts should differ across pack sizes.


Purpose: after selecting `slot_bits=34`, compare `pack_size=auto/48/32/16` under the same MNIST-IID, 10-round, 2048-bit Paillier setting.

This is a parameter sensitivity experiment. Dropout is disabled to isolate the packing overhead.

## Apply / prepare

```bash
cd /root
unzip -o ours_packed_packsize_10r_test_pack_v2.zip

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

# Safe to run if already patched; skips if code is already Ours-packed.
python3 /root/ours_packed_packsize_10r_test_pack_v2/patch/apply_ours_packed_patch.py
python3 /root/ours_packed_packsize_10r_test_pack_v2/scripts/check_packsize_patch.py

# CS timing patch should already be applied from cs_timing_patch_pack.
python3 /root/cs_timing_patch_pack/scripts/check_cs_timing_patch.py

python3 /root/ours_packed_packsize_10r_test_pack_v2/config_tools/make_ours_packed_packsize_10r_configs.py
chmod +x /root/ours_packed_packsize_10r_test_pack_v2/scripts/*.sh
```

## Run in foreground

Start Hardhat in another tmux/window first. Then run:

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

PACK_TAGS="pauto p48 p32 p16" stdbuf -oL -eL \
  /root/ours_packed_packsize_10r_test_pack_v2/scripts/run_ours_packed_packsize_10r.sh \
  | tee /root/packed_packsize_10r.log
```

To run fewer groups:

```bash
PACK_TAGS="pauto p48 p32" stdbuf -oL -eL \
  /root/ours_packed_packsize_10r_test_pack_v2/scripts/run_ours_packed_packsize_10r.sh \
  | tee /root/packed_packsize_10r.log
```

## Check status

```bash
/root/ours_packed_packsize_10r_test_pack_v2/scripts/check_ours_packed_packsize_status.sh
```

## Analyze

```bash
cd /root/fpa5
python3 /root/ours_packed_packsize_10r_test_pack_v2/scripts/analyze_ours_packed_packsize_10r.py \
  | tee /root/ours_packed_packsize_10r_analysis.csv
```

Combined result zip:

```text
/root/ours_packed_packsize_10r_results.zip
```
