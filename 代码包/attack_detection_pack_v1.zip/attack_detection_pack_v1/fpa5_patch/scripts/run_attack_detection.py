from __future__ import annotations

import argparse
import copy
import hashlib
import random
import time
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import torch
import yaml
from concurrent.futures import ThreadPoolExecutor, as_completed

from fl_audit.data import make_loaders
from fl_audit.model import make_model, get_vector, set_vector, evaluate, serialize_model_state
from fl_audit.protocol.entities import Client, KGC, ServerCS, model_sync_signed_payload
from fl_audit.protocol.verifier import verify_chain, verify_init
from fl_audit.crypto import paillier, pedersen
from fl_audit.crypto.merkle import MerkleTree
from fl_audit.crypto.signature import verify_obj, sign_obj
from fl_audit.encoding import dequantize, quantize
from fl_audit.utils.codec import bytes32_hex
from fl_audit.utils.timer import TimerRecorder
from fl_audit.utils.export import ensure_dir, save_json, save_csv, save_excel
from fl_audit.network import CommunicationProfiler, json_size_bytes, canonical_json_bytes


SUPPORTED_SCENARIOS = {
    "normal",
    "omit_uploaded_client",
    "forged_dropout_set",
    "tamper_aggregate",
    "wrong_model_publish",
    "fake_model_sync_resp",
    "forged_finaltx",
}

EXPECTED_STAGE = {
    "normal": "third_party_chain_verify_accept",
    "omit_uploaded_client": "cs_open_check",
    "forged_dropout_set": "dropout_set_consistency",
    "tamper_aggregate": "cs_open_check",
    "wrong_model_publish": "kgc_final_model_check",
    "fake_model_sync_resp": "client_model_sync_verify",
    "forged_finaltx": "third_party_chain_verify",
}


class AttackDetected(Exception):
    def __init__(self, stage: str, reason: str, round_id: int, attack_executed: bool = True):
        super().__init__(reason)
        self.stage = stage
        self.reason = reason
        self.round_id = int(round_id)
        self.attack_executed = bool(attack_executed)


def parse_args():
    ap = argparse.ArgumentParser(description="Run Ours attack-detection experiments without modifying the main run.py.")
    ap.add_argument("--config", default="configs/attack_detection_mnist_iid_quick.yaml")
    ap.add_argument("--scenario", default=None, choices=sorted(SUPPORTED_SCENARIOS))
    ap.add_argument("--attack-round", type=int, default=None)
    ap.add_argument("--target-client", type=int, default=None)
    ap.add_argument("--output-dir", default=None)
    ap.add_argument("--rounds", type=int, default=None)
    ap.add_argument("--paillier-bits", type=int, default=None)
    ap.add_argument("--device", default=None)
    ap.add_argument("--no-blockchain", action="store_true", help="Accepted for interface compatibility; attack suite is chain-logical and does not submit txs.")
    return ap.parse_args()


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def resolve_device(cfg: dict) -> str:
    requested = str(cfg.get("runtime", {}).get("device", "auto")).lower()
    if requested == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    if requested.startswith("cuda") and not torch.cuda.is_available():
        print("[WARN] CUDA was requested but is not available. Falling back to CPU.")
        return "cpu"
    return requested


def model_wire_payload(payload_type: str, r: int, model_hash_value: str, model_bytes: bytes, extra: dict | None = None) -> bytes:
    meta = {
        "payload_type": payload_type,
        "r": r,
        "modelHash": model_hash_value,
        "modelBytesLength": len(model_bytes),
        "modelBytesSha256": hashlib.sha256(model_bytes).hexdigest(),
    }
    if extra:
        meta.update(extra)
    meta_bytes = canonical_json_bytes(meta)
    return len(meta_bytes).to_bytes(8, byteorder="big", signed=False) + meta_bytes + model_bytes


def merkle_root_for_ids(ids: List[int], label: str = "D") -> str:
    leaves = [bytes32_hex({"set": label, "i": int(i)}) for i in sorted(ids)]
    return MerkleTree(leaves).root


def is_attack(cfg: dict, scenario: str, r: int, name: str) -> bool:
    attack_round = int(cfg.get("attack", {}).get("round", 1))
    return scenario == name and r == attack_round


def mark_detected(stage: str, reason: str, r: int, attack_executed: bool = True):
    raise AttackDetected(stage=stage, reason=reason, round_id=r, attack_executed=attack_executed)


def run_once(cfg: dict, scenario: str, out_dir: Path) -> Dict[str, Any]:
    set_seed(int(cfg.get("seed", 42)))
    device = resolve_device(cfg)
    timer = TimerRecorder()
    comm = CommunicationProfiler(cfg)

    attack_cfg = cfg.get("attack", {}) or {}
    attack_round = int(attack_cfg.get("round", 1))
    target_client = int(attack_cfg.get("target_client", 2))
    print(f"[attack] scenario={scenario}, attack_round={attack_round}, target_client=C{target_client}")
    print(f"[runtime] torch_device={device}, cuda_available={torch.cuda.is_available()}")

    train_loaders, test_loader, partitions = make_loaders(cfg)
    model = make_model(cfg["model"]["name"])
    dim = int(get_vector(model).numel())
    clients = [Client(cid=i) for i in range(1, int(cfg["federated"]["clients"]) + 1)]
    clients_by_id = {c.cid: c for c in clients}
    kgc = KGC()
    cs = ServerCS()
    client_pubkeys = {c.cid: c.public_key for c in clients}

    with timer.record(0, "setup", "KGC parameters, Paillier, Pedersen, InitTx"):
        setup = kgc.setup(clients, model, cfg)
    init_tx = setup["initTx"]
    pkey = setup["paillier"]
    ped_params = setup["pedersen"]
    U = setup["U"]
    Uroot = setup["Uroot"]

    init_ok = verify_init(init_tx, kgc.public_key, setup["sysPara"])
    if not init_ok:
        raise RuntimeError("InitTx verification failed")

    metrics_rows: List[Dict[str, Any]] = []
    crypto_rows: List[Dict[str, Any]] = []
    audit_rows: List[Dict[str, Any]] = []
    attack_events: List[Dict[str, Any]] = []
    final_txs = []
    trace = {
        "initTx": init_tx.__dict__,
        "rounds": [],
        "attack": {"scenario": scenario, "round": attack_round, "target_client": target_client},
        "runtime": {"device": device, "parallel_clients": cfg.get("runtime", {}).get("parallel_clients", False)},
    }

    detected: Optional[AttackDetected] = None
    attack_executed = False
    prev_audit_root = init_tx.auditRoot0
    current_model_hash = init_tx.modelHash0
    for c in clients:
        c.receive_model_broadcast(model, current_model_hash)

    rounds = int(cfg["federated"]["rounds"])
    total_samples = sum(len(loader.dataset) for loader in train_loaders.values())
    dropout_cfg = cfg["federated"].get("dropout", {}) or {}

    loss0, acc0 = evaluate(model, test_loader, device=device)
    metrics_rows.append({"round": 0, "test_loss": loss0, "test_accuracy": acc0, "effective_clients": 0, "dropout_clients": 0})

    try:
        for r in range(1, rounds + 1):
            print(f"\n========== ROUND {r} / scenario={scenario} ==========")
            round_trace = {"round": r}
            W_r_vec = get_vector(model).clone().double()
            with timer.record(r, "round_init", "alpha, zero-sum masks, zero-sum rho"):
                alpha, masks, rhos = kgc.init_round(r, current_model_hash, U, Uroot, dim, ped_params, int(cfg.get("seed", 42)))
            round_trace["alpha"] = alpha

            for cid in U:
                mask_payload = {"r": r, "i": cid, "alpha": alpha, "m": masks[cid].tolist(), "rho": str(rhos[cid])}
                comm.record(r, f"KGC->C{cid}", "MaskMsg", payload=mask_payload, note="private mask and Pedersen randomness")

            drop_ids = set(dropout_cfg.get(r, dropout_cfg.get(str(r), [])) or [])
            up_msgs = []
            client_stats = []
            active_clients = [c for c in clients if c.cid not in drop_ids]
            model_sync_events = []
            current_model_bytes = serialize_model_state(model)

            for c in active_clients:
                old_hash = c.local_model_hash
                sync_performed = c.needs_model_sync(current_model_hash)
                if sync_performed:
                    sync_req = c.make_model_sync_request(r, current_model_hash)
                    comm.record(r, f"C{c.cid}->CS", "ModelSyncReq", payload=sync_req, note="client requests current model because local hash is stale")
                    sync_payload = model_sync_signed_payload(r, c.cid, current_model_hash, current_model_bytes)
                    sig_sync_cs = sign_obj(cs.keypair.private_key, sync_payload)
                    sync_resp = {
                        "r": r,
                        "client_id": c.cid,
                        "modelHash": current_model_hash,
                        "modelBytesLength": sync_payload["modelBytesLength"],
                        "modelBytesSha256": sync_payload["modelBytesSha256"],
                        "modelBytes": current_model_bytes,
                        "sigSyncCS": sig_sync_cs,
                    }
                    sync_resp_wire = model_wire_payload(
                        "ModelSyncResp", r, current_model_hash, current_model_bytes,
                        extra={"client_id": c.cid, "modelBytesLength": sync_payload["modelBytesLength"], "modelBytesSha256": sync_payload["modelBytesSha256"], "sigSyncCS": sig_sync_cs},
                    )

                    if is_attack(cfg, scenario, r, "fake_model_sync_resp") and c.cid == target_client:
                        attack_executed = True
                        sync_resp = dict(sync_resp)
                        # Keep the model bytes intact but forge the signature. This directly tests the client-side ModelSyncResp check.
                        sync_resp["sigSyncCS"] = "00" + str(sync_resp["sigSyncCS"])[2:]
                        sync_resp_wire = model_wire_payload(
                            "ModelSyncResp.FORGED", r, current_model_hash, current_model_bytes,
                            extra={"client_id": c.cid, "sigSyncCS": sync_resp["sigSyncCS"]},
                        )
                        attack_events.append({"round": r, "scenario": scenario, "stage": "model_sync", "target": c.cid, "action": "forged sigSyncCS"})

                    comm.record(r, f"CS->C{c.cid}", "ModelSyncResp", payload=sync_resp_wire, note="signed current round model bytes for stale reconnecting client")
                    try:
                        c.sync_model_from_server(sync_resp, model_template=model, cs_public_key=cs.public_key)
                    except Exception as e:
                        if scenario == "fake_model_sync_resp" and c.cid == target_client:
                            mark_detected("client_model_sync_verify", str(e), r, attack_executed=True)
                        raise
                model_sync_events.append({
                    "round": r,
                    "client_id": c.cid,
                    "old_local_model_hash": old_hash,
                    "target_modelHash_r": current_model_hash,
                    "sync_performed": sync_performed,
                    "sigSyncCS_verified": True if sync_performed else False,
                })
            round_trace["modelSync"] = model_sync_events

            def _client_upload(c: Client):
                return c.make_upload(
                    r, alpha, current_model_hash, c.local_model, train_loaders[c.cid], total_samples, cfg,
                    masks[c.cid], rhos[c.cid], pkey.public, ped_params, timer=timer, device=device,
                )

            parallel_clients = bool(cfg.get("runtime", {}).get("parallel_clients", False))
            max_workers = int(cfg.get("runtime", {}).get("max_client_workers", len(active_clients) or 1))
            if parallel_clients and len(active_clients) > 1:
                with timer.record(r, "client_upload_parallel_wall", "wall-clock time for parallel client upload generation"):
                    with ThreadPoolExecutor(max_workers=max_workers) as ex:
                        futures = {ex.submit(_client_upload, c): c.cid for c in active_clients}
                        for fut in as_completed(futures):
                            msg, stat = fut.result()
                            up_msgs.append(msg)
                            client_stats.append(stat)
            else:
                with timer.record(r, "client_upload_sequential_wall", "wall-clock time for sequential client upload generation"):
                    for c in active_clients:
                        msg, stat = _client_upload(c)
                        up_msgs.append(msg)
                        client_stats.append(stat)

            up_msgs = sorted(up_msgs, key=lambda m: int(m["i"]))
            client_stats = sorted(client_stats, key=lambda z: int(z["cid"]))
            for msg in up_msgs:
                cid = int(msg["i"])
                up_size = json_size_bytes(msg)
                comm.record(r, f"C{cid}->CS", "UpMsg", bytes_count=up_size, note="ciphertext vector, commitment, receipt and signature")
                comm.record(r, f"C{cid}->KGC", "UpMsg", bytes_count=up_size, note="copy for KGC-side upload verification")

            with timer.record(r, "kgc_upload_verify", "signatures and rootUp"):
                valid_msgs, root_up = kgc.verify_uploads_and_root(r, up_msgs, client_pubkeys)
            U_r_kgc = sorted([int(m["i"]) for m in valid_msgs])
            D_r_kgc = sorted(list(set(U) - set(U_r_kgc)))

            # CS-side claimed set. For normal execution it matches KGC. For forged_dropout_set, CS claims an inconsistent dropout set.
            D_r_cs_claim = list(D_r_kgc)
            if is_attack(cfg, scenario, r, "forged_dropout_set"):
                attack_executed = True
                if target_client in D_r_cs_claim:
                    D_r_cs_claim = sorted([x for x in D_r_cs_claim if x != target_client])
                    action = f"remove C{target_client} from CS dropout claim"
                else:
                    D_r_cs_claim = sorted(D_r_cs_claim + [target_client])
                    action = f"add C{target_client} to CS dropout claim"
                attack_events.append({"round": r, "scenario": scenario, "stage": "dropout_set", "target": target_client, "action": action})

            rootD_kgc = merkle_root_for_ids(D_r_kgc, label="D_kgc")
            # Use same label intentionally for semantic comparison of the set, not of the role name.
            rootD_cs = merkle_root_for_ids(D_r_cs_claim, label="D_kgc")
            if rootD_cs != rootD_kgc:
                mark_detected(
                    "dropout_set_consistency",
                    f"CS and KGC dropout sets differ: D_cs={D_r_cs_claim}, D_kgc={D_r_kgc}, rootD_cs={rootD_cs[:18]}..., rootD_kgc={rootD_kgc[:18]}...",
                    r,
                    attack_executed=attack_executed,
                )

            round_trace["U_r_kgc"] = U_r_kgc
            round_trace["D_r_kgc"] = D_r_kgc
            round_trace["rootUp"] = root_up
            round_trace["rootD"] = rootD_kgc

            with timer.record(r, "kgc_compensation", "mDrop, rhoDrop, Cdrop, ComDrop"):
                m_drop, rho_drop, cdrop, com_drop = kgc.make_compensation(r, D_r_kgc, pkey.public, ped_params)
            drop_payload = {"r": r, "alpha": alpha, "D": D_r_kgc, "rootD": rootD_kgc, "identityOptimized": len(D_r_kgc) == 0, "Cdrop": [] if len(D_r_kgc) == 0 else [str(c) for c in cdrop], "ComDrop": str(com_drop)}
            comm.record(r, "KGC->CS", "DropMsg", payload=drop_payload, note="dropout compensation; compact identity when no dropout")

            cs_valid_msgs = list(valid_msgs)
            if is_attack(cfg, scenario, r, "omit_uploaded_client"):
                before = len(cs_valid_msgs)
                cs_valid_msgs = [m for m in cs_valid_msgs if int(m["i"]) != target_client]
                if len(cs_valid_msgs) != before:
                    attack_executed = True
                    attack_events.append({"round": r, "scenario": scenario, "stage": "cs_aggregate_input", "target": target_client, "action": "omit a valid UpMsg from CS aggregation only"})
                else:
                    attack_events.append({"round": r, "scenario": scenario, "stage": "cs_aggregate_input", "target": target_client, "action": "target was not valid; no omission executed"})

            with timer.record(r, "cs_aggregate", "Craw/Cagg and ComRaw/ComAgg"):
                craw, cagg, com_raw, com_agg = cs.aggregate(cs_valid_msgs, cdrop, com_drop, pkey.public, ped_params)

            if is_attack(cfg, scenario, r, "tamper_aggregate"):
                attack_executed = True
                # Multiply by g, i.e. add 1 to the first Paillier plaintext coordinate without updating ComAgg.
                cagg = list(cagg)
                cagg[0] = (int(cagg[0]) * int(pkey.public.g)) % int(pkey.public.n2)
                attack_events.append({"round": r, "scenario": scenario, "stage": "aggregate_ciphertext", "target": 0, "action": "add +1 to first aggregate ciphertext coordinate"})

            cagg_hash = bytes32_hex([str(c) for c in cagg])
            agg_payload = {"r": r, "alpha": alpha, "rootUp": root_up, "CaggHash": cagg_hash, "ComAgg": str(com_agg)}
            sig_agg = sign_obj(cs.keypair.private_key, agg_payload)
            if not verify_obj(cs.public_key, sig_agg, agg_payload):
                raise RuntimeError("sigAgg failed")
            agg_msg_payload = {"r": r, "alpha": alpha, "rootUp": root_up, "Cagg": [str(c) for c in cagg], "CaggHash": cagg_hash, "ComAgg": str(com_agg), "sigAgg": sig_agg}
            agg_size = json_size_bytes(agg_msg_payload)
            for cid in U_r_kgc:
                comm.record(r, f"CS->C{cid}", "AggMsg", bytes_count=agg_size, note="aggregate ciphertext vector for partial decryption")
            comm.record(r, "CS->KGC", "AggMsg", bytes_count=agg_size, note="aggregate transcript for KGC checking")

            with timer.record(r, "share_generation", "threshold shares"):
                share_msgs = [c.make_decryption_share(r, alpha, cagg_hash) for c in clients if c.cid not in drop_ids]
            for sm in share_msgs:
                cid = int(sm["ShareMsg"]["j"])
                comm.record(r, f"C{cid}->CS", "ShareMsg", payload=sm, note="threshold decryption share message")

            with timer.record(r, "combine_decrypt", "Shamir reconstruct lambda and decrypt aggregate vector"):
                xagg, used_shares = cs.recover_lambda_and_decrypt(
                    share_msgs, client_pubkeys, setup["shareField"], int(cfg["federated"]["threshold"]), pkey, cagg, r, alpha
                )

            try:
                with timer.record(r, "cs_open_check", "ComAgg == PedCom(xAgg;0)"):
                    com_check = pedersen.commit(ped_params, xagg.tolist(), 0)
                    if com_check != com_agg:
                        raise RuntimeError(f"CS open check failed: ComAgg != PedCom(xAgg;0); ComCheck={str(com_check)[:18]}..., ComAgg={str(com_agg)[:18]}...")
            except Exception as e:
                if scenario in {"omit_uploaded_client", "tamper_aggregate"}:
                    mark_detected("cs_open_check", str(e), r, attack_executed=attack_executed)
                raise

            with timer.record(r, "model_update", "apply decoded aggregate update"):
                update = torch.tensor(dequantize(xagg, int(cfg["encoding"]["scale"])), dtype=torch.float64)
                W_next_vec = W_r_vec + float(cfg["federated"].get("server_lr", 1.0)) * update
                set_vector(model, W_next_vec)

                if is_attack(cfg, scenario, r, "wrong_model_publish"):
                    attack_executed = True
                    tampered_vec = get_vector(model).clone().double()
                    tampered_vec[0] = tampered_vec[0] + 0.001
                    set_vector(model, tampered_vec)
                    attack_events.append({"round": r, "scenario": scenario, "stage": "model_publish", "target": 0, "action": "publish W_next with first coordinate offset +0.001"})

                model_hash_next = bytes32_hex(get_vector(model).numpy().tolist())

            model_payload = {"r": r, "alpha": alpha, "modelHashR": current_model_hash, "modelHashNext": model_hash_next, "CaggHash": cagg_hash, "ComAgg": str(com_agg)}
            sig_model = sign_obj(cs.keypair.private_key, model_payload)
            if not verify_obj(cs.public_key, sig_model, model_payload):
                raise RuntimeError("sigModel failed")

            next_model_bytes = serialize_model_state(model)
            model_msg_wire = model_wire_payload("ModelMsg", r, model_hash_next, next_model_bytes, extra={"modelHashR": current_model_hash, "CaggHash": cagg_hash, "sigModel": sig_model})
            comm.record(r, "CS->KGC", "ModelMsg", payload=model_msg_wire, note="model hashes plus serialized W_next state_dict")
            for cid in U_r_kgc:
                broadcast_wire = model_wire_payload("ModelBroadcast", r, model_hash_next, next_model_bytes, extra={"modelHashR": current_model_hash, "client_id": cid, "sigModel": sig_model})
                comm.record(r, f"CS->C{cid}", "ModelBroadcast", payload=broadcast_wire, note="new global model broadcast with serialized W_next state_dict")
                clients_by_id[cid].receive_model_broadcast(model, model_hash_next)

            try:
                with timer.record(r, "kgc_final_model_check", "model diff -> xModel -> PedCom check"):
                    u_model = (get_vector(model).double() - W_r_vec) / float(cfg["federated"].get("server_lr", 1.0))
                    x_model = quantize(u_model.numpy(), int(cfg["encoding"]["scale"]))
                    diff = np.abs(x_model - xagg)
                    mismatch = int((diff != 0).sum())
                    if mismatch != 0:
                        raise RuntimeError(f"KGC model diff encoding mismatch at {mismatch} coordinates")
                    if pedersen.commit(ped_params, x_model.tolist(), 0) != com_agg:
                        raise RuntimeError("KGC model differential commitment check failed")
            except Exception as e:
                if scenario == "wrong_model_publish":
                    mark_detected("kgc_final_model_check", str(e), r, attack_executed=attack_executed)
                raise

            with timer.record(r, "kgc_final_tx", "auditRoot and FinalTx"):
                final_tx = kgc.final_confirm(r, alpha, root_up, com_agg, current_model_hash, model_hash_next, prev_audit_root)
                final_txs.append(final_tx)
                prev_audit_root = final_tx.auditRoot
                current_model_hash = model_hash_next

            loss, acc = evaluate(model, test_loader, device=device)
            metrics_rows.append({"round": r, "test_loss": loss, "test_accuracy": acc, "effective_clients": len(U_r_kgc), "dropout_clients": len(D_r_kgc)})
            audit_rows.append({"round": r, "alpha": alpha, "rootUp": root_up, "rootD": rootD_kgc, "ComAggHash": final_tx.ComAggHash, "modelHashR": final_tx.modelHashR, "modelHashNext": final_tx.modelHashNext, "auditRoot": final_tx.auditRoot, "sigFinal_len": len(final_tx.sigFinal)})
            compensation_encryptions = dim if len(D_r_kgc) > 0 else 0
            compensation_commitments = 1 if len(D_r_kgc) > 0 else 0
            crypto_rows.extend([
                {"round": r, "metric": "model_dimension", "value": dim},
                {"round": r, "metric": "model_name", "value": cfg["model"]["name"]},
                {"round": r, "metric": "effective_clients", "value": len(U_r_kgc)},
                {"round": r, "metric": "dropout_clients", "value": len(D_r_kgc)},
                {"round": r, "metric": "pedersen_commitments", "value": len(U_r_kgc) + compensation_commitments + 2},
                {"round": r, "metric": "paillier_encryptions", "value": len(U_r_kgc) * dim + compensation_encryptions},
                {"round": r, "metric": "paillier_ciphertexts_aggregated", "value": len(U_r_kgc) * dim},
                {"round": r, "metric": "compensation_encryptions", "value": compensation_encryptions},
                {"round": r, "metric": "compensation_identity_optimized", "value": 1 if len(D_r_kgc) == 0 else 0},
            ])
            round_trace.update({"rootUp": root_up, "rootD": rootD_kgc, "ComAggHash": final_tx.ComAggHash, "modelHashNext": model_hash_next, "auditRoot": final_tx.auditRoot, "clientStats": client_stats})
            trace["rounds"].append(round_trace)
            print(f"round={r}, acc={acc:.4f}, effective={len(U_r_kgc)}, dropout={D_r_kgc}, auditRoot={final_tx.auditRoot[:18]}...")

        if scenario == "forged_finaltx" and final_txs:
            idx = max(0, min(int(attack_cfg.get("round", 1)) - 1, len(final_txs) - 1))
            attack_executed = True
            final_txs[idx].modelHashNext = bytes32_hex({"forged": True, "scenario": scenario, "round": idx + 1, "time": time.time()})
            attack_events.append({"round": idx + 1, "scenario": scenario, "stage": "finaltx", "target": "modelHashNext", "action": "tamper FinalTx after KGC signature"})

        chain_ok = verify_chain(init_tx, final_txs, kgc.public_key)
        if scenario == "forged_finaltx" and not chain_ok:
            detected = AttackDetected("third_party_chain_verify", "verify_chain rejected forged FinalTx/audit chain", int(attack_cfg.get("round", 1)), attack_executed=True)
        elif scenario == "normal" and chain_ok:
            detected = None
        elif scenario != "normal" and not chain_ok:
            detected = AttackDetected("third_party_chain_verify", "verify_chain rejected the chain", int(attack_cfg.get("round", 1)), attack_executed=attack_executed)

    except AttackDetected as e:
        detected = e
        print(f"[DETECTED] scenario={scenario}, stage={e.stage}, round={e.round_id}, reason={e.reason}")
    except Exception as e:
        # Unexpected failures are still written to disk so the shell suite can continue and you can debug.
        detected = AttackDetected("unexpected_exception", f"{type(e).__name__}: {e}", int(attack_cfg.get("round", 1)), attack_executed=attack_executed)
        trace["unexpected_exception"] = traceback.format_exc()
        print(trace["unexpected_exception"])

    if scenario == "normal":
        accepted = verify_chain(init_tx, final_txs, kgc.public_key) if final_txs else False
        detected_bool = False
    else:
        accepted = False if detected is not None else verify_chain(init_tx, final_txs, kgc.public_key)
        detected_bool = detected is not None and detected.stage != "unexpected_exception"

    result = {
        "scenario": scenario,
        "expected_stage": EXPECTED_STAGE.get(scenario, ""),
        "attack_round": attack_round,
        "target_client": target_client,
        "attack_executed": bool(attack_executed or scenario == "normal"),
        "detected": bool(detected_bool),
        "accepted": bool(accepted),
        "detection_round": detected.round_id if detected else "",
        "detection_stage": detected.stage if detected else "",
        "reason": detected.reason if detected else "normal execution accepted" if scenario == "normal" else "attack was not detected",
        "rounds_completed": len(final_txs),
        "model_dimension": dim,
        "paillier_bits": int(cfg["crypto"].get("paillier_bits", 0)),
    }

    verify_rows = [{"accepted": accepted, "detected": detected_bool, "scenario": scenario, "rounds": len(final_txs), "latestAuditRoot": final_txs[-1].auditRoot if final_txs else init_tx.auditRoot0}]
    save_csv(metrics_rows, out_dir / "metrics_round.csv")
    save_csv(timer.rows, out_dir / "runtime_cost.csv")
    save_csv(crypto_rows, out_dir / "crypto_cost.csv")
    save_csv(comm.rows, out_dir / "communication_cost.csv")
    save_csv(audit_rows, out_dir / "audit_chain.csv")
    save_csv(verify_rows, out_dir / "verify_result.csv")
    save_csv([result], out_dir / "attack_result.csv")
    save_csv(attack_events, out_dir / "attack_events.csv")
    save_excel({
        "metrics_round": metrics_rows,
        "runtime_cost": timer.rows,
        "crypto_cost": crypto_rows,
        "communication_cost": comm.rows,
        "audit_chain": audit_rows,
        "verify_result": verify_rows,
        "attack_result": [result],
        "attack_events": attack_events,
    }, out_dir / "summary_tables.xlsx")
    trace["attack_result"] = result
    trace["attack_events"] = attack_events
    save_json(trace, out_dir / "run_trace.json")
    print(f"[RESULT] {result}")
    print(f"Outputs saved to: {out_dir}")
    return result


def main():
    args = parse_args()
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    cfg.setdefault("attack", {})
    if args.scenario is not None:
        cfg["attack"]["scenario"] = args.scenario
    if args.attack_round is not None:
        cfg["attack"]["round"] = int(args.attack_round)
    if args.target_client is not None:
        cfg["attack"]["target_client"] = int(args.target_client)
    if args.rounds is not None:
        cfg.setdefault("federated", {})["rounds"] = int(args.rounds)
    if args.paillier_bits is not None:
        cfg.setdefault("crypto", {})["paillier_bits"] = int(args.paillier_bits)
    if args.device is not None:
        cfg.setdefault("runtime", {})["device"] = args.device

    scenario = str(cfg.get("attack", {}).get("scenario", "normal"))
    if scenario not in SUPPORTED_SCENARIOS:
        raise ValueError(f"Unsupported scenario {scenario}; choose one of {sorted(SUPPORTED_SCENARIOS)}")

    if args.output_dir is not None:
        out_dir = ensure_dir(args.output_dir)
    else:
        base = Path(cfg.get("output_dir", "outputs/attack_detection"))
        out_dir = ensure_dir(base / scenario)
    run_once(cfg, scenario, out_dir)


if __name__ == "__main__":
    main()
