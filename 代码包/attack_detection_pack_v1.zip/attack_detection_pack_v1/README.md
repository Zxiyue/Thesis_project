# Ours 攻击检测实验代码包 v1

本包用于在现有 `/root/fpa5` 环境中补充“恶意服务器攻击检测 / 公开审计有效性”实验，不覆盖主流程 `run.py`，只新增一个独立 runner：

- `scripts/run_attack_detection.py`
- `configs/attack_detection_mnist_iid_quick.yaml`
- `configs/attack_detection_mnist_iid_p2048.yaml`

## 实验场景

| scenario | 攻击含义 | 预期检测点 |
|---|---|---|
| `normal` | 无攻击控制组 | 第三方链式验证通过 |
| `omit_uploaded_client` | CS 在聚合时遗漏一个已上传客户端 | `cs_open_check` |
| `forged_dropout_set` | CS 伪造/篡改掉线集合 | `dropout_set_consistency` |
| `tamper_aggregate` | CS 篡改聚合密文但不更新承诺 | `cs_open_check` |
| `wrong_model_publish` | CS 发布与聚合结果不一致的新模型 | `kgc_final_model_check` |
| `fake_model_sync_resp` | CS 对恢复客户端返回伪造模型同步响应 | `client_model_sync_verify` |
| `forged_finaltx` | 链上 FinalTx 被篡改或伪造 | `third_party_chain_verify` |

## 快速运行

```bash
cd /root
unzip -o attack_detection_pack_v1.zip
cd /root/attack_detection_pack_v1

# 默认 quick：MNIST-IID，3轮，5客户端，Paillier 512-bit，用于快速验证审计逻辑
stdbuf -oL -eL bash scripts/run_attack_detection_suite.sh \
  | tee /root/attack_detection_suite_v1.log
```

结果包：

```text
/root/attack_detection_mnist_iid_suite_results.zip
```

查看状态：

```bash
bash /root/attack_detection_pack_v1/scripts/check_attack_detection_status.sh
```

## 2048-bit 复跑

quick 版用于快速检查代码和审计逻辑。论文中若要保持与主实验安全参数一致，可以复跑 2048-bit：

```bash
cd /root/attack_detection_pack_v1
CONFIG=configs/attack_detection_mnist_iid_p2048.yaml \
PAILLIER_BITS=2048 \
BASE_OUT=outputs/attack_detection_mnist_iid_p2048_suite \
stdbuf -oL -eL bash scripts/run_attack_detection_suite.sh \
  | tee /root/attack_detection_suite_p2048_v1.log
```

由于多数攻击在第 1 轮即被检测，2048-bit 版本不会像 50 轮主实验那样耗时，但仍建议在 `tmux` 中运行。

## 单独运行某一个攻击

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

python scripts/run_attack_detection.py \
  --config configs/attack_detection_mnist_iid_quick.yaml \
  --scenario omit_uploaded_client \
  --attack-round 1 \
  --target-client 2 \
  --output-dir outputs/attack_detection_single/omit_uploaded_client
```

## 输出文件

每个场景目录中会生成：

| 文件 | 内容 |
|---|---|
| `attack_result.csv` | 最关键，记录是否检测到攻击、检测阶段、原因 |
| `attack_events.csv` | 攻击注入动作记录 |
| `verify_result.csv` | 最终 accepted/detected |
| `runtime_cost.csv` | 各阶段耗时 |
| `communication_cost.csv` | 逻辑通信记录 |
| `audit_chain.csv` | 正常执行到 FinalTx 的审计链记录 |
| `run_trace.json` | 详细过程追踪 |

汇总文件位于：

```text
outputs/attack_detection_mnist_iid_suite/attack_detection_summary.csv
outputs/attack_detection_mnist_iid_suite/attack_detection_summary.md
```
