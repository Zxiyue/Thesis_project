from __future__ import annotations
import argparse
import csv
import json
import zipfile
from pathlib import Path
from typing import Dict, List


def read_csv_rows(path: Path) -> List[Dict[str, str]]:
    if not path.exists() or path.stat().st_size == 0:
        return []
    with path.open("r", encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: List[Dict[str, object]]):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list(rows[0].keys())
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for row in rows:
            w.writerow(row)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-dir", required=True)
    ap.add_argument("--zip-out", default="/root/attack_detection_mnist_iid_suite_results.zip")
    args = ap.parse_args()
    base = Path(args.base_dir).resolve()
    rows: List[Dict[str, object]] = []
    for result_file in sorted(base.glob("*/attack_result.csv")):
        rs = read_csv_rows(result_file)
        if rs:
            row = rs[0]
            row["result_dir"] = str(result_file.parent)
            rows.append(row)
    summary_csv = base / "attack_detection_summary.csv"
    write_csv(summary_csv, rows)
    summary_json = base / "attack_detection_summary.json"
    summary_json.write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")

    md = base / "attack_detection_summary.md"
    lines = ["# Attack Detection Suite Summary", "", f"Base directory: `{base}`", ""]
    if rows:
        headers = ["scenario", "attack_executed", "detected", "accepted", "detection_stage", "detection_round", "expected_stage", "reason"]
        lines.append("| " + " | ".join(headers) + " |")
        lines.append("|" + "|".join(["---"] * len(headers)) + "|")
        for r in rows:
            vals = [str(r.get(h, "")).replace("|", "/") for h in headers]
            lines.append("| " + " | ".join(vals) + " |")
    else:
        lines.append("No attack_result.csv files found.")
    md.write_text("\n".join(lines) + "\n", encoding="utf-8")

    zip_out = Path(args.zip_out)
    with zipfile.ZipFile(zip_out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(base.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(base.parent))
    print(f"[OK] summary_csv={summary_csv}")
    print(f"[OK] zip={zip_out}")


if __name__ == "__main__":
    main()
