#!/usr/bin/env bash
set -euo pipefail
FPA_DIR="${FPA_DIR:-/root/fpa5}"
BASE_OUT="${BASE_OUT:-outputs/attack_detection_mnist_iid_suite}"
cd "$FPA_DIR"
echo "[status] base: $FPA_DIR/$BASE_OUT"
for d in "$BASE_OUT"/*; do
  [[ -d "$d" ]] || continue
  echo "--- $d ---"
  if [[ -f "$d/attack_result.csv" ]]; then
    cat "$d/attack_result.csv"
  else
    echo "attack_result.csv not found"
  fi
done
