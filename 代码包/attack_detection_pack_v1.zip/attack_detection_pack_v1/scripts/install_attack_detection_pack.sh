#!/usr/bin/env bash
set -euo pipefail

FPA_DIR="${FPA_DIR:-/root/fpa5}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ ! -d "$FPA_DIR" ]]; then
  echo "[ERROR] FPA_DIR not found: $FPA_DIR"
  echo "Please set FPA_DIR=/path/to/fpa5 and rerun."
  exit 1
fi

mkdir -p "$FPA_DIR/scripts" "$FPA_DIR/configs"
cp -f "$PACK_DIR/fpa5_patch/scripts/run_attack_detection.py" "$FPA_DIR/scripts/run_attack_detection.py"
cp -f "$PACK_DIR/fpa5_patch/configs/attack_detection_mnist_iid_quick.yaml" "$FPA_DIR/configs/attack_detection_mnist_iid_quick.yaml"
cp -f "$PACK_DIR/fpa5_patch/configs/attack_detection_mnist_iid_p2048.yaml" "$FPA_DIR/configs/attack_detection_mnist_iid_p2048.yaml"
chmod +x "$FPA_DIR/scripts/run_attack_detection.py" || true

echo "[OK] Attack detection runner installed into $FPA_DIR"
echo "     - scripts/run_attack_detection.py"
echo "     - configs/attack_detection_mnist_iid_quick.yaml"
echo "     - configs/attack_detection_mnist_iid_p2048.yaml"
