#!/usr/bin/env bash
set -euo pipefail

FPA_DIR="${FPA_DIR:-/root/fpa5}"
PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${CONFIG:-configs/attack_detection_mnist_iid_quick.yaml}"
PAILLIER_BITS="${PAILLIER_BITS:-}"
DEVICE="${DEVICE:-cpu}"
ROUNDS="${ROUNDS:-3}"
BASE_OUT="${BASE_OUT:-outputs/attack_detection_mnist_iid_suite}"

bash "$PACK_DIR/scripts/install_attack_detection_pack.sh"
cd "$FPA_DIR"
export PYTHONPATH="$FPA_DIR:${PYTHONPATH:-}"

if [[ -d .venv ]]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

mkdir -p "$BASE_OUT"

run_one() {
  local scenario="$1"
  local attack_round="$2"
  local target_client="$3"
  local out_dir="$BASE_OUT/$scenario"
  local cmd=(python scripts/run_attack_detection.py --config "$CONFIG" --scenario "$scenario" --attack-round "$attack_round" --target-client "$target_client" --rounds "$ROUNDS" --device "$DEVICE" --output-dir "$out_dir")
  if [[ -n "$PAILLIER_BITS" ]]; then
    cmd+=(--paillier-bits "$PAILLIER_BITS")
  fi
  echo
  echo "================ RUN $scenario ================"
  echo "${cmd[*]}"
  "${cmd[@]}" 2>&1 | tee "$out_dir.log"
}

# Normal control run: should be accepted=True and detected=False.
run_one normal 1 2

# Malicious-server attacks. Most stop at round 1; fake_model_sync_resp needs R2 dropout and R3 recovery.
run_one omit_uploaded_client 1 2
run_one forged_dropout_set 1 2
run_one tamper_aggregate 1 2
run_one wrong_model_publish 1 2
run_one fake_model_sync_resp 3 2
run_one forged_finaltx 2 2

python "$PACK_DIR/scripts/summarize_attack_detection_results.py" --base-dir "$FPA_DIR/$BASE_OUT" --zip-out "/root/attack_detection_mnist_iid_suite_results.zip"

echo

echo "[DONE] Results package: /root/attack_detection_mnist_iid_suite_results.zip"
