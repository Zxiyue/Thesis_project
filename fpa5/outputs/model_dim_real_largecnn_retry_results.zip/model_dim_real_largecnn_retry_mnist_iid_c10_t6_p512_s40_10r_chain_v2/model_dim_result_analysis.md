# Model Dimension Multiprocess Experiment Summary


Synthetic cases are dimension-only padded-vector workloads and should not be used for accuracy comparison.


## All cases


| dimension_group | case_label | case | model | model_dim_actual | clients | threshold | rounds_completed | total_comm_MB | comm_MB_per_round |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| real | largecnn | d080602_real_largecnn | MNIST | 80602 | 10 | 6 | 0 | 5173.9063 | 517.3906 |

## real cases


| dimension_group | case_label | case | model | model_dim_actual | clients | threshold | rounds_completed | total_comm_MB | comm_MB_per_round |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| real | largecnn | d080602_real_largecnn | MNIST | 80602 | 10 | 6 | 0 | 5173.9063 | 517.3906 |