# Threshold t Multiprocess Summary

- Base dir: `/root/fpa5/outputs/threshold_t_multiprocess_mnist_iid_c20_p512_s40_10r_chain`
- Runs: 5
- Accepted runs: 5/5

## Key table

| case | clients | threshold | rounds_completed | accepted | total_comm_MB | comm_MB_per_round | comm_MB_AggMsg | init_tx_gas | finaltx_count | avg_finaltx_gas | total_gas | runtime_numeric_sum | crypto_numeric_sum |
| ---- | ------- | --------- | ---------------- | -------- | ------------- | ----------------- | -------------- | ----------- | ------------- | --------------- | --------- | ------------------- | ------------------ |
| t04  | 20      | 4         | 0                | True     | 1240.5849     | 1240.5849         | 402.7674       | 82006       | 10            | 52177.4000      | 603780    | 8166.4187           | 2785970.0000       |
| t08  | 20      | 8         | 0                | True     | 1242.0725     | 1242.0725         | 403.2629       | 81994       | 10            | 52179.8000      | 603792    | 8017.8631           | 2785970.0000       |
| t12  | 20      | 12        | 0                | True     | 1240.9128     | 1240.9128         | 402.8747       | 81994       | 10            | 52179.8000      | 603792    | 8284.8995           | 2785970.0000       |
| t16  | 20      | 16        | 0                | True     | 1240.0091     | 1240.0091         | 402.5772       | 82006       | 10            | 52179.8000      | 603804    | 8146.6891           | 2785970.0000       |
| t20  | 20      | 20        | 0                | True     | 1241.0540     | 1241.0540         | 402.9204       | 82006       | 10            | 52182.2000      | 603828    | 7841.4822           | 2785970.0000       |


## Notes

- Final protocol verdict uses `verify_result.csv` / `accepted`. Some `run_trace.json` files do not contain top-level `accepted`.
- If every online client sends a decryption share in the implementation, total share communication may not vary strongly with t. In that case, use Combine/recovery runtime and the security-availability tradeoff as the main t-related evidence.
- Chain cost is expected to remain nearly stable because the chain writes fixed InitTx/FinalTx declarations, not per-client decryption shares.