# Model Dimension Multiprocess Experiment Summary


Synthetic cases are dimension-only padded-vector workloads and should not be used for accuracy comparison.


## All cases


| dimension_group | case_label | case | model | model_dim_actual | clients | threshold | rounds_completed | accepted | final_accuracy | total_comm_MB | comm_MB_per_round | runtime_mean_start_experiment_total_wall | avg_finaltx_gas | total_gas |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| real | largecnn | d080602_real_largecnn | MNIST | 80602 | 10 | 6 | 10 | True | 0.9649 | 7355.628 | 735.5628 | 4950.6586 | 52176.2 | 603768 |

## real cases


| dimension_group | case_label | case | model | model_dim_actual | clients | threshold | rounds_completed | accepted | final_accuracy | total_comm_MB | comm_MB_per_round | runtime_mean_start_experiment_total_wall | avg_finaltx_gas | total_gas |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| real | largecnn | d080602_real_largecnn | MNIST | 80602 | 10 | 6 | 10 | True | 0.9649 | 7355.628 | 735.5628 | 4950.6586 | 52176.2 | 603768 |