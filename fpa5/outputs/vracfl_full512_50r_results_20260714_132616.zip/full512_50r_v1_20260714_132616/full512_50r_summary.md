# Full VRAC-FL 512-bit 50-round Summary

| Split | Accuracy | Wall excl. chain (s) | Wall incl. FinalTx (s) | Mean FinalTx Gas | Mean FinalTx latency (s) | Accepted |
|---|---:|---:|---:|---:|---:|---|
| iid | 0.9849 | 5615.3045286387205 | 5615.70887642072 | 48275.92 | 0.008086955639999999 | True |
| noniid | 0.9487 | 5959.660812273622 | 5960.094725993622 | 48278.08 | 0.0086782744 | True |
