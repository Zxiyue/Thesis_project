# Model Dimension Multiprocess Experiment Summary


Synthetic cases are dimension-only padded-vector workloads and should not be used for accuracy comparison.


## All cases


| dimension_group | case_label | case | model | model_dim_actual | clients | threshold | rounds_completed | accepted | final_accuracy | total_comm_MB | comm_MB_per_round | runtime_mean_start_experiment_total_wall | avg_finaltx_gas | total_gas |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| synthetic | syn100k | d100000_synthetic_syn100k | MNIST | 100000 | 10 | 6 | 10 | True | 0.251 | 9120.6756 | 912.0676 | 5559.9804 | 52176.2 | 603780 |

## synthetic cases


| dimension_group | case_label | case | model | model_dim_actual | clients | threshold | rounds_completed | accepted | final_accuracy | total_comm_MB | comm_MB_per_round | runtime_mean_start_experiment_total_wall | avg_finaltx_gas | total_gas |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| synthetic | syn100k | d100000_synthetic_syn100k | MNIST | 100000 | 10 | 6 | 10 | True | 0.251 | 9120.6756 | 912.0676 | 5559.9804 | 52176.2 | 603780 |