# Attack Detection Suite Summary

Base directory: `/root/fpa5/outputs/attack_detection_mnist_iid_suite`

| scenario | attack_executed | detected | accepted | detection_stage | detection_round | expected_stage | reason |
|---|---|---|---|---|---|---|---|
|  | True | True | False | client_model_sync_verify | 3 | client_model_sync_verify | client C2 rejected ModelSyncResp: invalid CS signature |
|  | True | True | False | dropout_set_consistency | 1 | dropout_set_consistency | CS and KGC dropout sets differ: D_cs=[2], D_kgc=[], rootD_cs=0x09154bc294cea160..., rootD_kgc=0xcc1d2f838445db7a... |
|  | True | True | False | third_party_chain_verify | 2 | third_party_chain_verify | verify_chain rejected forged FinalTx/audit chain |
|  | True | False | True |  |  | third_party_chain_verify_accept | normal execution accepted |
|  | True | True | False | cs_open_check | 1 | cs_open_check | CS open check failed: ComAgg != PedCom(xAgg;0); ComCheck=428693896690727395..., ComAgg=330571822494151506... |
|  | True | True | False | cs_open_check | 1 | cs_open_check | CS open check failed: ComAgg != PedCom(xAgg;0); ComCheck=165449628961211126..., ComAgg=153118312168994245... |
|  | True | True | False | kgc_final_model_check | 1 | kgc_final_model_check | KGC model diff encoding mismatch at 1 coordinates |
