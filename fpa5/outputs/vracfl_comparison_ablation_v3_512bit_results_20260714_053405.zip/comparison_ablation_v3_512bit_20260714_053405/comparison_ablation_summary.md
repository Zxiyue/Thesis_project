# Comparison and Ablation Summary

| Experiment | Rounds | Bits | Dimension | Accuracy | Total wall (s) | FinalTx Gas | FaultTx Gas | Chain |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| full_control | 20 | 512 | 6794 |  | 1949.1796280741692 | 975800 | 80546 | True |
| hash_only | 20 | 512 | 6794 |  | 1950.5524665564299 | 0 | 0 | True |
| no_faulttx | 20 | 512 | 6794 |  | 1928.5662807375193 | 975812 | 0 | True |
| no_kgc_independent_set | 20 | 512 | 6794 |  | 1955.4141854643822 | 975776 | 0 | True |
| no_modelsync_signature | 20 | 512 | 6794 |  | 1919.3455459475517 | 975800 | 0 | True |
| no_pedersen | 20 | 512 | 6794 |  | 1896.1281518042088 | 968108 | 0 | True |
| no_unit_comp_opt | 20 | 512 | 6794 |  | 2168.603058204055 | 975764 | 0 | True |
| FedAvg | 50 |  | 6794 | 0.9835 | 837.6476687788963 | 0 | 0 |  |
| FedAvg | 50 |  | 6794 | 0.9544 | 837.9054594486952 | 0 | 0 |  |
| Privacy-only | 50 | 512 | 6794 | 0.9849 | 5597.041934505105 | 0 | 0 |  |
| Privacy-only | 50 | 512 | 6794 | 0.9487 | 5515.013945952058 | 0 | 0 |  |
