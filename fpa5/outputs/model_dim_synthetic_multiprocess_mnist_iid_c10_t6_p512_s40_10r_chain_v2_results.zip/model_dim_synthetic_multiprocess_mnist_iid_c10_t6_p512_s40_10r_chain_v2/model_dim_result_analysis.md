# Model Dimension Multiprocess Experiment Summary


Synthetic cases are dimension-only padded-vector workloads and should not be used for accuracy comparison.


## All cases


| dimension_group | case_label | case | model | model_dim_actual | clients | threshold | rounds_completed | accepted | final_accuracy | total_comm_MB | comm_MB_per_round | runtime_mean_start_experiment_total_wall | avg_finaltx_gas | total_gas |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| synthetic | syn1k | d001000_synthetic_syn1k | MNIST | 1000 | 10 | 6 | 10 | True | 0.251 | 92.0896 | 9.209 | 83.9021 | 52176.2 | 603756 |
| synthetic | syn5k | d005000_synthetic_syn5k | MNIST | 5000 | 10 | 6 | 10 | True | 0.251 | 457.6682 | 45.7668 | 311.0067 | 52176.2 | 603780 |
| synthetic | syn10k | d010000_synthetic_syn10k | MNIST | 10000 | 10 | 6 | 10 | True | 0.251 | 912.6843 | 91.2684 | 592.0586 | 52179.8 | 603816 |
| synthetic | syn20k | d020000_synthetic_syn20k | MNIST | 20000 | 10 | 6 | 10 | True | 0.251 | 1825.2323 | 182.5232 | 1140.2383 | 52172.6 | 603744 |
| synthetic | syn50k | d050000_synthetic_syn50k | MNIST | 50000 | 10 | 6 | 10 | True | 0.251 | 4560.5413 | 456.0541 | 2731.2415 | 52166.6 | 603684 |
| synthetic | syn100k | d100000_synthetic_syn100k | MNIST | 100000 | 10 | 6 | 0 | nan | nan | 6408.8116 | 640.8812 | nan | nan | nan |

## synthetic cases


| dimension_group | case_label | case | model | model_dim_actual | clients | threshold | rounds_completed | accepted | final_accuracy | total_comm_MB | comm_MB_per_round | runtime_mean_start_experiment_total_wall | avg_finaltx_gas | total_gas |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| synthetic | syn1k | d001000_synthetic_syn1k | MNIST | 1000 | 10 | 6 | 10 | True | 0.251 | 92.0896 | 9.209 | 83.9021 | 52176.2 | 603756 |
| synthetic | syn5k | d005000_synthetic_syn5k | MNIST | 5000 | 10 | 6 | 10 | True | 0.251 | 457.6682 | 45.7668 | 311.0067 | 52176.2 | 603780 |
| synthetic | syn10k | d010000_synthetic_syn10k | MNIST | 10000 | 10 | 6 | 10 | True | 0.251 | 912.6843 | 91.2684 | 592.0586 | 52179.8 | 603816 |
| synthetic | syn20k | d020000_synthetic_syn20k | MNIST | 20000 | 10 | 6 | 10 | True | 0.251 | 1825.2323 | 182.5232 | 1140.2383 | 52172.6 | 603744 |
| synthetic | syn50k | d050000_synthetic_syn50k | MNIST | 50000 | 10 | 6 | 10 | True | 0.251 | 4560.5413 | 456.0541 | 2731.2415 | 52166.6 | 603684 |
| synthetic | syn100k | d100000_synthetic_syn100k | MNIST | 100000 | 10 | 6 | 0 | nan | nan | 6408.8116 | 640.8812 | nan | nan | nan |