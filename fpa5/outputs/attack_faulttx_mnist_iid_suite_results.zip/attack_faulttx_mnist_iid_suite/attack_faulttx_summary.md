# Attack Detection + KGC-only FaultTx Summary

- Scenarios: 13
- All scenarios passed: **True**
- FaultTx submitter: **KGC only**
- Mean FaultTx gas: 80542.00
- Mean FinalTx gas (scenario sums): 113022.40

| Scenario | Mode | Detected | Accepted | Fault type | Resolution | FaultTx | FinalTx | Fault isolation | Chain pass |
|---|---|---:|---:|---|---|---:|---:|---:|---:|
| normal | full_fl_v1 | False | True |  |  | 0 | 3 | True | True |
| omit_uploaded_client | full_fl_v1 | True | False | OMITTED_VALID_UPLOAD | ATTACK_CONFIRMED | 1 | 0 | True | True |
| tamper_aggregate | full_fl_v1 | True | False | AGGREGATE_INCONSISTENCY | REJECTED | 1 | 0 | True | True |
| wrong_model_publish | full_fl_v1 | True | False | MODEL_PUBLISH_INCONSISTENCY | REJECTED | 1 | 0 | True | True |
| fake_model_sync_resp | full_fl_v1 | True | False | MODEL_SYNC_INTEGRITY_FAILURE | REJECTED | 1 | 2 | True | True |
| forged_finaltx | full_fl_v1 | True | False | TRANSCRIPT_TAMPER | REJECTED | 1 | 3 | True | True |
| dropout_reconciliation_success | protocol_extension_crypto | True | True | SET_VIEW_MISMATCH | RECOVERED | 1 | 1 | True | True |
| dropout_reconciliation_failed | protocol_extension_crypto | True | False | RECONCILIATION_FAILED | ABORTED | 1 | 0 | True | True |
| ignore_kgc_dropout_set | protocol_extension_crypto | True | False | DROPOUT_SET_ATTACK | ATTACK_CONFIRMED | 1 | 0 | True | True |
| tamper_coordination_response | protocol_extension_crypto | True | False | COORDINATION_RESPONSE_TAMPER | REJECTED | 1 | 0 | True | True |
| tampered_decryption_share | protocol_extension_crypto | True | True | INVALID_DECRYPTION_SHARE | RECOVERED | 1 | 1 | True | True |
| wrong_signed_decryption_share | protocol_extension_crypto | True | False | DECRYPTION_RECOVERY_INCONSISTENCY | REJECTED | 1 | 0 | True | True |
| threshold_unreached | protocol_extension_crypto | True | False | THRESHOLD_UNREACHED | ABORTED | 1 | 0 | True | True |
