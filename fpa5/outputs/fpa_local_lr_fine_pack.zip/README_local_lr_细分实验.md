# 继续细分 local_lr 敏感性实验（0.20–0.25 区间）

本补丁包新增 4 组实验：

- local_lr = 0.21
- local_lr = 0.22
- local_lr = 0.23
- local_lr = 0.24

统一设置：

- dataset = Fashion-MNIST-Non-IID
- clients = 5
- threshold = 3
- rounds = 30
- server_lr = 1.0
- dropout = {}
- model = tiny_cnn
- device = cpu

## 使用

上传到服务器 `/root/fpa_local_lr_fine_pack.zip` 后执行：

```bash
cd /root/fpa5
unzip -o /root/fpa_local_lr_fine_pack.zip -d /root/fpa5
chmod +x run_local_lr_sensitivity_fine.sh

source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

python3 scripts/check_dataset_loader.py --configs configs/sensitivity_local_lr_0_21.yaml configs/sensitivity_local_lr_0_22.yaml configs/sensitivity_local_lr_0_23.yaml configs/sensitivity_local_lr_0_24.yaml
```

确认 FashionMNIST 加载无误后，运行：

```bash
tmux new -s localfine
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_local_lr_sensitivity_fine.sh
```

完成后下载：

```text
/root/local_lr_sensitivity_fine_results.zip
```
