#!/usr/bin/env bash
set -uo pipefail

cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

CONFIGS=(
  "configs/sensitivity_local_lr_0_21.yaml"
  "configs/sensitivity_local_lr_0_22.yaml"
  "configs/sensitivity_local_lr_0_23.yaml"
  "configs/sensitivity_local_lr_0_24.yaml"
)
NAMES=(
  "sensitivity_local_lr_0_21"
  "sensitivity_local_lr_0_22"
  "sensitivity_local_lr_0_23"
  "sensitivity_local_lr_0_24"
)

run_one() {
  local cfg="$1"
  local name="$2"
  echo "================================================================"
  echo "Running ${name}"
  echo "Config: ${cfg}"
  echo "Note: fine-grained local_lr sensitivity configs use Fashion-MNIST-Non-IID, 30 rounds, dropout: {}"
  echo "================================================================"

  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  pkill -f "run_kgc_server.py" || true
  pkill -f "run_cs_server.py" || true
  pkill -f "run_client_server.py" || true
  pkill -f "start_experiment.py" || true
  sleep 3

  rm -rf "outputs/${name}"

  echo "[INFO] Deploying contract for ${name}"
  npx hardhat run scripts/deploy.js --network localhost || { echo "[ERROR] deploy failed"; exit 1; }

  echo "[INFO] Starting entities for ${name}"
  python3 scripts/start_all_entities.py --config "${cfg}" --clients 5 || { echo "[ERROR] start_all_entities failed"; exit 1; }

  echo "[INFO] Starting experiment for ${name}"
  python3 scripts/start_experiment.py --config "${cfg}" || echo "[WARN] start_experiment returned non-zero; continue polling."

  local done_flag=0
  for i in $(seq 1 240); do
    if [ -f "outputs/${name}/verify_result.csv" ] && grep -q "True,30" "outputs/${name}/verify_result.csv"; then
      done_flag=1
      echo "[INFO] ${name} accepted=True rounds=30"
      break
    fi
    echo "---- $(date) ${name} status ----"
    tail -n 5 "outputs/${name}/metrics_round.csv" 2>/dev/null || echo "metrics not ready"
    cat "outputs/${name}/verify_result.csv" 2>/dev/null || echo "verify not ready"
    sleep 30
  done

  if [ "${done_flag}" -ne 1 ]; then
    echo "[ERROR] ${name} did not finish within polling window."
    exit 1
  fi

  python3 scripts/collect_results.py --config "${cfg}" || true
  python3 scripts/stop_all_entities.py --config "${cfg}" || true
  zip -r "/root/${name}_results.zip" "outputs/${name}"
  echo "[INFO] Result zip: /root/${name}_results.zip"
}

for idx in "${!CONFIGS[@]}"; do
  run_one "${CONFIGS[$idx]}" "${NAMES[$idx]}"
done

cd /root
zip -r /root/local_lr_sensitivity_fine_results.zip   /root/sensitivity_local_lr_0_21_results.zip   /root/sensitivity_local_lr_0_22_results.zip   /root/sensitivity_local_lr_0_23_results.zip   /root/sensitivity_local_lr_0_24_results.zip

echo "fine-grained local_lr sensitivity experiments finished: /root/local_lr_sensitivity_fine_results.zip"
