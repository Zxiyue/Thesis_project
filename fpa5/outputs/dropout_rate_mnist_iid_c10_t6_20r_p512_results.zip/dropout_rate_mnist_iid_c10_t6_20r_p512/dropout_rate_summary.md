# Dropout Rate Suite Summary

Base directory: `/root/fpa5/outputs/dropout_rate_mnist_iid_c10_t6_20r_p512`

| dropout_rate | dropout_count_per_round | online_count_per_round | threshold | accepted | status | rounds_completed | abort_round | final_acc | best_acc | total_comm_mb | model_sync_req_count | model_sync_verified_count | reason |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  | 0 | 10 | 6 | True | accepted | 20 |  | 0.9829 | 0.9839 | 121.63249969482422 | 0 | 0 | all rounds accepted |
|  | 1 | 9 | 6 | True | accepted | 20 |  | 0.9828 | 0.9837 | 114.6195011138916 | 19 | 19 | all rounds accepted |
|  | 2 | 8 | 6 | True | accepted | 20 |  | 0.9822 | 0.9822 | 103.40333366394043 | 19 | 19 | all rounds accepted |
|  | 3 | 7 | 6 | True | accepted | 20 |  | 0.9817 | 0.9817 | 92.19128704071045 | 19 | 19 | all rounds accepted |
|  | 4 | 6 | 6 | True | accepted | 20 |  | 0.9799 | 0.9799 | 80.87323093414307 | 19 | 19 | all rounds accepted |
|  | 5 | 5 | 6 | False | expected_abort | 0 | 1 | 0.1123 | 0.1123 | 0.0 | 0 | 0 | online clients 5 < threshold 6; planned_dropout=[1, 2, 3, 4, 5] |
