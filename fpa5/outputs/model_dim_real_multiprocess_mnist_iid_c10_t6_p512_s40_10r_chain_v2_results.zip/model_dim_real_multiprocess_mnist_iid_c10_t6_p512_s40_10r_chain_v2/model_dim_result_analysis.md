# Model Dimension Multiprocess Experiment Summary


Synthetic cases are dimension-only padded-vector workloads and should not be used for accuracy comparison.


## All cases


| dimension_group | case_label | case | model | model_dim_actual | clients | threshold | rounds_completed | accepted | final_accuracy | total_comm_MB | comm_MB_per_round | runtime_mean_start_experiment_total_wall | avg_finaltx_gas | total_gas |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| real | tiny | d006794_real_tiny | MNIST | 6794 | 10 | 6 | 10 | True | 0.9461 | 620.8604 | 62.086 | 448.7177 | 52173.8 | 603756 |
| real | logistic | d007850_real_logistic | MNIST | 7850 | 10 | 6 | 10 | True | 0.899 | 716.7575 | 71.6758 | 505.3433 | 52181 | 603804 |
| real | mlp | d012730_real_mlp | MNIST | 12730 | 10 | 6 | 10 | True | 0.9083 | 1161.7776 | 116.1778 | 759.2574 | 52175 | 603768 |
| real | small | d026666_real_small | MNIST | 26666 | 10 | 6 | 10 | True | 0.9596 | 2436.6859 | 243.6686 | 1604.7919 | 52175 | 603756 |
| real | largecnn | d080602_real_largecnn | MNIST | 80602 | 10 | 6 | 0 | nan | nan | 5177.4556 | 517.7456 | nan | nan | nan |

## real cases


| dimension_group | case_label | case | model | model_dim_actual | clients | threshold | rounds_completed | accepted | final_accuracy | total_comm_MB | comm_MB_per_round | runtime_mean_start_experiment_total_wall | avg_finaltx_gas | total_gas |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| real | tiny | d006794_real_tiny | MNIST | 6794 | 10 | 6 | 10 | True | 0.9461 | 620.8604 | 62.086 | 448.7177 | 52173.8 | 603756 |
| real | logistic | d007850_real_logistic | MNIST | 7850 | 10 | 6 | 10 | True | 0.899 | 716.7575 | 71.6758 | 505.3433 | 52181 | 603804 |
| real | mlp | d012730_real_mlp | MNIST | 12730 | 10 | 6 | 10 | True | 0.9083 | 1161.7776 | 116.1778 | 759.2574 | 52175 | 603768 |
| real | small | d026666_real_small | MNIST | 26666 | 10 | 6 | 10 | True | 0.9596 | 2436.6859 | 243.6686 | 1604.7919 | 52175 | 603756 |
| real | largecnn | d080602_real_largecnn | MNIST | 80602 | 10 | 6 | 0 | nan | nan | 5177.4556 | 517.7456 | nan | nan | nan |