#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import yaml
from torch.utils.data import Subset

from fl_audit.data import make_loaders
from fl_audit.model import get_vector, make_model


def unwrap(ds):
    while isinstance(ds, Subset):
        ds = ds.dataset
    return ds


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("configs", nargs="+", help="YAML configs to inspect")
    args = ap.parse_args()
    for cfg_path in args.configs:
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
        train_loaders, test_loader, parts = make_loaders(cfg)
        train_ds = unwrap(train_loaders[1].dataset)
        test_ds = unwrap(test_loader.dataset)
        model = make_model(cfg["model"]["name"])
        print("=" * 88)
        print("config:", cfg_path)
        print("baseline.scheme:", cfg.get("baseline", {}).get("scheme"))
        print("output_dir:", cfg.get("output_dir"))
        print("dataset.name:", cfg["dataset"].get("name"))
        print("actual train dataset class:", type(train_ds).__name__)
        print("actual test dataset class: ", type(test_ds).__name__)
        print("clients:", cfg["federated"].get("clients"))
        print("threshold:", cfg["federated"].get("threshold"))
        print("rounds:", cfg["federated"].get("rounds"))
        print("local_lr:", cfg["federated"].get("local_lr"))
        print("server_lr:", cfg["federated"].get("server_lr"))
        print("dropout:", cfg["federated"].get("dropout", {}))
        print("model:", cfg["model"].get("name"), "dim=", int(get_vector(model).numel()))
        print("client_1 samples:", len(train_loaders[1].dataset))
        print("test samples:    ", len(test_loader.dataset))
        print("partition clients:", sorted(parts.keys())[:10], "..." if len(parts) > 10 else "")


if __name__ == "__main__":
    main()
