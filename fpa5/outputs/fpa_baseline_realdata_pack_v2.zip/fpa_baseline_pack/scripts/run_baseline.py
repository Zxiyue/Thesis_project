#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import yaml

from fl_audit.baselines.priverifl_a_style import run_priverifl_a_style
from fl_audit.baselines.rtpfl_style import run_rtpfl_style


def load_cfg(path: str | Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if not isinstance(cfg, dict):
        raise ValueError(f"Invalid YAML config: {path}")
    return cfg


def main() -> None:
    ap = argparse.ArgumentParser(description="Run real-data baseline experiments.")
    ap.add_argument("--config", required=True, help="YAML config path")
    ap.add_argument("--scheme", default=None, choices=[None, "priverifl_a", "rtpfl"], help="Override baseline.scheme")
    args = ap.parse_args()

    cfg = load_cfg(args.config)
    scheme = args.scheme or str(cfg.get("baseline", {}).get("scheme", "")).lower()
    if scheme in {"priverifl-a", "priverifl_a", "priverifl_a_style", "baseline_priverifl_a"}:
        res = run_priverifl_a_style(cfg)
    elif scheme in {"rtpfl", "rtp-fl", "rtpfl_style", "baseline_rtpfl"}:
        res = run_rtpfl_style(cfg)
    else:
        raise ValueError(f"Unsupported baseline scheme: {scheme!r}. Use priverifl_a or rtpfl.")
    print(json.dumps(res, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
