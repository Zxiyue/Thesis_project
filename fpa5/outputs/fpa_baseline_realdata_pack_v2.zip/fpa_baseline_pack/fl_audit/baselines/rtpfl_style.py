from __future__ import annotations

import time
from typing import Any, Dict, List, Tuple

import numpy as np
import torch

from fl_audit.baselines.common import (
    CommRecorder,
    Runtime,
    active_clients_for_round,
    aggregate_cipher_vectors,
    make_client_keypairs,
    set_seed,
    train_and_quantize_update,
    update_global_model,
    write_common_outputs,
)
from fl_audit.crypto import paillier
from fl_audit.crypto.number import gen_prime
from fl_audit.crypto.signature import sign_obj, verify_obj
from fl_audit.crypto.shamir_recovery import split_secret, reconstruct
from fl_audit.data import make_loaders
from fl_audit.model import evaluate, get_vector, make_model, model_hash
from fl_audit.utils.codec import bytes32_hex


def _recover_private_key_from_shares(pub: paillier.PaillierPublicKey, share_items: List[Tuple[int, int]], field_prime: int) -> paillier.PaillierPrivateKey:
    lam = reconstruct(share_items, field_prime)
    mu = pow(paillier.L(pow(pub.g, lam, pub.n2), pub.n), -1, pub.n)
    return paillier.PaillierPrivateKey(lam=lam, mu=mu)


def run_rtpfl_style(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Run a real-data Reparable Threshold Paillier / RTP-FL-style baseline.

    Core mechanisms implemented:
      * real local training on torchvision dataset via make_loaders(cfg),
      * Paillier encrypted aggregation,
      * Shamir-shared Paillier lambda with threshold recovery,
      * ECDSA-signed uploads and signed decryption-share messages,
      * dropout tolerance when the active set still satisfies threshold.

    This baseline intentionally does not include Pedersen vector commitments,
    blockchain audit board, chained auditRoot, FinalTx, FraudProofTx, or model
    synchronization signatures; those are part of Ours-basic.
    """
    seed = int(cfg.get("seed", 42))
    set_seed(seed)
    out_dir = cfg.get("output_dir", "outputs/baseline_rtpfl")
    device = str(cfg.get("runtime", {}).get("device", "cpu"))
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    if device.startswith("cuda") and not torch.cuda.is_available():
        device = "cpu"

    timer = Runtime()
    comm = CommRecorder()
    metrics_rows: List[Dict[str, Any]] = []
    crypto_rows: List[Dict[str, Any]] = []
    baseline_rows: List[Dict[str, Any]] = []
    trace: Dict[str, Any] = {"scheme": "baseline_rtpfl_style", "rounds": []}

    model = make_model(cfg["model"]["name"])
    train_loaders, test_loader, _parts = make_loaders(cfg)
    clients = int(cfg["federated"]["clients"])
    threshold = int(cfg["federated"].get("threshold", max(1, clients // 2 + 1)))
    dim = int(get_vector(model).numel())

    with timer.record(0, "baseline_paillier_keygen", "Paillier key generation"):
        pkey = paillier.keygen(int(cfg.get("crypto", {}).get("paillier_bits", 512)))
    client_keys = make_client_keypairs(clients)
    share_field = gen_prime(max(pkey.private.lam.bit_length() + 32, 256))
    shares = split_secret(pkey.private.lam, clients, threshold, share_field)

    init_model_hash = model_hash(model)
    for cid in range(1, clients + 1):
        comm.add(0, "KGC", f"C{cid}", "InitModel", {"modelHash": init_model_hash, "dim": dim, "paillier_n": str(pkey.public.n), "threshold": threshold, "share": str(shares.shares[cid])})

    loss0, acc0 = evaluate(model, test_loader, device=device)
    metrics_rows.append({"round": 0, "test_loss": loss0, "test_accuracy": acc0, "effective_clients": 0, "dropout_clients": 0})

    accepted = True
    latest_root = bytes32_hex({"scheme": "baseline_rtpfl_style", "modelHash": init_model_hash})
    rounds_done = 0
    rounds = int(cfg["federated"]["rounds"])
    exp_t0 = time.perf_counter()

    for r in range(1, rounds + 1):
        r_t0 = time.perf_counter()
        active, dropped = active_clients_for_round(cfg, r)
        active_total_samples = sum(len(train_loaders[cid].dataset) for cid in active)
        model_hash_r = model_hash(model)
        encrypted_vectors: List[List[int]] = []
        local_losses: List[float] = []
        upload_signature_ok = True
        share_signature_ok = True

        # If active clients are below threshold, the RTP-style baseline must not output a model.
        enough_threshold = len(active) >= threshold
        if not enough_threshold:
            accepted = False
            baseline_rows.append({
                "round": r,
                "scheme": "RTP-FL-style",
                "accepted_so_far": False,
                "reason": "active clients below threshold",
                "effective_clients": len(active),
                "dropout_clients": len(dropped),
                "threshold": threshold,
                "round_wall_seconds": time.perf_counter() - r_t0,
            })
            trace["rounds"].append({"round": r, "active": active, "dropped": dropped, "threshold_ok": False})
            break

        for cid in active:
            x, local_loss, weight = train_and_quantize_update(model, train_loaders[cid], active_total_samples, cfg, timer, r, cid, device)
            local_losses.append(local_loss)
            with timer.record(r, "client_paillier_encrypt", "coordinate-wise Paillier encryption", cid=cid):
                c_vec = [paillier.encrypt(pkey.public, int(v)) for v in x.tolist()]
            receipt = {"scheme": "RTP-FL-style", "r": r, "i": cid, "modelHash": model_hash_r, "cHash": bytes32_hex(c_vec), "weight": weight}
            with timer.record(r, "client_receipt_sign", "sign encrypted upload", cid=cid):
                sig = sign_obj(client_keys[cid].private_key, receipt)
            comm.add(r, f"C{cid}", "Server", "UpMsg", {"Receipt": receipt, "sigUp": sig, "C": [str(v) for v in c_vec]})
            if not verify_obj(client_keys[cid].public_pem, sig, receipt):
                upload_signature_ok = False
            encrypted_vectors.append(c_vec)

        with timer.record(r, "server_paillier_aggregate", "homomorphic ciphertext aggregation"):
            c_agg = aggregate_cipher_vectors(pkey.public, encrypted_vectors)
        cagg_hash = bytes32_hex(c_agg)
        comm.add(r, "Server", "Clients", "AggMsg", {"r": r, "CaggHash": cagg_hash, "Cagg": [str(v) for v in c_agg], "threshold": threshold})

        # Signed Shamir decryption-share messages.  The current code models shares
        # of lambda, which is consistent with the existing Ours-basic experimental
        # implementation and is enough to measure threshold recovery overhead.
        valid_share_items: List[Tuple[int, int]] = []
        with timer.record(r, "client_decryption_share", "signed threshold Paillier share messages"):
            for cid in active:
                msg = {"r": r, "j": cid, "share": str(shares.shares[cid]), "caggHash": cagg_hash}
                sig = sign_obj(client_keys[cid].private_key, msg)
                comm.add(r, f"C{cid}", "Server", "ShareMsg", {"ShareMsg": msg, "sigShare": sig})
                if verify_obj(client_keys[cid].public_pem, sig, msg):
                    valid_share_items.append((cid, int(shares.shares[cid])))
                else:
                    share_signature_ok = False
                if len(valid_share_items) >= threshold:
                    break

        with timer.record(r, "server_threshold_recover", "reconstruct Paillier lambda from Shamir shares"):
            if len(valid_share_items) < threshold:
                accepted = False
                break
            recovered_priv = _recover_private_key_from_shares(pkey.public, valid_share_items[:threshold], share_field)

        with timer.record(r, "server_paillier_decrypt", "threshold-recovered Paillier decryption"):
            x_agg = np.array([paillier.decrypt(pkey.public, recovered_priv, int(c)) for c in c_agg], dtype=np.int64)

        accepted = bool(accepted and upload_signature_ok and share_signature_ok)
        with timer.record(r, "server_model_update", "apply aggregated update"):
            update_global_model(model, x_agg, cfg)
        with timer.record(r, "server_evaluate", "test evaluation"):
            test_loss, test_acc = evaluate(model, test_loader, device=device)

        model_hash_next = model_hash(model)
        latest_root = bytes32_hex({"prev": latest_root, "r": r, "modelHashR": model_hash_r, "modelHashNext": model_hash_next, "caggHash": cagg_hash, "thresholdShares": len(valid_share_items[:threshold])})
        rounds_done = r

        metrics_rows.append({"round": r, "test_loss": test_loss, "test_accuracy": test_acc, "effective_clients": len(active), "dropout_clients": len(dropped)})
        crypto_rows.extend([
            {"round": r, "metric": "model_dimension", "value": dim},
            {"round": r, "metric": "effective_clients", "value": len(active)},
            {"round": r, "metric": "dropout_clients", "value": len(dropped)},
            {"round": r, "metric": "threshold", "value": threshold},
            {"round": r, "metric": "paillier_encryptions", "value": len(active) * dim},
            {"round": r, "metric": "paillier_decryptions", "value": dim},
            {"round": r, "metric": "shamir_share_messages", "value": min(len(active), threshold)},
            {"round": r, "metric": "ecdsa_signatures", "value": len(active) + min(len(active), threshold)},
            {"round": r, "metric": "ecdsa_verifications", "value": len(active) + min(len(active), threshold)},
        ])
        baseline_rows.append({
            "round": r,
            "scheme": "RTP-FL-style",
            "upload_signature_ok": bool(upload_signature_ok),
            "share_signature_ok": bool(share_signature_ok),
            "threshold_ok": bool(enough_threshold),
            "accepted_so_far": bool(accepted),
            "effective_clients": len(active),
            "dropout_clients": len(dropped),
            "threshold": threshold,
            "used_shares": len(valid_share_items[:threshold]),
            "round_wall_seconds": time.perf_counter() - r_t0,
        })
        trace["rounds"].append({"round": r, "upload_signature_ok": upload_signature_ok, "share_signature_ok": share_signature_ok, "active": active, "dropped": dropped, "threshold_ok": enough_threshold, "used_shares": len(valid_share_items[:threshold]), "test_accuracy": test_acc, "test_loss": test_loss})
        if not accepted:
            break

    timer.add(0, "experiment_wall", time.perf_counter() - exp_t0, detail="total RTP-FL-style wall-clock time")
    write_common_outputs(
        out_dir,
        cfg=cfg,
        scheme_name="baseline_rtpfl_style",
        accepted=accepted,
        rounds_done=rounds_done,
        latest_root=latest_root,
        metrics_rows=metrics_rows,
        runtime=timer,
        comm=comm,
        crypto_rows=crypto_rows,
        trace=trace,
        blockchain_rows=[{"round": "N/A", "tx_type": "N/A", "gas_used": 0, "latency_sec": 0.0, "note": "RTP-FL-style baseline does not use blockchain audit board"}],
        baseline_rows=baseline_rows,
    )
    return {"accepted": accepted, "rounds": rounds_done, "output_dir": str(out_dir), "latestRoot": latest_root}
