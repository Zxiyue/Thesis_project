from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import torch

from fl_audit.baselines.common import (
    CommRecorder,
    HomomorphicLinearTag,
    Runtime,
    active_clients_for_round,
    aggregate_cipher_vectors,
    decrypt_vector,
    make_client_keypairs,
    set_seed,
    train_and_quantize_update,
    update_global_model,
    write_common_outputs,
)
from fl_audit.crypto import paillier
from fl_audit.crypto.signature import sign_obj, verify_obj
from fl_audit.data import make_loaders
from fl_audit.model import evaluate, get_vector, make_model, model_hash
from fl_audit.utils.codec import bytes32_hex


def run_priverifl_a_style(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Run a real-data PriVeriFL-A-style baseline.

    Core mechanisms implemented:
      * real local training on torchvision dataset via make_loaders(cfg),
      * coordinate-wise Paillier encrypted aggregation,
      * ECDSA-signed client upload receipts,
      * a linear homomorphic aggregation-verification tag.

    It intentionally does not implement the paper's full engineering stack or
    our audit board / Pedersen / auditRoot logic.  Use result names as
    "PriVeriFL-A-style", not as a complete original-paper reproduction.
    """
    seed = int(cfg.get("seed", 42))
    set_seed(seed)
    out_dir = cfg.get("output_dir", "outputs/baseline_priverifl_a")
    device = str(cfg.get("runtime", {}).get("device", "cpu"))
    if device == "auto":
        device = "cuda" if torch.cuda.is_available() else "cpu"
    if device.startswith("cuda") and not torch.cuda.is_available():
        device = "cpu"

    timer = Runtime()
    comm = CommRecorder()
    metrics_rows: List[Dict[str, Any]] = []
    crypto_rows: List[Dict[str, Any]] = []
    baseline_rows: List[Dict[str, Any]] = []
    trace: Dict[str, Any] = {"scheme": "baseline_priverifl_a_style", "rounds": []}

    model = make_model(cfg["model"]["name"])
    train_loaders, test_loader, _parts = make_loaders(cfg)
    clients = int(cfg["federated"]["clients"])
    total_samples = sum(len(loader.dataset) for loader in train_loaders.values())
    dim = int(get_vector(model).numel())

    with timer.record(0, "baseline_paillier_keygen", "Paillier key generation"):
        pkey = paillier.keygen(int(cfg.get("crypto", {}).get("paillier_bits", 512)))
    client_keys = make_client_keypairs(clients)
    tagger = HomomorphicLinearTag(dim=dim, seed=seed, prime_bits=int(cfg.get("baseline", {}).get("tag_prime_bits", 127)))

    # Init traffic approximation: public key and initial model broadcast.
    init_model_hash = model_hash(model)
    for cid in range(1, clients + 1):
        comm.add(0, "Server", f"C{cid}", "InitModel", {"modelHash": init_model_hash, "dim": dim, "paillier_n": str(pkey.public.n), "tagPrime": str(tagger.prime)})

    loss0, acc0 = evaluate(model, test_loader, device=device)
    metrics_rows.append({"round": 0, "test_loss": loss0, "test_accuracy": acc0, "effective_clients": 0, "dropout_clients": 0})

    accepted = True
    latest_root = bytes32_hex({"scheme": "baseline_priverifl_a_style", "modelHash": init_model_hash})
    rounds_done = 0
    rounds = int(cfg["federated"]["rounds"])
    exp_t0 = time.perf_counter()

    for r in range(1, rounds + 1):
        r_t0 = time.perf_counter()
        active, dropped = active_clients_for_round(cfg, r)
        active_total_samples = sum(len(train_loaders[cid].dataset) for cid in active)
        model_hash_r = model_hash(model)
        encrypted_vectors: List[List[int]] = []
        tags: List[int] = []
        local_losses: List[float] = []
        upload_receipts: List[Dict[str, Any]] = []
        signature_ok = True

        for cid in active:
            x, local_loss, weight = train_and_quantize_update(model, train_loaders[cid], active_total_samples, cfg, timer, r, cid, device)
            local_losses.append(local_loss)

            with timer.record(r, "client_paillier_encrypt", "coordinate-wise Paillier encryption", cid=cid):
                c_vec = [paillier.encrypt(pkey.public, int(v)) for v in x.tolist()]

            with timer.record(r, "client_homomorphic_tag", "linear aggregation-verification tag", cid=cid):
                tag = tagger.tag(x)

            receipt = {
                "scheme": "PriVeriFL-A-style",
                "r": r,
                "i": cid,
                "modelHash": model_hash_r,
                "cHash": bytes32_hex(c_vec),
                "tag": str(tag),
                "weight": weight,
            }
            with timer.record(r, "client_receipt_sign", "sign upload receipt", cid=cid):
                sig = sign_obj(client_keys[cid].private_key, receipt)

            upload = {"Receipt": receipt, "sigUp": sig, "C": c_vec, "tag": str(tag)}
            comm.add(r, f"C{cid}", "Server", "UpMsg", {"Receipt": receipt, "sigUp": sig, "C": [str(v) for v in c_vec], "tag": str(tag)})
            if not verify_obj(client_keys[cid].public_pem, sig, receipt):
                signature_ok = False
            encrypted_vectors.append(c_vec)
            tags.append(tag)
            upload_receipts.append(receipt)

        with timer.record(r, "server_paillier_aggregate", "homomorphic ciphertext aggregation"):
            c_agg = aggregate_cipher_vectors(pkey.public, encrypted_vectors)
        cagg_hash = bytes32_hex(c_agg)
        comm.add(r, "Server", "Verifier", "AggMsg", {"r": r, "CaggHash": cagg_hash, "Cagg": [str(v) for v in c_agg], "tags": [str(t) for t in tags]})

        with timer.record(r, "server_paillier_decrypt", "decrypt aggregated ciphertext vector"):
            x_agg = decrypt_vector(pkey.public, pkey.private, c_agg)

        with timer.record(r, "server_aggregation_verify", "verify aggregate tag and upload signatures"):
            expected_tag = tagger.add_tags(tags)
            observed_tag = tagger.tag(x_agg)
            tag_ok = (expected_tag == observed_tag)
            accepted = bool(accepted and signature_ok and tag_ok)

        with timer.record(r, "server_model_update", "apply aggregated update"):
            update_global_model(model, x_agg, cfg)
        with timer.record(r, "server_evaluate", "test evaluation"):
            test_loss, test_acc = evaluate(model, test_loader, device=device)

        model_hash_next = model_hash(model)
        latest_root = bytes32_hex({"prev": latest_root, "r": r, "modelHashR": model_hash_r, "modelHashNext": model_hash_next, "caggHash": cagg_hash, "tagOk": tag_ok})
        rounds_done = r

        metrics_rows.append({"round": r, "test_loss": test_loss, "test_accuracy": test_acc, "effective_clients": len(active), "dropout_clients": len(dropped)})
        crypto_rows.extend([
            {"round": r, "metric": "model_dimension", "value": dim},
            {"round": r, "metric": "effective_clients", "value": len(active)},
            {"round": r, "metric": "dropout_clients", "value": len(dropped)},
            {"round": r, "metric": "paillier_encryptions", "value": len(active) * dim},
            {"round": r, "metric": "paillier_decryptions", "value": dim},
            {"round": r, "metric": "ecdsa_signatures", "value": len(active)},
            {"round": r, "metric": "ecdsa_verifications", "value": len(active)},
            {"round": r, "metric": "homomorphic_tag_client_ops", "value": len(active)},
            {"round": r, "metric": "homomorphic_tag_verify_ops", "value": 1},
        ])
        baseline_rows.append({
            "round": r,
            "scheme": "PriVeriFL-A-style",
            "signature_ok": bool(signature_ok),
            "aggregation_tag_ok": bool(tag_ok),
            "accepted_so_far": bool(accepted),
            "effective_clients": len(active),
            "dropout_clients": len(dropped),
            "round_wall_seconds": time.perf_counter() - r_t0,
        })
        trace["rounds"].append({"round": r, "signature_ok": signature_ok, "tag_ok": tag_ok, "active": active, "dropped": dropped, "test_accuracy": test_acc, "test_loss": test_loss})
        if not accepted:
            break

    timer.add(0, "experiment_wall", time.perf_counter() - exp_t0, detail="total baseline wall-clock time")
    write_common_outputs(
        out_dir,
        cfg=cfg,
        scheme_name="baseline_priverifl_a_style",
        accepted=accepted,
        rounds_done=rounds_done,
        latest_root=latest_root,
        metrics_rows=metrics_rows,
        runtime=timer,
        comm=comm,
        crypto_rows=crypto_rows,
        trace=trace,
        blockchain_rows=[{"round": "N/A", "tx_type": "N/A", "gas_used": 0, "latency_sec": 0.0, "note": "PriVeriFL-A-style baseline does not use blockchain audit board"}],
        baseline_rows=baseline_rows,
    )
    return {"accepted": accepted, "rounds": rounds_done, "output_dir": str(out_dir), "latestRoot": latest_root}
