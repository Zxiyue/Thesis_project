#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

./run_priverifl_a_baselines.sh
./run_rtpfl_baselines.sh

cd /root
zip -r /root/baseline_all_results.zip \
  /root/priverifl_a_baseline_results.zip \
  /root/rtpfl_baseline_results.zip

echo "All baseline experiments finished. Download /root/baseline_all_results.zip"
