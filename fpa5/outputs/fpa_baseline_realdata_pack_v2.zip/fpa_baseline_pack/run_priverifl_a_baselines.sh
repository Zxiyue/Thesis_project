#!/usr/bin/env bash
set -euo pipefail
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

CONFIGS=(
  configs/baseline_priverifl_a_mnist_iid_50r.yaml
  configs/baseline_priverifl_a_mnist_noniid_50r.yaml
)

for cfg in "${CONFIGS[@]}"; do
  name=$(basename "$cfg" .yaml)
  echo "================================================================"
  echo "Running $name"
  echo "================================================================"
  rm -rf "outputs/$name"
  python3 scripts/run_baseline.py --config "$cfg"
  zip -r "/root/${name}_results.zip" "outputs/$name"
  echo "Saved /root/${name}_results.zip"
done

cd /root
zip -r /root/priverifl_a_baseline_results.zip \
  /root/baseline_priverifl_a_mnist_iid_50r_results.zip \
  /root/baseline_priverifl_a_mnist_noniid_50r_results.zip
