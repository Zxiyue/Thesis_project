# PriVeriFL-A-style 与 RTP-FL-style baseline 真实数据实验补丁

本补丁为 `/root/fpa5` 项目增加两个真实数据运行 baseline：

1. `PriVeriFL-A-style baseline`：真实本地训练 + Paillier/PHE 聚合 + ECDSA 上传签名 + 线性同态聚合验证标签。
2. `RTP-FL-style baseline`：真实本地训练 + Paillier/PHE 聚合 + Shamir 阈值恢复 Paillier lambda + 签名上传/签名份额 + 掉线阈值检查。

注意：这里是 `style baseline`，用于工程可比实验，不声称完整复现原论文所有协议细节和优化。

## 1. 安装补丁

把本压缩包上传到服务器，例如：

```bash
/root/fpa_baseline_pack.zip
```

解压覆盖到项目目录：

```bash
cd /root/fpa5
unzip -o /root/fpa_baseline_pack.zip -d /root/fpa5
chmod +x run_*baseline*.sh
```

## 2. 检查数据集和配置

```bash
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH

mkdir -p /root/fpa5/data
cp -rn /public/torchvision_datasets/MNIST /root/fpa5/data/ 2>/dev/null || true

python3 scripts/check_baseline_configs.py \
  configs/baseline_priverifl_a_mnist_iid_50r.yaml \
  configs/baseline_priverifl_a_mnist_noniid_50r.yaml \
  configs/baseline_rtpfl_mnist_iid_50r.yaml \
  configs/baseline_rtpfl_mnist_iid_dropout_50r.yaml
```

应看到实际数据集类为 `MNIST`，模型维度为 `tiny_cnn` 对应维度。

## 3. 运行 PriVeriFL-A-style baseline

```bash
tmux new -s priverifl
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_priverifl_a_baselines.sh
```

输出：

```text
/root/baseline_priverifl_a_mnist_iid_50r_results.zip
/root/baseline_priverifl_a_mnist_noniid_50r_results.zip
/root/priverifl_a_baseline_results.zip
```

## 4. 运行 RTP-FL-style baseline

```bash
tmux new -s rtpfl
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_rtpfl_baselines.sh
```

输出：

```text
/root/baseline_rtpfl_mnist_iid_50r_results.zip
/root/baseline_rtpfl_mnist_iid_dropout_50r_results.zip
/root/rtpfl_baseline_results.zip
```

## 5. 一次性运行全部 baseline

```bash
tmux new -s baselines
cd /root/fpa5
source .venv/bin/activate
export PYTHONPATH=/root/fpa5:$PYTHONPATH
./run_all_baselines.sh
```

最终输出：

```text
/root/baseline_all_results.zip
```

## 6. 与 Ours-basic 是否可以放在一起比较？

可以，但要分组比较，不能混淆变量。

### 可直接比较的组

PriVeriFL-A-style baseline 默认无掉线，所以建议与 Ours-basic 也补一组无掉线配置进行严格比较：

- `baseline_priverifl_a_mnist_iid_50r.yaml`
- `baseline_priverifl_a_mnist_noniid_50r.yaml`
- 对应 Ours-basic no-dropout 版本。

如果暂时没有 Ours-basic no-dropout，则可以与已完成 Ours-basic 50 轮主实验放在同一张总表，但要标注 Ours-basic 主实验含第 10、25 轮掉线。

### RTP-FL 掉线对比

`baseline_rtpfl_mnist_iid_dropout_50r.yaml` 含第 10、25 轮掉线，用于和 Ours-basic 的掉线场景比较。更严格的做法是补一个 Ours-basic 30 轮同配置掉线实验。

## 7. 输出文件说明

每个 baseline 输出目录包含：

```text
metrics_round.csv
verify_result.csv
runtime_cost.csv
crypto_cost.csv
communication_cost.csv
communication_network_only.csv
communication_summary_by_type.csv
blockchain_cost.csv
baseline_cost.csv
run_trace.json
summary_tables.xlsx
```

`blockchain_cost.csv` 对 baseline 标记为 N/A，因为这两个 baseline 不使用区块链公告板。论文中不要把 baseline 的 gas 与 Ours 的 gas 直接视为同类开销，而应说明 baseline 不提供区块链公告板和链式审计根。
