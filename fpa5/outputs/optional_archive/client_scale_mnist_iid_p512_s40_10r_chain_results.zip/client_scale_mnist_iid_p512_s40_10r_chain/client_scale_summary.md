# Client-scale experiment summary

clients,threshold,rounds_completed,accepted,final_acc_pct,total_comm_mb,comm_per_round_mb,avg_upload_wall_per_round_s,avg_final_tx_gas,min_final_tx_gas,max_final_tx_gas,paillier_encryptions_per_round,packing_cipher_count_per_client
5,3,10,True,98.2,31.481,3.148,57.743,52179.8,50453,67577,2835,567
10,6,10,True,97.79,60.721,6.072,145.141,52175.0,50453,67577,5670,567
20,12,10,True,96.73,119.124,11.912,233.287,52175.0,50441,67577,11340,567
40,24,10,True,94.98,236.45,23.645,430.367,52175.0,50453,67565,22680,567
60,36,10,True,91.55,353.142,35.314,633.255,52171.4,50429,67541,34020,567
80,48,10,True,85.29,470.127,47.013,805.8,52179.8,50453,67577,45360,567
100,60,10,True,74.13,587.01,58.701,978.588,52172.6,50441,67565,56700,567


Notes: Paillier is 512-bit functional setting; use this experiment for scalability trends. Blockchain is enabled and records InitTx/FinalTx gas for the fixed-format audit-board declaration.
